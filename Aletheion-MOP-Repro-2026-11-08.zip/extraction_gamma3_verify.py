"""Standalone exact gamma3 finite bridge, with no historical energy inputs.

Python3 standard library only. Uniform hub/path-forest bounds are proved in
gamma_section.tex. Integers certify all allocations; this is not a graph sample.
"""
if not __debug__:
    raise RuntimeError('Assertions must remain enabled; do not use python -O')
from pathlib import Path
from fractions import Fraction as Q
from math import isqrt,comb
from itertools import product
import json,time,hashlib
P=Path(__file__).resolve().parent;D=10**5;SCALE=10**10
def energy(q,p):
    assert q>=p>=1;m=q-p
    if not m:return q*SCALE
    bounds=[]
    for s in range(1,min(p,m)+1):
        ell=m-s+2;cap={1:Q(0),2:Q(1),3:Q(2),4:Q(8,3),5:Q(3)}.get(ell,Q(4)-Q(16,(ell+1)**2));loss=min(cap,Q(8*m-4*s,q)-Q(4*m*m,q*q));rad=Q(isqrt((q**3+m*m)*D*D),D)
        bounds.append(Q(q+m)-loss+Q(2*m*m,q*q)+Q(2*m,q*q)*rad)
    exact=max(Q(q),min(bounds));return exact.numerator*SCALE//exact.denominator
def main():
    start=time.monotonic();table={(q,p):energy(q,p)for q in range(1,100)for p in range(1,min(q,5)+1)};minimum=None;witness=None;count=0;byorder={}
    for n in range(72,105):
        total=n-3;cases=0
        for p1,p2,p3 in product(range(1,6),repeat=3):
            if p1+p2+p3>7:continue
            for q1 in range(p1,total-p2-p3+1):
                x=table[q1,p1]
                for q2 in range(p2,total-q1-p3+1):
                    q3=total-q1-q2;gap=x+table[q2,p2]+table[q3,p3]-2*n*SCALE;assert gap>=0,(n,q1,q2,q3,p1,p2,p3,gap);cases+=1
                    if minimum is None or gap<minimum:minimum=gap;witness=dict(n=n,q=[q1,q2,q3],p=[p1,p2,p3])
        expected=sum(comb(t-1,2)*comb(n-1-t,2)for t in range(3,8));assert cases==expected;byorder[n]=cases;count+=cases
    assert count==3795253 and minimum>0
    out=dict(status='PASS_STANDALONE_GAMMA3_COMPLETE72_TO104_UNIFORM_COMPRESSION_INTEGER_BRIDGE',allocations=count,byorder=byorder,scaled_minimum=minimum,scale=SCALE,minimum_lower=str(Q(minimum,SCALE)),witness=witness,root_lower_scale=D,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='Every positive q_i>=p_i, sumq=n-3,sump<=7; exact stated scalar inequality proof only, not a graph sample or whole global proof',seconds=time.monotonic()-start);(P/'extraction_gamma3_verify.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
