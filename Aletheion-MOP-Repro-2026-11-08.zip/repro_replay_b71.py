"""One fresh B71 replay, not an acceptance of supplied result/PASS files."""
if not __debug__:
    raise RuntimeError('Assertions must remain enabled; do not use python -O')
from pathlib import Path
import argparse,subprocess,sys,time,json,hashlib
ROOT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def integrity():
    v=json.loads((ROOT/'REPRO_MEMBERS.json').read_bytes())
    for r in v['members']:
        rel=Path(r['relative']);assert not rel.is_absolute()and'..'not in rel.parts
        p=ROOT/rel;assert p.stat().st_size==r['bytes']and sha(p)==r['sha256'],rel
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);a=parser.parse_args();a.output=a.output.resolve()
    if a.output.exists():raise RuntimeError('Fresh replay requires a new, nonexistent output directory')
    integrity();a.output.mkdir(parents=True);start=time.monotonic();runs=[];driver=ROOT/'repro_verify_finite.py';sourcehash=sha(driver)
    for mode in ['quick','positive','masked','assemble']:
        command=[sys.executable,'-B','-X','utf8',str(driver),mode,'--output',str(a.output)];step=time.monotonic()
        with(a.output/(mode+'.stdout.txt')).open('w',encoding='utf8')as out,(a.output/(mode+'.stderr.txt')).open('w',encoding='utf8')as err:
            p=subprocess.Popen(command,stdout=out,stderr=err)
            code=p.wait()
        row=dict(mode=mode,command=command,pid=p.pid,exit_code=code,seconds=time.monotonic()-step);runs.append(row);(a.output/'replay_processes.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(row),flush=True)
        if code:raise RuntimeError('Fresh replay stage failed: '+mode)
        if sha(driver)!=sourcehash:raise RuntimeError('Stage driver source changed during fresh replay')
    integrity();v=json.loads((a.output/'finite_assembly.json').read_bytes());assert v['mode']=='CHECKED_B71_FROM_FRESH_STANDALONE_MATH_INPUTS'and v['high_degree_parameter_rows']==11885 and v['positive328_used']==328 and v['masked130_used']==130
    result=dict(mode='FRESH_B71_ENTIRE_MATHEMATICAL_RECIPE_COMPLETED',runs=runs,seconds=time.monotonic()-start,driver_sha256=sourcehash,initial_directory_was_nonexistent=True,prior_math_result_files_or_native_PASSs_accepted=False,scope='Full finite arithmetic recipe; written reduction lemmas and published inputs retain their stated mathematical obligations.')
    (a.output/'fresh_B71_receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
if __name__=='__main__':main()
