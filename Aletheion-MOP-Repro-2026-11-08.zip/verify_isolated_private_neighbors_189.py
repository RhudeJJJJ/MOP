"""Small complete controls plus an actual high-degree residue carrier."""
from pathlib import Path
from itertools import combinations
from fractions import Fraction as F
import json,csv
from verify_dominating_set_core_186 import polygon,adjacency
from verify_component_chord_deficit_189 import check
ROOT=Path(__file__).resolve().parent

def main():
    count=0;isolated=0;rows=[]
    for n in range(3,10):
        number=0
        for E in polygon(tuple(range(n))):
            A=adjacency(range(n),E)
            for h in range(1,n+1):
                choices=[set(T) for T in combinations(range(n),h)
                         if set(T)|set().union(*(A[v] for v in T))==set(range(n))]
                if choices:break
            H=max(choices,key=lambda S:(sum(len(A[v]&S) for v in S)//2,sum(len(A[v]) for v in S)))
            for u in H:
                private={v for v in set(range(n))-H if A[v]&H=={u}}
                assert private
                if not A[u]&H:assert len(private)>=2;isolated+=1
            count+=1;number+=1
        rows.append({'n':n,'graphs':number})
    E={tuple(sorted(map(int,r))) for r in csv.reader((ROOT/'degree100-unseen-hubs-176-edges.csv').open())}
    outer=list(map(int,next(csv.reader((ROOT/'degree100-unseen-hubs-176-outer.csv').open()))))
    # Check component/rank identity in the stored actual cyclic ordering by
    # relabeling to the sequential-polygon convention used in the reader.
    rename={v:i for i,v in enumerate(outer)}
    relabeled={tuple(sorted((rename[a],rename[b]))) for a,b in E}
    A=adjacency(range(len(outer)),relabeled);H={u for u in A if len(A[u])>=37}
    assert len(H)==2 and all(len(A[u])==100 for u in H)
    b,c,z,k=check(list(range(len(outer))),relabeled,H)
    assert z==11
    triangles=sum(a in H and d in H for a,d in relabeled)-len(H)+b
    payment=F(10*len(H))+F(21,5)+F(3*triangles,2)-2*z
    assert payment==F(11,5)>0
    out={'status':'PASS_ISOLATED_PRIVATE_CONTROLS_AND_HIGH_HUB_RESIDUE',
      'graphs':count,'isolated_selected_vertices':isolated,'rows':rows,
      'carrier':{'n':len(outer),'b':b,'c':c,'z':z,'kappa':k,'H':sorted(H),'payment':str(payment)},
      'scope':'Finite normalization controls and one actual high-degree carrier; universal lemma has a separate written proof',
      'original':'GLOBAL OPEN'}
    (ROOT/'isolated-private-189-controls.json').write_text(json.dumps(out,indent=2)+'\n')
    print({k:v for k,v in out.items() if k!='rows'},flush=True)
if __name__=='__main__':main()
