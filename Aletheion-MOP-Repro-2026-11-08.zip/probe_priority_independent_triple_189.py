"""Assign all neighbors to a maximum-original-degree independent hub first."""
from pathlib import Path
from fractions import Fraction as F
import json
from probe_connected_triple_payment_188 import bound
ROOT=Path(__file__).resolve().parent

def main():
    cell={(q,p):bound(q,p) for q in range(1,135) for p in range(1,min(q,7)+1)}
    capped={(q,l):min(cell[q,p] for p in range(1,min(q,1+l)+1))
            for q in range(2,135) for l in range(7)}
    rows=[];checks=0
    for n in range(72,138):
        Q=n-3;best=None;arg=None
        for a in range(4,Q-3):
            for b in range(2,Q-a-1):
                c=Q-a-b
                if c<2 or max(b,c)>a:continue
                for lb in range(max(0,4-b),min(6,a-b)+1):
                    for lc in range(max(0,4-c),min(6-lb,a-c)+1):
                        v=cell[a,1]+capped[b,lb]+capped[c,lc]-2*n;checks+=1
                        if best is None or v<best:best=v;arg=(a,b,c,lb,lc)
        assert best is not None
        rows.append({'n':n,'margin':str(best),'q0_q1_q2_lost1_lost2':arg})
    out={'status':'EXACT_PRIORITY_INDEPENDENT_TRIPLE_SUFFICIENT_SCREEN',
      'rows':rows,'allocation_cases':checks,'unpaid_orders':[r['n'] for r in rows if F(r['margin'])<=0],
      'original':'GLOBAL OPEN','scope':'Maximum-original-degree priority assignment, no actual graph counterexample'}
    (ROOT/'priority-independent-triple-189-screen.json').write_text(json.dumps(out,indent=2)+'\n')
    print('PRIORITY_INDEPENDENT_UNPAID',out['unpaid_orders'],checks,flush=True)
    print('FIRST',rows[0],flush=True)
if __name__=='__main__':main()
