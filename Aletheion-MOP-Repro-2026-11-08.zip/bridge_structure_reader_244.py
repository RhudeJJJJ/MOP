"""Independent four-hub catalogue and outerplane/candidate coverage reader."""
from itertools import combinations,permutations,product
from bisect import bisect_left
import numpy as np
S2=65536

def components(V,E):
    left=set(V);out=[]
    while left:
        todo=[left.pop()];part=set(todo)
        while todo:
            v=todo.pop()
            for a,b in E:
                w=b if a==v else a if b==v else None
                if w in left:left.remove(w);part.add(w);todo.append(w)
        out.append(part)
    return out

def outerplane(V,E):
    V=set(V);E={tuple(sorted(e)) for e in E if set(e)<=V}
    if len(V)<=2:return True
    cs=components(V,E)
    if len(cs)>1:return all(outerplane(C,E) for C in cs)
    for v in sorted(V):
        cs=components(V-{v},E)
        if len(cs)>1:return all(outerplane(C|{v},E) for C in cs)
    # A2connected outerplane graph must have a Hamiltonian outer cycle.
    # Enumerate ALL edge-respecting cycles, then test every pair of chords.
    start=min(V);A={v:{b if a==v else a for a,b in E if v in(a,b)} for v in V};found=False
    def visit(path,left):
        nonlocal found
        if found:return
        if not left:
            if start not in A[path[-1]] or path[1]>path[-1]:return
            pos={v:i for i,v in enumerate(path)};chords=[];n=len(path)
            for u,v in E:
                a,b=sorted((pos[u],pos[v]))
                if b-a not in(1,n-1):chords.append((a,b))
            if all(not(a<c<b<d or c<a<d<b) for j,(a,b) in enumerate(chords) for c,d in chords[j+1:]):found=True
            return
        for v in sorted(A[path[-1]]&left):visit(path+[v],left-{v})
    visit([start],V-{start});return found

def core_catalogue():
    pairs=list(combinations(range(4),2));seen={}
    for bits in range(64):
        E={pairs[j] for j in range(6) if bits>>j&1}
        if len(E)==6 or (len(E)==4 and all(sum(v in e for e in E)==2 for v in range(4))):continue
        key=min(tuple(sorted(tuple(sorted((p[a],p[b]))) for a,b in E)) for p in permutations(range(4)))
        seen[key]=dict(edges=key,t3=sum(all(tuple(sorted(e)) in set(key) for e in combinations(T,2)) for T in combinations(range(4),3)))
    return sorted(seen.values(),key=lambda x:(len(x['edges']),x['edges']))

def shared_catalogue(core):
    E=set(core['edges']);A=[{v for v in range(4) if tuple(sorted((u,v))) in E} for u in range(4)];cs=components(range(4),E);pair=list(combinations(range(4),2));upper=[2-len(A[u]&A[v]) for u,v in pair];lower=[max(0,1-len(A[u]&A[v])) if v in A[u] else 0 for u,v in pair];types=[]
    for mask in range(1,16):
        T={i for i in range(4) if mask>>i&1}
        if len(T)<2:continue
        es={e for e in E if set(e)<=T};cp=components(T,es)
        if len(es)!=len(T)-len(cp) or any(sum(v in e for e in es)>2 for v in T):continue
        if any(len(components(C&T,es))>1 for C in cs if C&T):continue
        incidence=[int(u in T and v in T) for u,v in pair]
        if any(x>y for x,y in zip(incidence,upper)):continue
        types.append((mask,T,len(T)-1,len(cp)-1,incidence))
    accepted=set();completed=0
    def enumerate_counts(i,trace,dupe,sigma,pc):
        nonlocal completed
        if i==len(types):
            if any(x<y for x,y in zip(pc,lower)):return
            completed+=1;G=set(E);N=4+len(trace)
            for v,mask in enumerate(trace,4):G.update((u,v) for u in range(4) if mask>>u&1)
            for u,w in pair:
                if w in A[u]:continue
                common=[v for v,m in enumerate(trace,4) if m>>u&1 and m>>w&1]
                if len(common)==2:G.add(tuple(common))
            if outerplane(range(N),G):accepted.add(tuple(trace))
            return
        mask,T,d,s,inc=types[i];maxcopies=min((6-core['t3']-dupe)//d,min((lim-x)//y for x,y,lim in zip(pc,inc,upper) if y))
        for number in range(maxcopies+1):
            if sigma+number*s>2*len(cs)-2:continue
            enumerate_counts(i+1,trace+[mask]*number,dupe+number*d,sigma+number*s,[x+number*y for x,y in zip(pc,inc)])
    enumerate_counts(0,[],0,0,[0]*6)
    return A,cs,accepted,completed

def choices(E,masks):
    A=[{v for v in range(4) if tuple(sorted((u,v))) in E} for u in range(4)];cs=components(range(4),E);cid={v:j for j,C in enumerate(cs) for v in C};T=[{i for i in range(4) if m>>i&1} for m in masks];degrees=[[len(A[i]&t) for i in range(4)] for t in T];eligible=[sorted({i for i in t if not ds[i]} or t) for t,ds in zip(T,degrees)];a=list(map(len,A));tau=[sum(w in A[v] for v,w in combinations(A[i],2)) for i in range(4)];out=[]
    for owner in product(*eligible):
        s=[owner.count(i) for i in range(4)];X=[sum(i in t and j!=i for t,j in zip(T,owner)) for i in range(4)];C=[sum(ds[i] for ds,j in zip(degrees,owner) if j==i) for i in range(4)];cuts=[{j for t,ds,j in zip(T,degrees,owner) if i in t and j!=i and cid[i]!=cid[j] and not ds[i]} for i in range(4)];r=[a[i]-tau[i] for i in range(4)];lo=[max(1,C[i]-r[i]+1,C[i]-s[i]+1,(C[i]+1)//2) for i in range(4)];hi=[min(X[i]+1-r[i]+C[i],1+r[i]+len(cuts[i])) for i in range(4)]
        if all(x<=y for x,y in zip(lo,hi)):out.append(dict(owners=owner,s=s,pmin=lo,pmax=hi))
    return A,T,degrees,a,[sum(i in t for t in T) for i in range(4)],out

def path_caps(E,T,ds,owner,a):
    A=[{v for v in range(4) if tuple(sorted((u,v))) in E} for u in range(4)];forced=set()
    for i,j in combinations(range(4),2):
        if j in A[i]:continue
        hit=[v for v,t in enumerate(T) if i in t and j in t]
        if len(hit)==2:forced.add(tuple(hit))
    internal=[sum(owner[v]==owner[w]==i for v,w in forced) for i in range(4)];cut=[];ho=np.zeros((4,4),np.int64);oo=ho.copy()
    for t,j in zip(T,owner):
        for i in t-{j}:ho[i,j]+=1
    for v,w in forced:
        i,j=owner[v],owner[w]
        if i!=j:oo[i,j]+=1;oo[j,i]+=1
    for i in range(4):
        lost={v for v,t in enumerate(T) if i in t and owner[v]!=i};hh=sum(j in A[k] for k,j in combinations(A[i],2));h_o=sum(ds[v][i] for v in lost);o_o=sum(v in lost and w in lost for v,w in forced);cut.append(1+a[i]+len(lost)-hh-h_o-o_o)
    return internal,cut,ho,oo

def domain_candidates(E,masks,ch,tab,t3):
    A,T,ds,a,shared,_=choices(E,masks);inside,cut,_,_=path_caps(E,T,ds,ch['owners'],a);Nmin=68-len(masks);Nmax=155-len(masks);lists=[]
    for i in range(4):
        low=max(2 if not a[i] else 1,4-a[i]-shared[i]);xs=[]
        for k in range(low,Nmax+1):
            q=k+ch['s'][i];pmax=min(q,ch['pmax'][i],7-t3,q-inside[i],cut[i]);pmin=ch['pmin'][i]
            if pmin<=pmax:xs.append((k,int(tab[q,pmin,pmax])-2*(q+1)*S2))
        if not xs:return np.empty((0,4),np.uint8)
        lists.append(xs)
    left=[(ka,kb,ca+cb) for ka,ca in lists[0] for kb,cb in lists[1]];right=sorted(((ka,kb,ca+cb) for ka,ca in lists[2] for kb,cb in lists[3]),key=lambda x:x[2]);costs=[x[2] for x in right];sums=np.array([x[0]+x[1] for x in right]);out=[]
    for a,b,cost in left:
        limit=bisect_left(costs,-cost)
        if not limit:continue
        indices=np.flatnonzero((sums[:limit]>=Nmin-a-b)&(sums[:limit]<=Nmax-a-b))
        out.extend((a,b,right[j][0],right[j][1]) for j in indices)
    assert len(out)==len(set(out));return np.array(sorted(out),np.uint8).reshape((-1,4))
