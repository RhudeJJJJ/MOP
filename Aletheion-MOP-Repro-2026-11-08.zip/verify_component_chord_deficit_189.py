"""Exact full-family calibration for written arbitrary-H component deficit."""
from pathlib import Path
from itertools import combinations
import json,hashlib
from verify_dominating_set_core_186 import polygon,adjacency,edge
ROOT=Path(__file__).resolve().parent

def components(V,A):
    unseen=set(V);parts=[]
    while unseen:
        todo=[unseen.pop()];part=set(todo)
        while todo:
            for w in A[todo.pop()]&unseen:
                unseen.remove(w);part.add(w);todo.append(w)
        parts.append(part)
    return parts

def check(B,E,H):
    A=adjacency(B,E);O=set(B)-H;parts=components(H,A);b=len(parts)
    ids={v:i for i,part in enumerate(parts) for v in part}
    boundary={edge(v,(v+1)%len(B)) for v in B}
    c=sum(a in O and d in O and (a,d) not in boundary for a,d in E)
    z=sum(not A[v]&H for v in O);F={('H',i):set() for i in range(b)};sigma=0
    for v in O:
        N=A[v]&H
        if not N:continue
        induced=components(N,A);seen={ids[u] for u in N}
        assert len(induced)==len(seen) # Chordal connected-intersection lemma.
        for part in parts:
            hit=part&N
            if hit:assert len(components(hit,A))==1
        key=('O',v);F[key]={('H',i) for i in seen}
        for h in F[key]:F[h].add(key)
        sigma+=len(seen)-1
    kappa=len(components(set(F),F));edgesF=sum(map(len,F.values()))//2
    faces=edgesF-len(F)+kappa
    assert sigma==3*b-3-c+z==b-kappa+faces
    assert 0<=faces<=b-kappa
    assert c-z>=b+2*kappa-3>=b-1
    # Dominating case: the original176 total-path cap improves independently
    # of selected degrees, before importing any old local energy bound.
    if not z:
        eh=sum(a in H and d in H for a,d in E)
        t3=eh-len(H)+b
        assert t3>=0
        assert 4*len(H)-3-eh-c<=3*len(H)-2-t3
    return b,c,z,kappa

def main():
    rows=[];checks=0;tight=None;prior=json.loads((ROOT/'dominating-set-core-186-verification.json').read_text())
    for n in range(3,10):
        G=sorted(polygon(tuple(range(n))),key=lambda E:sorted(E));count=0
        digest=hashlib.sha256(json.dumps([sorted(E) for E in G],separators=(',',':')).encode()).hexdigest()
        assert digest==prior['coverage'][n-3]['family_sha256']
        for E in G:
            B=list(range(n))
            for h in range(1,n+1):
                for T in combinations(B,h):
                    H=set(T);b,c,z,k=check(B,E,H);count+=1
                    if tight is None and b==3 and z==0 and c==2:
                        tight={'n':n,'edges':sorted(E),'H':sorted(H),'b':b,'c':c,'z':z,'kappa':k}
        checks+=count;rows.append({'n':n,'graphs':len(G),'selected_sets':count,'family_sha256':digest})
        print('COMPONENT_DEFICIT_CONTROL',n,len(G),count,flush=True)
    assert tight is not None
    # Strictly stronger c-z>=b is false: retain a real maximal-outerplanar
    # tight carrier instead of claiming the new lemma can be strengthened.
    assert tight['c']-tight['z']==tight['b']-1<tight['b']
    out={'status':'PASS_COMPONENT_CHORD_DEFICIT_FULL_FINITE_CONTROLS',
      'rows':rows,'selected_sets':checks,'tight_independent_triple':tight,
      'stronger_b_bound_refuted_by_actual_carrier':True,
      'original':'GLOBAL OPEN','scope':'Finite calibration of written all-order minor/face proof; not finite extrapolation'}
    (ROOT/'component-chord-deficit-189-controls.json').write_text(json.dumps(out,indent=2)+'\n')
    print('PASS_COMPONENT_CHORD_DEFICIT189',checks,tight,flush=True)
if __name__=='__main__':main()
