"""Exact three-type shared-neighbor ledger for one edge and one isolated hub."""
from pathlib import Path
from fractions import Fraction as F
import json
from probe_connected_triple_payment_188 import bound
ROOT=Path(__file__).resolve().parent

def main():
    cells={(q,phi):min(bound(q,p) for p in range(1,min(q,phi)+1))
           for q in range(1,118) for phi in range(1,6)}
    rows=[];checks=0;profiles=[]
    for eg in range(2):
        for c in range(4):
            rank=3-c;hh=2-eg
            for beta in range(min(rank,hh)+1):
                alpha=hh-beta
                for ga in range(rank-beta+1):
                    gb=rank-beta-ga
                    profiles.append((eg,c,beta,alpha,ga,gb))
    for n in range(72,121):
        Q=n-3
        for first in ('isolated','endpoint'):
            best=None;arg=None
            for eg,c,beta,alpha,ga,gb in profiles:
                if first=='isolated':
                    lost=(ga+beta,gb+beta+alpha,0);phi=(2+ga,2+gb,1)
                else:
                    lost=(beta,alpha+beta+gb,ga);phi=(2,2+gb,1+ga)
                assert sum(lost)==5-eg-c
                for qa in range(1,Q-2):
                    if qa+1+lost[0]<4:continue
                    for qb in range(1,Q-qa-1):
                        qu=Q-qa-qb
                        if qu<2 or qb+1+lost[1]<4 or qu+lost[2]<4:continue
                        d=(qa+1+lost[0],qb+1+lost[1],qu+lost[2])
                        if first=='isolated' and (d[2]<max(d[:2]) or d[0]<d[1]):continue
                        if first=='endpoint' and d[0]<max(d[1:]):continue
                        margin=cells[qa,phi[0]]+cells[qb,phi[1]]+cells[qu,phi[2]]-2*n;checks+=1
                        if best is None or margin<best:
                            best=margin;arg={'q':(qa,qb,qu),'phi':phi,'lost':lost,'profile':(eg,c,beta,alpha,ga,gb),'degrees':d}
            assert best is not None
            rows.append({'n':n,'first':first,'margin':str(best),'arg':arg})
    out={'status':'EXACT_PRIORITY_EDGE_ISOLATE_SUFFICIENT_SCREEN',
      'profiles':profiles,'rows':rows,'allocation_cases':checks,
      'unpaid_rows':[r for r in rows if F(r['margin'])<=0],
      'original':'GLOBAL OPEN','scope':'Exact rank/HH-face sharing ledger and valid singleton-priority assignment'}
    (ROOT/'priority-edge-isolate-189-screen.json').write_text(json.dumps(out,indent=2)+'\n')
    print('PRIORITY_EDGE_ISOLATE_UNPAID',out['unpaid_rows'],checks,flush=True)
    print('FIRST',rows[:2],flush=True)
if __name__=='__main__':main()
