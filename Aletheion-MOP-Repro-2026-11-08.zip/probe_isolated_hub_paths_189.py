"""Tighter original-block allocation by isolation/private-neighbor geometry."""
from pathlib import Path
from fractions import Fraction as F
import json
from probe_connected_triple_payment_188 import bound
ROOT=Path(__file__).resolve().parent

def solve(specs,excess,capQ=134):
    D={(0,0):(F(0),[])};transitions=0
    for minimum,phi in specs:
        cells={}
        for q in range(minimum,capQ+1):
            for p in range(1,min(q,phi+excess)+1):
                loss=max(0,p-phi);key=(q,loss);value=bound(q,p)
                if key not in cells or value<cells[key][0]:cells[key]=(value,p)
        new={}
        for (Q,L),(prior,trace) in D.items():
            for (q,ell),(value,p) in cells.items():
                if Q+q>capQ or L+ell>excess:continue
                key=(Q+q,L+ell);candidate=prior+value;transitions+=1
                if key not in new or candidate<new[key][0]:new[key]=(candidate,trace+[(q,p)])
        D=new
    return D,transitions

def main():
    rows=[];tot=0;tails={}
    for e,specs,E in ((0,[(2,1)]*3,6),(1,[(1,2),(1,2),(2,1)],3)):
        D,transitions=solve(specs,E);tot+=transitions
        for n in range(8,138):
            states=[value for (Q,L),value in D.items() if Q==n-3]
            if not states:continue
            value,trace=min(states,key=lambda v:v[0])
            rows.append({'n':n,'e_H':e,'budget':E,'margin':str(value-2*n),'blocks_q_p':trace})
        unpaid=[r['n'] for r in rows if r['e_H']==e and F(r['margin'])<=0]
        tails[str(e)]=max(unpaid)+1 if unpaid else 8
        print('EXACT_ISOLATED_HUB_TAIL',e,tails[str(e)],transitions,flush=True)
    out={'status':'EXACT_ISOLATED_HUB_SUFFICIENT_ALLOCATION_SCREEN',
      'rows':rows,'tails_within_screen':tails,'transitions':tot,
      'original':'GLOBAL OPEN','scope':'Tightened universal parameter relaxation; no actual original counterexample'}
    (ROOT/'isolated-hub-paths-189-screen.json').write_text(json.dumps(out,indent=2)+'\n')
    print('N72',[r for r in rows if r['n']==72],flush=True)

if __name__=='__main__':main()
