"""Fresh finite mathematical computations, independent of native PASS receipts.

Stored target tables specify the finite domains; their supplied extrema are
checked against freshly computed integer DP maxima. They are not accepted
as proof merely because a historical status string says PASS.
"""
if not __debug__:
    raise RuntimeError('Assertions must remain enabled; do not use python -O')

from pathlib import Path
from fractions import Fraction as F
import argparse,json,sys,hashlib,time,subprocess,importlib.util,difflib,shutil
ROOT=Path(__file__).resolve().parent;W=ROOT/'work'
def rd(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def payment(t,M):
    d,k,l=t['d'],t['k'],t['l'];n=d+k;m=d-1+2*k;mu2,mu3,mu4=2*m,6*k,2*M-2*m+8*(k-l);shift=F(t['shift']);den=mu4+4*shift*mu3+6*shift*shift*mu2+n*shift**4;assert den>0
    reserve=(mu3+2*shift*mu2)**2/den-(n-1);h=F(d-1,d);required=k+5+F(2*(k+3*l),d)-F(6,d*d)-reserve;return F(1)if required<=0 else 4*h*h*(d+h*h)-required**2
def positive(args):
    p=W/'mop-finite-input-dp-20261108';sys.path.insert(0,str(p));import all_mass_dp as dp
    targets=rd(p/'positive-targets.json');assert len(targets)==len({(r['n'],r['d'],r['k'],r['l'])for r in targets})==328;rows=[];groups=[];start=time.monotonic()
    for d in sorted({r['d']for r in targets},reverse=True):
        selected=[r for r in targets if r['d']==d];K=max(r['k']for r in selected);L=max(r['l']for r in selected);print(json.dumps(dict(mode='fresh_positive',degree=d,K=K,L=L,event='START')),flush=True)
        tables=dp.polygons(K+2,d);values,layers=dp.chain(d,K,L,tables)
        for t in selected:
            actual=values[t['k'],t['l']];assert actual==t['M2_R'];margin=payment(t,actual);assert margin>0;rows.append(dict(target=t,actual_maximum=actual,positive_payment_indicator=str(margin)))
        groups.append(dict(d=d,K=K,L=L,layers=layers));save(args.output/'positive_progress.json',dict(rows=rows,groups=groups));print(json.dumps(dict(mode='fresh_positive',degree=d,rows=len(rows),seconds=time.monotonic()-start,event='DONE')),flush=True)
    assert len(rows)==328;save(args.output/'positive_fresh.json',dict(mode='FULL_FRESH_POSITIVE328_INTEGER_DP_AND_PAYMENTS',rows=rows,groups=groups,source_hashes={n:sha(p/n)for n in['all_mass_dp.py','positive-targets.json']},seconds=time.monotonic()-start));print('FULL_FRESH_POSITIVE328_INTEGER_DP_AND_PAYMENTS',flush=True)
def masked(args):
    p=W/'mop-masked-input-dp-20261108';sys.path.insert(0,str(p));import all_mass_dp as polygons,masked_dp as dp
    targets=rd(p/'targets.json')['rows'];assert len(targets)==len({(r['n'],r['d'],r['C'],r['k'],r['l'])for r in targets})==130;rows=[];groups=[];start=time.monotonic()
    for d,C in sorted({(r['d'],r['C'])for r in targets},reverse=True):
        selected=[r for r in targets if(r['d'],r['C'])==(d,C)];K=max(r['k']for r in selected);L=max(r['l']for r in selected);print(json.dumps(dict(mode='fresh_masked',degree=d,cap=C,K=K,L=L,event='START')),flush=True)
        tables=polygons.polygons(K+2,C);values,layers=dp.chain(d,C,K,L,tables)
        for t in selected:
            actual=values.get((t['k'],t['l'],0))
            if t['M2_R']is None:assert actual is None;margin=None
            else:
                assert actual is not None
                if t['comparison']=='EXACT_SAME_MASK0_DOMAIN':assert actual==t['M2_R']
                else:assert actual<=t['M2_R']
                margin=payment(t,actual);assert margin>0
            rows.append(dict(target=t,actual_mask0_maximum=actual,positive_payment_indicator=None if margin is None else str(margin)))
        groups.append(dict(d=d,C=C,K=K,L=L,layers=layers));save(args.output/'masked_progress.json',dict(rows=rows,groups=groups));print(json.dumps(dict(mode='fresh_masked',degree=d,cap=C,rows=len(rows),seconds=time.monotonic()-start,event='DONE')),flush=True)
    assert len(rows)==130 and len(groups)==29;save(args.output/'masked_fresh.json',dict(mode='FULL_FRESH_MASKED130_INTEGER_DP_AND_PAYMENTS',rows=rows,groups=groups,source_hashes={n:sha(p/n)for n in['all_mass_dp.py','masked_dp.py','targets.json']},seconds=time.monotonic()-start));print('FULL_FRESH_MASKED130_INTEGER_DP_AND_PAYMENTS',flush=True)
def degree(args):
    p=W/'mop-global-input-audit-20261108';sys.path.insert(0,str(p));spec=importlib.util.spec_from_file_location('repro_degree',p/'check_finite_degree_envelope.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);start=time.monotonic();rows=[]
    for n in range(43,72):
        D=m.cap(n);actual,count,states=m.literal(n,D);other,w=m.scout.bound(n,D);assert actual==other;gap=F(1359*n,32)-F(729,2)+F(441,n)-actual;assert gap>0;rows.append(dict(n=n,D=D,M2_upper=actual,margin=str(gap),histograms=count,states=states))
    assert len(rows)==29 and min(F(r['margin'])for r in rows)==F(1567,2080);save(args.output/'degree_fresh.json',dict(mode='FULL_FRESH_29_DEGREE_ENVELOPES',rows=rows,seconds=time.monotonic()-start,source_hashes={n:sha(p/n)for n in['check_finite_degree_envelope.py','scout_degree_inputs.py']}));print('FULL_FRESH_29_DEGREE_ENVELOPES',flush=True)

def fresh_tree(args):
    # Explicit manifest members only; never recurse over an old archive or DB.
    tree=args.output/('runtime_'+args.mode);manifest=rd(ROOT/'REPRO_MEMBERS.json');tree.mkdir(exist_ok=True)
    for r in manifest['members']:
        rel=Path(r['relative']);assert not rel.is_absolute() and '..'not in rel.parts
        src=ROOT/rel;assert src.stat().st_size==r['bytes'] and sha(src)==r['sha256']
        dest=tree/rel;dest.parent.mkdir(parents=True,exist_ok=True)
        if not dest.exists():shutil.copyfile(src,dest)
        else:assert sha(dest)==r['sha256'],('Changed immutable source in runtime',rel)
    # The original prepare() functions require byte-identical root aliases.
    high=tree/'work/mop-high-pair-inputs-20261108'
    plan=rd(high/'source-plan.json')
    aliases={n:high/'inputs'/n for n in plan['explicit_members']}
    aliases.update({n:high/'class-inputs'/n for n in ['split-fan-small-certificate.json','three-hub-partition-certificate.json','dominating_triangle_class_proof.txt']})
    for name,source in aliases.items():
        dest=tree/name
        if dest.exists():assert sha(dest)==sha(source)
        else:shutil.copyfile(source,dest)
    save(args.output/'runtime_aliases.json',{n:sha(p)for n,p in aliases.items()});return tree

def replay(args,tree,relative,seconds=900):
    source=tree/relative;label=Path(relative).stem;out=args.output/(label+'.stdout.txt');err=args.output/(label+'.stderr.txt');start=time.monotonic()
    with out.open('w',encoding='utf8')as o,err.open('w',encoding='utf8')as e:
        p=subprocess.Popen([sys.executable,'-B','-X','utf8',str(source)],cwd=tree,stdout=o,stderr=e)
        try:code=p.wait(timeout=seconds)
        except subprocess.TimeoutExpired:p.kill();code=p.wait();save(args.output/(label+'.process.json'),dict(exit_code=code,wall_time_seconds=time.monotonic()-start,timed_out=True,pid=p.pid));raise
    save(args.output/(label+'.process.json'),dict(command=[sys.executable,'-B','-X','utf8',str(source)],cwd=str(tree),exit_code=code,wall_time_seconds=time.monotonic()-start,timed_out=False,pid=p.pid,stdout_file=str(out),stderr_file=str(err)))
    assert code==0,(relative,err.read_text());print(label,'EXIT',code,'SECONDS',time.monotonic()-start,flush=True)

def quick(args):
    tree=fresh_tree(args);degree(args)
    replay(args,tree,'work/mop-early-cover-20261108/read_early.py')
    early=rd(tree/'work/mop-early-cover-20261108/early-result.json');assert early['base_graphs']==6853 and early['small_gap_graphs']==61 and early['parameter_rows_12_to33']+early['parameter_rows_34_to42']==4636
    save(args.output/'early_fresh.json',dict(mode='FULL_FRESH_B42_MATH_REPLAY',result=early))
    replay(args,tree,'work/mop-high-pair-inputs-20261108/read_high_pairs.py')
    replay(args,tree,'work/mop-high-pair-inputs-20261108/read_class_payments.py')
    high=rd(tree/'work/mop-high-pair-inputs-20261108/high-pair-result.json');classes=rd(tree/'work/mop-high-pair-inputs-20261108/class-result.json')
    assert sum(r['cases']for r in high['classes']if r['class_name']!='internal33_32_nonhub_one_ear')==4760
    assert next(r['cases']for r in high['classes']if r['class_name']=='internal33_32_nonhub_one_ear')==54870
    assert classes['complete_second_degree_common_neighbor_cases']==1150
    save(args.output/'high_fresh.json',dict(mode='FULL_FRESH_HIGH_PAIR_AND_CLASS_MATH_REPLAY',high_pair=high,classes=classes))

def charge190(args):
    names=['verify_tighter_charge_small_190.py','verify_tighter_split_fan_charge_190.py','verify_nonlinear_small_190.py','verify_nonlinear_split_fan_190.py']
    tree=args.output/'c190';tree.mkdir(exist_ok=True)
    data=['tighter-charge-190-small-certificate.json','tighter-split-fan-190-initial-screen.json','nonlinear-charge-190-small-certificate.json','nonlinear-charge-190-initial-screen.json']
    for name in names+data:shutil.copyfile(ROOT/name,tree/name)
    for name in names:replay(args,tree,name)
    expected={'tighter-charge-190-small-verification.json':('PASS_ALL_TIGHTER_CHARGE_SMALL_SHAPES_INTEGER_PSD',None),'tighter-split-fan-190-verification.json':('PASS_TIGHTER_SPLIT_FAN_FINITE_BASE',4951),'nonlinear-charge-190-small-verification.json':('PASS_NONLINEAR_ALL_FINITE_SHAPES_INTEGER_PSD',None),'nonlinear-charge-190-verification.json':('PASS_NONLINEAR_SPLIT_FAN_FINITE_BASE',4950)}
    rows={}
    for name,(status,cells)in expected.items():
        v=rd(tree/name);assert v['status']==status
        if cells is not None:assert v['cells']==cells and not v['failures']
        rows[name]=v
    for initial,main in [('tighter-split-fan-190-initial-screen.json','tighter-split-fan-190-verification.json'),('nonlinear-charge-190-initial-screen.json','nonlinear-charge-190-verification.json')]:
        # Bridge two independent coverage routes: freshly discovered residual
        # parameter shapes must be exactly the small-reader obligation list.
        key=lambda r:(r['q'],r['p'],r['s'])
        required={key(r)for r in rd(tree/initial)['failures']}
        actual={key(r)for r in rows[main]['finite_psd_shapes']}
        assert actual==required,(initial,actual^required)
    save(args.output/'charge190_fresh.json',dict(mode='FULL_FRESH_EXACT_FINITE_CHARGE190_BASES',results=rows))
def assemble(args):
    # Fail closed on MATHEMATICAL replay results, not original-machine receipts.
    required=[('positive_fresh.json','FULL_FRESH_POSITIVE328_INTEGER_DP_AND_PAYMENTS'),('masked_fresh.json','FULL_FRESH_MASKED130_INTEGER_DP_AND_PAYMENTS'),('degree_fresh.json','FULL_FRESH_29_DEGREE_ENVELOPES'),('early_fresh.json','FULL_FRESH_B42_MATH_REPLAY'),('high_fresh.json','FULL_FRESH_HIGH_PAIR_AND_CLASS_MATH_REPLAY')];inputs={}
    for name,mode in required:v=rd(args.output/name);assert v['mode']==mode,(name,'wrong scope');inputs[name]=v
    pos=inputs['positive_fresh.json']['rows'];mask=inputs['masked_fresh.json']['rows'];assert len(pos)==328 and len(mask)==130
    for r in pos:assert r['actual_maximum']==r['target']['M2_R']and payment(r['target'],r['actual_maximum'])==F(r['positive_payment_indicator'])>0
    for r in mask:
        if r['actual_mask0_maximum']is not None:assert payment(r['target'],r['actual_mask0_maximum'])==F(r['positive_payment_indicator'])>0
    # Import mathematical scalar functions only, never its old main()/gate.
    source=W/'mop-finite-assembly-20261108/read_finite_assembly.py';spec=importlib.util.spec_from_file_location('repro_scalar',source);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    key=lambda t:(t['n'],t['d'],t['k'],t['l'])
    positive={key(r['target']):r for r in pos};masked={key(r['target']):r for r in mask}
    ptargets={key(t):t for t in rd(W/'mop-finite-input-dp-20261108/positive-targets.json')};mtargets={key(t):t for t in rd(W/'mop-masked-input-dp-20261108/targets.json')['rows']}
    assert len(positive)==328 and len(masked)==130 and positive.keys()==ptargets.keys()and masked.keys()==mtargets.keys()
    assert all(r['target']==ptargets[k]for k,r in positive.items())and all(r['target']==mtargets[k]for k,r in masked.items())
    degree=inputs['degree_fresh.json']['rows'];assert len(degree)==29 and {r['n']for r in degree}==set(range(43,72))and all(r['D']==m.degree_cap(r['n'])and F(r['margin'])>0 for r in degree)
    assert inputs['early_fresh.json']['result']['base_graphs']==6853 and inputs['early_fresh.json']['result']['small_gap_graphs']==61
    high=inputs['high_fresh.json']['classes'];complements={(r['n'],r['d'],r['cap'],r['e'],r['adjacent'],r['common'])for r in high['complement_cases']};assert len(complements)==1150
    scan=rd(W/'mop-finite-assembly-20261108/scan-result.json');seen=set();usedpos=set();usedmask=set();counts={};minimum={};vacuous=0;largest=0
    for r in scan['rows']:
        n,d,k,l=r['n'],r['d'],r['k'],r['l'];K=(n,d,k,l);assert K not in seen;seen.add(K);assert k==n-d-1 and 43<=n<=71 and m.degree_cap(n)<d<n
        assert(l==0 and k==0)or(1<=l<=min(k,d-1));rule=r['rule'];counts[rule]=counts.get(rule,0)+1;gain=None
        if rule=='whole_moment':
            U=min(n*n+7*n-18,(2*d+8)*n-6*d-12,d*d+9*d-10+m.bound_q(k,l)+15*k+2*l);gain=max(m.moment_value(n,U,F(j,16))-2*n for j in range(24,65));assert gain>=0
        elif rule=='rho0_hub':gain=m.hub(d,k,l);assert gain==F(r['margin'])>=0
        elif rule=='coarse_residual_moment':
            M=4*d-6+m.bound_q(k,l)+13*k;f=m.residual(d,k,l,M,F(r['shift']));assert f==F(r['reserve']);gain=m.hub(d,k,l,max(F(0),f));assert gain==F(r['margin'])>=0
        elif rule=='balanced_block_B42':
            assert 1<=l<=k and k+2<=42;largest=max(largest,k+2);f=m.closed_balanced(k,l);assert f==F(r['reserve']);gain=m.hub(d,k,l,f);assert gain==F(r['margin'])>=0
        elif rule=='single_gap_B42':
            assert l==1 and d>=23 and 3<=k+2<=42 and r['gap_order']==k+2;L=d-2;h=F(L-2,L);gain=4*h*h*(L+10)-100;assert gain>0
        elif rule=='fresh_positive328':
            rec=positive[K];t=rec['target'];M=rec['actual_maximum'];f=m.residual(d,k,l,M,F(t['shift']));gain=m.hub(d,k,l,f);assert gain==F(rec['positive_payment_indicator'])==F(r['margin'])>0;usedpos.add(K)
        elif rule=='PENDING_MASKED_AND_COMPLEMENTS':
            rec=masked[K];t=rec['target'];C=t['C'];assert n>=60 and r['cap']==C and 2<=C<=d
            for e in range(C+1,d+1):
                for adj,hs in[(True,[1,2]),(False,[0,1,2])]:assert all((n,d,C,e,adj,h)in complements for h in hs)
            M=rec['actual_mask0_maximum']
            if M is None:assert t['M2_R']is None;vacuous+=1
            else:
                assert M<=t['M2_R'];f=m.residual(d,k,l,M,F(t['shift']));gain=m.hub(d,k,l,f);assert gain==F(rec['positive_payment_indicator'])>0
            usedmask.add(K)
        else:raise AssertionError(('Unpaid rule',r))
        if gain is not None:minimum[rule]=min(minimum.get(rule,gain),gain)
    expected={(n,d,n-d-1,l)for n in range(43,72)for d in range(m.degree_cap(n)+1,n)for l in([0]if n-d-1==0 else range(1,min(n-d-1,d-1)+1))}
    assert seen==expected and len(seen)==11885 and usedpos==positive.keys()and usedmask==masked.keys()and largest==26
    assert counts==scan['rules']and not scan['unresolved']
    save(args.output/'finite_assembly.json',dict(mode='CHECKED_B71_FROM_FRESH_STANDALONE_MATH_INPUTS',high_degree_parameter_rows=len(seen),low_degree_orders=len(degree),positive328_used=len(usedpos),masked130_used=len(usedmask),vacuous_masked_classes=vacuous,rule_counts=counts,minimum_exact_indicators={k:str(v)for k,v in minimum.items()},fresh_input_files={name:sha(args.output/name)for name,_ in required},scalar_kernel_source_sha256=sha(source),scope='Finite arithmetic and coverage, conditional on the written reduction lemmas; no native/history PASS premise.'))
    print('CHECKED_B71_FROM_FRESH_STANDALONE_MATH_INPUTS',flush=True)
def main():
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['positive','masked','degree','quick','charge190','assemble']);parser.add_argument('--output',type=Path,default=ROOT/'results');args=parser.parse_args();args.output=args.output.resolve();args.output.mkdir(parents=True,exist_ok=True);globals()[args.mode](args)
if __name__=='__main__':main()
