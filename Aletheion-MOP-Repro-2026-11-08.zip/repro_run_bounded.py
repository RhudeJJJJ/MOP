"""One own bounded verifier process, exact exit/output metadata retained."""
if not __debug__:
    raise RuntimeError('Assertions must remain enabled; do not use python -O')

from pathlib import Path
import subprocess,sys,time,datetime,json,argparse
P=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('label');parser.add_argument('--seconds',type=int,default=5400);parser.add_argument('command',nargs=argparse.REMAINDER);a=parser.parse_args();command=a.command
if command and command[0]=='--':command=command[1:]
assert command and 1<=a.seconds<=5400
folder=P/'repro_fresh_finite_results';folder.mkdir(exist_ok=True);start=time.monotonic();prefix=folder/a.label;assert not prefix.with_suffix('.process.json').exists()
with prefix.with_suffix('.stdout.txt').open('w',encoding='utf8')as out,prefix.with_suffix('.stderr.txt').open('w',encoding='utf8')as err:
    p=subprocess.Popen(command,stdout=out,stderr=err);creation=datetime.datetime.now(datetime.timezone.utc).isoformat();timedout=False
    try:code=p.wait(timeout=a.seconds)
    except subprocess.TimeoutExpired:timedout=True;p.kill();code=p.wait()
meta=dict(command=command,pid=p.pid,observed_created_utc=creation,exit_code=code,wall_time_seconds=time.monotonic()-start,timeout_seconds=a.seconds,timed_out=timedout,stdout_file=str(prefix.with_suffix('.stdout.txt')),stderr_file=str(prefix.with_suffix('.stderr.txt')),scope='Only this own Popen handle may be killed on timeout; no retry/foreign process control')
prefix.with_suffix('.process.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta));sys.exit(0 if code==0 else 1)
