"""Standalone mathematical replay entrypoints; no Aletheion or PASS receipts.

Run from an extracted bundle. Slow full modes really evaluate every numeric
compact leaf, not cached exact area records. --smoke proves only stated subset.
"""
if not __debug__:
    raise RuntimeError('Assertions must remain enabled; do not use python -O')

from pathlib import Path
from fractions import Fraction as F
import argparse,json,sys,time,subprocess,shutil,hashlib
ROOT=Path(__file__).resolve().parent;W=ROOT/'work'
def rd(p):return json.loads(p.read_bytes())
def out(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v),flush=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def c0(args):
    source=W/'mop-c0-needed-input-20261108';scratch=args.output/'c0_work';scratch.mkdir(parents=True,exist_ok=True)
    names=list(rd(source/'original-source-inputs.json')['members'])+['read_needed_c0.py','needed-c0-proof.md','prepare_sources.py','original-source-inputs.json']
    for n in names:
        dest=scratch/n;data=(source/n).read_bytes()
        if dest.exists():assert dest.read_bytes()==data
        else:dest.write_bytes(data)
    command=[sys.executable,'-B','-X','utf8',str(scratch/'read_needed_c0.py')];r=subprocess.run(command,cwd=scratch,capture_output=True,text=True,encoding='utf8');out(args.output/'c0_process.json',dict(command=command,exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr));assert r.returncode==0,r.stderr
    result=rd(scratch/'needed-c0-result.json');assert result['fresh_exact_node_envelopes']==2304 and all(F(v['gain_lower'])>F(409,100)for v in result['rows']);out(args.output/'c0_result.json',result)
def private(args):
    p=W/'mop-private-sibling-middle-20261108';sys.path.insert(0,str(p));import rational_grid;rational_grid.install()
    import private_ad5 as direct,private_common_ad5 as common,bulk_small_tail as st,uniform_private_tail as lt,net_interval as net
    from bulk_band_cover import Cover
    certificate=rd(p/'bulk-band-v2-certificate.json');grid=rd(p/'bulk-frequency-grid.json');assert certificate['format']=='private-sibling-two-bands-one-unbounded-arm-v1'and len(grid)==80
    bands={}
    for name,tail in [('small',st),('large',lt)]:
        cover=Cover(name);items=certificate['cells'][name];assert len(items)==80
        if args.smoke:
            part=items[0]['partition']
            while 'split'in part:part=part['split'][0]
            a,b=F(part['a']),F(part['b']);a0,b0=F(grid[0]['a']),F(grid[0]['b']);target=cover.amplitude/(1+((a0+b0)/2)**2)
            upper,count,empty,anchor=cover.parse_tree(part['trees'][0],a,b,target,direct,common,*cover.roots()[0]);bands[name]=dict(domain='FIRST frequency leaf/FIRST ordered residue root only',numerical_leaves=count,empty=empty,anchor=anchor,upper=str(upper));continue
        total=F(0);end=F(1,2);leaves=empty=0
        for i,(item,row)in enumerate(zip(items,grid)):
            a,b=F(row['a']),F(row['b']);assert a==end and item['index']==i and item['band']==name;end=b;target=cover.amplitude/(1+((a+b)/2)**2);assert F(item['target'])==target
            area,n,e,anchor,fcells=cover.cell(item['partition'],a,b,target,direct,common);total+=area;leaves+=n;empty+=e;print(json.dumps(dict(band=name,index=i,numerical_leaves=leaves)),flush=True)
        assert end==16;high=sum((tail.tail(F(j,1024),F(j+1,1024))[1]/1024 for j in range(64)),F(0));gain=cover.reserve-F(1,2)-2*(total+high)/net.PI[0];assert gain>F(1,20);bands[name]=dict(compact_upper=str(total),tail_upper=str(high),surplus_lower=str(gain),numerical_leaves=leaves,empty=empty)
    out(args.output/('private_smoke.json'if args.smoke else'private_full.json'),dict(mode='SMOKE_PARTIAL_NO_FAMILY_THEOREM'if args.smoke else'FULL_FRESH_NUMERIC_PRIVATE_TWO_BANDS',bands=bands,no_prior_PASS_or_execution_receipts_read=True))
def double_compact(args):
    base=W/'mop-double-reciprocal-20261108';h=W/'mop-double-fixed-middle-20261108';d=W/'mop-double-eigen-tail-20261108';sys.path.insert(0,str(base));sys.path.insert(0,str(h));import rational_grid;rational_grid.install()
    import reciprocal_cover as old,reciprocal_model as direct,reciprocal_common as common,fixed_cover,fixed_bound
    selection=rd(d/'selection36.json');assert selection['compact_slabs']==36 and selection['cutoff']=='5';rows=selection['frequency_grid'];assert len(rows)==36
    if args.smoke:
        i=23;item=rd(d/'selected-data'/f'{i:04}.json');a,b,target=map(F,(item['a'],item['b'],item['target']));upper,n,anchor,depth=fixed_cover.tree(item['trees'][0],a,b,target,fixed_cover.roots()[0],fixed_bound.bound);out(args.output/'double_smoke.json',dict(mode='SMOKE_ONE_ROOT_NO_FAMILY_THEOREM',slab=i,root=fixed_cover.roots()[0],numerical_leaves=n,upper=str(upper)));return
    total=F(0);end=F(1,2);records=[]
    for i,row in enumerate(rows):
        item=rd(d/'selected-data'/f'{i:04}.json');a,b=F(row['a']),F(row['b']);assert a==end and item['index']==i;end=b;target=(F(5,2)if i<16 else F(14,5))/(1+((a+b)/2)**2)
        if i<16:
            assert F(item['target'])==target;area,n,anchor,depth,freq=old.frequency(item['partition'],a,b,target,direct,common)
        else:
            # Includes i23: numerical reading, no cached preflight area reuse.
            assert (item['a'],item['b'])==(str(a),str(b))and F(item['target'])==target;area,n,anchor,depth=fixed_cover.read_cell(item,fixed_bound.bound)
        assert area<=(b-a)*target;total+=area;records.append(dict(index=i,a=str(a),b=str(b),area=str(area),numerical_leaves=n,raw_data_sha256=sha(d/'selected-data'/f'{i:04}.json')));print(json.dumps(records[-1]),flush=True)
    assert end==5;out(args.output/'double_compact.json',dict(mode='FULL_FRESH_NUMERIC_DOUBLE_COMPACT36',compact_upper=str(total),numerical_leaves=sum(v['numerical_leaves']for v in records),records=records,no_saved_area_or_PASS_or_execution_receipt_read=True))
def double_tail(args):
    d=W/'mop-double-eigen-tail-20261108';sys.path.insert(0,str(d));import eigen_tail_v3 as tail;import net_interval as net
    if args.compact:
        c=rd(args.compact);assert c['mode']=='FULL_FRESH_NUMERIC_DOUBLE_COMPACT36'and len(c['records'])==36;compact=F(c['compact_upper']);mode='FULL_DOUBLE_COMPACT_AND_SIGNED_TAIL_ARITHMETIC'
    else:compact=F(rd(d/'selection36.json')['target_compact_upper']);mode='CONDITIONAL_TARGET_BUDGET_ONLY_NO_COMPACT_PROOF'
    cases=[]
    for m in range(14,42):
        high=sum((tail.tail(F(j,640),F(j+1,640),m)[1]/640 for j in range(128)),F(0));reserve=tail.reserve(m);gain=reserve-F(1,2)-2*(compact+high)/net.PI[0];assert gain>F(1,20);cases.append(dict(total=m,tail_upper=str(high),reserve=str(reserve),surplus_lower=str(gain)))
    out(args.output/'double_tail.json',dict(mode=mode,compact_upper=str(compact),cases=cases,exact_whole_tail_intervals=3584,no_prior_PASS_or_execution_receipts_read=True))
def main():
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['c0','private','double-compact','double-tail']);parser.add_argument('--smoke',action='store_true');parser.add_argument('--compact',type=Path);parser.add_argument('--output',type=Path,default=ROOT/'results');args=parser.parse_args();args.output=args.output.resolve();{'c0':c0,'private':private,'double-compact':double_compact,'double-tail':double_tail}[args.mode](args)
if __name__=='__main__':main()
