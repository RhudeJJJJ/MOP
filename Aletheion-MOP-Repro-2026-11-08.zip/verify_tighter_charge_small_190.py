"""Exact original matrices, all-shape coverage, and integer Gram readback."""
from pathlib import Path
from fractions import Fraction as F
from math import isqrt
from itertools import product
import json,hashlib
ROOT=Path(__file__).resolve().parent

def score(record,D):
    q,p,s=record['q'],record['p'],record['s'];parts=record['parts'];L=record['factor']
    assert parts==sorted(parts) and all(x>=1 for x in parts)
    assert sum(parts)==q and len(parts)==p and sum(x>1 for x in parts)==s
    assert len(L)==q+1 and len(set(map(len,L)))==1 and all(type(x)==int for row in L for x in row)
    E={(0,v) for v in range(1,q+1)};i=1
    for length in parts:
        E.update((v,v+1) for v in range(i,i+length-1));i+=length
    assert len(E)==q+q-p
    G=[[sum(a*b for a,b in zip(row,col)) for col in L] for row in L]
    numerator=4*D*D*sum(G[a][b] for a,b in E)-sum(x*x for row in G for x in row)
    bound=F(numerator,D**4)
    r=isqrt(q*10**12);upper=F(r,10**6) if r*r==q*10**12 else F(r+1,10**6)
    target=2*q-F(11*p,7)-F(7,4)+2*upper
    assert bound>target,(q,p,s,parts,bound-target)
    return bound-target,bound

def main():
    P=json.loads((ROOT/'tighter-charge-190-small-certificate.json').read_text())
    base=json.loads((ROOT/'tighter-split-fan-190-initial-screen.json').read_text())
    required=set()
    # Different coverage route: ordered positive compositions, then sort.
    for row in base['failures']:
        q,p,s=row['q'],row['p'],row['s'];m=q-p
        for edges in product(range(1,m+1),repeat=s):
            if sum(edges)!=m:continue
            parts=tuple(sorted([1]*(p-s)+[x+1 for x in edges]))
            required.add((q,p,s,parts))
    keys=[(r['q'],r['p'],r['s'],tuple(r['parts'])) for r in P['records']]
    assert set(keys)==required and len(keys)==len(required)
    margins=[score(record,P['denominator']) for record in P['records']]
    damaged=dict(P['records'][0]);damaged['factor']=[[0] for _ in damaged['factor']]
    try:score(damaged,P['denominator'])
    except AssertionError:rejected=True
    else:raise AssertionError('Zero factor accepted')
    out={'status':'PASS_ALL_TIGHTER_CHARGE_SMALL_SHAPES_INTEGER_PSD',
         'records':len(keys),'parameter_shapes':len(base['failures']),
         'minimum_margin':str(min(m[0] for m in margins)),
         'certificate_sha256':hashlib.sha256((ROOT/'tighter-charge-190-small-certificate.json').read_bytes()).hexdigest(),
         'zero_factor_rejected':rejected,'original':'GLOBAL OPEN',
         'scope':'Exact finite local-shape coverage and PSD lower energy; proposals are not proof without this reader'}
    (ROOT/'tighter-charge-190-small-verification.json').write_text(json.dumps(out,indent=2)+'\n')
    print(out,flush=True)
if __name__=='__main__':main()
