"""Combine degree4, private mass, path losses and exact incidence totals."""
from pathlib import Path
from fractions import Fraction as F
import json
from probe_connected_triple_payment_188 import bound
ROOT=Path(__file__).resolve().parent

def solve(specs,excess,incidences,Qmax=134):
    D={(0,0,0):(F(0),[])};transitions=0
    for minimum,phi,internal in specs:
        cells=[]
        for q in range(minimum,Qmax+1):
            for p in range(1,min(q,phi+excess)+1):
                ell=max(0,p-phi)
                lost=max(ell,4-internal-q,0)
                cells.append((q,ell,lost,bound(q,p),p))
        new={}
        for (Q,E,T),(prior,trace) in D.items():
            for q,ell,lost,v,p in cells:
                if Q+q>Qmax or E+ell>excess or T+lost>incidences:continue
                key=(Q+q,E+ell,T+lost);payment=prior+v;transitions+=1
                if key not in new or payment<new[key][0]:new[key]=(payment,trace+[(q,p,lost)])
        D=new
    return D,transitions

def main():
    rows=[];tails={};transitions=0
    for e,specs,E,T in ((0,[(2,1,0)]*3,6,6),(1,[(1,2,1),(1,2,1),(2,1,0)],3,5)):
        D,cnt=solve(specs,E,T);transitions+=cnt
        for n in range(8,138):
            eligible=[v for (Q,l,t),v in D.items() if Q==n-3]
            if not eligible:continue
            v,trace=min(eligible,key=lambda x:x[0])
            rows.append({'n':n,'e_H':e,'margin':str(v-2*n),'blocks_q_p_lostmin':trace})
        unpaid=[r['n'] for r in rows if r['e_H']==e and F(r['margin'])<=0]
        tails[str(e)]=max(unpaid)+1 if unpaid else 8
        print('INCIDENCE_LOSS_TAIL189',e,tails[str(e)],cnt,flush=True)
    out={'status':'EXACT_DEGREE4_INCIDENCE_LOSS_SUFFICIENT_SCREEN',
         'rows':rows,'tails_within_screen':tails,'transitions':transitions,
         'original':'GLOBAL OPEN','scope':'universal assignment relaxation, not a graph counterexample'}
    (ROOT/'incidence-loss-189-screen.json').write_text(json.dumps(out,indent=2)+'\n')
    print('N72',[r for r in rows if r['n']==72],flush=True)
if __name__=='__main__':main()
