"""Exact finite parameter base for a tighter universal split-fan charge."""
from pathlib import Path
from fractions import Fraction as F
from math import isqrt
import json
ROOT=Path(__file__).resolve().parent
alpha=F(11,7);beta=F(7,4);scale=10**6
def sqrt_lo(x):return F(isqrt(x.numerator*scale*scale//x.denominator),scale)
def sqrt_hi(x):
    lo=sqrt_lo(x);return lo if lo*lo==x else lo+F(1,scale)

def main():
    from verify_tighter_charge_small_190 import score
    certificate=json.loads((ROOT/'tighter-charge-190-small-certificate.json').read_text())
    local=certificate['records'];psd_shapes=[]
    rows=[];weights=[];compressions=[];fail=[];shapes=0
    for q in range(100):
        for p in ([0] if not q else range(1,q+1)):
            target=2*q-alpha*p-beta+2*sqrt_hi(F(q));m=q-p;paid_shapes=[]
            for s in ([0] if not m else range(1,min(p,m)+1)):
                shapes+=1
                if q<=2 or not m:
                    lower=F(4 if (q,p)==(2,1) else q)
                    radius=F(0)
                else:
                    longest=m-s+2
                    radius=(F(0),F(1),F(2),F(8,3),F(3))[longest-1] if longest<=5 else F(4)-F(16,(longest+1)**2)
                    D2=4*m-2*s;loss=min(radius,F(2*D2,q)-F(4*m*m,q*q))
                    lower=max(F(q),F(q+m)-loss+F(2*m*m,q*q)+F(2*m,q*q)*sqrt_lo(F(q**3+m*m)))
                if lower<=target:
                    D2=4*m-2*s;D3=4*m-4*s+max(0,2*s-m)
                    required=target-m+radius
                    R=sqrt_hi(required)+F(1,scale);assert R*R>required
                    success=False
                    for t in (F(1,2),F(1,3),F(1,4),F(1,8),F(1,16),F(1,32),F(1),F(2),F(1,64),F(3,4),F(3,2)):
                        hub=F(q+2*t*m)/R
                        form=2*hub*(q+2*t*m)+2*m+2*t*D2+2*t*t*D3
                        norm=hub*hub+q+4*t*m+t*t*D2
                        gap=form-R*norm
                        if gap>0:
                            lower=R*R+m-radius;success=True
                            weights.append({'q':q,'p':p,'s':s,'R':str(R),'t':str(t),'positive_test':str(gap)})
                            break
                    if not success:
                        N=m+s;n0=p-s;a=F(2*m,N)
                        loss=min(radius,F(2*D2,N)-a*a)
                        H=2*q+a*a+m-loss-target
                        if H>0:
                            R=sqrt_lo(H)
                            cubic=R**3+a*R**2-q*R-a*n0
                            if cubic>0:
                                lower=2*q+a*a-R*R+m-loss;success=True
                                compressions.append({'q':q,'p':p,'s':s,'R':str(R),'positive_cubic':str(cubic)})
                    if not success:
                        cases=[r for r in local if (r['q'],r['p'],r['s'])==(q,p,s)]
                        if cases:
                            lower=min(score(r,certificate['denominator'])[1] for r in cases)
                            success=True;psd_shapes.append({'q':q,'p':p,'s':s,'carriers':len(cases)})
                    if not success:fail.append({'q':q,'p':p,'s':s,'gap':str(lower-target)})
                if lower>target:paid_shapes.append(lower-target)
            if len(paid_shapes)==(1 if not m else min(p,m)):
                rows.append({'q':q,'p':p,'minimum_margin':str(min(paid_shapes))})
    out={'status':'PASS_TIGHTER_SPLIT_FAN_FINITE_BASE' if not fail else 'OPEN_TIGHTER_SPLIT_FAN_SUFFICIENT_BASE',
      'alpha':str(alpha),'beta':str(beta),'q_range':[0,99],'cells':len(rows),'shape_cells':shapes,
      'weighted_witnesses':weights,'three_dimensional_witnesses':compressions,'failures':fail,
      'finite_psd_shapes':psd_shapes,
      'minimum_margin':min((r['minimum_margin'] for r in rows),key=lambda s:F(s)),
      'rows':rows,'original':'GLOBAL OPEN','scope':'Exact sufficient local-parameter certificate; analytic infinite tail still required'}
    (ROOT/'tighter-split-fan-190-verification.json').write_text(json.dumps(out,indent=2)+'\n')
    print('TIGHTER_SPLIT_FAN_BASE190',out['status'],len(rows),shapes,len(weights),len(compressions),fail[:8],flush=True)
if __name__=='__main__':main()
