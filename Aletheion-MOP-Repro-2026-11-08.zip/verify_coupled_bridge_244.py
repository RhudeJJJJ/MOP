"""Independent catalogue/MITM coverage, literal Fraction tables, Laplace minors."""
from pathlib import Path
from itertools import combinations,permutations,product
from fractions import Fraction as F
from math import isqrt
import json,hashlib,copy,sys
import numpy as np
from bridge_structure_reader_244 import core_catalogue,shared_catalogue,choices,path_caps,domain_candidates,outerplane
from verify_small_splitfans_243 import check as check_small
ROOT=Path(__file__).resolve().parent;S=256;S2=S*S
read=lambda n:json.loads((ROOT/n).read_text(encoding='utf-8-sig'))
sha=lambda n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest()

def rebuild_tables():
    small=read('small-splitfans-243-certificate.json');assert sha('small-splitfans-243-witnesses.npz')==small['archive_sha256']
    with np.load(ROOT/'small-splitfans-243-witnesses.npz',allow_pickle=False) as z:check_small(small,{k:z[k] for k in z.files})
    fixed={(z['q'],z['path_component_cap']):F(z['lower']) for z in small['at_most_p_table']};tables={k:np.zeros((156,11,11),np.int64) for k in('E','D','Z','T','V')}
    for q in range(1,156):
        lower={};mode={}
        for p in range(1,min(q,10)+1):
            m=q-p;bounds=[]
            if not m:first=F(q)
            else:
                for nontrivial in range(1,min(p,m)+1):
                    length=m-nontrivial+2;cap={1:F(0),2:F(1),3:F(2),4:F(8,3),5:F(3)}.get(length,F(4)-F(16,(length+1)**2));loss=min(cap,F(8*m-4*nontrivial,q)-F(4*m*m,q*q));rad=F(isqrt((q**3+m*m)*10**12),10**6);bounds.append(F(q+m)-loss+F(2*m*m,q*q)+F(2*m,q*q)*rad)
                first=max(F(q),min(bounds))
            sq=F(isqrt(q*10**12),10**6);sp=F(isqrt(p*10**12)+1,10**6);lo=max(first,2*q-F(11*p,7)-F(7,4)+2*sq,2*q-p+2*sq-2*sp-F(m,4*q),fixed.get((q,p),F(0)));lower[p]=lo.numerator*S2//lo.denominator
            a=isqrt(S2*(q**3+m*m)//(q*q))-S*m//q;assert a>0;norm=a*a+q*S2;t=2*a*S*q+2*S2*m;d2=4*m-2 if m else 0;av=q*q*S2+q*a*a+4*a*S*m+S2*d2;variance=F(av,norm)-F(t*t,norm*norm);assert variance>=0
            vv=2*S2*variance;mode[p]=(S*t//norm,isqrt(S2*a*a//norm),isqrt(S2*S2//norm),-(-vv.numerator//vv.denominator))
        for l in range(1,min(q,10)+1):
            for h in range(l,min(q,10)+1):
                tables['E'][q,l,h]=min(lower[p] for p in range(l,h+1))
                for j,key in enumerate(('D','Z','T','V')):tables[key][q,l,h]=(max if key=='V' else min)(mode[p][j] for p in range(l,h+1))
    hub=np.zeros((160,160),np.bool_)
    for n in range(72,160):
        for d in range(4,n):
            h=F(d-1,d);r=d+h*h;root=F(isqrt(r.numerator*10**12//r.denominator),10**6);k=n-d-1;hub[n,d]=2*h*root-k-5-F(8*k,d)+F(6,d*d)>=0
    tables['hub_paid']=hub;return tables

def determinant(C,U):
    if len(U)==1:return C[:,U[0],U[0]]
    out=np.zeros(len(C),np.int64);i=U[0]
    # General Laplace expansion, independent of the producer permutation sum.
    def rect(rows,cols):
        if len(rows)==1:return C[:,rows[0],cols[0]]
        z=np.zeros(len(C),np.int64)
        for j,col in enumerate(cols):z+=((-1)**j)*C[:,rows[0],col]*rect(rows[1:],cols[:j]+cols[j+1:])
        return z
    return rect(U,U)

def psd(C,U):
    assert np.max(np.abs(C),initial=0)<4096 and 24*4096**4<2**63
    good=np.ones(len(C),np.bool_)
    for r in range(1,len(U)+1):
        for sub in combinations(U,r):good&=determinant(C,sub)>=0
    return good

def data(private,ch,E,masks,tab,t3,exactp=None):
    A,T,ds,a,shared,_=choices(E,masks);inside,cut,ho,oo=path_caps(E,T,ds,ch['owners'],a);q=private+np.array(ch['s']);hi=np.minimum.reduce([q,np.broadcast_to(ch['pmax'],q.shape),np.full_like(q,7-t3),q-np.array(inside),np.broadcast_to(cut,q.shape)]);lo=np.broadcast_to(ch['pmin'],q.shape);valid=np.all(lo<=hi,axis=1)
    if exactp is not None:valid&=np.all((lo<=exactp)&(exactp<=hi),axis=1)&(exactp.sum(axis=1)<=10-t3);lo=hi=exactp
    safehi=np.maximum(hi,1);safelo=np.minimum(lo,safehi);en=tab['E'][q,safelo,safehi].sum(axis=1);d=tab['D'][q,safelo,safehi];z=tab['Z'][q,safelo,safehi];t=tab['T'][q,safelo,safehi];v=tab['V'][q,safelo,safehi];C=np.zeros((len(private),4,4),np.int64)
    for i in range(4):C[:,i,i]=d[:,i]
    for i,j in combinations(range(4),2):C[:,i,j]=C[:,j,i]=(int(j in A[i])*z[:,i]*z[:,j]+ho[i,j]*z[:,i]*t[:,j]+ho[j,i]*z[:,j]*t[:,i]+oo[i,j]*t[:,i]*t[:,j])//S
    return valid,en,C,v

def charge(en,C,v,code):
    if code==0:return en,np.ones(len(en),np.bool_)
    if code<16:
        U=tuple(i for i in range(4) if code>>i&1);assert len(U)>=2;g=sum(2*C[:,i,j]**2 for i,j in combinations(U,2))-v[:,U].sum(axis=1);return en+g,psd(C,U)
    pairs=(((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2)))[code-16];value=en.copy()
    for pair in pairs:
        i,j=pair;g=2*C[:,i,j]**2-v[:,i]-v[:,j];value+=np.where(psd(C,pair),np.maximum(g,0),0)
    return value,np.ones(len(en),np.bool_)

def all_p(private,ch,E,masks,tab,t3):
    q=np.array(private)+ch['s'];upper=np.minimum(np.minimum(q,ch['pmax']),7-t3);P=np.array([p for p in product(*(range(l,int(h)+1) for l,h in zip(ch['pmin'],upper))) if sum(p)<=10-t3],np.int64).reshape((-1,4))
    if not len(P):return None,0
    valid,en,C,v=data(np.tile(private,(len(P),1)),ch,E,masks,tab,t3,P);best=en.copy();codes=[sum(1<<i for i in U) for size in (2,3,4) for U in combinations(range(4),size)]+[16,17,18]
    for code in codes:
        value,good=charge(en,C,v,code);update=good&(value>best);best[update]=value[update]
    return (int(best[valid].min()) if np.any(valid) else None),int(valid.sum())

def controls():
    # A real positive scalar-pair example achieves the exact bonus2.
    C=np.array([[[2,1,0,0],[1,3,0,0],[0,0,1,0],[0,0,0,1]]],np.int64);assert psd(C,(0,1))[0] and 2**2+3**2+2==15
    bad=C.copy();bad[0,0,0]=bad[0,1,1]=1;bad[0,0,1]=bad[0,1,0]=2;assert not psd(bad,(0,1))[0] and 9<10
    # Two J2 old blocks, u=e1 each, have alpha1,var1 and compressedJ2.
    # Whole splus=(17+sqrt5)/2<10, whereas omitting the variance costs
    # falsely claims baseline8+bonus2=10. Correct lower is6.
    old=[[1,1],[1,1]];vec=[1,0];Av=[sum(x*y for x,y in zip(row,vec)) for row in old];alpha=sum(x*y for x,y in zip(vec,Av));variance=sum(x*x for x in Av)-alpha*alpha;assert alpha==1 and variance==1
    J=np.array([[[1,1,0,0],[1,1,0,0],[0,0,1,0],[0,0,0,1]]],np.int64);assert psd(J,(0,1))[0]
    assert 5<3**2 and 8+2-2*(variance+variance)==6
    # Exact full characteristic product of the +/- exchange sectors.
    pplus=[1,-3,1];pminus=[1,-1,-1];poly=[0]*5
    for i,x in enumerate(pplus):
        for j,y in enumerate(pminus):poly[i+j]+=x*y
    assert poly==[1,-4,3,2,-1] and 5<F(9,4)**2 and F(17,2)+F(9,8)<10
    def contact_ok(l,k):assert 0<=l<=k
    for l,k in ((-1,0),(1,0)):
        try:contact_ok(l,k)
        except AssertionError:pass
        else:raise AssertionError('Incorrect interface accepted')
    # Independent graph-domain controls for outerplanarity.
    assert outerplane(range(4),{(0,1),(1,2),(2,3),(0,3)})
    assert not outerplane(range(4),set(combinations(range(4),2)))
    assert not outerplane(range(5),{(i,j) for i in (0,1) for j in (2,3,4)})
    return dict(valid_scalar_pair_and_exact_bonus=True,nonPSD_core_rejected=True,missing_variance_false_bound_rejected=True,negative_or_overshooting_interface_rejected=True,C4_pass_K4_K23_fail=True)

def same_table(a,b):assert a.dtype==b.dtype and np.array_equal(a,b)
def same_domain(a,b):assert np.array_equal(a,b)

def damage_controls(tab,domain):
    for damage in ('missing_candidate','duplicate_candidate','changed_private_count'):
        bad=domain.copy()
        if damage=='missing_candidate':bad=bad[:-1]
        elif damage=='duplicate_candidate':bad[-1]=bad[0]
        else:bad[-1,0]+=1
        try:same_domain(domain,bad)
        except AssertionError:pass
        else:raise AssertionError('Candidate coverage damage accepted:'+damage)
    bad=tab['V'].copy();assert bad[4,2,2]>0;bad[4,2,2]=0
    try:same_table(tab['V'],bad)
    except AssertionError:pass
    else:raise AssertionError('Missing variance table accepted')
    return True

def main():
    if '--manifest' in sys.argv:
        for n,h in read('coupled-bridge-244-manifest.json')['artifact_sha256'].items():assert Path(n).name==n and sha(n)==h,n
    c=read('coupled-bridge-244-certificate.json');assert c['n_range']==[72,159] and c['unpaid_profiles']==0 and sha('coupled-bridge-244-witnesses.npz')==c['archive_sha256'];tab=rebuild_tables()
    with np.load(ROOT/'coupled-bridge-244-witnesses.npz',allow_pickle=False) as zz:z={k:zz[k] for k in zz.files}
    for k,x in tab.items():same_table(z[k],x)
    assert all(controls().values());catalogue=core_catalogue();assert len(catalogue)==len(c['rows'])==9;proofs={(p['core_index'],tuple(p['shared_masks'])):p for p in c['proofs']};assert len(proofs)==len(c['proofs'])==303;used=set();counts=[];candidate_total=0;checked=0;impossible=0;fallback_cases=0;hub_cases=0;keys=set(tab);damage_checked=False
    for ci,(core,row) in enumerate(zip(catalogue,c['rows'])):
        E=set(core['edges']);assert E==set(map(tuple,row['core']['edges'])) and core['t3']==row['core']['t3'];A,cs,raw,completed=shared_catalogue(core);assert len(raw)==row['unowned_types'];autos=[p for p in permutations(range(4)) if {tuple(sorted((p[a],p[b]))) for a,b in E}==E];assert autos==list(map(tuple,row['automorphisms']));canon={};mapping={tuple(x['source']):x for x in row['orbit_map']};assert set(mapping)==raw
        for masks in raw:
            orbit=[]
            for p in autos:orbit.append((tuple(sorted(sum(1<<p[i] for i in range(4) if m>>i&1) for m in masks)),p))
            cm,perm=min(orbit);assert cm in raw and mapping[masks]['canonical']==list(cm) and mapping[masks]['permutation']==list(perm);canon[cm]=True
        assert len(canon)==row['representatives'];core_candidates=0;admitted=0
        for masks in sorted(canon):
            A,T,ds,a,shared,chs=choices(E,masks)
            if not chs:assert (ci,masks) not in proofs;continue
            admitted+=1;proof=proofs[ci,masks];used.add((ci,masks));index=proof['index'];assert proof['fixed_owner']==list(chs[0]['owners']) and proof['choices']==len(chs);private=domain_candidates(E,masks,chs[0],tab['E'],core['t3']);key='r'+str(index);keys|={key+s for s in('_private','_owner','_kind','_lower')};same_domain(private,z[key+'_private']);assert len(private)==proof['candidates'];owner=z[key+'_owner'];kind=z[key+'_kind'];stored=z[key+'_lower'];assert owner.shape==kind.shape==stored.shape==(len(private),) and owner.dtype==kind.dtype==np.uint8 and stored.dtype==np.int64;n=private.astype(np.int64).sum(axis=1)+4+len(masks);target=2*n*S2;assert np.all(stored>=target);candidate_total+=len(private);core_candidates+=len(private)
            if len(private)>1 and not damage_checked:damage_checked=damage_controls(tab,private)
            for code in sorted(set(map(int,kind))):
                for ix in sorted(set(map(int,owner[kind==code]))):
                    ids=np.flatnonzero((kind==code)&(owner==ix));P=private[ids].astype(np.int64);tg=target[ids]
                    if code==128:
                        assert ix<4;d=P[:,ix]+a[ix]+shared[ix];assert np.all(tab['hub_paid'][n[ids],d]);hub_cases+=len(ids);continue
                    if code==129:
                        for p in P:
                            assert all(all_p(p,ch,E,masks,tab,core['t3'])[0] is None for ch in chs);impossible+=1
                        continue
                    assert ix<len(chs);ch=chs[ix]
                    if code==64:
                        for p,tg0 in zip(P,tg):
                            value,count=all_p(p,ch,E,masks,tab,core['t3']);assert value is not None and value>=tg0;fallback_cases+=count
                        checked+=len(ids);continue
                    assert code==0 or 2<=code<=18;valid,en,C,v=data(P,ch,E,masks,tab,core['t3']);value,good=charge(en,C,v,code);assert np.all(~valid|(good&(value>=tg)));impossible+=int((~valid).sum());checked+=int(valid.sum())
        assert core_candidates==row['candidates'];counts.append(dict(core_index=ci,raw_types=len(raw),all_unfiltered_completed_types=completed,representatives=len(canon),admitted=admitted,candidate_profiles=core_candidates));print('INDEPENDENT_BRIDGE244',ci,'raw',len(raw),'representatives',len(canon),'admitted',admitted,'candidates',core_candidates,flush=True)
    assert used==set(proofs) and keys==set(z) and candidate_total==c['total_candidates']==286769 and damage_checked
    # Exact inherited analytic h4 tail:7+(173/14)^2 has ceiling160.
    tail=F(7)+F(173,14)**2;assert 159<tail<=160
    out=dict(status='PASS_INDEPENDENT_GAMMA4_PARAMETER_BRIDGE72_TO159_244',original='GLOBAL OPEN',certificate_sha256=sha('coupled-bridge-244-certificate.json'),archive_sha256=c['archive_sha256'],n_range=[72,159],core_types=9,raw_shared_types=sum(r['raw_types'] for r in counts),orbit_representatives=sum(r['representatives'] for r in counts),admitted_representatives=len(proofs),candidate_profiles=candidate_total,verified_energy_profiles=checked,verified_wholehub_profiles=hub_cases,explicitly_impossible_profiles=impossible,same_p_cases=fallback_cases,table_cells_compared=5*156*11*11,rows=counts,controls=dict(**controls(),missing_duplicate_changed_candidate_and_zero_variance_table_rejected=damage_checked),inherited_tail_threshold=160,scope='Independent64graph/Hamiltonianouterplane/catalogue/MITMcandidates/Fractiontables/Laplaceminors/ownerproofreader. Newfinitebridgepluswrittenlemma; fullgamma<=4alsoUSESdeclaredinherited8..71cover/176/190/wholehubinputs. NotoriginalALLMOPclosure/human/formalaudit.')
    (ROOT/'coupled-bridge-244-verification.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf8');print('PASS_INDEPENDENT_FULL_GAMMA4_BRIDGE244',candidate_total,'profiles;9cores; originalGLOBALOPEN',flush=True)
if __name__=='__main__':main()
