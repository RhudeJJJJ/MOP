"""Exact finite constants in the analytic split-fan tails; no floats."""
if not __debug__:
    raise RuntimeError('Assertions must remain enabled; do not use python -O')
from fractions import Fraction as Q
from math import isqrt
from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parent
a=[Q(13*p,35)-Q(9,4)+2*(1-Q(p,100))**2 for p in range(1,7)]
b=[-4+2*(1-Q(p,100))**2+(1-Q(p,100))/4+2*Q(isqrt(p*10**12),10**6)-Q(p,5) for p in range(1,34)]
assert min(a)==Q(2857,35000)>0
assert min(b)==Q(77,10000)>0
assert Q(159)<7+Q(173,14)**2<Q(160)
assert 2*Q(10)>Q(73,4)
assert Q(528,225)>0 # q30 strict Perron test excess
assert 2*Q(583,100)*(1-Q(71,100))-Q(27,8)==Q(4,625)
out=dict(status='PASS_EXACT_FINITE_CONSTANTS_IN_ANALYTIC_GAMMA_TAILS',A_six_minimum=str(min(a)),B_33_minimum=str(min(b)),gamma4_threshold=str(7+Q(173,14)**2),scope='Only finite constants in displayed analytic proofs, not a global theorem check',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(P/'extraction_gamma_tail_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
