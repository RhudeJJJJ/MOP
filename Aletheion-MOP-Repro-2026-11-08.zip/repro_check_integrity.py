"""Content integrity only. This is not a mathematical certificate checker."""
if not __debug__:
    raise RuntimeError('Assertions must remain enabled; do not use python -O')

from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parent
def main():
    manifest=json.loads((ROOT/'REPRO_MEMBERS.json').read_bytes());raw=0
    for row in manifest['members']:
        rel=Path(row['relative']);assert not rel.is_absolute()and'..'not in rel.parts;p=ROOT/rel;b=p.read_bytes();assert len(b)==row['bytes']and hashlib.sha256(b).hexdigest()==row['sha256'],str(rel);raw+=len(b)
    print(json.dumps(dict(status='ALL_EXPLICIT_CONTENT_HASHES_MATCH',members=len(manifest['members']),raw_bytes=raw,scope='Byte integrity only; run mathematical readers separately.')))
if __name__=='__main__':main()
