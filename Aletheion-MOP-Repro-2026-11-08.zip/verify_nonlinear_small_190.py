from pathlib import Path
from fractions import Fraction as F
from math import isqrt
from itertools import product
import json,hashlib
from verify_tighter_charge_small_190 import score
ROOT=Path(__file__).resolve().parent
def target(q,p):
    scale=10**6;r=isqrt(q*scale*scale);u=F(r,scale) if r*r==q*scale*scale else F(r+1,scale)
    lo=F(isqrt(p*scale*scale),scale)
    return F(2*q-p)+2*u-2*lo-F(q-p,4*q)
def main():
    initial=json.loads((ROOT/'nonlinear-charge-190-initial-screen.json').read_text())
    C=json.loads((ROOT/'nonlinear-charge-190-small-certificate.json').read_text());required=set()
    for r in initial['failures']:
        q,p,s=r['q'],r['p'],r['s'];m=q-p
        for weights in product(range(1,m+1),repeat=s):
            if sum(weights)==m:required.add((q,p,s,tuple(sorted([1]*(p-s)+[x+1 for x in weights]))))
    keys=[(r['q'],r['p'],r['s'],tuple(r['parts'])) for r in C['records']]
    assert len(keys)==len(set(keys)) and set(keys)==required
    margins=[]
    for r in C['records']:
        bound=score(r,C['denominator'])[1];gap=bound-target(r['q'],r['p']);assert gap>0
        margins.append(gap)
    damaged=dict(C['records'][0]);damaged['factor']=[[0] for _ in damaged['factor']]
    try:
        bound=score(damaged,C['denominator'])[1]
        assert bound>target(damaged['q'],damaged['p'])
    except AssertionError:rejected=True
    else:raise AssertionError('Damaged Gram factor accepted')
    out={'status':'PASS_NONLINEAR_ALL_FINITE_SHAPES_INTEGER_PSD','parameter_shapes':len(initial['failures']),
      'records':len(keys),'minimum_margin':str(min(margins)),'zero_factor_rejected':rejected,
      'certificate_sha256':hashlib.sha256((ROOT/'nonlinear-charge-190-small-certificate.json').read_bytes()).hexdigest(),
      'original':'GLOBAL OPEN','scope':'Exact original matrices and full exceptional-shape coverage; no eigenvalue numerics used for proof'}
    (ROOT/'nonlinear-charge-190-small-verification.json').write_text(json.dumps(out,indent=2)+'\n')
    print(out,flush=True)
if __name__=='__main__':main()
