"""Exact min-plus bound on three ORIGINAL assigned hub blocks."""
from pathlib import Path
from fractions import Fraction as F
import json
from probe_connected_triple_payment_188 import bound
ROOT=Path(__file__).resolve().parent

def main():
    capQ=134;capP=9
    cells={(q,p):bound(q,p) for q in range(1,capQ+1)
           for p in range(1,min(q,capP)+1)}
    tables={1:{(q,p):(v,[(q,p)]) for (q,p),v in cells.items()}}
    transitions=0
    for h in (2,3):
        D={}
        for Q in range(h,capQ+1):
            for P in range(h,min(Q,capP)+1):
                best=None;arg=None
                for q in range(1,Q-h+2):
                    for p in range(1,min(q,P-h+1)+1):
                        if (Q-q,P-p) not in tables[h-1]:continue
                        prior,trace=tables[h-1][Q-q,P-p]
                        value=prior+cells[q,p];transitions+=1
                        if best is None or value<best:best=value;arg=[(q,p)]+trace
                assert best is not None
                D[Q,P]=(best,arg)
        tables[h]=D
        print('PASS_MINPLUS_TABLE',h,len(D),transitions,flush=True)
    rows=[]
    for n in range(8,138):
        Q=n-3
        for e in (0,1,2):
            budget=9-e
            value,arg=min((tables[3][Q,P] for P in range(3,min(Q,budget)+1)),key=lambda t:t[0])
            rows.append({'n':n,'e_H_lower':e,'path_budget':budget,'margin':str(value-2*n),'blocks_q_p':arg})
    tails={}
    for e in (0,1,2):
        unpaid=[r['n'] for r in rows if r['e_H_lower']==e and F(r['margin'])<=0]
        tails[str(e)]=max(unpaid)+1 if unpaid else 8
    out={'status':'EXACT_MINPLUS_THREE_HUB_SUFFICIENT_SCREEN','cells':[
          {'q':q,'p':p,'lower':str(v)} for (q,p),v in cells.items()],
         'rows':rows,'sufficient_tail_within_screen':tails,'transitions':transitions,
         'original':'GLOBAL OPEN','scope':'Complete allocation relaxation, not actual graph search; analytic infinite tail still required'}
    (ROOT/'domination-three-paths-189-screen.json').write_text(json.dumps(out,indent=2)+'\n')
    print('EXACT_SUFFICIENT_TAILS189',tails,flush=True)
    print('N72', [r for r in rows if r['n']==72],flush=True)

if __name__=='__main__':main()
