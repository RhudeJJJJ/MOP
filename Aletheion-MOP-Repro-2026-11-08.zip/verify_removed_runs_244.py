"""Independent actual-graph calibration of removed-neighbor component bounds."""
from pathlib import Path
from itertools import combinations,product
from math import comb
import json
ROOT=Path(__file__).resolve().parent

def polygon(V):
    if len(V)==2:yield {tuple(sorted(V))};return
    a,b=V[0],V[-1]
    for j in range(1,len(V)-1):
        for left in polygon(V[:j+1]):
            for right in polygon(V[j:]):yield left|right|{tuple(sorted((a,b)))}

def adjacency(V,E):
    A={v:set() for v in V}
    for a,b in E:A[a].add(b);A[b].add(a)
    return A

def parts(V,A):
    todo=set(V);count=0
    while todo:
        count+=1;stack=[todo.pop()]
        while stack:
            for w in A[stack.pop()]&todo:todo.remove(w);stack.append(w)
    return count

def bound(A,H,assignment,allow_adjacent=False):
    shared=[v for v in A if v not in H and len(A[v]&H)>=2];forced=set()
    for a,b in combinations(sorted(H),2):
        if b in A[a] and not allow_adjacent:continue
        vs=[v for v in shared if {a,b}<=A[v]]
        if len(vs)==2:forced.add(tuple(vs))
    strict=0;checks=0
    for i in H:
        kept={v for v,j in assignment.items() if j==i}
        if not kept:continue
        removed=A[i]-kept;actual_removed_edges=sum(len(A[v]&removed) for v in removed)//2;assert actual_removed_edges==len(removed)-parts(removed,A)
        selected=A[i]&H;lost={v for v in removed if v not in H};tau=sum(w in A[v] for v,w in combinations(selected,2));ho=sum(len(A[v]&selected) for v in lost);oo=sum(v in lost and w in lost for v,w in forced);known=tau+ho+oo
        assert known<=actual_removed_edges
        lower_removed_components=len(removed)-actual_removed_edges;cap=len(removed)-known+1;p=parts(kept,A);assert p<=lower_removed_components+1<=cap
        old=len(lost)+1-(len(selected)-tau)+sum(len(A[v]&selected) for v in kept);assert p<=old
        strict+=cap<old;checks+=1
    return checks,strict

def main():
    graphs=0;marked=0;assignments=0;checks=0;strict=0;first=None
    for n in range(4,10):
        count_before=graphs
        for E in polygon(tuple(range(n))):
            A=adjacency(range(n),E);graphs+=1
            for hs in combinations(range(n),4):
                H=set(hs);O=set(range(n))-H
                if any(not(A[v]&H) for v in O):continue
                marked+=1;vs=sorted(O)
                for owners in product(*(sorted(A[v]&H) for v in vs)):
                    ass=dict(zip(vs,owners));c,s=bound(A,H,ass);assignments+=1;checks+=c;strict+=s
                    if s and first is None:first=dict(n=n,edges=sorted(E),H=sorted(H),assignment=ass)
        print('REMOVED_RUNS244',n,graphs,marked,assignments,checks,strict,flush=True)
        assert graphs-count_before=={4:2,5:5,6:14,7:42,8:132,9:429}[n]
    # Exact MOP5 control: an adjacent selected pair's two common outside
    # neighbors are NOT forced adjacent. A fake edge would claim p<=0.
    E={(0,1),(0,2),(1,2),(0,3),(1,3),(1,4),(2,4)};A=adjacency(range(5),E);H={0,1};ass={2:0,3:0,4:1};bound(A,H,ass)
    try:bound(A,H,ass,True)
    except AssertionError:bad_adj=True
    else:raise AssertionError('Falseadjacent-pairOOedgeaccepted')
    assert strict>0 and first is not None
    out=dict(status='PASS_REMOVED_NEIGHBOR_RUN_BOUND244',original='GLOBAL OPEN',graphs=graphs,dominating_marked_foursets=marked,all_owner_assignments=assignments,nonempty_hub_blocks=checks,strict_improvements_over_old_cap=strict,first_strict=first,controls=dict(actual_MOP5_passes=True,false_forced_OO_for_adjacent_H_pair_rejected=bad_adj),scope='Completepolygon4..9/allDOMINATINGmarkedH4/allactualowners finitecalibration. Writtenall-orderneighborpathargumentisproof; notfiniteextrapolation/gamma4energyclosure.')
    (ROOT/'removed-runs-244-verification.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf8');print('PASS_REMOVED_RUNS244',graphs,assignments,checks,strict,flush=True)
if __name__=='__main__':main()
