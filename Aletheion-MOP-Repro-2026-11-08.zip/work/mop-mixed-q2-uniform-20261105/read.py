"""Full coverage and arithmetic reader; does not import certificate producer."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
import json,hashlib,copy,sys,time
import curve_interval as c
from exact_controls import private,control
P=Path(__file__).resolve().parent
def verify_curve(data,recompute=True):
 r=data['r'];assert r in(2,3,4,5);total=F(0);cells=0
 for region,end in [('compact',F(4)),('tail',F(1,4))]:
  rows=[x for x in data['leaves']if x['region']==region];assert rows;pos=F(0)
  for row in rows:
   a,b=F(row['a']),F(row['b']);assert a==pos and a<b<=end;pos=b;vp=F(0);uppers=[];lowers=[]
   for j,cell in enumerate(row['v']):
    assert len(cell)==4;v,w,lo,hi=map(F,cell);assert v==vp and 0<=v<w<=1 and lo<=hi;vp=w
    if recompute:assert c.enclosure(region,r,a,b,v,w)==(lo,hi)
    uppers.append(hi);lowers.append(lo);cells+=1
   assert vp==1 and len(row['v'])==data['nv']
   assert max(uppers)==F(row['upper']) and max(lowers)==F(row['lower'])
   total+=(b-a)*max(uppers)
  assert pos==end
 assert all(x['region']in('compact','tail')for x in data['leaves'])
 assert total==F(data['upper'])<F(5,4) and cells==data['cells']
 return total,cells
def gram(data):
 B,T=private(3);W=data['factor'];D=data['denominator'];assert data['p']==3 and data['q']==2 and len(W)==6 and all(len(x)==6 and all(type(y)is int for y in x)for x in W)
 Z=c.h.mm(W,c.h.tr(W));G=c.h.mm(c.h.tr(W),W)
 value=F(2*sum(B[i][j]*Z[j][i]for i in range(6)for j in range(6)),D**2)-F(sum(x*x for row in G for x in row),D**4)
 assert value>F(137,20);return value
def oldsmall():
 sys.path.insert(0,str(P.parent/'mop-terminal-fan-20261105'));from read_small_cores_geometry import allsets
 rows=[]
 for n in range(3,8):
  cases=allsets(n)
  for edges in cases:
   witness=next(pair for pair in combinations(range(n),2)if all(v in pair or any(tuple(sorted((v,u)))in edges for u in pair)for v in range(n)))
   rows.append(dict(n=n,edges=sorted(edges),dominating_pair=witness))
 assert len(rows)==64;return rows
def rejected(fn):
 try:fn()
 except (AssertionError,ArithmeticError):return True
 return False
def main():
 data=json.loads((P/'curve-certificates.json').read_text());assert data['format']=='all-v-whole-positive-line-four-curves-v1' and [z['r']for z in data['curves']]==[2,3,4,5]
 bounds=[];total=0
 for row in data['curves']:
  value,n=verify_curve(row);bounds.append(str(value));total+=n;print(json.dumps(dict(r=row['r'],fully_recomputed_cells=n,upper=float(value))),flush=True)
 gd=json.loads((P/'private-p3-gram.json').read_text());score=gram(gd);controls=control();small=oldsmall()
 bad=copy.deepcopy(data['curves'][0]);bad['leaves'][0]['v'].pop()
 missing=copy.deepcopy(data['curves'][0]);missing['leaves']=[z for z in missing['leaves']if z['region']!='tail']
 broken=copy.deepcopy(gd);broken['factor']=[[0]*6 for _ in range(6)]
 damage=dict(missing_v_cell=rejected(lambda:verify_curve(bad,False)),missing_entire_tail=rejected(lambda:verify_curve(missing,False)),broken_private_Gram=rejected(lambda:gram(broken)))
 assert all(damage.values());L,U=c.h.machin_pi();assert L>F(157,50)
 margin=F(17,20)-F(125,157);assert margin==F(169,3140)>F(1,20)
 out=dict(status='PASS_EXACT_MIXED_Q2_ALL_OUTWARD_LENGTHS_FOUR_CONTINUOUS_CURVES',curves_upper=bounds,fully_recomputed_cells=total,private_p3_F_lower=str(score),private_uniform_surplus='>17/20 for every p>=2',universal_increment='>2(p+3)+1/20 for any old UNIT MOP order>=3, any ordered boundary edge; no old degree/order upper bound',margin_lower=str(margin),exact_direct_matrix_controls=controls,oldsmall_domination_witnesses=small,damaged_rejected=damage,original_status='GLOBAL_OPEN',remaining_mixed_inward_lengths=[15,16,17,18,19,20],external_external='OPEN including unrestricted Fork6',source_scope='Independent producer/reader control flow shares directed interval module and inherited algebra; no external formal audit. Gamma<=4 small-old consequence retains source244 inherited-input boundary.',proof_sha256=hashlib.sha256((P/'uniform-q2-proof.md').read_bytes()).hexdigest(),certificate_sha256=hashlib.sha256((P/'curve-certificates.json').read_bytes()).hexdigest())
 (P/'reader-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:out[k]for k in('status','fully_recomputed_cells','margin_lower','damaged_rejected','original_status')}))
if __name__=='__main__':main()
