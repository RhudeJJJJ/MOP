"""Exact rational integration of an envelope over all v, not sampled v."""
from pathlib import Path
from fractions import Fraction as F
import json,time,heapq,sys
import curve_interval as c
P=Path(__file__).resolve().parent
def slab(region,r,a,b,nv):
 rows=[]
 for j in range(nv):
  lo,hi=c.enclosure(region,r,a,b,F(j,nv),F(j+1,nv))
  rows.append([str(F(j,nv)),str(F(j+1,nv)),str(lo),str(hi)])
 return dict(a=str(a),b=str(b),v=rows,lower=str(max(F(x[2])for x in rows)),upper=str(max(F(x[3])for x in rows)))
def integrate(r,nv=16):
 leaves={};heap=[];counter=0;lower=F(0);upper=F(0);cells=0
 def insert(region,a,b):
  nonlocal counter,lower,upper,cells
  try:row=slab(region,r,a,b,nv)
  except (ArithmeticError,AssertionError):
   mid=(a+b)/2;insert(region,a,mid);insert(region,mid,b);return
  row['region']=region;leaves[counter]=row
  low=(b-a)*F(row['lower']);high=(b-a)*F(row['upper']);lower+=low;upper+=high;cells+=nv
  heapq.heappush(heap,(-(high-low),counter));counter+=1
 for region,n,end in [('compact',32,F(4)),('tail',8,F(1,4))]:
  for j in range(n):insert(region,end*j/n,end*(j+1)/n)
 print(json.dumps(dict(r=r,stage='initial',slabs=len(leaves),upper=float(upper))),flush=True)
 t0=time.time();last=t0
 while upper>=F(5,4):
  _,key=heapq.heappop(heap);row=leaves.pop(key);a,b=F(row['a']),F(row['b']);lower-=(b-a)*F(row['lower']);upper-=(b-a)*F(row['upper']);mid=(a+b)/2
  insert(row['region'],a,mid);insert(row['region'],mid,b)
  if time.time()-last>35:
   print(json.dumps(dict(r=r,stage='refining',slabs=len(leaves),cells_evaluated=cells,upper=float(upper),seconds=round(time.time()-t0,1))),flush=True);last=time.time()
  assert len(leaves)<30000,'no cheap closure: inspect v dependency before repeating'
 rows=sorted(leaves.values(),key=lambda z:(z['region'],F(z['a'])))
 return dict(r=r,nv=nv,leaves=rows,lower=str(lower),upper=str(upper),cells=nv*len(rows),evaluated=cells)
def main():
 results=[]
 for r in (2,3,4,5):
  part=integrate(r);results.append(part);(P/f'curve-r{r}-certificate.json').write_text(json.dumps(part,separators=(',',':'))+'\n')
  print(json.dumps(dict(r=r,status='CERTIFICATE_PRODUCED_NOT_YET_INDEPENDENTLY_READ',upper=float(F(part['upper'])),cells=part['cells'])),flush=True)
 (P/'curve-certificates.json').write_text(json.dumps(dict(format='all-v-whole-positive-line-four-curves-v1',curves=results),separators=(',',':'))+'\n')
if __name__=='__main__':main()
