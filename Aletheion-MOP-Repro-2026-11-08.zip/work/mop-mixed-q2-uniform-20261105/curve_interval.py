"""Directed rational enclosures of FOUR bounded curve families, no p cutoff."""
from pathlib import Path
from fractions import Fraction as F
import sys
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'mop-negative-modes-20261105'));import homotopy_interval as h
C=h.con;add=h.add;sub=h.sub;mul=h.mul;div=h.div;sq=h.square;scale=h.times;sqrt=h.sqrt
def powi(a,n):
    out=C(1)
    for _ in range(n):out=mul(out,a)
    return out
def clip(a,lo=F(0),hi=F(1)):
    assert a[1]>=lo and a[0]<=hi;return max(a[0],lo),min(a[1],hi)
def ca(a,b):return add(a[0],b[0]),add(a[1],b[1])
def cn(a):return h.neg(a[0]),h.neg(a[1])
def cs(a,b):return ca(a,cn(b))
def cr(a,x):return mul(a[0],x),mul(a[1],x)
def cm(a,b,y=None):
    # y omitted: ordinary a+i*b; y=z^2: a+i*z*b.
    return sub(mul(a[0],b[0]),mul(mul(a[1],b[1]),C(1)if y is None else y)),add(mul(a[0],b[1]),mul(a[1],b[0]))
def ci(a,y=None,minnorm=None):
    den=add(sq(a[0]),mul(C(1)if y is None else y,sq(a[1])))
    if minnorm is not None:den=max(den[0],minnorm),den[1]
    return div(a[0],den),h.neg(div(a[1],den))
def cd(a,b,y=None,minnorm=None):return cm(a,ci(b,y,minnorm),y)
def real(a):return a,C(0)
def pathpol(t,r,tail=False):
    a=C(1);b=C(1)if tail else t
    for _ in range(2,r+1):a,b=b,add(b,mul(sq(t),a))if tail else add(mul(t,b),a)
    return a,b
def compact_params(t,r,v):
    lam=div(C(2),add(t,sqrt(add(sq(t),C(4)))))
    hinf=div(lam,add(C(1),lam));prev,cur=pathpol(t,r)
    delta=div(powi(lam,r+1),mul(add(prev,cur),add(C(1),lam)))
    signed=scale(delta,1 if r%2 else -1);vv=sq(v);hh=clip(add(hinf,mul(vv,signed)))
    bracket=sub(add(C(2),mul(t,sub(C(1),scale(hinf,2)))),mul(mul(t,vv),signed))
    magnitude=mul(v,sqrt(mul(delta,h.positive(bracket))))
    kk=(scale(magnitude,-1 if r==3 else 1),C(0))if r%2 else(C(0),scale(magnitude,-1 if r==2 else 1))
    return hh,kk
def compact_raw(t,r,hh,kk):
    one=sub(C(1),hh);t2=sq(t);t3=mul(t2,t);t4=sq(t2)
    Z=(t,C(2));D=(add(mul(add(t3,scale(t,3)),one),mul(add(t2,C(1)),hh)),scale(one,-2))
    N0=(add(sub(t4,t2),C(2)),add(scale(t3,4),scale(t,8)))
    Nf=(mul(t,sub(t2,C(3))),scale(add(t2,C(2)),4))
    Ne=(scale(t,-4),scale(add(t2,C(3)),2))
    N=ca(ca(cr(N0,one),cr(Nf,hh)),cm(Ne,kk))
    faa=ca(cd(real(C(r)),Z),cd(N,cm(cm(Z,Z),D)))
    abnum=ca(ca(cr((t,C(1)),one),real(hh)),kk)
    fab=cm(cd((t2,h.neg(t)),Z),cd(abnum,D,minnorm=F(4,5)))
    fbb=cd(ca(cr((scale(t2,2),scale(t,-2)),one),real(mul(t,hh))),D,minnorm=F(4,5))
    return [[faa,fab],[fab,fbb]]
def matmul(A,B):return [[add(mul(A[i][0],B[0][j]),mul(A[i][1],B[1][j]))for j in range(2)]for i in range(2)]
KI=[[C(F(2,3)),C(-F(1,3))],[C(-F(1,3)),C(F(2,3))]]
def trace(A):return add(A[0][0],A[1][1])
def det(A):return sub(mul(A[0][0],A[1][1]),mul(A[0][1],A[1][0]))
def support(t,Fc):
    R=[[v[0]for v in row]for row in Fc];I=[[v[1]for v in row]for row in Fc]
    KR=matmul(KI,R);KIi=matmul(KI,I)
    norm2=h.positive(add(trace(matmul(KR,KR)),trace(matmul(KIi,KIi))))
    dc=cs(cm(Fc[0][0],Fc[1][1]),cm(Fc[0][1],Fc[0][1]));absdet=sqrt(add(sq(dc[0]),sq(dc[1])))
    nuclear=sqrt(h.positive(add(norm2,scale(absdet,F(2,3)))))
    result=add(sub(trace(KIi),scale(mul(t,trace(KR)),F(1,2))),scale(mul(sqrt(add(sq(t),C(4))),nuclear),F(1,2)))
    return h.positive(result)
def tail_params(z,r,v):
    y=sq(z);L=div(C(2),add(C(1),sqrt(add(C(1),scale(y,4)))))
    prev,cur=pathpol(z,r,True);A=div(powi(L,r+1),mul(add(cur,mul(z,prev)),add(C(1),mul(z,L))))
    hinf=div(mul(z,L),add(C(1),mul(z,L)));sign=1 if r%2 else -1;vv=sq(v)
    delta=scale(mul(powi(z,2*r+1),A),sign)
    H=add(div(L,add(C(1),mul(z,L))),scale(mul(mul(vv,powi(z,2*r)),A),sign))
    bracket=sub(sub(add(C(1),scale(z,2)),scale(hinf,2)),mul(vv,delta))
    gamma=mul(v,sqrt(mul(A,h.positive(bracket))))
    J=(scale(mul(powi(z,r-1),gamma),-1 if r==3 else 1),C(0))if r%2 else(C(0),scale(mul(powi(z,r-2),gamma),-1 if r==2 else 1))
    return H,J
def tail_raw(z,r,H,J):
    y=sq(z);z4=sq(y);one=sub(C(1),mul(z,H))
    Z=(C(1),C(2));D=(add(mul(add(C(1),scale(y,3)),one),mul(mul(y,add(C(1),y)),H)),scale(mul(y,one),-2))
    N0=(add(sub(C(1),y),scale(z4,2)),add(C(4),scale(y,8)))
    Nf=(mul(sub(y,scale(z4,3)),H),mul(add(scale(y,4),scale(z4,8)),H))
    Ne=(scale(z4,-4),add(scale(y,2),scale(z4,6)))
    N=ca(ca(cr(N0,one),Nf),cm(Ne,J,y))
    uaa=ca(cd(real(C(r)),Z,y),cd(N,cm(cm(Z,Z,y),D,y),y))
    Nab=ca(ca(cr((C(1),C(1)),one),real(mul(y,H))),cr(J,y))
    uab=cd(cm((C(1),C(-1)),Nab,y),cm(Z,D,y),y)
    ubb=cd(ca(cr((C(2),C(-2)),one),real(mul(y,H))),D,y)
    return [[uaa,uab],[uab,ubb]]
def tail_support(z,U):
    Q=[[v[0]for v in row]for row in U];M=[[h.neg(v[1])for v in row]for row in U];y=sq(z)
    dQ=det(Q)
    if Q[0][0][0]<=0 or dQ[0]<=0:raise ArithmeticError('split: tail Qhat positive definite not enclosed')
    Cq=matmul(KI,Q);Cm=matmul(KI,M);q=trace(Cq);m=trace(Cm);u=scale(dQ,F(1,3));v=scale(det(M),F(1,3))
    w=scale(sub(add(mul(Q[0][0],M[1][1]),mul(Q[1][1],M[0][0])),scale(mul(Q[0][1],M[0][1]),2)),F(1,3))
    disc=h.positive(sub(sq(w),scale(mul(u,v),4)))
    rad=sqrt(add(sq(sub(u,mul(y,v))),mul(y,sq(w))))
    den=add(add(rad,u),mul(y,v));den=max(den[0],2*u[0]),den[1]
    hh=div(disc,den);fac=add(C(1),scale(y,4))
    numerator=add(sq(sub(scale(q,2),m)),scale(mul(fac,hh),2))
    denominator=scale(add(add(sqrt(mul(fac,h.positive(add(sq(q),mul(y,add(sq(m),scale(hh,2))))))),q),scale(mul(y,m),2)),2)
    denominator=max(denominator[0],4*q[0]),denominator[1]
    return h.positive(div(numerator,denominator))
def enclosure(region,r,a,b,c,d):
    x=(F(a),F(b));v=(F(c),F(d));assert r in (2,3,4,5) and 0<=a<b and 0<=c<d<=1
    if region=='compact':H,J=compact_params(x,r,v);return support(x,compact_raw(x,r,H,J))
    assert region=='tail';H,J=tail_params(x,r,v);return tail_support(x,tail_raw(x,r,H,J))
