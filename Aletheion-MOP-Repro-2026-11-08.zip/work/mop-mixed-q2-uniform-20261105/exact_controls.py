"""Independent exact rational complex elimination controls (no float spectra)."""
from fractions import Fraction as F
import curve_interval as c
Z=(F(0),F(0));ONE=(F(1),F(0))
def a(x,y):return x[0]+y[0],x[1]+y[1]
def n(x):return -x[0],-x[1]
def m(x,y):return x[0]*y[0]-x[1]*y[1],x[0]*y[1]+x[1]*y[0]
def d(x,y):return m(x,(y[0]/(y[0]**2+y[1]**2),-y[1]/(y[0]**2+y[1]**2)))
def inverse(A):
 k=len(A);M=[row[:]+[ONE if i==j else Z for j in range(k)]for i,row in enumerate(A)]
 for j in range(k):
  v=next(i for i in range(j,k)if M[i][j]!=Z);M[j],M[v]=M[v],M[j];pivot=M[j][j];M[j]=[d(x,pivot)for x in M[j]]
  for i in range(k):
   if i!=j:
    q=M[i][j];M[i]=[a(x,n(m(q,y)))for x,y in zip(M[i],M[j])]
 return [row[k:]for row in M]
def inside(value,interval):assert interval[0]<=value<=interval[1]
def private(p):
 k=p+3;B=[[F(0)]*k for _ in range(k)]
 for i,j in [(0,p),(0,p+1),(0,p+2),(p+1,p+2)]+[(j,j+1)for j in range(1,p)]:B[i][j]=B[j][i]=F(1)
 T=[[F(int(i<=p))for i in range(k)],[F(int(i in(0,p+1)))for i in range(k)]]
 return B,T
def control():
 count=0
 for p in range(2,14):
  r=2+(p-2)%4;B,T=private(p);k=len(B)
  for t in (F(1,4),F(1),F(4)):
   inv=inverse([[(t if i==j else F(0),B[i][j])for j in range(k)]for i in range(k)])
   cap=[[tuple(sum(T[i][a0]*inv[a0][b][part]*T[j][b]for a0 in range(k)for b in range(k))for part in range(2))for j in range(2)]for i in range(2)]
   prev,cur=F(1),t
   for j in range(2,p+1):prev,cur=cur,t*cur+prev
   f=prev/cur;phase=[ONE,(0,-1),(-1,0),(0,1)][(p-1)%4];e=(phase[0]/cur,phase[1]/cur)
   assert e[1]*e[0]==0 and e[0]**2-e[1]**2==f*f+t*f-1
   hh=c.C(f/(1+f));kk=(c.C(e[0]/(1+f)),c.C(e[1]/(1+f)))
   compact=c.compact_raw(c.C(t),r,hh,kk)
   shaved=d((F(p-r),F(0)),(t,F(2)))
   for i in range(2):
    for j in range(2):
     target=a(cap[i][j],n(shaved))if i==j==0 else cap[i][j]
     for part in range(2):inside(target[part],compact[i][j][part])
   if t==4:
    H=c.C(f/(1+f)*t);J=(c.C(e[0]/(1+f)*t),c.C(e[1]/(1+f)*t*t))
    raw=c.tail_raw(c.C(1/t),r,H,J)
    for i in range(2):
     for j in range(2):
      target=a(cap[i][j],n(shaved))if i==j==0 else cap[i][j]
      for part in range(2):inside(target[part],(raw[i][j][part][0]/t**(part+1),raw[i][j][part][1]/t**(part+1)))
   count+=1
 return count
if __name__=='__main__':print(dict(exact_direct_private_matrix_controls=control()))
