from pathlib import Path
import json,hashlib,shutil
P=Path(__file__).resolve().parent;ROOT=P.parent.parent
def main():
    names=['extended-base-certificates.jsonl','extended-base-verification.json','small-gap-reserve-certificates.json'];raw=sum((ROOT/n).stat().st_size for n in names);free=shutil.disk_usage(P).free;assert raw<8*1024**2 and free-raw-16*1024**2>8*1024**3;hashes={}
    for name in names:
        data=(ROOT/name).read_bytes();h=hashlib.sha256(data).hexdigest();dest=P/'inputs'/name;dest.parent.mkdir(exist_ok=True)
        if dest.exists():assert dest.read_bytes()==data
        else:dest.write_bytes(data)
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==h;hashes[name]=h
    out=dict(explicit_original_members=names,input_raw_bytes=raw,source_sha256=hashes,free_before=free,maximum_additional_raw_bytes=16*1024**2,no_archive_or_database_write=True)
    (P/'source-plan.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
