# Fresh complete original finite basis through order42

8 November2026. ORIGINAL ALL UNIT MOP n>=8 GLOBAL OPEN; goal ACTIVE.
This is a finite original2n theorem, subject to its terminal exact reader
and the two named published general graph theorems below. It is not an
all-order induction step.

THEOREM. EVERY finite simple UNIT maximal outerplanar graph of order
8<=n<=42 has F=splus>=2n. The order8..11 base is strict. Every assumption
needed for the finite composition is identified here and tested in its
actual scope; a saved PASS status is not used to replace a computation.

1. Complete direct small graph certificates.

Read every integer Gram record in extended-base-certificates.jsonl.
For each n8..11, require exactly2n-3 distinct edges, all outer polygon
edges, integer endpoints0..n-1 and no crossing diagonals. These conditions
make each record a polygon triangulation. Distinct edge sets and exact
Catalan counts132,429,1430,4862 establish coverage of ALL6853 labeled
triangulations. Every abstract MOP has an outer Hamiltonian cycle and
can be labeled cyclically, so this also covers every original graph.
No nontrivial graph is omitted by passing to isomorphism classes.

For each full integer factor Y and positive integer scale s, set
X=YYt/s^2, which is PSD identically. Check EVERY entry and column and
the exact integer numerator

            4s^2 sum_edges(YYt)uv - sum_ij(YYt)ij^2.

Dividing by s^4 gives2Tr(AX)-Tr(X^2)<=F. Every base record exceeds2n.
Floating proposal methods play no role in this exact reader.

For later gap blocks use the independent small-gap file with ALL5+14+42
triangulations of orders5,6,7. The same full domain/distinct/Catalan and
integer Gram checks give F>899/100,56/5,27/2 respectively, hence
F>=2p-2. For p3, the triangle has F4=2p-2. For p4 the two possible
labeled triangulations are both K4-e, with positive energy
(9+sqrt17)/2>6=2p-2. This proves the small-block assertion for ALLp3..7.

2. Written moment and geometric bounds, not assumed scalar tables.

A UNIT MOP has n-2 triangles and n-3 quadrilateral cycles. The latter
correspond exactly to its internal diagonals and the two faces sharing
each one. Thus mu2=4n-6,mu3=6n-12,mu4=2M2+4n-18. The PSD witness
t(A+rI)^2 proves F>=2n when M2<=T_r(n), with

 T_r=((6n-12+2r(4n-6))^2/(2n)
       -(4n-18+4r(6n-12)+6r^2(4n-6)+n r^4))/2.

It suffices to maximize T_r over the41 exact choices r=j/16,j24..64.
No continuous optimization assertion is needed. For maximum degree d,
every degree in[2,d] gives M2<=(2d+8)n-6d-12 by summing
(degree-2)(degree-d)<=0. Also M2<=n^2+7n-18: delete an ear of degree2
with adjacent neighbors a,b. Their degree sum is<=n+2 because they have
at most two common neighbors. Restoring the ear increases M2 by
2deg(a)+2deg(b)+2<=2n+6. Starting at the triangle gives the displayed
bound by induction, without an energy hypothesis.

For a maximum-degree hub v, d neighbors form an induced path and the
nonneighbors are in d-1 polygon gaps of masses m_i>=0, sum k=n-d-1.
Let l be the number of nonempty gaps. In each gap a vertex sees only
the two roots; exactly one sees both. If their degrees inside the gap
block are r,s, their sum is<=m+3, so S_i=sum c_w^2=r+s<=m+3.
Hence S<=k+3l. The closed-neighborhood fan has degree-square sum
d^2+9d-10. A gap contributes at most m^2+11m+4(r+s)-10 before the
cross term of adjacent gaps; that cross term is at most2m_i m_(i+1).
This follows by expanding the two root degree increments and using
M2(gap block)<=m^2+11m and baseline neighbor degrees<=3.

For k>0, the quadratic gap expression is bounded by
Q(k,l)=min(k^2,(k-l)^2+6(k-l)+3l-2). To see this, write each nonempty
mass1+y_i. Their adjacency graph is a subgraph of a path on l vertices,
with at most l-1 edges and degree<=2. Expanding gives a constant<=3l-2,
a linear term<=6 sum y_i and a quadratic term<=(sum y_i)^2. PutQ(0,0)=0.
Therefore a valid total moment upper is

 U=min(n^2+7n-18,(2d+8)n-6d-12,
       d^2+9d-10+Q(k,l)+15k+2l).

3. The actual hub payment and the external inputs.

Put R=G-v, h=(d-1)/d and rho(R)=F(R)-(|R|-1). Compression to the
span of v and the uniform vector on its neighbor path, followed by
principal PSD pinching on its orthogonal complement, gives

 F(G)-2n >=2h sqrt(d+h^2)-k-5-2S/d+6/d^2+rho(R).

The compression loss is at most2||A_R u||^2-(u^t A_R u)^2, since negative
square energy cannot increase under compression. Here u^t A_R u=2h,
||A_R u||^2=(4d-6+S)/d, giving the formula above. This is an actual
graph bound, not energy monotonicity under edge deletion.

Published input1: Liu-Tang-Zhang, arXiv2607.18031v1, Theorem1.2,
https://arxiv.org/html/2607.18031v1 : every connected simple graph H has
F(H)>=|H|-1. R is connected, containing the outer cycle with v removed
as a Hamiltonian path. Thus rho(R)>=0. For an available lower reserve f,
put required=k+5+2(k+3l)/d-6/d^2-f. If required<=0 the hub pays; otherwise
the sufficient exact condition is4h^2(d+h^2)-required^2>=0.

For d<=8,n>=12, no external input is needed: M2<=24n-60 and
T_2=39n-267+324/n, whose difference is3(n-12)(5n-9)/n>=0.
For n12..33 and d>=9, the full feasible(d,l) parameter set is paid by
the moment or rho0 hub bound. The exact reader regenerates that entire
set and all inequalities; there are1949 tuples.

4. All remaining order34..42 parameters and their genuine block chains.

R is a block chain of the nonempty gap MOPs and intervening bridge edges;
it is not a vertex partition into overlapping gap blocks. Every case
where the two previous rules fail has k<=11. Each actual gap block
has p=m+2<=13. If p3..7 use section1; if p8..13 use the already proved
base and order12..33 result. Hence rho(block)>=m+1.

Published input2: Akbari-Hu-Liu, arXiv2609.06778v1, Lemma2.5(2.11),
https://arxiv.org/html/2609.06778v1 : two disjoint connected graphs of
order>=2, glued at vertices whose deletions both stay connected, obey
rho(glue)>=(8/9)(rho1+rho2)-2/9. Both hypotheses hold at every split
between consecutive nonempty gaps: the cut vertex is a terminal root
on each side of the chain. Deleting it leaves the corresponding polygon
block and any other-root bridge attachments connected. In a one-block
section the two possible end paths attach at distinct polygon roots.
Deleting each attaching root leaves its polygon side and its path side
connected, including a one-vertex path remainder.

Let g(x)=(8x-2)/9. A one-gap section, with up to two attached bridge
paths, has rho>=g(g(m+1))=(64m+30)/81. Empty paths permit the same
conservative lower bound because g(x)<=x for x>=0. For a positive
ordered mass tuple t define f((m))=(64m+30)/81 and

 f(t)=max_j[(8/9)(f(t[:j])+f(t[j:]))-2/9].

Induction by the legal chain splits proves rho(R)>=f(t), regardless of
the lengths of its intervening bridge paths. Minimize f over ALL ordered
positive compositions of k into l parts. Insert that reserve into the
actual hub inequality. Every one of2687 tuples at n34..42 pays:2386
by moments,130 by the rho0 hub and171 by this full-composition block
rule. All rational margins are nonnegative. Counts and the complete
index set are independently checked in the reader. This completes the
FINITE original2n theorem through42 in the stated order, without circular
use of any unproved larger-order energy assertion.

Only the two precisely stated published graph results are imported;
their statements and gluing hypotheses have been checked against the
primary sources. No finite certificate or source hash proves those
external theorems anew. The original all-order goal and larger finite
stages remain separate, as do native intake and source-export replay.
