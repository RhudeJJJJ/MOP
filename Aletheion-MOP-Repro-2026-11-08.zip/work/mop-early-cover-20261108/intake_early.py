from pathlib import Path
import hashlib,json,sqlite3,shutil,subprocess,sys,time
P=Path(__file__).resolve().parent;DB=Path('C:/Users/jonas/Aletheion/aletheion/aletheion.db');PRE='math:mop:fresh-early-cover:'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dig(s):return hashlib.sha256(s.encode()).hexdigest()
def rd(n):return json.loads((P/n).read_bytes())
def save(n,v):(P/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def prepare():
    r=rd('early-result.json');assert r['status']=='PASS_FRESH_COMPLETE_ORIGINAL_UNIT_MOP_FINITE_COVER_8_TO42';assert all(sha(P/n)==h for n,h in r['source_sha256'].items())
    parents=['legacy:essays:3023:r1:38807ebb1296ae02','math:mop:fresh-positive-catalan:scope:20261108'];c=sqlite3.connect('file:'+str(DB)+'?mode=ro',uri=True);c.execute('BEGIN');assert not c.execute('select node_id from weave_nodes where node_id like ?',(PRE+'%',)).fetchall();snap=[]
    for i in parents:
        body=c.execute('select body from weave_nodes where node_id=?',(i,)).fetchone()[0];snap.append(dict(node_id=i,body=body,sha256=dig(body)))
    c.rollback();c.close();save('early-parent-snapshot.json',snap)
    ids={k:PRE+k+':20261108'for k in ['payment','base','composition','scope','proofsource','certificate']};nodes=[];edges=[]
    def node(k,kind,body,status):nodes.append(dict(node_id=ids[k],kind=kind,title='Fresh complete original MOP finite basis8..42: '+k,body=body,epistemic=status,provenance=json.dumps([dict(path=str(P/'early-acceptance.md'),sha256=sha(P/'early-acceptance.md'))])))
    def edge(a,b,rel,why):edges.append(dict(edge_id='edge:'+dig(a+'|'+rel+'|'+b),from_id=a,to_id=b,relation=rel,rationale=why,status='curated'))
    node('payment','claim','EVERY finite simple UNIT maximal outerplanar graph G with8<=n<=42 has F=splus>=2n. Complete fresh mathematical reader exit0, not inherited PASS labels. All6853 original graph Grams n8..11 and all4636 actual degree/gap parameter inequalities n12..42 recomputed. Published inputs are exactly Liu-Tang-Zhang2607.18031v1 Theorem1.2 and Akbari-Hu-Liu2609.06778v1 Lemma2.5(2.11), with graph hypotheses checked in the complete written argument. No n>=43 or original global conclusion.','PROVEN complete finite original2n cover with precise published inputs')
    node('base','claim','ALL UNIT MOP n8..11 are covered by6853 distinct valid cyclically labeled polygon triangulations with counts132,429,1430,4862. Every record has all boundary edges,2n-3 unique unit edges,no crossing diagonals and integer endpoints. Cardinalities equal Catalan numbers, so full family coverage, including every abstract original graph after cyclic relabeling. Every full integer Gram column and Frobenius square checked; all F lower bounds strictly exceed2n. Exact minimum margin at8 is63255800391005/281474976710656. ALL61 gap Grams n5..7 also checked, proving stronger than2p-2; triangle/diamond hand formulas supply p3,4. No numerical eigenvalue is proof evidence.','PROVEN complete exact original graph bases and small gap floors')
    node('composition','claim','The written proof derives M2<=n²+7n-18 by ear induction, the degree-product bound, the full coupled gap moment bound and S<=k+3l. PSD shifts pay all needed moment cases. Actual hub compression and the connected n-1 theorem pay the other n12..33 cases,1949 complete tuples; Delta<=8,n>=12 is paid directly by PSD shift2. At n34..42, all2687 tuples pay:2386moment,130rho0hub,171legal block-chain glue cases. Every ordered gap-mass composition is included; largest used mass11 means block order<=13, already paid earlier in the finite proof, or p3..7 explicit floor. The8/9 glue lemma is applied only where both graphs have order>=2 and deleting their joining vertices preserves connectedness. No overlapping blocks treated as independent principal parts and no larger-order energy premise.','PROVEN noncircular finite assembly and exact parameter coverage')
    node('scope','claim','ORIGINAL EVERY finite simple UNIT MOP n>=8 F=splus>=2n remains GLOBAL OPEN; goal ACTIVE. This fresh complete8..42 theorem discharges only that early finite input. Stages43..71 still need their actual remaining scalar, capped/restricted and high-second-hub/kernel pieces; the328 positive Catalan inputs have their separate complete fresh reconstruction. Gamma4 and unbounded parent-family obligations remain distinct. Source hashes, portable replay, automatic context delivery and mathematical truth are different evidence. No external first-priority, independent human/formal audit or LOTSE causal effect claimed.','PROVEN scope; unrestricted original still OPEN')
    for k in ['payment','base','composition','scope']:edge(ids[k],ids['proofsource'],'requires','Complete graph factors, necessary bounds, legal glue proof and full exact reader obligatory.')
    for k in ['payment','base','composition']:edge(ids[k],ids['certificate'],'requires','Complete terminal graph and scalar results in the full source envelope.')
    for i in parents:edge(ids['scope'],i,'qualifies','The complete early8..42 input is freshly discharged; later finite and global inputs keep their original obligations.')
    shutil.copyfile(P.parent/'mop-finite-input-dp-20261108/run_guarded_native.py',P/'run_guarded_native.py')
    names=list(r['source_sha256'])+['reader-inputs.json','early-result.json','early-acceptance.md','intake_early.py','run_guarded_native.py','early-parent-snapshot.json'];files=[P/n for n in dict.fromkeys(names)]
    env=dict(format='full-source-envelope-v2-relative-files',files=[dict(path=str(f),relative=f.relative_to(P).as_posix(),bytes=f.stat().st_size,sha256=sha(f),content=f.read_bytes().decode())for f in files]);payload=json.dumps(env,ensure_ascii=True,separators=(',',':'));pieces=[payload[j:j+72000]for j in range(0,len(payload),72000)]
    header=dict(format='complete-source-envelope-chunks-v1',payload_utf8_bytes=len(payload.encode()),payload_sha256=dig(payload),parts=[dict(node_id=PRE+'sourcepart'+str(j)+':20261108',part=j+1,bytes=len(s.encode()),sha256=dig(s))for j,s in enumerate(pieces)])
    node('proofsource','source',json.dumps(header,separators=(',',':')),'FULL source header; every raw numbered source required')
    for j,(v,s)in enumerate(zip(header['parts'],pieces),1):
        nodes.append(dict(node_id=v['node_id'],kind='source',title='Complete early basis full source '+str(j),body=s,epistemic='FULL raw fragment incomplete alone',provenance=json.dumps([dict(payload_sha256=dig(payload),part=j)])));edge(ids['proofsource'],v['node_id'],'requires','Complete raw source fragment required.')
    node('certificate','source',json.dumps({k:v for k,v in r.items()if k not in ['scalar_rows','source_sha256']},separators=(',',':')),'Terminal summary; ALL graph factors/scalar rows and full reader in required source envelope')
    save('early-packet.json',dict(schema_version=1,nodes=nodes,edges=edges));save('early-source-hashes.json',{str(f):sha(f)for f in files});raw=sum(f.stat().st_size for f in files);backup=DB.stat().st_size+16*1024**2;free=shutil.disk_usage(P).free;assert raw<16*1024**2 and free-backup-3*raw>8*1024**3
    save('early-write-plan.json',dict(explicit_members=[str(f)for f in files],raw_bytes=raw,backup_count=1,backup_upper_each=backup,free_before=free,no_expected_deduplication=True));print(json.dumps(dict(status='PREPARED_FRESH_COMPLETE_EARLY8_TO42_NATIVE_INTAKE',nodes=len(nodes),edges=len(edges),files=len(files),parts=len(pieces),raw_bytes=raw,backup_upper_each=backup,free_before=free)))
def audit():
    assert all(sha(Path(f))==h for f,h in rd('early-source-hashes.json').items());packet=rd('early-packet.json');c=sqlite3.connect('file:'+str(DB)+'?mode=ro',uri=True);c.row_factory=sqlite3.Row;c.execute('BEGIN');actual=[];nodes={}
    for table,key,item in [('weave_nodes','node_id',n)for n in packet['nodes']]+[('weave_edges','edge_id',n)for n in packet['edges']]:
        row=dict(c.execute('select * from '+table+' where '+key+'=?',(item[key],)).fetchone());assert all(row[k]==v for k,v in item.items());actual.append(dict(table=table,row=row))
        if table=='weave_nodes':nodes[row['node_id']]=row
    for s in rd('early-parent-snapshot.json'):assert dig(c.execute('select body from weave_nodes where node_id=?',(s['node_id'],)).fetchone()[0])==s['sha256']
    c.rollback();c.close();save('early-actual-readback.json',actual);header=json.loads(nodes[PRE+'proofsource:20261108']['body']);parts=[]
    for j,v in enumerate(header['parts'],1):
        s=nodes[v['node_id']]['body'];assert j==v['part']and len(s.encode())==v['bytes']and dig(s)==v['sha256'];parts.append(s)
    payload=''.join(parts);assert len(payload.encode())==header['payload_utf8_bytes']and dig(payload)==header['payload_sha256'];env=json.loads(payload);root=P/'native-replay'
    for f in env['files']:
        data=f['content'].encode();rel=Path(f['relative']);assert not rel.is_absolute()and'..'not in rel.parts;assert data==Path(f['path']).read_bytes()and len(data)==f['bytes']and hashlib.sha256(data).hexdigest()==f['sha256'];dest=root/rel;dest.parent.mkdir(parents=True,exist_ok=True)
        if dest.exists():assert dest.read_bytes()==data
        else:dest.write_bytes(data)
    argv=[sys.executable,'-B','-X','utf8',str(root/'read_early.py')];t=time.monotonic();r=subprocess.run(argv,cwd=root,capture_output=True,text=True,encoding='utf8');save('early-replay-process.json',dict(argv=argv,exit_code=r.returncode,wall_time_seconds=time.monotonic()-t,stdout=r.stdout,stderr=r.stderr));assert r.returncode==0,r.stderr
    fresh=json.loads((root/'early-result.json').read_bytes());expected=rd('early-result.json')
    for v in [fresh,expected]:v.pop('seconds',None)
    assert fresh==expected,'some exact graph or scalar field changed'
    for label in ['early-dryrun','early-import']:assert rd(label+'.process.json')['exit_code']==0
    receipt=rd('early-import.stdout.json');assert receipt['inserted']==dict(nodes=len(packet['nodes']),edges=len(packet['edges']),reviews=0);backup=Path(receipt['backup']);assert backup.is_file()and backup.stat().st_size<=rd('early-write-plan.json')['backup_upper_each']
    out=dict(status='PASS_NATIVE_FRESH_COMPLETE8_TO42_AND_ALL_EXACT_SOURCE_REPLAY',native_run_id=receipt['run_id'],nodes=len(packet['nodes']),edges=len(packet['edges']),files=len(env['files']),parts=len(parts),all_source_bytes_identical=True,every_exact_6853graph_61smallgap_4636scalar_result_identical=True,elapsed_seconds_only_excluded=True,parents_unchanged=True,backup=str(backup),free_after=shutil.disk_usage(P).free,original_global='OPEN',original_goal_complete=False)
    save('early-native-audit.json',out);print(json.dumps(out))
if __name__=='__main__':prepare()if len(sys.argv)==1 or sys.argv[1]=='prepare'else audit()
