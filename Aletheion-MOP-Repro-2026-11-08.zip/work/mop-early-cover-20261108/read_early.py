from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache
from math import comb
from collections import Counter
import json,hashlib,time
P=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def domain(n,edges):
    assert all(len(e)==2 and all(type(v)is int for v in e)for e in edges)
    E=frozenset(map(tuple,edges));assert len(E)==len(edges)==2*n-3 and all(0<=x<y<n for x,y in E)
    boundary={(i,i+1)for i in range(n-1)}|{(0,n-1)};assert boundary<=E
    diagonals=E-boundary;assert all(not(a<c<b<d or c<a<d<b)for a,b in diagonals for c,d in diagonals)
    return E
def gram(n,edges,Y,s,rank=None):
    assert type(s)is int and s>0 and len(Y)==n;cols=len(Y[0]);assert cols>0 and(rank is None or cols==rank)
    assert all(len(r)==cols and all(type(x)is int for x in r)for r in Y)
    W=[[sum(x*y for x,y in zip(Y[i],Y[j]))for j in range(n)]for i in range(n)]
    return F(4*s*s*sum(W[x][y]for x,y in edges)-sum(v*v for r in W for v in r),s**4)
@lru_cache(None)
def threshold(n):
    return max((((6*n-12+2*r*(4*n-6))**2/F(2*n)-(4*n-18+4*r*(6*n-12)+6*r*r*(4*n-6)+n*r**4))/2,r)for r in(F(j,16)for j in range(24,65)))
def qbound(k,l):return 0 if k==0 else min(k*k,(k-l)**2+6*(k-l)+3*l-2)
def hub(d,k,l,reserve=F(0)):
    h=F(d-1,d);required=k+5+F(2*(k+3*l),d)-F(6,d*d)-reserve
    return F(1)if required<=0 else 4*h*h*(d+h*h)-required*required
@lru_cache(None)
def compositions(k,l):
    if l==1:return((k,),)
    return tuple((i,)+rest for i in range(1,k-l+2)for rest in compositions(k-i,l-1))
@lru_cache(None)
def blocks(masses):
    if len(masses)==1:return F(64*masses[0]+30,81)
    return max(F(8,9)*(blocks(masses[:i])+blocks(masses[i:]))-F(2,9)for i in range(1,len(masses)))
def main():
    start=time.monotonic();plan=json.loads((P/'source-plan.json').read_bytes());assert all(sha(P/'inputs'/n)==h for n,h in plan['source_sha256'].items());names=['early-proof.md','read_early.py','prepare_early.py','source-plan.json']+['inputs/'+n for n in plan['explicit_original_members']];hashes={n:sha(P/n)for n in names};manifest=P/'reader-inputs.json'
    if manifest.exists():assert json.loads(manifest.read_bytes())==hashes
    else:manifest.write_text(json.dumps(hashes,indent=2)+'\n')
    seen={n:set()for n in range(8,12)};minimum={}
    with(P/'inputs/extended-base-certificates.jsonl').open()as stream:
        for line in stream:
            r=json.loads(line);n=r['n'];assert n in seen;E=domain(n,r['edges']);assert E not in seen[n];seen[n].add(E)
            value=gram(n,E,r['gram_factor'],r['scale'])-2*n;assert value>0;minimum[n]=min(minimum.get(n,value),value)
    assert all(len(E)==comb(2*n-4,n-2)//(n-1)for n,E in seen.items())and sum(map(len,seen.values()))==6853
    original=json.loads((P/'inputs/extended-base-verification.json').read_bytes());assert {str(n):str(v)for n,v in minimum.items()}==original['min_margin_rational']
    obj=json.loads((P/'inputs/small-gap-reserve-certificates.json').read_bytes());small={n:set()for n in [5,6,7]};small_min={};targets={5:F(899,100),6:F(56,5),7:F(27,2)};assert {int(n):F(v)for n,v in obj['targets'].items()}==targets
    for r in obj['records']:
        n=r['order'];assert n in small;E=domain(n,r['edges']);assert E not in small[n];small[n].add(E)
        value=gram(n,E,r['integer_gram_factor_rows'],obj['factor_scale'],r['positive_columns']);assert value>targets[n];small_min[n]=min(small_min.get(n,value),value)
    assert all(len(E)==comb(2*n-4,n-2)//(n-1)for n,E in small.items())and sum(map(len,small.values()))==61
    scalar=[];counts={};max_k=0
    for n in range(12,43):
        T,shift=threshold(n);seen_params=set();rules=Counter()
        for d in range(9,n):
            k=n-d-1
            for l in([0]if k==0 else range(1,min(k,d-1)+1)):
                U=min(n*n+7*n-18,(2*d+8)*n-6*d-12,d*d+9*d-10+qbound(k,l)+15*k+2*l);row=dict(n=n,d=d,k=k,l=l,M2_upper=U)
                if U<=T:row.update(rule='moment',shift=str(shift),margin=str(T-U))
                elif hub(d,k,l)>=0:row.update(rule='hub',margin=str(hub(d,k,l)))
                else:
                    assert n>=34 and 1<=l<=k<=13 and k+2<=33
                    candidates=compositions(k,l);assert len(candidates)==comb(k-1,l-1)
                    reserve=min(map(blocks,candidates));margin=hub(d,k,l,reserve);assert margin>=0,(n,d,k,l,margin)
                    row.update(rule='block_hub',reserve=str(reserve),margin=str(margin),all_ordered_compositions=len(candidates));max_k=max(max_k,k)
                assert(n,d,l)not in seen_params;seen_params.add((n,d,l));rules[row['rule']]+=1;scalar.append(row)
        expected={(n,d,l)for d in range(9,n)for l in([0]if n-d-1==0 else range(1,min(n-d-1,d-1)+1))};assert seen_params==expected;counts[n]=dict(rules)
    early=sum(r['n']<=33 for r in scalar);later=len(scalar)-early;assert early==1949 and later==2687 and sum(r['rule']=='block_hub'for r in scalar)==171 and max_k==11
    assert all(sha(P/n)==h for n,h in hashes.items())
    out=dict(status='PASS_FRESH_COMPLETE_ORIGINAL_UNIT_MOP_FINITE_COVER_8_TO42',base_graphs=6853,base_counts={n:len(E)for n,E in seen.items()},base_minimum_strict_margin={n:str(v)for n,v in minimum.items()},small_gap_graphs=61,small_gap_minima={n:str(v)for n,v in small_min.items()},parameter_rows_12_to33=early,parameter_rows_34_to42=later,block_rule_rows=171,largest_block_gap_mass=max_k,counts_by_order=counts,scalar_rows=scalar,source_sha256=hashes,seconds=time.monotonic()-start,scope='EVERY finite simple UNIT MOP8<=n<=42 has F>=2n, strict in base8..11. Complete written geometry/degree/moment/PSD/chain proof plus full exact graph and parameter checks, using ONLY the stated published connected n-1 and cut-vertex8/9 graph theorems as outside inputs. Original unrestricted all-order target stays OPEN.',original_global='OPEN',native_intake='PENDING')
    (P/'early-result.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in ['scalar_rows','source_sha256','counts_by_order']},indent=2))
if __name__=='__main__':main()
