# A sharp whole-graft root-ball phase bound, and payment of saturated S3

6 November2026. ORIGINAL: EVERY finite simple UNIT maximal outerplanar G,
n>=8, F(G)=sum_{lambda>0}lambda^2>=2n, equivalently D(G)>=6. ORIGINAL
GLOBAL OPEN, goal ACTIVE. This note proves a general stronger sufficient
increment bound and two actual local payments. It does not close the
original global compensation problem. No external formal/human audit,
literature priority or complete-corpus/Drive reading is claimed.

## 1. Same actual old root and COMPLETE private response

Let H be any old unit MOP, h>=3, ab any ordered actual boundary edge.
The auxiliary old unit edge K2 is also allowed, explicitly as an increment
domain, not as an original paid base. Retain ab ONCE. Attach a closed
literal unit triangulated cap, with private symmetric adjacency B and
two real contact rows T, no other private outside contacts. Let G be the
same actual resulting MOP. At t>0 put

 J=[[0,1],[1,0]], K=2I+J, Ki=K^-1,
 Z0=tI+iJ+F0, H0=Z0^-1,
 Fc=T(tI+iB)^-1 T^t, L=K^-1/2 Fc K^-1/2,
 c=1/t-i/2, rho=sqrt(1/t^2+1/4).

The existing actual-root sector201 gives 2ReF0+tImF0>=0 and the SAME
inequality for the COMPLETE physical Fc. For old K2, F0=0 verifies it
directly. All real/imaginary parts are Hermitian parts; star is adjoint.
Strict accretivity ReZ0>=tI and inverse congruence give

 2ReH0-tImH0>=t H0* K H0,
 K^1/2 H0 K^1/2 = cI+rho U, ||U||<=1.                (1)

The second line is the exact completed matrix square. It retains both
root directions, all private modes, and the SAME old H0 throughout the
whole graft. It is not a weighted original graph or a collection of
independently chosen homotopy states.

Define

 A=I+cL, W=rho L A^-1.                               (2)

The complete cap sector implies

 ReA=I+ReL/t+ImL/2>=I,
 A* A-rho^2 L*L=I+2ReL/t+ImL>=I,
 I-W*W=A^{-*}(A*A-rho^2L*L)A^-1>0.                  (3)

Thus A is strictly accretive and ALL singular values sigma1,sigma2 of W
are strictly below1. No private lower spectral bound or old degree/order
upper bound is used. Formula(3) is a full noncommuting matrix identity.

## 2. Exact two-dimensional contraction determinant phase

LEMMA. For ANY complex2x2 W with ||W||<1,

 max_{||U||<=1} ImTrLog(I+UW)=asin(sigma1)+asin(sigma2). (4)

Log is the accretive branch, anchored by replacing W by sW,s0..1.
This is a sharp statement over the WHOLE contraction ball, not a claim
that an original graph realizes a maximizing U.

PROOF. Apply an SVD to W and cycle the determinant; the variable U is
still an arbitrary contraction, and W can be replaced by D=diag(sigma1,
sigma2). For a fixed SVD U=P diag(r1,r2)Q*, consider complex diagonal
variables z1,z2 in the closed unit disks. I+P diag(z1,z2)Q*D is strictly
accretive because its perturbation has norm<1. Its trace-log is analytic;
the harmonic maximum principle in each variable puts the largest imaginary
part on |z1|=|z2|=1. Thus it suffices to optimize over UNITARY U.

Write a general unitary as

 U=e^(i phi)[[e^(i alpha) cos(theta), e^(i beta) sin(theta)],
             [-e^(-i beta) sin(theta), e^(-i alpha) cos(theta)]].

Its determinant expression is

 det(I+UD)=1+sigma1*sigma2*e^(2i phi)
     +e^(i phi) cos(theta)(sigma1 e^(i alpha)+sigma2 e^(-i alpha)).

For fixed phi, cos(theta) in[0,1] and alpha sweep a filled ellipse in the
complex determinant plane. It never contains zero or crosses the negative
real axis: I+UD has positive definite real part, so its two eigenvalue
arguments sum to a value strictly between-pi and pi. Argument is harmonic
on that ellipse, hence its maximum is on the boundary cos(theta)=1.
In a degenerate line ellipse every image point is already attained with
cos(theta)=1; the zero matrix is trivial. These boundary choices make U
diagonal. The two diagonal phases phi+alpha,phi-alpha are independent.
The largest argument of1+sigma e^(i psi),sigma<1,is asin(sigma), by the
tangent from the origin to its circle centered1. This proves(4). Equality
is attained with e^(i psi_j)=-sigma_j+i sqrt(1-sigma_j^2). QED.

This elementary proof explicitly covers unequal/equal singular values,
zero singular values and nondiagonal/nonnormal W. It uses the sum of
singular values' angular contributions, not a scalar trace substitute.

## 3. Whole-graft bound with the old root retained

The exact determinant ratio is

 det(I+H0 Fc)=det(I+(cI+rho U)L)
            =det(A) det(I+UW).                       (5)

For each s0..1 replace Fc by sFc in(2)-(5). Both A_s and I+U W_s remain
strictly accretive by(3), and at s0 they are I. Therefore their continuous
trace-log phases add to the actual lifted whole-graft phase
delta=ImTrLogZ1-ImTrLogZ0, without any principal-argument reset of a
determinant PRODUCT. Equation(4) gives the universal bound

 delta(t)<=b(t),
 b(t)=ImTrLogA+asin(sigma1(W))+asin(sigma2(W)).         (6)

It is sharp over the enlarged root ball(1), even though the maximizing
root need not be graph-realizable or the same at different frequencies.
Since H0=0 is in that ball, b>=0. Since both trace-log contributions in(5)
are each between-pi and pi, b<2pi. The actual old H0 is one point of this
ball, held fixed across the ENTIRE graft. This avoids the older separate
maximization of H_s at every homotopy parameter s.

The equal-trace spectral-phase identity yields

 DeltaF=F(B)+Tr(TT^t)-(2/pi)integral_0^infinity t delta(t)dt
       >=F(B)+Tr(TT^t)-(2/pi)integral_0^infinity t b(t)dt. (7)

For completeness, integral_0^R t atan(lambda/t)dt equals
R^2 atan(lambda/R)/2+lambda R/2
 -lambda|lambda| atan(R/|lambda|)/2, with zero value for lambda0.
Its asymptotic value is lambda R-pi lambda|lambda|/4+o(1).
Subtracting equal-trace finite spectra cancels the linear term; the exact
trace-square increase for G versus H direct-sum B is2TrTT^t. This is(7).

## 4. Pointwise dominance and safe zero modes

Let E_old be the old full-cap homotopy support,

 E_old=ImTr(KiFc)/t-ReTr(KiFc)/2
                     +sqrt(t^2+4)||L||_*/(2t), V_old=t E_old.

Then

        0<=t b(t)<=min(V_old(t),2pi*t).               (8)

Here is why the first upper comparison is UNIVERSAL, not numerical.
Start at ANY invertible H in ball(1). Its inverse Z obeys
2ReZ+tImZ>=tK. Adding sFc preserves this inequality. Equation(3), with
sFc, ensures I+sH Fc never has a zero determinant for every contraction
U from(1), so all inverses along the graft exist. Inverse congruence puts
H_s=(I+sH Fc)^-1H back in the SAME ball(1) at every s. Hence
ImTr(H_s Fc)<=E_old and integration over s gives delta(H)<=E_old.
Invertible H are dense in the ball; the determinant factors never vanish,
so the inequality extends to its singular points by continuity. Maximizing
over H gives b<=E_old by(4)-(6). The2pi bound was proved above.

Thus the new bound is never worse than the old homotopy support INCLUDING
the later low-frequency2pi*t cap. A visible private zero mode can make
V_old nonintegrable at zero; t b(t)<=2pi*t is automatically integrable.
At infinity the old V_old is O(t^-2) for every finite B,T here. For rank2 T,
the retained exact normalized-tail identity below has positive denominators
and a continuous limit after taking t sufficiently larger than ||B||.
For rank1 T the response has one fixed active direction: its scalar
expansion Fc=C/t-iD/t^2+O(t^-3),C>0, cancels the leading constants in
V_old and gives the same O(t^-2). Rank0 is zero. No frequency cutoff or
unstated limit of the old graph is substituted for the complete tail.

The new sufficient bound still cannot alone pay EVERY bare external
branch: F(B)+contact_mass=2k there, and b>=0. Universal single Fork6,
unrestricted external-branch payment and the original goal remain OPEN.

## 5. Intrinsic rational invariants and the actual phase branch

For x=t^2 put Q=T(xI+B^2)^-1T^t,M=TB(xI+B^2)^-1T^t,
C=KiQ,N=KiM, and

 q=TrC,m=TrN,u=detC,v=detN,
 w=C11N22+C22N11-C12N21-C21N12,
 r=xu-v,D=r^2+xw^2,R=(x+4)/(4x).

Then s=TrL=tq-im, d=detL=r-itw, and detA=aR+i aI where

 aR=1+q-m/2+(1/x-1/4)r-w,
 aI=-[m+xq/2+(1-x/4)w+r]/t.

C,N need not commute or be symmetric. L is complex symmetric. Its exact
squared Frobenius norm is nf=x(q^2-2u)+(m^2-2v).
Cayley-Hamilton in dimension2 gives L A^-1=(L+c d I)/detA. Consequently

 alpha=||W||_F^2
   =R[nf+2(r-xw/2)q+2(w+r/2)m+2R D]/(aR^2+aI^2),
 beta=|detW|^2=R^2 D/(aR^2+aI^2).

For theta=asin(sigma1)+asin(sigma2),

 cos(theta)=sqrt(1-alpha+beta)-sqrt(beta), theta in[0,pi). (9)

The reader checks these formulas against DIFFERENT direct exact complex
matrix inverses, adjoints and metric Frobenius traces. It does not silently
replace the metric-conjugated W by a similar matrix's unweighted norm.

On each compact certificate cell, directed arithmetic proves aR>0 and

 denominator=aR cos(theta)-aI sin(theta)>0,
 numerator=aI cos(theta)+aR sin(theta)>=0.

Here sin(theta)=sqrt(1-cos(theta)^2)>=0. Since argA is in(-pi/2,pi/2),
theta in[0,pi), positive denominator puts their sum in(-pi/2,pi/2);
nonnegativity b>=0 then identifies the EXACT branch

           b=atan(numerator/denominator).            (10)

These scalar branch conditions are certificate-specific, not an extra
restriction on the general theorem(6). A separate point enclosure from
argA+acos(cos(theta)) checks the alternative coordinates. A rational control
with A=(3+4i)I and the sharp singular values3/5,4/5 has lifted phase>pi
while its determinant product has negative principal argument. This detects
the otherwise unsafe global replacement of the lifted sum by product arg.

## 6. Two literal actual applications and what was already excluded

ASYMMETRIC COUPLED CAP. At ab, attach an external/external branch p1,q2:
private v0..v3 form a path, a sees v0,v1, b sees v1,v2,v3. On its last
outer edge v3b graft a balanced Fork. The union has7 private vertices,
14 added unit edges. No private outside contacts are allowed. The theorem is

       DeltaF>71/5=14+1/5.                            (11)

This is stronger than the separately justified branch debt plus C1 credit.
It is an actual serial compensation rule. It is NOT an independent new
minimal-counter exclusion: the union ALREADY contains a closed C1, rooted
at b,v2 with private v3 and the three child-Fork vertices. The reader checks
ALL nine C1 edges, its directed long arc and all private closedness.
The analogous claim that the previous balanced double-Fork exclusion was
independent also needs this qualification: each j1 pair contains old C1.
Their true coupled increment theorems and the whole irregular Fork-class
proof remain valid; no valid lemma is falsely revised.

SATURATED S3. Use the EXACT source convention of saturated-cap-proof.md:
S0 empty; Sd adds one private vertex on the root then recurses on BOTH new
edges to depth d-1. Thus S1 has1,S2 has3,S3 has7 private vertices.
S2 is the balanced Fork and remains universally unpaid in the present
proof. S3 is one root triangle with a balanced Fork on EACH new root side.
The new all-parent theorem is

       F(H+S3)-F(H)>59/4=14+3/4.                      (12)

It applies to every old unit MOP h>=3 and auxiliary K2. Both complete
private/old root domains satisfy sector201. Unlike(11), this rooted S3
has no closed literal C1 or C2. Its previous positive-mode filter lower
is insufficient. The old source proved saturated Sd only for d>=5 via
private-block energy; it did not prove this seven-private-vertex increment.
An early exploratory filename called this seven-vertex cap S2; that was a
depth-label error. Geometry and the accepted theorem use the original
S3=2^3-1=7 convention. No d2/Fork6 closure is inferred.

## 7. Complete rational finite integrations, including both tails

For each application all seven roots of the actual private characteristic
are isolated by rational Sturm counts from independently reconstructed
Newton traces. The exact zero interval is retained. The proposed roots
come from SymPy; no floating eigenvalue accepts an energy bound.
Their positive lower squared endpoints give the private F lower.

Take epsilon1/8. The ENTIRE low interval is paid with t b<=2pi*t,
giving the exact energy charge2epsilon^2=1/32. On[1/8,4] use(9)-(10).
On t>=4, use the valid dominating old homotopy tail from(8): its exact
normalization maps t to z1/t and the whole tail to z in[0,1/4].
The two concrete private graphs have degree<=4 and rank2 T, which are
the actual premises for that retained rationalized tail formula. No
invertibility of B at t0 is assumed or used.

Every disjoint dyadic leaf of BOTH finite intervals is retained in a
lossless binary preorder tree. The standard-library reader reconstructs
the literal unit graph and both contact-polynomial routes (adjugate and
direct moments), recomputes EVERY outward leaf enclosure, sums exact
areas and checks full tree/byte accounting. Directed dyadic arithmetic
uses192 bits. For atan(q), use oddness, reciprocal reduction for q>1 and
the half-angle q/(1+sqrt(1+q^2))<1/2 for0<=q<=1. Twelve alternating terms
and the positive next-term remainder enclose the value outward. Machin's
identity bounds pi. Only the proved nonnegativities in(3),(9),(10) permit
interval clamping. A denominator/branch without a strictly positive lower
bound forces subdivision, rather than acceptance from a floating sign.

The final arithmetic check in each case is

 F(B)_lower+actual_contact_mass-1/32-2*I_upper/pi_lower
       > the target in(11) or(12).                   (13)

The certificates retain ALL root intervals and every integration leaf;
reader reports contain the concrete exact fractions. Algebra controls
include noncommuting complex matrices, two-sided rotated sharpness
witnesses, equal/zero singular values and the over-pi phase lift. They
calibrate the written universal proof, not a finite substitute for it.

## 8. A fresh small-parent boundary closes the S3 counter cut

For old h2..7 there are1,1,2,5,14,42 rooted labeled polygon triangulations,
respectively,65 total, with the root fixed at the closing outer edge.
The equality unit here is the EXACT labeled edge set; no unlabeled-graph
or degree-histogram quotient is used. Any actual ordered MOP boundary is
obtained by relabeling the outer cycle into this form.

The proposer enumerates them by the unique triangle incident to the root
and its two smaller polygons. The separate reader uses nonroot ear growth.
Every MOP has two ears, and for order>3 the two adjacent root vertices
cannot both be ears; hence some ear can be deleted without losing the
fixed root edge. This proves completeness of that DIFFERENT ear-growth
recursion. The exact edge sets and Catalan counts agree.

For each of these65 parents, the COMPLETE whole S3 graft of order h+7 is
freshly certified by a full integer Gram X=WW^t/16^2. The exact score is
4 sum_actual_edges(WW^t)_ab/16^2-||W^tW||_F^2/16^4, with every original
vertex and the ENTIRE squared norm retained. All whole scores exceed2n;
the minimum certified margin is48723/65536. NumPy only proposes W.
This verifies only these rooted S3 grafts, not all MOPs of orders9..14.
It is independent of inherited B71 or any earlier small-graph base.

Therefore NO minimal ORIGINAL counterexample contains a closed S3 at ANY
order. For total n>=15 its deletion leaves h=n-7>=8, paid by minimality,
and(12) pays G. If9<=n<=14 use the fresh65 whole grafts. A graph of order8
cannot contain a seven-private-vertex cap plus its two roots. In particular
the retained n>=72 counter front is S3-free without any fresh upgrade of
its OTHER inherited hypotheses. Every closed literal Sd with d>=3 contains
a closed bottom S3; hence ALL such saturated caps are excluded from a
minimal original counter, not just the earlier depths>=5.

## 9. Original remaining obligation

The original all-MOP2n theorem is STILL OPEN. General dual trees need not
contain a closed saturated S3, and a globally nonnegative actual removal
ledger has not been proved. Universal bare S2/Fork6 also remains OPEN.
The new exact whole-graft bound(6)-(8) is available on EVERY complete actual
two-root cap, while(11)-(12) are its verified finite literal applications.
The next work should preserve the C1/S3-free domain and the SAME old root
through larger unequal-arm or irregular branch regions. A finite numerical
optimizer supplies feasible values LOWER-bounding a supremum, never the
UPPER bound required for a payment proof. No cone witness is an original
graph counterexample without actual graph realization. LOTSE method_effect
remains OPEN. Native storage/replay and session-entry delivery are distinct.
