from pathlib import Path
import json,hashlib,sqlite3,shutil,sys,subprocess,time
P=Path(__file__).resolve().parent;W=P.parent;D=W/'mop-double-eigen-tail-20261108';H=W/'mop-double-fixed-middle-20261108';DB=Path('C:/Users/jonas/Aletheion/aletheion/aletheion.db');PRE='math:mop:complete-double-middle:'
def rd(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dig(s):return hashlib.sha256(s.encode()).hexdigest()
def save(n,v):(P/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def gate():
    result=rd(D/'selected36-result.json');assert result['status']=='PASS_COMPLETE_DOUBLE_PARENT_M14_TO41_SELECTED36_ROOT_DIRECTION_TAIL';tool=rd(P/'selected36-terminal-tool.json');assert tool['exit_code']==0 and 'PASS_COMPLETE_DOUBLE_PARENT_M14_TO41_SELECTED36_ROOT_DIRECTION_TAIL'in tool['output'];assert rd(W/'mop-private-completion-20261108/native-audit.json')['status']=='PASS_NATIVE_COMPLETE_BOTH_SIBLING_ROLES_AND_EXPORTED_ACCEPTANCE_AUDIT'
    hashes=rd(D/'selected36-inputs.json');assert len(hashes)==78 and result['source_sha256']==hashes and all(sha(W/n)==h for n,h in hashes.items());runtime=rd(D/'runtime-prefix-observation.json');assert sha(D/'runtime-prefix-observation.json')==result['runtime_prefix_observation_sha256'];assert sha(D/'original-reader-prefix-tool.json')==runtime['event_file_sha256']and rd(D/'original-reader-prefix-tool.json')==runtime['full_tool_result'];assert result['observed_original_prefix_index']>=35
    assert len(result['compact_records'])==36 and[v['index']for v in result['compact_records']]==list(range(36));assert[v['actual_total']for v in result['cases']]==list(range(14,42))
    from fractions import Fraction as F
    assert all(F(v['surplus_lower'])>F(1,20)and len(v['cells'])==128 for v in result['cases'])
    for v in result['compact_records']:assert sha(D/v['data'])==v['data_sha256']and sha(D/v['exact_record'])==v['exact_sha256']
    return result
def prepare():
    r=gate();parents=['math:mop:actual-middle-method:geometry:20261108','math:mop:actual-middle-method:scope:20261108','math:mop:actual-middle-method:proofsource:20261108','math:mop:root-direction-selected36:budget:20261108','math:mop:root-direction-selected36:scope:20261108','math:mop:root-direction-selected36:source:20261108','math:mop:complete-siblings:both:20261108','math:mop:complete-siblings:scope:20261108'];con=sqlite3.connect('file:'+str(DB)+'?mode=ro',uri=True);con.execute('BEGIN');assert not con.execute('select node_id from weave_nodes where node_id like ?',(PRE+'%',)).fetchall();snap=[]
    for n in parents:row=con.execute('select body from weave_nodes where node_id=?',(n,)).fetchone();assert row is not None,n;snap.append(dict(node_id=n,body=row[0],sha256=dig(row[0])))
    con.rollback();con.close();save('parent-snapshot.json',snap);old={v['node_id']:v['body']for v in snap};shutil.copyfile(W/'mop-private-completion-20261108/run_guarded_native.py',P/'run_guarded_native.py')
    own=[D/v[k]for v in r['compact_records']for k in['data','exact_record']]+[D/n for n in['selected36-result.json','runtime-prefix-observation.json','original-reader-prefix-tool.json']]+[P/n for n in['selected36-terminal-tool.json','acceptance-proof.md','intake_double_completion.py','run_guarded_native.py','parent-snapshot.json']];assert len(own)==80;files=[dict(path=str(f),relative=f.relative_to(W).as_posix(),bytes=f.stat().st_size,sha256=sha(f),content=f.read_bytes().decode('utf8'))for f in own]
    ids={k:PRE+k+':20261108'for k in['middle','scope','proofsource']};nodes=[];edges=[]
    def node(k,kind,body,ep):nodes.append(dict(node_id=ids[k],kind=kind,title='Completed actual double-parent middle: '+k,body=body,epistemic=ep,provenance=json.dumps([dict(path=str(P/'acceptance-proof.md'),sha256=sha(P/'acceptance-proof.md'))])))
    def edge(a,b,relation,why):
        eid='edge:'+dig(a+'|'+relation+'|'+b)
        if not any(e['edge_id']==eid for e in edges):edges.append(dict(edge_id=eid,from_id=a,to_id=b,relation=relation,rationale=why,status='curated'))
        return eid
    effect='The general double-child14<=q+r<=41 family is now fully PROVEN at every old UNIT MOP H>=3,ordered boundary,independent positive p,q,r,s,with DeltaF>2N+1/20.'
    node('middle','claim',effect+' Original complete numerical compact per-slab proofs0..35 reused with full67-source/raw-data binding and genuine original exact-reader execution through35. New selected36 composition actually terminal exit0; all36 full grammars,all28*128 whole signed infinite-tail cells and all28 exact final margins pass. ResultSHA256='+sha(D/'selected36-result.json')+'. Whole reflection fixesq>=r over the entire actual integral; both outer arms infinite. No old upper order/degree/norm bound, sample extrapolation or successful full56 terminal claim.','PROVEN full original-domain double middle; numerical subproof reuse and complete exact final composition')
    scope_effect='Both sibling roles and the double-middle14..41 are fully paid. The final original-quantifier/mathematical assembly audit remains separate; original EVERY finite simple UNIT MOP n>=8,F=splus>=2n remains GLOBAL OPEN here; goal ACTIVE.'
    node('scope','claim',scope_effect+' The sufficient compact route requires36slabs toT5,not successful completion of the older56job. Its20method and original77method source envelopes remain mandatory. Earlier valid56conditional budget,private floors,small-pair/tail payments,helper counterexamples and actual graph target remain unchanged. Native intake/export, entry delivery, truth, worldwide priority and independent human/formal audit are distinct.','PROVEN local family completion; original global status not changed by this intake')
    payload=json.dumps(dict(format='full-source-envelope-v2-relative-files',files=files),ensure_ascii=True,separators=(',',':'));parts=[payload[j:j+72000]for j in range(0,len(payload),72000)];header=dict(format='complete-source-envelope-chunks-v1',payload_utf8_bytes=len(payload.encode()),payload_sha256=dig(payload),parts=[dict(node_id=PRE+'sourcepart'+str(j)+':20261108',part=j+1,bytes=len(s.encode()),sha256=dig(s))for j,s in enumerate(parts)])
    node('proofsource','source',json.dumps(header,separators=(',',':')),'FULL new acceptance and all72 actual raw-data/exact-record members; original77+new20 full method dependencies mandatory')
    for j,(v,s)in enumerate(zip(header['parts'],parts),1):nodes.append(dict(node_id=v['node_id'],kind='source',title='Complete double middle full source part '+str(j),body=s,epistemic='FULL fragment incomplete alone',provenance=json.dumps([dict(payload_sha256=dig(payload),part=j)])));edge(ids['proofsource'],v['node_id'],'requires','Every full source fragment required.')
    for k in['middle','scope']:edge(ids[k],ids['proofsource'],'requires','Full exact acceptance and actual source/data/terminal receipts.')
    for n in[parents[0],parents[2],parents[3],parents[5]]:edge(ids['middle'],n,'requires','Complete actual geometry/phase, original numerical proof sources and root-direction signed tail method.')
    edge(ids['scope'],ids['middle'],'requires','Only completed exact middle removes its work obligation.');edge(ids['scope'],parents[6],'requires','Both sibling roles already actually completed.')
    bindings=[]
    def bind(prior,successor,quote,scope,successor_effect):
        assert quote in old[prior]and scope in old[prior];assert successor_effect in next(n['body']for n in nodes if n['node_id']==successor);eid=edge(successor,prior,'revises','Only exact completion/work-front clause updated; earlier true theorem and global audit boundary retained.');i=len(bindings)+1;n=f'revision-{i}.json';save(n,dict(version=1,reviewer='Codex exact full double-middle terminal acceptance,20261108',affected_prior_claim=dict(node_id=prior,field='body',quote=quote),prior_scope=dict(node_id=prior,field='body',quote=scope),successor_effect=dict(node_id=successor,field='body',quote=successor_effect)));bindings.append(dict(edge_id=eid,path=str(P/n)))
    bind(parents[1],ids['scope'],'Full family acceptance needs ALL56 exact slabs and both signed final inequalities.','New full HYBRID56 computation is RUNNING:',scope_effect)
    bind(parents[4],ids['middle'],'New selected36 foreground composition34736 is RUNNING;','All28 signed tails/final margins must complete.',effect)
    bind(parents[4],ids['scope'],'No full double family accepted here; private sibling also pending.','Original EVERY finite simple UNIT MOP n>=8,F>=2n remains GLOBAL OPEN / goalACTIVE.',scope_effect)
    bind(parents[7],ids['middle'],'general double-child14<=q+r<=41 still requires terminal full exact acceptance.','Private-c sibling q+ell<=49 is fully paid;',effect)
    save('revision-plan.json',bindings);raw=sum(f['bytes']for f in files);backup=DB.stat().st_size+32*1024**2;free=shutil.disk_usage(P).free;assert raw<8*1024**2 and free-5*backup-6*raw>8*1024**3;save('write-plan.json',dict(explicit_files=[str(f)for f in own],raw_bytes=raw,backup_count=5,backup_upper_each=backup,free_before=free,reserve_bytes=8*1024**3));save('source-hashes.json',{str(f):sha(f)for f in own});save('packet.json',dict(schema_version=1,nodes=nodes,edges=edges));print(json.dumps(dict(status='PREPARED_COMPLETE_ACTUAL_DOUBLE_MIDDLE_NATIVE_PACKET',nodes=len(nodes),edges=len(edges),files=len(files),raw_bytes=raw,parts=len(parts),bindings=len(bindings),free_before=free)))
def envelope(con,n):
    h=json.loads(con.execute('select body from weave_nodes where node_id=?',(n,)).fetchone()[0]);parts=[]
    for i,v in enumerate(h['parts'],1):s=con.execute('select body from weave_nodes where node_id=?',(v['node_id'],)).fetchone()[0];assert v['part']==i and len(s.encode())==v['bytes']and dig(s)==v['sha256'];parts.append(s)
    s=''.join(parts);assert len(s.encode())==h['payload_utf8_bytes']and dig(s)==h['payload_sha256'];return json.loads(s)
def audit():
    expected=gate();assert all(sha(Path(n))==h for n,h in rd(P/'source-hashes.json').items());packet=rd(P/'packet.json');con=sqlite3.connect('file:'+str(DB)+'?mode=ro',uri=True);con.row_factory=sqlite3.Row;con.execute('BEGIN');actual=[]
    for table,key,v in[('weave_nodes','node_id',n)for n in packet['nodes']]+[('weave_edges','edge_id',e)for e in packet['edges']]:
        row=dict(con.execute('select * from '+table+' where '+key+'=?',(v[key],)).fetchone());assert all(row[k]==x for k,x in v.items());actual.append(dict(table=table,row=row))
    for v in rd(P/'parent-snapshot.json'):assert dig(con.execute('select body from weave_nodes where node_id=?',(v['node_id'],)).fetchone()[0])==v['sha256']
    envelopes=[envelope(con,n)for n in['math:mop:actual-middle-method:proofsource:20261108','math:mop:root-direction-selected36:source:20261108',PRE+'proofsource:20261108']];con.rollback();con.close();save('actual-readback.json',actual);root=P/'native-export';seen={}
    for env in envelopes:
        for f in env['files']:
            b=f['content'].encode();rel=Path(f['relative']);assert not rel.is_absolute()and'..'not in rel.parts and len(b)==f['bytes']and hashlib.sha256(b).hexdigest()==f['sha256']and b==Path(f['path']).read_bytes()
            if str(rel)in seen:assert seen[str(rel)]==b
            seen[str(rel)]=b;dest=root/rel;dest.parent.mkdir(parents=True,exist_ok=True)
            if dest.exists():assert dest.read_bytes()==b
            else:dest.write_bytes(b)
    # Original reader uses H paths; hydrate byte-identical copies from the
    # complete selected data/exact snapshot, without contacting live sources.
    for v in expected['compact_records']:
        for key,folder in[('data','full-checkpoints'),('exact_record','exact-slabs')]:
            b=(root/D.name/v[key]).read_bytes();dest=root/H.name/folder/f"{v['index']:04}.json";dest.parent.mkdir(parents=True,exist_ok=True)
            if dest.exists():assert dest.read_bytes()==b
            else:dest.write_bytes(b)
    argv=[sys.executable,'-B','-X','utf8',str(root/D.name/'read_selected36.py')];start=time.monotonic();r=subprocess.run(argv,cwd=root,capture_output=True,text=True,encoding='utf8');save('export-process.json',dict(argv=argv,exit_code=r.returncode,wall_time_seconds=time.monotonic()-start,stdout=r.stdout,stderr=r.stderr));assert r.returncode==0,r.stderr;got=rd(root/D.name/'selected36-result.json');assert{k:v for k,v in got.items()if k!='seconds'}=={k:v for k,v in expected.items()if k!='seconds'}
    for n in['dryrun','import']:assert rd(P/(n+'.process.json'))['exit_code']==0
    receipt=rd(P/'import.stdout.json');assert receipt['inserted']==dict(nodes=len(packet['nodes']),edges=len(packet['edges']),reviews=0);backup=Path(receipt['backup']);assert backup.is_file()and backup.stat().st_size<=rd(P/'write-plan.json')['backup_upper_each'];out=dict(status='PASS_NATIVE_COMPLETE_DOUBLE_MIDDLE_AND_FULL_EXPORTED_SELECTED36_COMPOSITION',native_run_id=receipt['run_id'],nodes=len(packet['nodes']),edges=len(packet['edges']),new_files=len(envelopes[-1]['files']),parent_method_files=[len(v['files'])for v in envelopes[:-1]],canonical_source_bytes_identical=True,all36_grammars_all3584_signed_tail_cells_and28_margins_recomputed_identical=True,original_compact_numeric_AD_proofs='Source-bound original complete per-slab numeric proofs reused; no fresh second AD leaf replay',genuine_original_prefix35_and_selected36_terminal0_retained=True,backup=str(backup),free_after=shutil.disk_usage(P).free,revision_binding='Separate subsequent guarded bind/readback required',original_global='OPEN here, final assembly audit separate');save('native-audit.json',out);print(json.dumps(out))
if __name__=='__main__':prepare()if len(sys.argv)==1 or sys.argv[1]=='prepare'else audit()
