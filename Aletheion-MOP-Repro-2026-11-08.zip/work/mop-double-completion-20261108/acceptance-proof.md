# Acceptance of the original double-parent middle: gate and mathematical scope

8 November2026. This source is staged before completion. It becomes an
accepted input ONLY with the full terminal selected36 result, genuine
original exact-reader execution through slab35, and its exact source/data
checks. It is not itself a declaration that those gates have passed.

The theorem gated here is: for EVERY old UNIT MOP H,h>=3, EVERY ordered
boundary ab and ALL independent p,q,r,s>=1 with14<=m=q+r<=41, the literal
parent B(E_(p,q),E_(r,s)),N=p+q+r+s+3, has DeltaF>2N+1/20.
No upper old order/degree/norm bound is allowed; both outer arms are infinite.
Coherent whole reflection fixes q>=r, so the actual378 middle pairs and
all16 ordered outer residues cover the original domain. Reflection changes
old ordered roots too and does not assume a symmetry of H.

The obligatory earlier77-file actual-middle method envelope supplies the
literal private graph/contact model, all-length Schur/continuant formulas,
complete infinite endpoint enclosures, direct/common AD bounds, old sector,
root-ball phase theorem, lossless positive-ray lemma, full grammar and
original23 preflight. The obligatory20-file root-direction method envelope
supplies the exact K-normalized two-direction Gram and signed spectral
tail proof. Both are complete native dependencies, not replaced by hashes.

The normalized response subtracts only the positive outer lossless rays.
Their Wplus is zero; the algebraic phase upper increases on subtraction.
It is not a graph-energy monotonicity or weighted target substitution.
The actual private reserve is G(m+2) for each fixed integer m, where
G(R)=2h²+2h sqrt(R+h²)-6,h=1-2/R. Its graph keeps this reserve over the
ENTIRE integral. Different m or different frequency witnesses are not
identified by their total or counted as extra energy credits.

The complete compact interval[1/2,5] has36 contiguous base slabs. Slabs0..15
use the complete four-infinite-curve exact enclosure containing every
actual reflected graph, with the stronger old5/2 target. Slabs16..35 use
every actual finite middle pair and both infinite outer arms, target14/5.
The complete original exact per-slab numerical proofs are reused with
all67 source hashes, exact rational areas and raw-data hashes. Slab23 is
the complete source-identical exact preflight at the identical domain and
target. A zero callback in the new composition checks ONLY full grammar,
domains and counts; it does not supply numerical leaf inequalities.
The genuine original execution observation is additionally mandatory.

The entire low interval costs at most1/2 in energy. In the complete tail
t>=5, z=1/t runs over[0,1/5]. Orthogonal K-normalized contact columns have
Gram diag((2m+9)/3,3). The all-length star/path-forest norm is less than
sqrt(m+2)+2. Whole-cell spectral calculus bounds both signed resolvents,
including the centered off-diagonal bound. The exact support density
retains both directions and all signs, including indefinite imaginary M.
Its denominator floors2u and4q are PROVED inequalities and every actual
whole-cell positive divisor is checked. No arbitrary epsilon is inserted.

For EACH of28 actual totals, all128 rational inverse-frequency intervals
are recomputed, then the exact inequality

 G_lower(m+2)-1/2-2(compact_upper+tail_upper_m)/pi_lower>1/20

must pass. These3584 whole intervals include inverse-frequency zero and
the ENTIRE infinite-frequency tail. No frequency or graph sampling closes
this theorem. The selected36 composition must actually terminate exit0.
The original56 job need not terminate successfully and is never called a
completed56 certificate. Any retirement of its redundant own process pair
requires actual identity checks and preserved original data.

The portable native-export acceptance reexecutes the SAME selected36
composition with the complete72 raw-data/exact-record snapshot, all78
computation-source identities, genuine runtime evidence and original
preflight. It rechecks full grammars, all3584 signed tails and all28
scalar margins, explicitly reusing rather than repeating the original
expensive numerical compact AD subproofs. Only runtime seconds may differ.
Independent implementation/human/formal proof review is not asserted.

This middle theorem alone is not a global theorem. The old small ordered
middle pairs, small-total C0 counter exclusion, analytic m>=42, unary
parents, BOTH completed sibling roles, whole-small-old gamma4 bridge,
original finite B71 and full structural reduction retain their scopes.
Final original-quantifier/mathematical audit is separate. Current native
status, entry delivery, mathematical truth and worldwide priority are
different claims. A failed gate leaves exactly that missing input visible.
