# Three parent forms above a deepest branch, and their whole small-old cover

8 November2026. Original ALL finite simple UNIT MOP G,n>=8,F=splus>=2n
remains GLOBAL OPEN. This is a structural reduction and a whole-small-old
bridge under the EXACT already retained gamma<=4 theorem premises. It
does not prove the two presently unpaid parent-form increments.

1. Start from the CURRENT assembled minimal-counter structure. Use the
retained original finite-base boundary n>=72, terminal-first-turn payment,
whole-small-old stops and all-mixed-branches theorem, with their declared
inherited inputs. Every terminal unary face path in such a counter is an
actual straight external-apex fan. Every deepest branching face admits
both child fan apices external relative to that face's closing edge.
These are existential descriptions of actual closed caps, not disjoint
assignment classes; a one-face triangle can have two apex descriptions.

Root the weak dual at a LEAF face using one of its boundary edges.
This root has at most one child. If the dual has no branch, the terminal
first-turn theorem makes the whole graph a fan, already whole paid at
n>=72. Otherwise choose a branching face X of MAXIMUM depth d.
It is not the root and has a parent Y at depth d-1. Its two child trees
have no branch and hence are actual straight fans; call X's closed cap
E_(p,q), p,q>=1, choosing its external/external representation.

If Y has one child, its exact terminal face tree is U(E_(p,q)). If Y
has two children, inspect X's sibling Z. If Z has no branch, Z is a
terminal straight fan P_ell and the group is B(E_(p,q),P_ell). Its apex
is either the parent's old external root or the private parent vertex;
these are precisely the TWO distinct sibling roles currently certified
separately, with their actual contacts retained. If Z contains a branch,
that branch must be Z itself: a unary step before it would put the branch
below depth d, contradicting maximality. Its two children contain no
branch for the same reason. Choose its permitted external/external
representation E_(r,s). The group is B(E_(p,q),E_(r,s)). All lengths
are positive, independently unbounded. Coherent WHOLE reflection covers
whether X is the left or right child of Y.

Thus these THREE parent forms exhaust the actual parent of a deepest
branch, not arbitrary unrelated subtrees or just one finite family. A
proper terminal subtree gives a closed chord-side cap by triangulated
polygon separation; its private vertices have no outside contacts except
the two closing roots a,b. The parent vertex c is counted private ONCE.

2. ALL old remainders of order2..7 have a whole gamma<=4 certificate.
For ANY Hamiltonian outer cycle of h<=7 with boundary edge ab, the two
adjacent vertices a,b already dominate themselves and their cycle neighbors.
For h>=4, the vertices not covered by these FOUR cycle positions lie in
one consecutive segment of at most h-4<=3 vertices. Its midpoint (or
either vertex if length2) dominates that entire segment. For h2,3 the
two roots alone suffice. Extra triangulation edges only help this
domination assertion; no monotonicity of F under edge addition is used.
Therefore the ACTUAL old H has a dominating set of the form {a,b,v},
where v may be omitted. This is stronger for this purpose than merely
knowing that an arbitrary old dominating pair exists.

For each of the three grouped parent forms, every new private vertex is
adjacent to at least one of a,b,c or is c itself. In U(E), the child's
two external apices are a,c (or reflected c,b), so they dominate both
arms and the child's center. In B(E,P), a,c dominate the left E and the
right fan's apex is b or c. In B(E,E), a,c dominate the left E and c,b
the right E. This uses the literal external/external description of
each deepest child, not the child's face tree alone.

Hence {a,b,c,v}, omitting duplicates/unneeded v, dominates the WHOLE
actual graft for EVERY independent length and every old H of order2..7.
Its domination number is<=4. Whenever total n>=8, the EXISTING full
gamma<=4 original theorem244/4133 gives F(G)>=2n, at its EXACT named
inherited finite8..71, split-fan176, charges/tail190, connected n-1 and
finite gamma4 bridge boundaries. That complete original theorem was
reread; no fresh replay of its286769-profile bridge or upgrade of those
premises is asserted. These whole-small-old graphs are therefore paid
within precisely the same inherited boundary already used by our global
minimal-counter work. A local increment into unpaid small H is not used.

This includes auxiliary old K2 as a WHOLE domination construction, not
an extension of any increment theorem from old MOP h>=3 to h2.

3. Exact remaining sufficient work. To exclude these three forms in a
minimal original counter, it now suffices to pay their actual increments
for every old H>=8; all h2..7 cases have the whole bridge in section2.
Positive increments for all three would imply global closure at the
unchanged inherited finite-base boundary, by section1 and minimality.

The B(E,P) form requires BOTH distinct sibling roles and their full
parameter ranges; the two running exact certificates are not yet accepted
by this note. U(E) (empty sibling) is NOT obtained by setting ell0 in a
theorem that required ell>=1. B(E,E) (two deepest children) is NOT the
previous S3 theorem unless all four arm lengths are1. Their general
increment obligations are OPEN. In particular, even acceptance of BOTH
current B(E,P) role families does not complete the original conjecture.

This gives an alternative sufficient route to closing bare UB directly:
pay the unary-parent and double-child families, retaining all small-old
and source boundaries. It does not assert those payments, a counterexample,
novel priority, independent mathematical audit or a LOTSE causal effect.
The exact control program reconstructs full literal unit polygons and
dominating sets and enumerates finite parent-tree coverage only to
calibrate the written all-depth and all-length arguments above.
