# Two-dipole normalization: uniform branch debt and a long-arm payment

5 November2026. Original ALL finite simple UNIT maximal outerplanar
G,n>=8,F=splus>=2n (equivalently D>=6) remains GLOBAL OPEN/goal ACTIVE.
This proves all-order quantitative increments and new necessary cuts.
The full universal external-branch floor(UB) and Fork6 remain OPEN.

1. Actual graph, complete parameter range, and the new conclusions.
Let H be ANY finite simple UNIT MOP of order>=3, ab ANY ordered boundary
edge. Retain ab. Add triangle abc and two external-apex terminal fans:
a has p>=1 path vertices L ending at c, b has q>=1 path vertices R
ending at c. All private vertices are closed relative to a,b. Put
k=p+q+1. In long-arc order the private graph B=P_k; its two contact
rows T are prefix0..p and suffixp..k-1 (both contain c at indexp).
There are2k new edges, F(B)=k-1, and TrTT^t=k+1.

THEOREM A, uniform debt: for EVERY such H,p,q,

                  F(new)-F(H)>2k-19/10.                (1)

Thus an ACTUAL old whole energy reserve F(H)-2|H|>=19/10 pays the
WHOLE new graph. There are no upper bounds on old order, any old
degree or spectrum. This is an increment for this literal two-arm cap,
not general edge-gluing or a bare one-apex fan attachment.

THEOREM B, long arm: put D0=max(deg_H(a),deg_H(b)) and
alpha=max(p-1,q-1). If

                    alpha>=max(D0,2601),

then
                  F(new)-F(H)>2k+1/50.                 (2)

The other arm is any positive integer and the far interior is
unbounded. The OLD root degrees, not whole new degrees, occur here.

2. Exact isometric state, without growing contact mass. Let J be the
root edge matrix, K=2I+J=[[2,1],[1,2]], Ki=K^-1. Direct path counts give

 G=TT^t=[[p+1,1],[1,q+1]], T(2I-B)T^t=2I.

Define a (k+1)-by-k real incidence D with first row -e0, consecutive
rows e_(j-1)-e_j and last row e_(k-1). Then D^tD=2I-B. Let
C=2I-DD^t: it is the unit path on0..k with diagonal1 at its two ends,
and zero other diagonal entries. It is an AUXILIARY real symmetric
matrix, not assigned an original graph energy. Both
2I-C=DD^t>=0 and2I+C=4I-DD^t>0; the latter quadratic form is the sum
of consecutive squared sums plus twice the two endpoint squares.
Thus its spectrum is in(-2,2]. The vector of all ones is its eigen2
direction. DB=CD, so the resolvents intertwine.

Put W=DT^t. Its columns are EXACTLY
 w_a=e_(p+1)-e0, w_b=e_k-e_p.
All four coordinates are distinct for p,q>=1. Thus W^tW=2I and both
columns are orthogonal to the all-ones vector. V=W/sqrt2 is an isometry.
For t>0 set

 S(t)=V^t(tI+iC)^-1 V,
 Z=t+2i,
 Fcap=T(tI+iB)^-1T^t=(G+2iS)/Z.                      (3)

The identity follows by multiplying the original resolvent by Z and
using D^tD=2I-B. The SAME finite auxiliary C and V supply S at ALL
frequencies. In particular ||S(t)||<=1/t. No independent pointwise
choice of S or replacement of the physical parent is made.

This builds on the preceding q2 proof's zero-support path shaving;
the new content is the two-channel isometry and the uniform bounds
below, not a claim to first use of that shaving principle.

3. Preserve further state constraints. The first compressed moment is

 V^tCV=[[1/2,(1_(p1)+1_(q1)-1)/2],
         [(1_(p1)+1_(q1)-1)/2,1/2]].                 (4)

It is the root-plus projector for p=q1, I/2 for exactly one arm1, and
the root-minus projector when both arms>=2. These are MOMENT classes,
not equal physical responses or equal graphs. Every frequency still
uses the whole path-generated spectral measure.
If k is even its zero atom is zero. If k is odd, define
P(j)=1 if j mod4 is1or2, otherwise0; A=P(p+1), B0=P(k)-P(p). Then

 V^t E_C({0}) V =2/(k+1) (A,B0)^t(A,B0).              (5)

Indeed the Dirichlet private path's zero vector is(1,0,-1,0,...),
with squared norm(k+1)/2. The intertwinement gives the same compressed
zero atom. Its norm is<=4/(k+1)<=1; for Fork6 it is exactly the
root-minus projector, while p=q2 gives zero. No zero mode is discarded.

4. A signed normalized response which is still accretive. Set
E=diag(p-1,q-1)>=0 and

 Fstar=(K+2iS)/Z, so Fcap=Fstar+E/Z.                 (6)

Fstar is NOT asserted to be a physical graft. In its formal resolvent
partial fractions, shaving creates a negative residue -E at lambda2.
We use only the following actual algebraic properties on real t>0.
Write S=tQ-iM, where Q=V^t(t^2+C^2)^-1V>0 and M is real symmetric.
Because C>=-2I, M+2Q>=0. Direct calculation gives

 ReFstar=t[K+2M+4Q]/(t^2+4)>=tK/(t^2+4)>0,
 2ReFstar+tImFstar=2tQ>=0.                          (7)

Thus Fstar has the precise positivity needed by the old root-sector
homotopy. This is not a graph-realizability or energy-transfer claim.

5. Pointwise phase domination, with a measurable strict reserve.
Let F0(t) be the SAME actual old response. Source201 proves Wplus(F0)
=2ReF0+tImF0>=0 for every original boundary. Put
Zstar=tI+iJ+F0+Fstar, Z_s=Zstar+s E/Z, H_s=Z_s^-1.
All Z_s are strictly accretive, and

 2ReZ_s+tImZ_s=tK+Wplus(F0)+Wplus(Fstar)>=tK,

since Wplus(E/Z)=0. Inverse congruence gives
2ReH_s-tImH_s=H_s^*(2ReZ_s+tImZ_s)H_s>=tH_s^*KH_s>0.
Consequently the continuous trace-log derivative satisfies

 d_s ImTrLog Z_s
 =ImTr(H_s E/Z)
 =-Tr[E(2ReH_s-tImH_s)]/(t^2+4)<=0.                (8)

Let delta_full,delta_star be the phases of Z_full,Zstar relative to
the OLD root matrix tI+iJ+F0, using their accretive trace logs anchored
at infinity. There is no rewrapped determinant argument. Equation(8)
proves delta_full<=delta_star pointwise, strictly if E is nonzero.
Both t-weighted integrals converge: the low phases are bounded by2pi,
and their large-t phases are O(t^-3). In particular delta_star has
leading term -6/t^3, from Fstar=K/t-i[[2,2],[2,2]]/t^2+O(t^-3).
Define I_full=integral t delta_full and Jstar=integral t delta_star.
Integrating(8) retains the quantitative lower reserve

 Jstar-I_full >= R,
 R=integral_0^infinity [t^2/(t^2+4)]
                  integral_0^1 Tr(E H_s^* K H_s)ds dt. (9)

If E=0 the difference is0; if E!=0 the actual difference and R are
positive. All matrices in this formula come from ONE old parent and
ONE actual p,q cap. Positive phase contributions elsewhere are not
silently omitted; (9) is a nonnegative integral over the entire axis.

6. A complete uniform bound Jstar<3. The full-cap root matrix-ball
argument applies to Fstar by(7), without claiming physical realization.
It gives t delta_star<=V(t,Fstar), where

 V(t,F)=ImTrKiF-t ReTrKiF/2
                   +sqrt(t^2+4)||Ki^1/2 F Ki^1/2||_*/2.

This follows by completing the inverse sector square and trace-norm
duality, as in the retained complete-cap homotopy proof. Put
L=Ki^1/2 S Ki^1/2. Substitution in(6) cancels ALL explicit Z factors:

       V(t,Fstar)=ImTrL-1+||I+2iL||_*/2.             (10)

For any two-by-two complex A, its singular values obey
sigma<=(1+sigma^2)/2, hence ||A||_*<=(2+||A||_F^2)/2.
Taking A=I+2iL in(10) gives the GLOBAL bound V<=||L||_F^2.
In a Ki eigenbasis its eigenvalues are1,1/3. Using
lambda_i lambda_j<=(lambda_i^2+lambda_j^2)/2 and the row AND column
norm bounds on S yields

              0<=V(t,Fstar)<=10/(9t^2).              (11)

This uses the whole isometric state, not a bound only at large t.
It includes every noncommuting term and all frequencies. On0..epsilon
use instead delta_star<2pi, since both 2-by-2 trace logs have imaginary
parts in(-pi,pi). With epsilon=4/7, (11) on the ENTIRE remaining tail gives

 Jstar <pi epsilon^2+10/(9epsilon)
        <18341/6174<3.                              (12)

No compact interval or infinite tail is dropped; no quadrature is used.

7. Convert back to the SAME actual energy increment. The private path
is bipartite and its determinant is positive real for t>0. The exact
equal-trace phase identity therefore gives

 DeltaF=F(B)+TrTT^t-(2/pi)I_full=2k-(2/pi)I_full.

Using(9) and the unrounded first bound in(12),

 DeltaF>2k-[2epsilon^2+20/(9pi epsilon)]+(2/pi)R
        >2k-130966/69237+(2/pi)R
        >2k-19/10.                                  (13)

Here pi>157/50 bounds the positive reciprocal term; the low pi cancels
exactly. This proves TheoremA, with a preserved positive length reserve.
The uniform debt is not a proof of its desired nonnegative limit0.

8. A long arm recovers the entire debt, independently of the far graph.
For an original old boundary, G0=R0R0^t has diagonal degrees-1 and
offdiagonal1, so ||G0||<=D0. The actual Hermitian resolvent gives
||F0(t)||<=D0/t, without bounding the far interior norm or order.
Suppose alpha=max(p-1,q-1)>=max(D0,2601), and put l=sqrt(alpha)>=51.
For t in[l,2l] and0<=s<=1,

 ||Z_s||<=t+1+D0/t+||Fstar||+alpha/t
         <=4l+1+4/l <=(41/10)l.

We used ||Fstar||<=(3+2/t)/sqrt(t^2+4)<=4/t for t>=2.
Thus H_s^* K H_s>=(100/(1681 l^2))I and TrE>=alpha=l^2.
Also t^2/(t^2+4)>=99/100 on this interval. Restricting the NONNEGATIVE
reserve(9) to this verified interval gives

 R>=99l/1681>=5049/1681.

By(12), R-Jstar>5049/1681-18341/6174. It is positive and
(7/11) times this rational difference is>1/50. Since2/pi>7/11,
the actual energy increment is>2k+1/50, proving TheoremB. The interval
and old-degree premise are essential to THIS quantitative conclusion.

9. Exact effect on the remaining original counter domain. The previous
all-mixed exclusion and elementary small-old proof imply that every
deepest branch of a minimal original counter n>=72 admits this external/
external representation and leaves old h>=8. Put eta=F(H)-2h. Minimality
gives eta>=0. TheoremA rules out eta>=19/10; TheoremB rules out the
long-arm premise. Therefore every such actual branch must have

       0<=eta<19/10,
       max(p,q)<=max(D0,2601).                       (14)

Old h2..7 is paid by the previous elementary WHOLE small-core theorem,
not by an unwarranted2h premise. The inherited finite8..71 boundary and
other named structural inputs remain. No gamma4 input is added here.
This narrows the required WHOLE-graph compensation: the stronger(UB)
for every parent would still suffice, but only the near-threshold
parents in(14) can be relevant to an original counter. One may instead
prove I_full<=pi eta/2 there; that remaining bridge is OPEN.

10. Verification, prior limits and next actual work. The separate
stdlib reader checks400 literal integer path/incidence states, all
isometry/intertwinement/moment/kernel identities and75 direct rational
full-resolvent comparisons with the dual state and normalized response.
It verifies every rational constant and rejects the empty-arm, missing
length-threshold and missing-old-degree premises. The ALL-order proof
is the written factorization, matrix inequalities and complete integrals,
not extrapolation from these controls. Algebra utilities are shared;
there is no external human/formal audit or first-method/priority claim.

For p0 or q0 the nonnegative shaving and orthogonal dipole mass used
here fail. The known bare-fan/C0 underpayments and unbounded generic
fan-edge-gluing loss remain valid. The latter comparison uses the
whole energy of a second growing fan; our baseline2k
counts only new vertices and does not include that fan's growing reserve.
No such whole-fan additivity is asserted. The exact83vertex concentration
counter, Fork6 pointwise-phase counter and twofan vanishing-margin limit
also remain valid. Neither a signed Fstar energy nor a pointwise
Fork-dominance assertion is made. The raw nonouter/weighted numerical
controls are not original counterexamples or accepted universal results.
The next work retains the SAME old physical response and the whole
path-generated state in the remaining near-threshold regime, with its
positive reserve(9) available. Original full goal remains ACTIVE/OPEN.
