"""Explicit bounded foreground producer. Floating output is never acceptance."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,time,sys
import bulk_band_scout as scout
from bulk_band_cover import Cover
P=Path(__file__).resolve().parent
INPUTS=['produce_bulk_bands_v2.py','read_bulk_bands_v2.py','bulk_band_cover.py','bulk_band_scout.py','bulk-frequency-grid.json','bulk-band-budget.json','bulk-band-coverage.json','bulk_small_tail.py','uniform_private_tail.py','private_ad5.py','private_common_ad5.py','float_discovery.py','exact.py','disk_interval.py','net_interval.py','rational_grid.py','curve_interval.py','private-model-verification.json','native-audit.json','check_bulk_tail_controls.py','bulk-tail-controls.json']
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def atomic(path,value):
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(value,separators=(',',':'))+'\n');temp.replace(path)
def main():
    prefix='--prefix'in sys.argv;start=time.monotonic();folder=P/'bulk-band-v2-checkpoints';folder.mkdir(exist_ok=True)
    hashes={name:sha(P/name)for name in INPUTS};manifest=folder/'producer-inputs.json'
    if manifest.exists():assert json.loads(manifest.read_bytes())==hashes,'frozen inputs changed: inspect without overwriting'
    else:atomic(manifest,hashes)
    grid=json.loads((P/'bulk-frequency-grid.json').read_bytes());attempts=[]
    def cell(name,a,b,target,depth=0):
        result=scout.solve(name,float(a),float(b),float(target)-1e-7)
        if result['status']=='HEURISTIC_BAND_COVER':return dict(a=str(a),b=str(b),trees=result['trees'],stats=result['stats'])
        print(json.dumps(dict(status='HEURISTIC_BAND_FREQUENCY_REFINEMENT',band=name,a=str(a),b=str(b),depth=depth,reason=result['reason'])),flush=True)
        assert depth<8,'bounded frequency refinement exhausted';mid=(a+b)/2
        return dict(a=str(a),b=str(b),split=[cell(name,a,mid,target,depth+1),cell(name,mid,b,target,depth+1)])
    for name in ['small','large']:
        cover=Cover(name)
        for index,row in enumerate(grid[:1]if prefix else grid):
            path=folder/f'{name}-{index:04}.json'
            if path.exists():continue
            a,b=F(row['a']),F(row['b']);target=cover.amplitude/(1+((a+b)/2)**2)
            print(json.dumps(dict(status='HEURISTIC_BAND_CELL_STARTED',band=name,index=index,total=len(grid))),flush=True)
            partition=cell(name,a,b,target);atomic(path,dict(band=name,index=index,target=str(target),partition=partition))
            print(json.dumps(dict(status='HEURISTIC_BAND_CHECKPOINT',band=name,index=index,total=len(grid),seconds=time.monotonic()-start)),flush=True)
    assert all(sha(P/name)==value for name,value in hashes.items()),'source changed during producer'
    if prefix:
        print(json.dumps(dict(status='HEURISTIC_TWO_BAND_PREFIX_READY_REQUIRES_EXACT_READER',seconds=time.monotonic()-start)),flush=True);return
    cert=dict(format='private-sibling-two-bands-one-unbounded-arm-v1',source_sha256=hashes,cells={name:[json.loads((folder/f'{name}-{j:04}.json').read_bytes())for j in range(len(grid))]for name in ['small','large']},original_global='OPEN')
    atomic(P/'bulk-band-v2-certificate.json',cert)
    print(json.dumps(dict(status='HEURISTIC_TWO_BAND_CERTIFICATE_READY_REQUIRES_EXACT_READER',base_cells=160,seconds=time.monotonic()-start)),flush=True)
if __name__=='__main__':main()
