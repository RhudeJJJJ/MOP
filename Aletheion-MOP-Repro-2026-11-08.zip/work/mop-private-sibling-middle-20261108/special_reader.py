"""Exact entire frequency/ONE infinite p family, fixed PRIVATE q1 ell2; no float import."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,time,sys
import rational_grid
rational_grid.install()
import private_ad5 as direct,private_common_ad5 as common,special_tail as tail,net_interval as net
P=Path(__file__).resolve().parent
NAMES={'special_produce.py','special_reader.py','special_tail.py','special-grid.json','float_discovery.py','private_ad5.py','private_common_ad5.py','disk_interval.py','net_interval.py','rational_grid.py','curve_interval.py','exact.py'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def tree(code,a,b,target,p):
    pos=leaves=anchor=0;upper=F(0)
    def visit(p,tail):
        nonlocal pos,leaves,anchor,upper
        assert pos<len(code),'truncated special tree';symbol=code[pos];pos+=1;anchor=max(anchor,p)
        if symbol in'04':
            value=(common if symbol=='0'else direct).bound(a,b,F(0)if tail else F(1),F(1),F(1),F(1),F(1),F(1),F(3),F(3),p,2,1)['upper']
            assert value<=target,'exact special leaf misses target';upper=max(upper,value);leaves+=1;return
        assert symbol=='1'and tail,'invalid special split';visit(p,False);visit(p+4,True)
    visit(p,True);assert pos==len(code),'special tree suffix';return upper,leaves,anchor
def frequency(part,a,b,target):
    assert F(part['a'])==a and F(part['b'])==b and a<b
    if'split'in part:
        assert'trees'not in part and len(part['split'])==2;mid=(a+b)/2;x=frequency(part['split'][0],a,mid,target);y=frequency(part['split'][1],mid,b,target);return x[0]+y[0],x[1]+y[1],max(x[2],y[2]),x[3]+y[3]
    assert len(part['trees'])==4,'all FOUR ordered p residues required';maximum=F(0);leaves=anchor=0
    for p,code in enumerate(part['trees'],1):value,count,depth=tree(code,a,b,target,p);maximum=max(maximum,value);leaves+=count;anchor=max(anchor,depth)
    return(b-a)*maximum,leaves,anchor,1
def main():
    start=time.monotonic();reader_hash=sha(Path(__file__));preflight='--preflight'in sys.argv;live='--live'in sys.argv;manifest=json.loads((P/'special-inputs.json').read_bytes());assert set(manifest)==NAMES and all(sha(P/n)==v for n,v in manifest.items())
    grid=json.loads((P/'special-grid.json').read_bytes());cert=None if live or preflight else json.loads((P/'special-certificate.json').read_bytes());seen=[];areas=[];end=F(1,4);total=F(0);leaves=anchor=fcells=0
    for index,row in enumerate(grid):
        if preflight and index>0:break
        if live or preflight:
            path=P/'special-checkpoints'/f'{index:04}.json';deadline=time.monotonic()+600
            while not path.exists():assert time.monotonic()<deadline,'bounded special checkpoint wait expired';time.sleep(.25)
            data=json.loads(path.read_bytes())
        else:data=cert['cells'][index]
        a,b=F(row['a']),F(row['b']);assert a==end and data['index']==index;end=b;seen.append(data);area,count,depth,nfreq=frequency(data['partition'],a,b,F(data['target']));total+=area;leaves+=count;anchor=max(anchor,depth);fcells+=nfreq;areas.append(dict(index=index,area_upper=str(area),leaves=count,anchor=depth,frequency_cells=nfreq))
        if index%10==0:print(json.dumps(dict(status='EXACT_SPECIAL_PROGRESS',index=index,total=len(grid),leaves=leaves,seconds=time.monotonic()-start)),flush=True)
    if preflight:
        out=dict(status='PASS_EXACT_SPECIAL_ONE_BASE_CELL_PREFLIGHT_ONLY',area_upper=str(total),leaves=leaves,anchor=anchor,frequency_cells=fcells,full_special_root_payment='OPEN',original_global='OPEN',seconds=time.monotonic()-start);(P/'special-preflight-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out));return
    assert end==8
    if live:cert=json.loads((P/'special-certificate.json').read_bytes())
    assert cert['format']=='private-q1-ell2-infinite-p-v1'and cert['q']==1 and cert['ell']==2 and cert['cells']==seen and cert['source_sha256']==manifest
    assert all(sha(P/n)==v for n,v in manifest.items())and sha(Path(__file__))==reader_hash
    It=sum((tail.tail(F(k,512),F(k+1,512))[1]/512 for k in range(64)),F(0));gain=F(7,5)-F(1,8)-2*(total+It)/net.PI[0];assert gain>F(1,10)
    out=dict(status='PASS_EXACT_PRIVATE_q1_ell2_ALL_p_FULL_ROOT_PAYMENT',compact_integral_upper=str(total),tail_integral_upper=str(It),surplus_lower=str(gain),surplus_float=float(gain),proved_surplus='1/10',frequency_cells=fcells,length_leaves=leaves,max_p_anchor=anchor,q=1,ell=2,outer_p='UNBOUNDED',certificate_sha256=sha(P/'special-certificate.json'),reader_sha256=reader_hash,seconds=time.monotonic()-start,original_global='OPEN',scope='Fixed PRIVATE q1 ell2; full actual graph/source proof and intake separate. General bulk/private role and original global OPEN.')
    (P/'special-reader-cells.json').write_text(json.dumps(areas,separators=(',',':'))+'\n');(P/'special-reader-result.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
if __name__=='__main__':main()
