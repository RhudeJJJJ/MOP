"""Specific q1 ell2 actual tail constants and damaged ONE-infinite-axis grammar."""
from pathlib import Path
from fractions import Fraction as F
import json
import special_reader as reader
import exact as e,geometry as g,private_physical as phys
P=Path(__file__).resolve().parent
def rejected(fn):
    try:fn()
    except(AssertionError,ArithmeticError):return 1
    raise AssertionError('damaged special cover accepted')
def main():
    cases=0
    for p in(1,2,5,9):
        B,T=g.cap(p,1,2);N=len(B);assert max(map(sum,B))==4
        V=e.mm(B,e.tr(T));V=[[x-2*y for x,y in zip(row,rr)]for row,rr in zip(V,e.tr(T))]
        assert e.mm(T,V)==[[-2,0],[0,-2]]and e.mm(e.tr(V),V)==[[8,4],[4,8]]
        for t in(F(8),F(16)):
            z2=1/(t*t);BB=e.mm(B,B);R=e.inverse([[int(i==j)+z2*BB[i][j]for j in range(N)]for i in range(N)]);C=e.mm(e.mm(e.tr(V),R),V);D=e.mm(e.mm(e.mm(e.tr(V),B),R),V)
            assert 0<=C[0][0]<=8 and 0<=C[1][1]<=8 and abs(C[0][1])<=8 and all(abs(x)<=32 for row in D for x in row)
            full=phys.response(p,1,2,t);aa=1+4*z2;Q=[[3,1],[1,2]]
            for i in range(2):
                for j in range(2):
                    qp=Q[i][j]/aa+8*z2*int(i==j)/(aa*aa)-z2*((1-4*z2)*C[i][j]-4*z2*D[i][j])/(aa*aa)
                    mp=2*Q[i][j]/aa-2*(1-4*z2)*int(i==j)/(aa*aa)-z2*((1-4*z2)*D[i][j]+4*C[i][j])/(aa*aa)
                    assert qp==t*full[i][j][0]and mp==-t*t*full[i][j][1]
            cases+=1
    a,b,target=F(1),F(1001,1000),F(1);oldD,oldC=reader.direct.bound,reader.common.bound
    try:
        reader.direct.bound=reader.common.bound=lambda *args:dict(upper=F(1,10))
        part=dict(a=str(a),b=str(b),trees=['0']*4);assert reader.frequency(part,a,b,target)==((b-a)/10,4,4,1)
        assert reader.tree('100',a,b,target,1)[1]==2
        tests=[lambda:reader.tree('',a,b,target,1),lambda:reader.tree('00',a,b,target,1),lambda:reader.tree('2',a,b,target,1),lambda:reader.tree('1',a,b,target,1),lambda:reader.tree('11000',a,b,target,1),lambda:reader.frequency(dict(part,trees=['0']*3),a,b,target),lambda:reader.frequency(dict(part,a='0'),a,b,target),lambda:reader.frequency(dict(a=str(a),b=str(b),split=[part]),a,b,target),lambda:reader.frequency(dict(a=str(a),b=str(b),split=[part,part]),a,b,target)]
        damage=sum(rejected(f)for f in tests)
    finally:reader.direct.bound=oldD;reader.common.bound=oldC
    damage+=rejected(lambda:reader.tree('0',a,b,F(0),1))
    out=dict(status='PASS_SPECIAL_PRIVATE_q1_ell2_TAIL_IDENTITIES_AND_DAMAGED_COVERAGE',actual_full_private_tail_cases=cases,geometry_p_states=4,actual_gram=[[8,4],[4,8]],all_p_norm_bound='4 by exact maximum private row degree4; written all-p geometry proof',residue_roots=4,damaged_coverages_rejected=damage,scope='Full graph inputs and grammar calibration; full frequency numerical acceptance remains separate',original_global='OPEN')
    (P/'special-support-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
