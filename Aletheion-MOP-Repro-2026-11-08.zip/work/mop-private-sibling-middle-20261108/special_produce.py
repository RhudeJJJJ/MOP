"""FLOAT partition for fixed PRIVATE q1 ell2 and ALLp, atomic bounded foreground."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,time,sys
import float_discovery
float_discovery.install()
import private_ad5 as direct,private_common_ad5 as common
P=Path(__file__).resolve().parent
NAMES=['special_produce.py','special_reader.py','special_tail.py','special-grid.json','float_discovery.py','private_ad5.py','private_common_ad5.py','disk_interval.py','net_interval.py','rational_grid.py','curve_interval.py','exact.py']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def atomic(path,data):
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(data,separators=(',',':'))+'\n');temp.replace(path)
def solve(a,b,target,limit=2000):
    calls=leaves=anchor=0;maximum=0.
    def visit(p,tail):
        nonlocal calls,leaves,anchor,maximum
        calls+=1;anchor=max(anchor,p)
        if calls>limit or p>160:raise ArithmeticError('bounded special selector limit')
        best=None
        for module,symbol in((common,'0'),(direct,'4'))if a<2 else((direct,'4'),(common,'0')):
            got=module.bound(a,b,0. if tail else 1.,1.,1.,1.,1.,1.,3.,3.,p,2,1);got['symbol']=symbol
            if best is None or got['upper']<best['upper']:best=got
            if best['upper']<=target:break
        if best['upper']<=target:leaves+=1;maximum=max(maximum,best['upper']);return best['symbol']
        if not tail:raise ArithmeticError('special singleton frequency refinement required')
        return'1'+visit(p,False)+visit(p+4,True)
    try:return dict(trees=[visit(p,True)for p in range(1,5)],calls=calls,leaves=leaves,anchor=anchor,maximum=maximum)
    except ArithmeticError as error:return dict(refine=str(error),calls=calls)
def main():
    start=time.monotonic();hashes={n:sha(P/n)for n in NAMES};manifest=P/'special-inputs.json'
    if manifest.exists():assert json.loads(manifest.read_bytes())==hashes,'changed special inputs; preserve checkpoint evidence'
    else:atomic(manifest,hashes)
    folder=P/'special-checkpoints';folder.mkdir(exist_ok=True);grid=json.loads((P/'special-grid.json').read_bytes());preflight='--preflight'in sys.argv
    def cell(a,b,target,depth=0):
        got=solve(float(a),float(b),float(target)-1e-7)
        if'refine'not in got:return dict(a=str(a),b=str(b),trees=got['trees'],stats={k:v for k,v in got.items()if k!='trees'})
        assert depth<8,'special bounded frequency refinement exhausted';mid=(a+b)/2
        return dict(a=str(a),b=str(b),split=[cell(a,mid,target,depth+1),cell(mid,b,target,depth+1)])
    for index,row in enumerate(grid):
        if preflight and index>0:break
        path=folder/f'{index:04}.json'
        if path.exists():continue
        a,b=F(row['a']),F(row['b']);target=F(13,10)/(1+((a+b)/2)**2);atomic(path,dict(index=index,target=str(target),partition=cell(a,b,target)))
        if index%10==0:print(json.dumps(dict(status='HEURISTIC_SPECIAL_CHECKPOINT',index=index,total=len(grid),seconds=time.monotonic()-start)),flush=True)
    assert all(sha(P/n)==v for n,v in hashes.items())
    if preflight:print(json.dumps(dict(status='HEURISTIC_SPECIAL_FIRST_CELL_READY_REQUIRES_EXACT_READER',seconds=time.monotonic()-start)),flush=True);return
    cert=dict(format='private-q1-ell2-infinite-p-v1',q=1,ell=2,source_sha256=hashes,cells=[json.loads((folder/f'{j:04}.json').read_bytes())for j in range(len(grid))],scope='ALLp>=1, complete low/high frequency retained separately; ORIGINAL GLOBAL OPEN');atomic(P/'special-certificate.json',cert);print(json.dumps(dict(status='HEURISTIC_SPECIAL_FULL_CERTIFICATE_READY_REQUIRES_EXACT_READER',base_cells=len(grid),seconds=time.monotonic()-start)),flush=True)
if __name__=='__main__':main()
