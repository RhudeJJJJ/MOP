# Private bull surplus for every three-parameter external child cap

8 November 2026. The ORIGINAL global MOP conjecture remains OPEN. This
note proves a PRIVATE energy floor for ALL p,q,ell>=1. It does not pay
the full q-dependent root phase or imply complete original coverage.

Use parent abc on retained old boundary ab, E_(p,q) child on ac with
external child apices a,c, and external b-apex sibling fan ell on cb.
The private graph B is a core Fan_(q+2), on path d,r1,...,rq plus hub c,
with a pendant path p at d and a pendant path ell at c. In private order
left_p,d,right_q,c,sibling_ell, its exact unit geometry has

 N=p+q+ell+2, edges(B)=N+q-1, Tr TTt=N-q+1.

The actual old edge is retained once. Geometry.py constructs the literal
unit noncrossing edges and full asymmetric root contacts. The two root
roles are not identified by reflection.

THEOREM. With c0=(sqrt13-sqrt5)/2, EVERY such integer triple obeys

 F(B)>=N+q-1+c0, hence F(B)+Tr TTt>=2N+c0.                (1)

Equality in the private floor occurs only at p=q=ell=1. For q>=10 a
stronger explicit private surplus above edges is f(q+1)-1, where
f(r)=2sqrt(r)-2/sqrt(r)-4-2/r+1/r^2. Full actual graft root costs remain
to be subtracted; (1) is not an increment theorem.

## 1. Finite small core sizes, with both outer lengths unbounded

For the unit path P_m put S_m=tI+iA(P_m), D_m=det S_m,
X_m=e_(m-1)^t adj(S_m) 1, E_m=1^t adj(S_m)1. The empty conventions
are D0=1,X0=E0=0; D1=t,X1=E1=1. Tridiagonal elimination and the
Desnanot-Jacobi identity give the exact Gaussian-polynomial recurrences

 D_(m+1)=t D_m+D_(m-1),
 X_(m+1)=D_m-i X_m,
 E_(m+1)=t E_m+E_(m-1)+D_m-2i X_m.                      (2)

For the last identity, appending the last path vertex gives
E_(m+1)=tE_m+D_m-2iX_m+(D_(m-1)E_m-X_m^2)/D_m, and the numerator
in its last term equals D_m E_(m-1). Apply Desnanot-Jacobi to the
bordered matrix [[S_m,1],[1t,0]], whose determinant is -E_m.
Every D_m(t)>0 for t>0, so the elimination is legitimate.

Set m=q+1. A real correction r at the first path vertex changes its
determinant to D_m+rD_(m-1) and its coronal numerator to E_m+rE_(m-1).
Both statements are exact diagonal-cofactor identities; removing the
first vertex leaves the uniform path of length m-1, with the same all-one
source. Adding hub c gives the core determinant

 Z(t,r,s)=(t+s)(D_m+rD_(m-1))+E_m+rE_(m-1).             (3)

Actual outer paths give r=D_(p-1)/D_p,s=D_(ell-1)/D_ell in (0,1/t].
Their two eliminated determinant factors D_p D_ell are positive real.

For EACH q=1,...,9, check_all_q_private_floor.py computes (2) exactly
over Q[i][t]. It checks nonnegative coefficients of R_m=Re E_m,
R_(m-1),M_m=-Im E_m,M_(m-1), with M_m nonzero. Thus (3)=C-iM has
C>0,M>0 for ALL t>0,r,s>=0. Its lifted phase is -atan(M/C), anchored
at infinity. Increasing s to1/t decreases M/C. At s=1/t write

 tC=C0+rC1,
 C0=(t^2+1)D_m+tR_m, C1=(t^2+1)D_(m-1)+tR_(m-1).

For EACH of the NINE specified q values the same coefficient checker
proves that M_m C1-M_(m-1)C0 has nonnegative coefficients and is nonzero.
It is therefore strictly positive for every t>0. Consequently M/C also
decreases as r increases to1/t. This proves, for EACH of those q and
ALL outer p,ell, that the absolute negative phase is at least its
p=ell=1 value. The order of the two comparisons is essential; no claim
of r-monotonicity at every smaller s is made.

Use the accepted equal-trace Coulson identity
D(B)=-(4/pi) integral_0^infinity t Im Tr Log(tI+iB) dt. All private
and zero modes remain present. The determinant factors above are
positive real, so their branch introduces no extra argument. The
identity also follows directly by summing the eigenvalue functions
atan(lambda/t): trace B=0 cancels their divergent linear terms, and
integration gives -(pi/4)sum lambda|lambda|. This uses the finite actual
spectrum, including zero contributions, and no graph-specific assumption.
The
pointwise phase comparison gives D(B)>=D(B_min(q)), where B_min(q)
has p=ell=1. No finite outer-length truncation is used.

For q1, the bull has characteristic
x(x^2-x-3)(x^2+x-1), hence D(B_min(1))=sqrt13-sqrt5. The inherited
one-triangle comparison is strict when either outer length exceeds1.
For EACH q2,...,9, the checker builds the literal B_min(q), computes
its full exact characteristic polynomial, and isolates ALL distinct
real roots with rational Sturm arithmetic. Repeated-root multiplicities
are recovered by successive gcd layers; every zero mode is counted
explicitly. Sum of positive lower-end squares minus negative upper
magnitude squares proves D(B_min(q))>12/5. This is more than 2c0,
since c0=4/(sqrt13+sqrt5)<20/29<7/10.

Thus (1), strictly except the bull equality case, is established for
ALL p,ell at the finite small-core range q1,...,9. The additional108
full PRIVATE characteristic controls calibrate (3) against literal
two-path elimination at rational t; these controls do not establish
the universal p,ell quantifier. Identities (2),(3) and the exact
coefficient signs establish that quantifier.

## 2. The entire unbounded core range q>=10

Pinch the actual private adjacency into its THREE disjoint principal
blocks Fan_(q+2),P_p,P_ell. Convexity of the spectral trace functional
F(A)=Tr((A_+)^2) gives

 F(B)>=F(Fan_(q+2))+(p-1)+(ell-1).                    (4)

This partitions vertices once; it deletes only the two cross-block
edges for the pinching comparison. It does not sum overlapping motif
credits or replace the old root by an independent graph.

For completeness, derive the needed analytic fan lower bound directly.
Let r=q+1, and delete the hub of Fan_(r+1), leaving P_r. Its largest
eigenvalue is below2 and F(P_r)=r-1. Full interlacing gives
F(Fan_(r+1))>rho^2+r-5. The Rayleigh vector with hub coordinate sqrt r
and path coordinates1 gives rho>=sqrt r+1-1/r. Expanding the square
therefore gives the all-r bound

 F(Fan_(r+1))>2r+f(r).                               (5)

These are the same retained analytic inequalities in
fan_direct_D_bound_proof.txt and hereditary-retirement-proof.md. The
finite small-fan spectral theorem is not needed for this use of (5).
Combining (4),(5) gives F(B)>edges(B)+f(q+1)-1 for EVERY q>=10 and
EVERY p,ell. Function f is increasing for r>=1: its derivative is
r^(-1/2)+r^(-3/2)+2r^(-2)-2r^(-3)>0. Since sqrt11>33/10,

 f(11)-1>66/10-20/33-5-2/11+1/121=1489/1815>7/10>c0.

This closes the entire infinite q tail with no extrapolation of the
q1..9 or the exploratory q1..127 computations. Together with section1
it proves (1) for ALL THREE independent unbounded integer lengths.

## 3. Actual consequence and remaining global obligation

The universal private/contact starting surplus c0 no longer requires
a fixed q. The larger explicit f(q+1)-1 budget is available for all
q>=10, and exact finite base budgets are retained at q2..9. The next
root-payment work may use these quantified budgets without reopening
the private-energy question. Its full q-dependent same-root phase cost
is still unpaid outside already certified q families. No full all-q
increment, original minimal-counter coverage or global compensation
theorem follows merely from (1). No priority, human/formal external
audit or LOTSE causal effect is claimed. Native intake is still pending.
