# Both internal lengths at a private sibling apex: complete large tail

8 November 2026. ORIGINAL every finite simple UNIT maximal outerplanar
graph G of order n>=8 has F(G)=splus(G)>=2n remains GLOBAL OPEN.
This note treats a different actual cap from the external-b sibling cap.
It does not identify their contacts or transfer a root-phase certificate.

THEOREM. For EVERY old UNIT MOP H of order h>=3, EVERY ordered boundary
edge ab and EVERY independent integers p,q,ell>=1 with q+ell>=56, form
the following actual graft. Keep ab once, add parent abc, an external
E_(p,q) child on ac (first child apex a, second child apex c), and a
sibling fan of length ell on cb whose apex is PRIVATE c. With
N=p+q+ell+2 new vertices and 2N added unit edges, the result satisfies

                     F(G)-F(H)>2N+1/25.                   (1)

No old degree, spectral-norm or upper-order bound is imposed. Auxiliary
K2 is not included in the inherited branch theorem's h>=3 domain.

1. Exact vertices, roles and intermediate graph. Write the private
outer order as left_p,d,middle_q,c,sibling_ell. Besides parent edges ac,bc
and the child edge ad,dc, the left fan has apex a along a,left_p,d;
the middle fan has apex c along d,middle_q,c; and the sibling fan has
apex c along c,s1,...,s_ell,b. All consecutive path edges and fan spokes
occur once; there are no additional contacts to H.

Delete the q middle vertices and s1,...,s_(ell-1), retaining s_ell.
The SAME induced intermediate Hbar is the external/external branch
E_(p+1,1) on ab. Its k=p+3 private vertices are left_p,d,c,s_ell.
The retained edge c,s_ell is the old spoke, which becomes the boundary
edge after deletion. The accepted quantitative branch theorem therefore
applies to the actual Hbar and original H:

                F(Hbar)-F(H)>2k-184/157.                   (2)

In Hbar the NEW vertex c has exactly the FOUR neighbors a,b,d,s_ell.
The hereditary retirement theorem on chordal outerplanar graphs gives

                F(Hbar)-F(Hbar-c)<=U(4)=8,
                U(D)=min(2D,D+2sqrt(D)).                  (3)

Only c is retired, once. Original old vertices, including ab, remain
in Hbar-c. No unrelated optimal witnesses are added together.

2. A fully analytic two-path join bound. Let r>=2 and let P be a
disjoint union of at most two finite paths on r total vertices, allowing
an empty component. Then P is bipartite with at least r-2 edges, so
F(P)>=r-2; its largest adjacency eigenvalue mu1 has mu1^2<4. Let J be
the actual graph K1 join P. Principal interlacing, keeping all positive
eigenvalues and all zero modes, gives

                F(J)>=rho(J)^2+F(P)-mu1^2
                     >rho(J)^2+r-6.                      (4)

Use the Rayleigh vector with hub coordinate sqrt(r) and all path
coordinates one. Its squared norm is 2r and its quadratic form is
2r sqrt(r)+2edges(P). Hence

                rho(J)>=sqrt(r)+1-2/r>0.

Squaring and substituting into (4) proves, for EVERY such two-path P,

 F(J)>2r+g(r),
 g(r)=2sqrt(r)-4/sqrt(r)-5-4/r+4/r^2.                      (5)

This proof does not presume that adding the missing path edge increases
F. It applies directly to the actual split-path graph.

3. One disjoint principal partition of the final G. The vertices outside
Hbar-c are exactly c, all q middle vertices and the first ell-1 sibling
vertices. Their induced graph is K1 join (P_q disjoint_union P_(ell-1)):
c is the hub, and the two paths have NO connecting edge. Thus with
r=q+ell-1, pinching and (2)--(5) imply

 F(G)>=F(Hbar-c)+F(J),
 F(G)-F(H)>2(k+r)+g(r)-8-184/157
          =2N+g(r)-8-184/157.                             (6)

The unit edges between the two blocks exist in G; they are discarded
only in the valid spectral pinching comparison. This is not an
application of the original conjecture to a weighted auxiliary graph.

4. Entire infinite length range. For r>=2,

 g'(r)=r^(-1/2)+2r^(-3/2)+4r^(-2)-8r^(-3)>0.

At r=55 use s=927/125 with s^2<55. The exact rational lower is

 2s-4/s-5-4/55+4/55^2-8-184/157
       =108404531/2201277375>1/25.

Consequently EVERY r>=55 satisfies the claimed bound, proving (1)
for the entire q+ell>=56 tail and every unbounded p. The finite geometry
controls merely calibrate the graph operation; monotonicity and (4)--(6)
prove the infinite quantifiers.

5. Consequence and preserved limits. In a minimal counterexample to the
ORIGINAL conjecture, an occurrence of this cap is excluded WHERE deleting
its N private vertices leaves old h>=8. No all-small-old whole payment
follows from a positive increment. This may overlap C1/S3/T5 and earlier
private-apex Fork-fan cuts; no extra disjoint motif credit is claimed.

For this exact private-sibling role the remaining parameter region is
q+ell<=55, p still unbounded; this statement does not settle bare Fork6,
other cap roles or a complete global decomposition. The identity used
here is literal ordered unit edges, not total length alone: only the
lower bound (5) depends on r. The internal q and ell remain distinct
for all other operations. The next phase investigation can now restrict
this role to the finite ordered q,ell triangle while keeping p infinite.

Dependencies, read in their stated scope: quantitative-trace-proof.md
(SHA256 05cf89c095672a6b582ee7a16a2d0e4ed9a6e84c4570d133c16fad1a183b5cc6),
hereditary-retirement-proof.md
(SHA256 a3a333620979d64bdacaebd0cc28b0da679bf46800641235f735ca5e04943706).
No priority, external formal audit or LOTSE causal effect is claimed.
Native intake and independent source replay are pending.
