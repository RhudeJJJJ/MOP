# Degree-four retirement below 141/20 and two exact cap-tail consequences

8 November 2026. ORIGINAL EVERY finite simple UNIT maximal outerplanar G,
n>=8, has F(G)=splus(G)>=2n remains GLOBAL OPEN. No global decomposition,
unrestricted small-old payment, external formal audit or priority claimed.

THEOREM A. For EVERY finite simple chordal outerplanar graph X, allowing
disconnected graphs, bridges and isolated vertices, and EVERY vertex v
of actual degree FOUR,

                 F(X)-F(X-v)<141/20=7.05.                  (1)

This strengthens the previous valid degree-four upper cost U(4)=8.
The hereditary domain and actual contact row are unchanged.

1. Complete all-frequency scalar bound. The accepted hereditary-sector
proof gives, for actual C=A[X-v], contact row a with ||a||^2=4,
f(t)=a(tI+iC)^-1at and EVERY t>0,

 0<Re f<=4/t, |Im f|<=2Re f/t,
 delta(t)=arg(t+f(t)),
 |delta(t)|<=atan(8/[t(t^2+4)]),
 F(X)-F(X-v)=4-(2/pi)integral_0^infinity t delta(t)dt.        (2)

These are the SAME actual extension and induced deletion; no upper
bound on other degrees or order is introduced. The scalar determinant
t+f is strictly accretive, fixing the lifted phase without winding.
We retain the arctangent rather than replace it by its argument.

Let I be the integral of t atan(8/[t(t^2+4)]) on the entire positive
axis. Integration by parts has vanishing boundary terms at0 and infinity:
t^2 times the angle tends to0 at both ends. Differentiating the angle
therefore gives the exact rational integral

 I=integral_0^infinity 4t^2(3t^2+4)/[(t^3+4t)^2+64] dt.

Put x=t/(1+t), y=1-x. Then, INCLUDING the limit x=1,

 I=integral_0^1 R(x)dx,
 R(x)=4x^2(3x^2+4y^2)/
      [x^6+8x^4 y^2+16x^2 y^4+64y^6].                    (3)

The denominator is strictly positive on[0,1]. This exact compactification
retains the entire infinite-frequency tail; R(0)=0 and R(1)=12.

2. Transparent exact rational certificate. Partition[0,1] into M=4096
equal cells. On cell[i/M,(i+1)/M], let a=i,b=i+1, yl=M-b,yh=M-a.
All variables are nonnegative. Termwise monotonicity gives the ENTIRE
cell bound

 R(x)<=4b^2(3b^2+4yh^2)M^2/
       [a^6+8a^4 yl^2+16a^2 yl^4+64yl^6].                 (4)

Each denominator is positive; no endpoint is omitted. Round each upper
OUTWARDS by ceiling to a multiple of2^-96, sum and divide by M. Exact
unbounded integer arithmetic yields

 I<=1542145004899383119281499346463845/
    324518553658426726783156020576256.

Machin's identity with alternating rational remainders verifies pi>157/50.
Consequently the all-frequency cost is STRICTLY less than

 4+2I_upper/(157/50)
 =89503038046857574086992978892068317/
  12737353231093249026238873807618048
 <141/20.                                                (5)

This proves(1) for EVERY allowed graph, not a finite graph survey.
The checker also verifies the integration-by-parts denominator expansion
and the positive compactification polynomial identity. Graph truth is
supplied by the original actual hereditary sector proof, not by byte hashes.

3. EXTERNAL-b sibling cap: entire q>=40 tail. Keep precisely the actual
graph and deletion chain of large-middle-payment-proof.md. For all old
UNIT MOP H,h>=3, ordered boundary ab, integers p,ell>=1,q>=40, delete
ONLY middle_q and retain dc. SAME Hbar is E_(p+1,ell), k=p+ell+2.
Its private c has exact degree4. Retire c ONCE using(1), and pinch final
G into Hbar-c and Fan_(q+1). The accepted universal branch debt184/157
and self-contained fan Rayleigh/interlacing inequality imply

 DeltaF>2N+f(q)-141/20-184/157,
 f(r)=2sqrt(r)-2/sqrt(r)-4-2/r+1/r^2, N=p+q+ell+2.           (6)

The known f is increasing for r>=1. At q40, sqrt40>1581/250 gives
exact surplus119928413/1985736000>1/20. Thus EVERY such q>=40,
with both outer lengths unbounded, has DeltaF>2N+1/20.
Combining prior q1,q2 payments, only q3..39 remain for this external
family's complete increment theorem. The running q3..45 certificate is
still valid work on its full frozen domain; it is not edited or truncated.

4. PRIVATE-c sibling cap: entire q+ell>=50 tail. Keep precisely the
different actual graph and deletion chain of private-sibling-tail-proof.md.
Retain the LAST sibling vertex s_ell, delete middle_q and the first ell-1
siblings; SAME Hbar=E_(p+1,1), k=p+3. Its actual c has degree4.
Retire c ONCE and pinch into Hbar-c and K1 join(P_q disjoint P_(ell-1)).
Writing r=q+ell-1 and g(r)=2sqrt(r)-4/sqrt(r)-5-4/r+4/r^2, the actual
two-path Rayleigh/interlacing proof gives

 DeltaF>2N+g(r)-141/20-184/157.                            (7)

g increases for r>=2. At r49 use sqrt49=7 exactly; its surplus is
954683/7539140>1/10. Hence EVERY p,q,ell>=1 with q+ell>=50 has
DeltaF>2N+1/10 for all old UNIT MOP H,h>=3. The remaining ordered
private-role pairs satisfy q+ell<=49; p is still unbounded.

5. Source/status precision. The two cap graphs have DIFFERENT literal
root contacts; (6) and(7) use their separate justified graph partitions.
Only the universal degree4 retirement bound is shared. No independently
optimized overlapping witnesses are added. All old unit edges, including
ab, remain counted once. Auxiliary K2 is not inferred from the inherited
branch theorem's h>=3 domain. A minimal original counter excludes these
occurrences only WHERE the deleted old remainder h>=8; all-small-old whole
payment and complete original grammar/compensation remain OPEN.

The earlier external q>=46 and private q+ell>=56 payment theorems remain
TRUE. Only their subsequent work-front clauses are refined: q3..45 becomes
q3..39 for the external family, and private q+ell<=55 becomes<=49. Precise
curated revisions must bind those exact stored clauses; a separate note
or related_candidate edge alone is not their delivered correction.

The next actual work changes by this quantified reduction, not by calling
two different graphs identical when their total lengths agree. Preserve
q,ell and both apex roles for all other operations. Source export replay,
session-entry delivery, mathematical validity and worldwide novelty remain
distinct. The original persistent goal remains ACTIVE and GLOBAL OPEN.

Full original dependencies: hereditary-retirement-proof.md,
quantitative-trace-proof.md, large-middle-payment-proof.md,
private-sibling-tail-proof.md. No finite fan spectral extrapolation is used.
Native intake/revision binding are a separate auditable step.
