# External-apex Fork-fan: uniform whole-graft phase certificate

6 November2026. LOCAL FINITE ACCEPTANCE PASSED: the full rational reader
checked all1163frequency cells and36027endpoint rectangles plus the
complete64cell infinite tail. Universal surplus lower is
581855678894280369672264455/9903520314283042199192993792>1/20. The selector requested1/100;
the actual exact lower proves the stronger1/20 surplus without changing
the partition or redefining the ORIGINAL global target. ORIGINAL EVERY finite
simple UNIT maximal outerplanar G,n>=8,F(G)=sum(lambda>0)lambda^2>=2n,
equivalently D(G)>=6 remains GLOBAL OPEN/goal ACTIVE. No original global
completion, counterexample, literature priority or external formal/human
audit is claimed.

## 1. Exact scope, retained source and actual old root

Use the closed literal cap from the accepted Fork-fan proof: old boundary
ab retained ONCE; parenttriangleabc, balancedForkchild onac and straight
fan of arbitrary integerell>=1 oncb with EXTERNAL hubb. There are
k=ell+4 private vertices,2k added unit edges, no other private outside
contacts. EVERY old unit MOP H of orderh>=3 and EVERY ordered boundary
edge is eligible; auxiliaryK2 is an increment domain too, not an original
paid base. Private path orderx,y,z,c,fan gives exactly

 B=P_k+edge(1,3), Ta=indicator{0,1,3}, Tb=indicator{3,..,k-1}.

The accepted analytic private-energy theorem gives F(B)>=k+c0,
c0=(sqrt13-sqrt5)/2, and contact massTrTTt=k. All private modes, including
zeros, are retained in that theorem. Neither a finite spectral survey
nor mode omission is used here.

The accepted sharp full root-ball phase theorem (native
math:mop:net-root-phase:{bound,dominance,proofsource}:20261106) keeps
the SAME physical old root H0 throughout the ENTIRE actual graft. For
Fc=T(tI+iB)^-1Tt and K=2I+J, its lifted actual phase obeysdelta<=b(Fc,t),

 DeltaF>=F(B)+TrTTt-(2/pi)integral_0^infinity t b(Fc,t)dt.             (1)

For ANY auxiliary complexF satisfyingWplus(F)=2ReF+tImF>=0 define
L=K^-1/2 F K^-1/2,c=1/t-i/2,rho=sqrt(1/t^2+1/4),
A=I+cL,W=rho L A^-1. Then

 A*A-rho^2L*L=I+2ReL/t+ImL>=I,
 b(F,t)=ImTrLogA+asin(sigma1W)+asin(sigma2W), 0<=b<2pi.              (2)

Both factors' lifted trace-logs are kept, not a principal argument reset
of a product. The accepted lossless-ray lemma (native
math:mop:fork-fan:lossless-ray:20261106) says adding a nonnegative real
rank-one ray gamma vv^t/(t+2i) can only DECREASE this phase upper. It is
an algebraic phase theorem, not the earlier FALSE graph-energy rootboost
monotonicity. No graph energy is assigned to a signed auxiliary response.

## 2. Normalize the unbounded length; preserve all actual states

Letw=t+2i,R=Tt,V=(B-2I)R. Accepted all-length identities give

 Fc=Q/w+2iI/w^2-S/w^2, S=Vt(tI+iB)^-1V,
 Q=[[3,1],[1,ell+1]], TV=-2I,
 Va=-e0+2e2-e3+e4, Vb=e1+e2-e3-e_(k-1),
 VtV=[[7,2],[2,4]] ifell1, else[[7,3],[3,4]].

Subtract the positive lossless bulk(ell-1)e_b e_b^t/w. The resulting
F1 has SAMEWplus as actualFc and fixed leadingQ1=[[3,1],[1,2]]. Hence
b(Fc,t)<=b(F1,t). The latter auxiliary is used ONLY to bound the actual
same-graft phase in(1).

For D0=1,D1=t,D_j=tD_(j-1)+D_(j-2), the tail endpoints are
r=D_(ell-1)/D_ell,e=(-i)^(ell-1)/D_ell, with exact correlation
e^2=r^2+t r-1. Along each residueell=1,2,3,0mod4, D increases, since
D_(j+2)-D_j=tD_(j+1)>0. Therefore EVERY actualell is contained in one of
the following FOUR curvesj1..4,u0..1:

 s=u/D_j(t), e=+s,-is,-s,+is forj1,2,3,4 respectively,
 r=(-t+sqrt(t^2+4+4s^2))/2 foroddj,
 r=(-t+sqrt(t^2+4-4s^2))/2 forevenj.

Actual state hasu=D_j/D_ell. Interpolated states are NOT assumed physical
or sector-valid. Every bound below applies to their Wplus>=0 subset;
all other states remain harmless enlargement or are certified empty.

Let C4 be path0-1-2-3 plusshortcut13, h=(1+i(r+e))/w,
Z4=tI+iC4+r e3e3t, Urows(1,1,0,1),(0,0,0,1-ih). Exact tail elimination
gives

 F1=(1+2ih)e_b e_b^t/w+U Z4^-1 Ut.                                 (3)

Transpose is NOT adjoint. Formula(3) is independent of ell except for its
correlated endpoint state. Efficient adjugate contractions for the first
Urowa and e3 are

 d=rt^3+2rt+t^4+4t^2-2it+1,
 naa=2rt^2-2irt+r+3t^3-4it^2+2t-2i,
 nab=t^3-it^2+i, nbb=t^3+2t,
 Faa=naa/d, Fab=(1-ih)nab/d,
 Fbb=(1+2ih)/w+(1-ih)^2 nbb/d.                                    (4)

ForALLt>0,r>=0, Red>=1, so no pole is introduced. The separate bivariate
coefficient reader checks the full formal Z4adj(Z4)=dI and these THREE
contractions, not merely sampled t,r. At t>=3/4 the reader may equivalently
eliminate coordinates0,2 first, retaining
Z2=[[t+2/t,1/t+i],[1/t+i,t+1/t+r]], transformed sourcea=(1-i/t,1),
sourceb=(0,1-ih), and directa term1/t. This is the same actual Schur
identity; choosing either formula changes no mathematical function.

## 3. Stable exact net angle and its determinant quadrant

WriteF1=tQ-iM for real symmetricQ,M, with NO assumptionQ>=0 on the
compact enlarged domain. Setx=t^2,
q=TrKiQ,m=TrKiM,u=detQ/3,v=detM/3,
w0=(Q00M11+Q11M00-2Q01M01)/3,r0=xu-v,Rho2=(x+4)/(4x).
The exact complex determinant ofA in(2) isar+i ai, with

 ar=1+q-m/2+(1/x-1/4)r0-w0,
 ai=-(m+xq/2+(1-x/4)w0+r0)/t,
 az=ar^2+ai^2, dz=r0^2+xw0^2.

Letalpha=TrW*W,beta=detW*W. The accepted rational formulas compute these
fromq,m,u,v,w0, and beta=Rho2^2 dz/az. Their angle sumtheta satisfies

 costheta=sqrt(1-alpha+beta)-sqrt(beta), 0<=theta<pi.

An exact cancellation-safe alternative is important near low-frequency
zero modes. PutS0=2Q-M andG=I+K^-1/2S0K^-1/2. Then

 detG=1+TrKiS0+detS0/3,
 det(I-W*W)=detG/az,
 costheta=(sqrt(detG)-Rho2 sqrt(dz))/sqrt(az).                       (5)

These are full noncommuting matrix identities from A*A-rho^2L*L=G;
they do not replace matrices by scalar traces. Wplus>=0 impliesG>=I,
thusdetG>=1, allowing valid-subset clipping ONLY in the raw interval bound.
AD uses the analytic expression without that clipping.

ReA>=I givesImTrLogA in(-pi,pi). It need NOT lie in(-pi/2,pi/2): six
exact full-response controls actually havear<0,ai<0. The reader therefore
uses a lifted continuous arg(ar+i ai) from a WHOLE-box quadrant:
ar>0 givesatan(ai/ar); ai>0 givespi/2-atan(ar/ai); ai<0 gives
-pi/2-atan(ar/ai). An unresolved quadrant falls back to2pi, never to an
unjustified principal-value replacement. Addtheta=acos(costheta).
Wherear>0 and the computedcos(argA+theta)>0, the equivalent faster
atan of the angle-sum numerator/denominator is allowed. Since then
argA+theta is in(-pi/2,3pi/2), positive cosine forces the correct
(-pi/2,pi/2) branch; b>=0 on sector-valid states supplies its sign.

## 4. Complete compact rectangles and centered rational AD

The compact domain is EXACTLYt1/4..8,u0..1 for each of FOUR curves.
Frequency bins[1/4,1/2],[1/2,3/4],[3/4,1],[1,2],[2,4],[4,8] are subdivided
by complete binary trees. Every frequency leaf carries FOUR complete
binaryu trees. The independent reader verifies no gap, overlap, missing
child, altered domain or nonzero padding BEFORE integration.

At a rectangle a raw outward response enclosure proves emptiness only
when a diagonal or determinant UPPER ofWplus is negative. Otherwise it
bounds the valid subset via(2),(5), using2pi*t as a safe fallback for ANY
unresolved analytic/phase branch. No invalid state is silently discarded.

Centered AD bounds the SAME analytic scalar expressionf(t,u)=t b(F1,t)
where its real square roots, positive divisors and determinant quadrant
are certified on the ENTIRE rectangle. Ordinary interval derivatives
in BOTH variables, includingatan andacos derivatives, give

 f(t,u)<=f(tm,um)+sup|partial_t f|(b-a)/2
                         +sup|partial_u f|(ub-ua)/2.                (6)

Even an invalid midpoint is harmless when the analytic extension exists
on the whole box: at every valid point it agrees with(2), and mean value
applies to that analytic extension. No PSD clipping is differentiated.
If an AD prerequisite fails the raw safe bound is used. Exact independent
inverse differentiation checks all1344 response partial components at84
rational physical states, both compact representation branches and the
nonprincipal negative determinant quadrant. These controls calibrate AD;
the chain/product/quotient rules and whole-box prerequisites justify(6).

All accepted arithmetic is OUTWARD on an exact2^96 rational grid with
unbounded Python integers. Each rational input is first enclosed; integer
floor/ceiling implements every product, positive division and square root.
The Dyadic numeric protocol gives exact normalized rational numerator and
denominator; outside interval primitives arithmetic is exactFraction.
There is no integer overflow and float inputs to this backend are rejected.
26002 independent rational inequality/protocol checks calibrate it.
Arctangent uses the accepted12term half-angle alternating-series enclosure
with explicit remainder; Machinpi bounds are exact. This is a new96bit
backend, not a claim that the parent192bit helper ran unchanged.

The selector uses NumPy/float estimates ONLY to choose the binary trees.
Its original bytes are retained; a later metadata-only binding adds the
exact backend source hash without changing a single rectangle. The rational
reader imports NO float selector and recomputes EVERY leaf. Discovery
uppers, goals, elapsed times and gain candidates are NEVER proof inputs.

For each frequency leaf the integrand upper is the MAXIMUM over ALLu
leaves and ALLfour curves, multiplied by the frequency width. It is NOT
an integral or weighted average overu. This distinction is essential for
the universal quantifier over actual integer lengths.

## 5. Entire high and low frequency ends, uniform in ell

Putz=1/t,x=z^2,a=1+4x. With the exact defect vectors of section2,
C=Vt(I+xB^2)^-1V,D=Vt B(I+xB^2)^-1V have ALL-length bounds

 C00 in[0,7], C11 in[0,4], |C01|<=sqrt28<6,
 |D00|<=21, |D11|<=12, |D01|<=3sqrt28<18.

Indeed||B||<=3 by the actual maximum degree3, the first inverse is a
positive contraction, and Cauchy plus||B(I+xB^2)^-1||<=3 proves the bounds.
This is an analytic all-ell statement, not a tail frequency sample.
Expansion of the SAME normalized response gives

 Qp=t ReF1=Q1/a+8xI/a^2-x[(1-4x)C-4xD]/a^2,
 Mp=-t^2 ImF1=2Q1/a-2(1-4x)I/a^2
                         -x[(1-4x)D+4C]/a^2.

On all64 rational z intervals covering[0,1/8], the whole-box bounds prove
Qp>0 by first principal minor and determinant. WriteA0=K^-1/2QpK^-1/2,
M0=K^-1/2MpK^-1/2,q=TrA0,m=TrM0,u=detA0,v=detM0,
w=TrA0TrM0-Tr(A0M0),Z=sqrt((u-xv)^2+xw^2),
h0=(w^2-4uv)/(Z+u+xv). Herew^2-4uv>=0 forA0>0,M0 symmetric.
The accepted same-ball homotopy supportV_old=t E_old obeys

 V_old=-xm-q/2+sqrt((1+4x)(q^2+x(m^2+2h0)))/2,
 V_old/z^2=[(2q-m)^2+2(1+4x)h0] /
     [2(sqrt((1+4x)(q^2+x(m^2+2h0)))+q+2xm)].                     (7)

This is an exact nuclear-norm identity and rationalization, not division
by a quantity merely presumed nonzero. Every denominator has a positive
interval lower bound on the complete z domain includingz0. The generic
phase comparisonb<=E_old extends to this same-sector auxiliary by the
accepted inverse-congruence proof. Thus summing(7) over ALL64z cells
bounds integral_8^infinity t b(F1,t)dt for EVERYell. Thirty-six full exact
private-resolvent controls check the C/D and Qp/Mp signs; the analytic
norm argument establishes uniformity.

At the remaining entire low interval0<t<1/4, (2) alone gives energy
cost(2/pi)integral t b dt<=2(1/4)^2=1/8. No singular or zero mode is
deleted, and no hidden frequency cutoff remains.

## 6. Exact sufficient conclusion and boundaries

LetI_comp be the rational reader's full compact upper andI_tail its
complete normalized infinity-tail upper. Its exact radical lowercL and
Machin lowerpiL give

 DeltaF-2k >=cL-1/8-2(I_comp+I_tail)/piL.                           (8)

Acceptance requires this rational lower to exceed1/100. Only a terminal
PASS of the full independent reader establishes the numerical part of
the claimed uniform payment. Its artifacts must bind every actual helper
byte, all1163frequency cells and36027endpoint rectangles proposed by the
selector, plus all64tail intervals. Counts are coverage evidence, not
standalone mathematical truth.

If accepted, this proves the external Fork-fan increment for ALLe ll>=1
and ALLoldH in the stated domain. Together with the retained PRIVATE
apex theorem>2k+1/10 it pays both hub roles at every length, counting
ell1(the SAME literalT5) only once. Existing sharperT5 and other true
payments remain unchanged. In a minimal original counter it excludes
these closed caps WHERE the deleted old remainderh>=8. All-small-old
whole payment for everyell is NOT inferred from a positive increment;
only the earlierT5 has that fresh unconditional original-order boundary.

The two-tail-reduction-proof.md extends private energy and fixed-head
normalization to childE_(p,1) plus sibling fanell, BOTHparametersunbounded.
Its sixteen compact curve pairs are a NEW OPEN phase problem, not covered
by this four-curve certificate. This provides the next actual grouped
branch attack. GeneralchildE_(p,q),bareFork6 and the original global
nonnegative compensation remain OPEN. No occurrence/coverage theorem is
inferred merely from this local payment. No new agent, timer, foreign
message or background research was used; foreground numerical selector
and exact reader are explicit. No LOTSEcausalmethod_effect or sessionentry
delivery claim follows from native source storage/replay.
