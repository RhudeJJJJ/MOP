"""Role-specific pending model/controls; writes ONLY this new private-role folder."""
from pathlib import Path
import shutil,json,hashlib
P=Path(__file__).resolve().parent;OLD=P.parent/'mop-finite-middle-20261108'

def replace(text,old,new,count=1):
    assert text.count(old)==count,(old,text.count(old));return text.replace(old,new)
def write(name,text):
    path=P/name
    if path.exists():assert path.read_text()==text,'existing own source changed: inspect '+name
    else:path.write_text(text)

def main():
    for name in('complex_exact.py','curve_interval.py','poly8.py'):
        target=P/name
        if target.exists():assert target.read_bytes()==(OLD/name).read_bytes()
        else:shutil.copyfile(OLD/name,target)
    text=(OLD/'geometry.py').read_text();text=replace(text,'([2]+right+[1],1)','([2]+right+[1],2)');text=replace(text,'N+q-1','N+q+l-2');text=replace(text,'N-q+1','p+4');write('geometry.py',text)
    text=(OLD/'middle_physical.py').read_text();text=replace(text,'for k,length in enumerate((p,ell)):Fc[k][k]=z.sub(Fc[k][k],z.div(z.z(length-1),z.z(t,2)))','Fc[0][0]=z.sub(Fc[0][0],z.div(z.z(p-1),z.z(t,2)))');write('private_physical.py',text)
    text=(OLD/'middle_ad5.py').read_text();text='"""PRIVATE-c sibling FIVE-variable response; full acceptance still OPEN."""\n'+text[text.index('from fractions import Fraction as F'):]
    text=replace(text,'ca(z(t+rr),cd(ca(z(gamma),cm(z(0,2),hm)),w))','ca(z(t),cd(ca(z(gamma),cm(z(0,2),ca(hm,hr))),w))')
    text=replace(text,'fr=cd(ca(z(1),cm(z(0,2),hr)),w)','fr=z(rr)');text=replace(text,'3<=ga<=gb<=45','2<=ga<=gb<=49');write('private_ad5.py',text)
    text=(OLD/'middle_common_ad5.py').read_text().replace('middle_ad5','private_ad5')
    text=replace(text,'nr=cs(z(t-2*rr,4),ct(er,2))','nr=ct(w2,rr)')
    text=replace(text,'J=ca(cs(ca(ct(w2,t+rr),ct(w,gamma)),ct(ca(z(rm),em),2)),z(0,2))','J=ca(cs(ca(ct(w2,t),ct(w,gamma)),ct(ca(ca(z(rm),em),ca(z(rr),er)),2)),z(0,4))');write('private_common_ad5.py',text)
    for oldname,newname,common in(('check_middle_ad5.py','check_private_ad5.py',False),('check_common_ad5.py','check_private_common_ad5.py',True)):
        text=(OLD/oldname).read_text().replace('middle_ad5','private_ad5').replace('middle_physical','private_physical').replace('middle_common_ad5','private_common_ad5')
        text=replace(text,'sm=z.div(z.add(z.z(gamma),z.mul(z.z(0,2),hm)),w)','sm=z.div(z.add(z.z(gamma),z.mul(z.z(0,2),z.add(hm,hr))),w)')
        text=replace(text,"z.add(z.z(t+R['r']),sm)",'z.add(z.z(t),sm)')
        text=replace(text,'fr=z.div(z.add(z.z(1),z.mul(z.z(0,2),hr)),w)',"fr=z.z(R['r'])")
        text=replace(text,'z.mul(z.z(0,2),dh[2])','z.mul(z.z(0,2),z.add(dh[2],dh[1]))')
        text=replace(text,'z.add(z.z(int(ist)+dr[1]),ds)','z.add(z.z(int(ist)),ds)')
        text=replace(text,'for k,(hd,ff)in enumerate(zip((dh[0],dh[1]),(fl,fr))):part[k][k]=z.add(part[k][k],z.div(z.sub(z.mul(z.z(0,2),hd),ff if ist else z.z()),w))','part[0][0]=z.add(part[0][0],z.div(z.sub(z.mul(z.z(0,2),dh[0]),fl if ist else z.z()),w));part[1][1]=z.add(part[1][1],z.z(dr[1]))')
        text=replace(text,'[(p,q,ell)for q in(3,4,5,6)for p in range(1,5)for ell in range(1,5)]+[(2,45,4),(5,16,6),(8,24,9)]','[(p,q,ell)for q in range(1,5)for p in range(1,5)for ell in range(1,5)]+[(2,1,48),(5,28,20),(8,24,25)]')
        text=replace(text,'endpoint(t,q,(q-3)%4+3)','endpoint(t,q,(q-1)%4+1)')
        text=replace(text,'independent_head(t,L,R,M,F(q))','independent_head(t,L,R,M,F(q+ell))')
        text=replace(text,'for k,length in enumerate((p,ell)):dfull[k][k]=z.add(dfull[k][k],z.div(z.z(length-1),z.mul(w,w)))','dfull[0][0]=z.add(dfull[0][0],z.div(z.z(p-1),z.mul(w,w)))')
        text=replace(text,'max(F(3),F(q)-dg),min(F(45),F(q)+dg)','max(F(2),F(q+ell)-dg),min(F(49),F(q+ell)+dg)')
        if common:
            text=text.replace('PASS_COMMON_FIVE_VARIABLE_RESPONSE_PARTIALS_AND_INDEPENDENT_PHASE','PASS_PRIVATE_SIBLING_COMMON_RESPONSE_ALL_PARTIALS_AND_FULL_PRIVATE_PHASE').replace('common-ad5-check.json','private-common-ad5-check.json')
        else:
            text=text.replace('PASS_FIVE_VARIABLE_MIDDLE_RESPONSE_ALL_PARTIALS_AND_FULL_PRIVATE_TANGENTS','PASS_PRIVATE_SIBLING_FIVE_VARIABLE_RESPONSE_ALL_PARTIALS_AND_FULL_PRIVATE_TANGENTS').replace('middle-ad5-check.json','private-ad5-check.json')
        text=text.replace('independent middle bulk gamma','independent TOTAL internal bulk gamma=q+ell');write(newname,text)
    text=(OLD/'check_common_polynomials.py').read_text().replace('middle_common_ad5','private_common_ad5')
    text=replace(text,'nr=cs(z(t-2*s,4),z(2*f))','nr=ct(w2,s)')
    text=replace(text,'J=ca(cs(ca(ct(w2,t+s),ct(w,gamma)),z(2*(u+g))),z(0,2))','J=ca(cs(ca(ct(w2,t),ct(w,gamma)),z(2*(u+g+s+f))),z(0,4))')
    text=text.replace('PASS_FORMAL_EIGHT_VARIABLE_TWO_HEAD_COMMON_RESPONSE_AND_DETERMINANT','PASS_FORMAL_PRIVATE_SIBLING_EIGHT_VARIABLE_COMMON_RESPONSE_AND_DETERMINANT').replace('common-polynomial-check.json','private-common-polynomial-check.json').replace('middle gamma retained','TOTAL q+ell gamma retained');write('check_private_common_polynomials.py',text)
    print('PREPARED_ROLE_SPECIFIC_PRIVATE_HEAD_AND_INDEPENDENT_CONTROLS; acceptance pending actual runs')
if __name__=='__main__':main()
