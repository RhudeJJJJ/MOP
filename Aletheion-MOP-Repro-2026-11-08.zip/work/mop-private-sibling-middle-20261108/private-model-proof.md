# PRIVATE sibling role: complete private floors, a false helper and validated response

8 November2026. ORIGINAL EVERY finite simple UNIT maximal outerplanar G,
n>=8 has F(G)=splus(G)>=2n remains GLOBAL OPEN. The general full graft
increment in this PRIVATE-c sibling role remains OPEN on small internal
totals. This note proves its private-energy floor for ALL lengths and
validates the distinct response/tail inputs for the next phase proof.

1. Actual vertices and ALL-length private floor. Keep old ordered ab
ONCE, parent abc, external E_(p,q) child on ac with apices a,c, and a
sibling fan ell on cb whose apex is PRIVATE c. ALL p,q,ell>=1. Write
S=q+ell, N=p+S+2, private order left_p,d,middle_q,c,sibling_ell.
Private B is c join(P_(q+1) disjoint P_ell) with a pendant P_p at d.
Its edges are p+2S, contact mass p+4, summing2N. The complete contacts
are Ta=indicator{0,...,p}+e_c and Tb=e_c+e_(N-1), c=p+q+1.
In particular old b contacts ONLY c and the LAST sibling vertex.
The external-b role's all-sibling contact row is not substituted here.

THEOREM P. Before paying ANY actual old-root phase, EVERY such triple has

 F(B)+Tr(TTt)>2N+17/10 if S>=4;
 F(B)+Tr(TTt)>2N+6/5 if S=3;
 F(B)+Tr(TTt)>=2N+c0 if S=2,
 c0=(sqrt13-sqrt5)/2, equality only at p=q=ell=1.             (1)

For EVERY S>=12 the stronger surplus>9/5 also holds. Moreover, for
EVERY ell>=2 and S>=4, the stronger surplus>9/5 holds for ALLp as well.
This last restriction deliberately excludes the ell1 single-triangle
sibling that coincides with the external role.

2. Entire S>=12 tail by a disjoint partition. For P a union of at most
two paths on r>=2 vertices, F(P)>=r-2 and its largest eigenvalue has
square<4. Interlacing and the hub-sqrt(r) Rayleigh vector give

 F(K1 join P)>2r+g(r),
 g(r)=2sqrt(r)-4/sqrt(r)-5-4/r+4/r^2.

g increases for r>=2. Pinch B into the TWO disjoint blocks
J=c join(P_(q+1) disjoint P_ell) and P_p. With r=S+1,
F(B)>edges(B)+g(S+1)+1. At S12, sqrt13>18/5 proves
g13+1>13726/7605>9/5. This covers ALL unbounded S>=12 and p>=1,
not extrapolation from a finite list of internal pairs.

3. Complete finite-core proof, without a false universal comparison.
For S2..11 there are55 ORDERED pairs(q,ell), not55 independent motifs
or unlabeled graphs. Put m=q+1. For the path pencil Sj=tI+iA(Pj), let
Dj=detSj, Ej=1t adj(Sj)1 and Xj=e_last^t adj(Sj)1. With D0=1,
D1=t,E0=X0=0,E1=X1=1, exact cofactor recurrences give

 D_(j+1)=tDj+D_(j-1),
 X_(j+1)=Dj-iXj,
 E_(j+1)=tEj+E_(j-1)+Dj-2iXj.

After eliminating outer P_p, r=D_(p-1)/Dp and the determinant is

 Dp*Z,
 Z=(tD_ell+E_ell)(Dm+rD_(m-1))+D_ell(Em+rE_(m-1))
  =(C0+rC1)-i(M0+rM1).                                    (2)

ALL55 exact coefficient sets have C0,C1,M0,M1 nonnegative, C0,M0
nonzero, so C,M>0 for EVERYt>0,r>=0. The continuous private phase is
-atan(M/C), not a reset of a product argument. Positive factors Dp
introduce no phase. All private and zero modes remain in the equal-trace
Coulson identity D(B)=(4/pi)integral_0^infinity t atan(M/C)dt.

There are THREE fully checked routes covering ALL55 pairs:

*37 pairs: M0C1-M1C0 has nonnegative coefficients and is nonzero.
 Increasing r to1/t decreases M/C; hence D(B)>=D(B at p1) for ALLp.
 Full multiplicity-aware rational Sturm isolation of the literal p1
 matrix gives D>17/5 for S4..11 and D>12/5 for S3. The S2 bull has
 exact characteristic x(x^2-x-3)(x^2+x-1) and D=sqrt13-sqrt5.
 If p>1 then r<1/t, giving strictness in the bull floor.

*17 pairs: that phase derivative test fails, but full exact Sturm
 isolation of the actual core J gives D(J)>27/5. Principal pinching
 B into J and P_p yields private surplus>D(J)/2-1>17/10 for ALLp.

*One pair, q3 ell2: use the separate scalar envelope in section4.

The exact checker retains EVERY pair, actual base/core characteristic,
all root multiplicities and explicit zero modes, route and polynomial.
330 full private determinant controls calibrate(2) on p1,p2 at three
rational frequencies. The recurrences, route inequalities and partitions
prove the unbounded p quantifier. No bare base spectrum proves it alone.

4. Exact counterexample to the attempted helper and its replacement.
For q3 ell2 the derivative cross polynomial is

 -4t^2+12t^6+10t^8+2t^10.

At t1/4 it equals-129455/524288. The actual p1 endpoint is4, the p2
endpoint4/17, and exact full determinants give phase ratios2560/749
and1503744/459457 respectively, the latter SMALLER. Thus the universal
PRIVATE-role p1 pointwise phase comparison is REFUTED. The failed
attempt is preserved. This is not a counterexample to integrated private
energy, the external-role comparison, or the ORIGINAL global conjecture.

For EVERYp>=1, the actual path recurrence gives instead

                  t/(t^2+1)<=r_p<=1/t.

For each fixed t, M/C is fractional-linear in r with C>0, so its minimum
on this interval is at one of the TWO endpoints, regardless of derivative
sign. Clearing their positive denominators gives two ratios of positive-
coefficient polynomials. On each rational cell[a,b], numerator(a) divided
by denominator(b) bounds each ratio below. Take their minimum, the exact
lower atan interval and lower t=a. The528 contiguous cells on[1/4,64]
give integral lower1083574234703210730493319083387169/
324518553658426726783156020576256. With the exact upper pi enclosure
this proves D(B)>17/5 for ALLp.

ALL omitted frequencies have nonnegative D-integrand, by the exact
C>0,M>0 proof for ALLt>0. They may therefore be dropped for this LOWER
bound. No unbounded-frequency remainder is assumed zero or omitted from
an UPPER cost. This mechanism replaces, rather than renames, the refuted
monotonicity premise. Sections2--4 establish ALL of(1).

For the stronger ell>=2,S>=4 floor, the finite S4..11 table has44
ordered pairs.26 valid phase/base routes already give Dbase>18/5;
16 core-pinching routes give Dcore>28/5. The q3 ell2 envelope is already
stronger than18/5. Only q4 ell2 needs one additional two-endpoint envelope:
the SAME528-cell argument, with independently constructed polynomials,
gives D>18/5 using even the coarser proven pi upper22/7. Thus ALL44
pairs have private reserve>9/5. The entire S>=12 tail was already proved
above. No stronger small-total ell1 floor is inferred from this result.

5. The distinct normalized two-head response. Put w=t+2i,
rj=D_(j-1)/Dj, ej=(-i)^(j-1)/Dj,
hj=(1+i(rj+ej))/w, sj=j/w+2i hj/w.
Eliminate all THREE actual paths. Subtract ONLY the nonnegative outer
left lossless ray(p-1)/w; internal q and ell bulk are retained. The heads
d,c have

 Zdd=t+r_p+r_q, Zdc=i+h_q, Zcc=t+s_q+s_ell,
 Ua=(1-i h_p)e_d+e_c, Ub=(1-i h_ell)e_c,
 F=diag((1+2i h_p)/w,r_ell)+U Z^-1 Ut.                     (3)

Transpose, NOT adjoint, is used. The old-b direct term is r_ell, unlike
the external-b role's coronal. In interval work gamma=q+ell is retained
as an independent TOTAL bulk coordinate, with actual gamma fixed at the
integer sum. Artificial independent midpoint boxes are not actual graphs.

For the common denominator put a=t+rL+eL+i, b=t+rR+eR+i,
m=t+rM+eM+i, d=t+rL+rM, nL=t-2(rL+eL)+4i,
nR=rR*w^2 and
J=t*w^2+gamma*w-2(rM+eM+rR+eR)+4i, Delta=dJ+m^2.
The same scaled adjugate identities give the response denominator
w^2 Delta and numerators

 Naa=nL Delta+a^2J-2iamw^2+dw^4,
 Nab=bw(dw^2-iam), Nbb=nR Delta+b^2dw^2,
 P=nR Naa+b^2w^2(nL d+a^2),
 Naa Nbb-Nab^2=Delta P, detF=P/(w^4 Delta).

TEN raw coefficient identities over eight independent variables verify
the full scaled adjugate, response and determinant, with NO endpoint
relations imposed. The generic sharp net-phase determinant formula is
unchanged for an arbitrary complex symmetric F. Its actual-sector/lifted
quadrant and whole-box analytic requirements remain mandatory.

BOTH direct and common variants are independently checked against FULL
actual PRIVATE inverses and inverse differentiation: EACH201 physical
states,402 point/box cases,16080 partial components,3216 true t tangents
with ALL THREE endpoint chain terms, and201 independently computed phases.
The five variables are t,uL,uR,uM,gamma. These calibrate expressions;
no infinite length/frequency coverage follows from these finite controls.

6. Actual sparse tail inputs, complete high frequency. Let V=(B-2I)Tt,
c=p+q+1 and sibling sj at index c+j. Literal coordinates are

 Va=-e0+2e_(p+1)+sum_(j2..q)e_(p+j)-e_c+sum_(j1..ell)e_(c+j),
 Vb=e_p+sum_(j1..q)e_(p+j)-e_c+
    sum_(j1..ell-1)e_(c+j)+indicator{ell>=2}e_(c+ell-1)-e_(N-1).

Thus TV=-2I, TTt=[[p+2,1],[1,2]], and VtV diagonals are S+5 and
S+5-3indicator{ell=1}, cross S+1-indicator{ell=1}. After the single
outer lossless normalization the leading Q is[[3,1],[1,2]]. The exact
resolvent identity is F=Q/w+2iI/w^2-Vt(tI+iB)^-1V/w^2.

For ALL2<=S<=49, B is the star at c with S+1 leaves plus a path forest.
Therefore ||B||<sqrt50+2<10, both Gram diagonals<=54,
C=Vt(I+z^2 B^2)^-1V has diagonals[0,54], |C01|<=54, and
D0=Vt B(I+z^2 B^2)^-1V has all absolute entries<=540.
The same-sector support/nuclear rationalization with THESE actual
role-specific constants verifies ALL64 cells z in[0,1/16], including
positive-real response and EVERY divisor. The COMPLETE t>=16 phase
integral upper is32197540213698234376907766372339/
81129638414606681695789005144064.

Independent10 literal geometries and20 FULL PRIVATE tail cases verify
all sparse coordinates, Gram entries and signed C/D-to-response formulas.
They now close the earlier role-specific input-control gap; the analytic
coordinate/norm proof supplies uniformity in p,q,ell, not finite sampling.

7. Actual next work and preserved target. The compact root-phase proof
for ell>=2,S4..49, p infinite, remains OPEN. It may now use uniform private
reserve9/5, this validated two-head TOTAL-bulk response and the entire
tail. The sole small ordered pair q1 ell2 at S3 is NOW fully paid for
ALLp by special-payment-proof.md, with increment>2N+1/4. Its private
p1 cross comparison is valid and its stored base has D>14/5, giving
private reserve>7/5. This does not pay the compact bulk. Ell1 graphs coincide literally
with the external role for that single-triangle sibling and may use only
actually accepted external ranges. The accepted analytic S>=50 private
full increment theorem has its old H>=3 domain and remains intact.

No complete root payment, occurrence extraction, unrestricted small-old
whole theorem, bareFork6/UB or global compensation follows from private
floors or finite response controls alone. Preserve apex roles, all original
finite-input hypotheses, exact earlier source/entry gaps and the running
external certificate's frozen domain. No priority, external formal audit
or LOTSE causal method_effect is claimed. Native intake is a separate step.
