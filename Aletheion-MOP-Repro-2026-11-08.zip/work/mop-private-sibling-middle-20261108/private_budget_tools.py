"""Finite q<=9 polynomial/root proof pieces; q>=10 analytic in written proof."""
from fractions import Fraction as F
from pathlib import Path
import json
import exact as e,geometry as g
P=Path(__file__).resolve().parent
def add(a,b,k=1):return e.trim([(a[j]if j<len(a)else 0)+k*(b[j]if j<len(b)else 0)for j in range(max(len(a),len(b)))])
def scale(a,k):return e.trim([k*v for v in a])
def za(a,b):return add(a[0],b[0]),add(a[1],b[1])
def zm(a,b):return add(e.mul(a[0],b[0]),e.mul(a[1],b[1]),-1),add(e.mul(a[0],b[1]),e.mul(a[1],b[0]))
def divide(a,b):
    a=e.trim(a);b=e.trim(b);q=[F(0)]*max(1,len(a)-len(b)+1)
    while a!=[0]and len(a)>=len(b):
        k=len(a)-len(b);v=a[-1]/b[-1];q[k]+=v
        for j in range(len(b)):a[j+k]-=v*b[j]
        a=e.trim(a)
    assert a==[0];return e.trim(q)
def gcd(a,b):
    while b!=[0]:a,b=b,e.remainder(a,b)
    return scale(a,1/a[-1])
def root_lower(B):
    cp=e.characteristic(B);zero=0
    while cp[0]==0:cp=cp[1:];zero+=1
    layers=[];current=cp
    while len(current)>1:
        common=gcd(current,e.derivative(current));squarefree=divide(current,common);layers.append(e.sturm(squarefree));current=common
    seq=layers[0];bound=F(max(map(sum,B))+2);intervals=[];stack=[(-bound,bound)]
    while stack:
        a,b=stack.pop();count=e.variations(seq,a)-e.variations(seq,b)
        if not count:continue
        assert count>0
        if count==1 and b-a<=F(1,4096)and a*b>0:
            mult=sum(e.variations(s,a)-e.variations(s,b)for s in layers);intervals.append((a,b,mult));continue
        for k in range(1,len(cp)+2):
            mid=(k*a+b)/(k+1)
            if all(e.ev(s[0],mid)!=0 for s in layers):break
        else:raise AssertionError('nonroot rational split unavailable')
        stack.extend([(a,mid),(mid,b)])
    assert sum(m for a,b,m in intervals)+zero==len(B)
    lower=sum((m*a*a if a>0 else-m*a*a for a,b,m in intervals),F(0))
    return dict(characteristic=list(map(str,e.characteristic(B))),zero_modes=zero,roots=[[str(a),str(b),m]for a,b,m in sorted(intervals)],D_lower=str(lower)),lower
