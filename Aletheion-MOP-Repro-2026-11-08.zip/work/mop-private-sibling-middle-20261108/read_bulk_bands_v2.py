"""Exact reader, fixed graph chooses one total band for its ENTIRE integral."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,time,sys
import rational_grid
rational_grid.install()
import private_ad5 as direct,private_common_ad5 as common
import bulk_small_tail as smalltail,uniform_private_tail as largetail,net_interval as net
from bulk_band_cover import Cover
P=Path(__file__).resolve().parent
REQUIRED={'produce_bulk_bands_v2.py','read_bulk_bands_v2.py','bulk_band_cover.py','bulk_band_scout.py','bulk-frequency-grid.json','bulk-band-budget.json','bulk-band-coverage.json','bulk_small_tail.py','uniform_private_tail.py','private_ad5.py','private_common_ad5.py','float_discovery.py','exact.py','disk_interval.py','net_interval.py','rational_grid.py','curve_interval.py','private-model-verification.json','native-audit.json','check_bulk_tail_controls.py','bulk-tail-controls.json'}
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def await_file(path,live):
    deadline=time.monotonic()+1800
    while not path.exists():
        assert live and time.monotonic()<deadline,'bounded foreground wait expired '+path.name
        time.sleep(.25)
    return json.loads(path.read_bytes())
def main():
    prefix='--prefix'in sys.argv;live='--live'in sys.argv;start=time.monotonic();reader_hash=sha(Path(__file__))
    folder=P/'bulk-band-v2-checkpoints';hashes=await_file(folder/'producer-inputs.json',live)
    assert set(hashes)==REQUIRED
    assert all(sha(P/name)==value for name,value in hashes.items()),'input mismatch before read'
    assert json.loads((P/'native-audit.json').read_bytes())['status']=='PASS_NATIVE_PRIVATE_FLOORS_EXACT_HELPER_COUNTER_MODEL_AND_ALL_p_q1_ell2_PAYMENT'
    assert json.loads((P/'bulk-band-coverage.json').read_bytes())['status']=='PASS_TWO_BAND_EXHAUSTIVE_AP_COVERAGE_AND_DAMAGED_GRAMMARS'
    assert json.loads((P/'bulk-tail-controls.json').read_bytes())['status']=='PASS_TWO_BAND_FULL_PHYSICAL_TAIL_CONTROLS'
    grid=json.loads((P/'bulk-frequency-grid.json').read_bytes());seen={};bands={};areas={}
    for name in ['small','large']:
        cover=Cover(name);total=F(0);end=F(1,2);leaves=empty=anchor=fcells=0;seen[name]=[];areas[name]=[]
        for index,row in enumerate(grid[:1]if prefix else grid):
            path=folder/f'{name}-{index:04}.json';item=await_file(path,live);a,b=F(row['a']),F(row['b'])
            assert a==end and item['index']==index and item['band']==name;end=b
            target=F(item['target']);assert target==cover.amplitude/(1+((a+b)/2)**2)
            area,count,missing,depth,fc=cover.cell(item['partition'],a,b,target,direct,common)
            seen[name].append(item);total+=area;leaves+=count;empty+=missing;anchor=max(anchor,depth);fcells+=fc
            areas[name].append(dict(index=index,area=str(area),leaves=count,empty=missing,anchor=depth,frequency_cells=fc))
            print(json.dumps(dict(status='EXACT_BAND_PROGRESS',band=name,index=index,total=len(grid),leaves=leaves,seconds=time.monotonic()-start)),flush=True)
        result=dict(compact_integral_upper=str(total),frequency_cells=fcells,length_leaves=leaves,arithmetic_empty_leaves=empty,max_p_anchor=anchor,ordered_internal_pairs=152 if name=='small'else 975,unbounded_parameter='p')
        if not prefix:
            assert end==16
            tail=smalltail if name=='small'else largetail
            It=sum((tail.tail(F(k,1024),F(k+1,1024))[1]/1024 for k in range(64)),F(0))
            gain=cover.reserve-F(1,2)-2*(total+It)/net.PI[0]
            assert gain>F(1,20),'complete band payment fails'
            result.update(tail_integral_upper=str(It),private_reserve=str(cover.reserve),surplus_lower=str(gain),surplus_float=float(gain))
        bands[name]=result
    assert all(sha(P/name)==value for name,value in hashes.items())and sha(Path(__file__))==reader_hash
    if not prefix:
        cert=await_file(P/'bulk-band-v2-certificate.json',live)
        assert cert['format']=='private-sibling-two-bands-one-unbounded-arm-v1'and cert['source_sha256']==hashes and cert['cells']==seen
    out=dict(status='PASS_EXACT_TWO_BAND_INITIAL_FREQUENCY_PREFIX_ONLY'if prefix else'PASS_EXACT_PRIVATE_SIBLING_ell_AT_LEAST2_TOTAL4_TO49_ALL_p_PAYMENT',bands=bands,reader_sha256=reader_hash,source_sha256=hashes,seconds=time.monotonic()-start,original_global='OPEN',root_payment='OPEN'if prefix else'PROVEN DeltaF>2N+1/20 within stated family',scope='Unit private-c sibling role, p>=1,q>=1,ell>=2; actual fixed total4..49. No complete MOP coverage inferred.')
    if not prefix:out['certificate_sha256']=sha(P/'bulk-band-v2-certificate.json')
    stem='bulk-band-v2-prefix'if prefix else'bulk-band-v2-reader'
    (P/(stem+'-cells.json')).write_text(json.dumps(areas,separators=(',',':'))+'\n');(P/(stem+'-result.json')).write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items()if k!='source_sha256'}),flush=True)
if __name__=='__main__':main()
