"""Exact ordered AP coverage, separately fixed internal-total bands."""
from fractions import Fraction as F

BANDS={'small':(4,19,F(9,5),F(17,10)), 'large':(20,49,F(4),F(9,2))}

class Cover:
    def __init__(self,name):
        self.name=name;self.minimum,self.maximum,self.reserve,self.amplitude=BANDS[name]
    def total_range(self,q,Q,ell,L):
        assert 1<=q<=Q<=self.maximum-2 and (Q-q)%4==0
        assert 2<=ell<=L<=self.maximum-1 and (L-ell)%4==0
        lo=q+ell;hi=Q+L;lo+=4*max(0,(self.minimum-lo+3)//4)
        hi=min(hi,self.maximum);hi-=((hi-(q+ell))%4)
        return None if lo>hi else(lo,hi)
    def roots(self):
        return [(p,q,q+4*((self.maximum-2-q)//4),ell,ell+4*((self.maximum-1-ell)//4))for p in range(1,5)for q in range(1,5)for ell in range(2,6)]
    def parse_tree(self,code,a,b,target,direct,common,p,q,Q,ell,L):
        pos=leaves=empty=maxp=0;upper=F(0)
        def visit(p,tail,q,Q,ell,L):
            nonlocal pos,leaves,empty,maxp,upper
            assert pos<len(code),'truncated tree';symbol=code[pos];pos+=1;maxp=max(maxp,p);band=self.total_range(q,Q,ell,L)
            if symbol=='5':assert band is None,'false arithmetic empty';empty+=1;return
            assert band is not None,'nonempty symbol on empty class'
            if symbol in '04':
                got=(common if symbol=='0'else direct).bound(a,b,F(0)if tail else F(1),F(1),F(0)if ell<L else F(1),F(1),F(0)if q<Q else F(1),F(1),F(band[0]),F(band[1]),p,ell,q)
                assert got['upper']<=target,'exact band leaf misses target'
                upper=max(upper,got['upper']);leaves+=1;return
            if symbol=='1':
                assert tail,'split isolated p';visit(p,False,q,Q,ell,L);visit(p+4,True,q,Q,ell,L)
            elif symbol=='2':
                for q0,q1 in split(q,Q):visit(p,tail,q0,q1,ell,L)
            elif symbol=='3':
                for l0,l1 in split(ell,L):visit(p,tail,q,Q,l0,l1)
            else:raise AssertionError('unknown tree symbol')
        visit(p,True,q,Q,ell,L);assert pos==len(code),'tree suffix'
        return upper,leaves,empty,maxp
    def cell(self,part,a,b,target,direct,common):
        assert F(part['a'])==a and F(part['b'])==b and a<b
        if 'split' in part:
            assert 'trees'not in part and len(part['split'])==2
            mid=(a+b)/2;x=self.cell(part['split'][0],a,mid,target,direct,common);y=self.cell(part['split'][1],mid,b,target,direct,common)
            return x[0]+y[0],x[1]+y[1],x[2]+y[2],max(x[3],y[3]),x[4]+y[4]
        assert len(part['trees'])==64;upper=F(0);leaves=empty=maxp=0
        for code,root in zip(part['trees'],self.roots()):
            val,count,missing,anchor=self.parse_tree(code,a,b,target,direct,common,*root)
            upper=max(upper,val);leaves+=count;empty+=missing;maxp=max(maxp,anchor)
        return (b-a)*upper,leaves,empty,maxp,1

def split(lo,hi):
    assert lo<hi and(hi-lo)%4==0
    count=(hi-lo)//4+1;mid=lo+4*(count//2-1)
    return(lo,mid),(mid+4,hi)
