"""Exact Q[i][eight variables] identities, with NO endpoint reductions."""
from pathlib import Path
import json
import private_common_ad5 as model
from poly8 import P,V,z,ca,cs,cm,ct,determinant
ROOT=Path(__file__).resolve().parent
def equal(a,b):return all(not p.c for p in cs(a,b))
def main():
    t,r,s,u,e,f,g,gamma=V;w=z(t,2);w2=cm(w,w);a=ca(z(t+r,1),z(e));b=ca(z(t+s,1),z(f));m=ca(z(t+u,1),z(g));nl=cs(z(t-2*r,4),z(2*e));nr=ct(w2,s);d=t+r+u;J=ca(cs(ca(ct(w2,t),ct(w,gamma)),z(2*(u+g+s+f))),z(0,4));Z=[[z(d),cm(z(0,1),m)],[cm(z(0,1),m),J]];D=determinant(Z);adj=[[J,ct(Z[0][1],-1)],[ct(Z[0][1],-1),z(d)]];U=[[a,w2],[z(),cm(b,w)]]
    original={k:getattr(model,k)for k in('z','ca','cs','cm','ct','cd','sq')};oldend=model.ad.endpoints
    try:
        for k,fun in dict(z=z,ca=ca,cs=cs,cm=cm,ct=ct,cd=lambda a,b:a,sq=lambda a:a*a).items():setattr(model,k,fun)
        model.ad.endpoints=lambda tt,uu,j:((r,z(e))if j==1 else(s,z(f))if j==2 else(u,z(g)))
        den,aa,ab,bb,pp=model.numerators(t,P(),P(),P(),gamma,1,2,3)
    finally:
        for k,fun in original.items():setattr(model,k,fun)
        model.ad.endpoints=oldend
    count=0
    assert equal(den,cm(w2,D));count+=1
    for i in range(2):
        for j in range(2):
            out=z()
            for k in range(2):out=ca(out,cm(Z[i][k],adj[k][j]))
            assert equal(out,D if i==j else z());count+=1
            value=cm((nl,nr)[i],D)if i==j else z()
            for k in range(2):
                for l in range(2):value=ca(value,cm(cm(U[i][k],adj[k][l]),U[j][l]))
            assert equal(value,aa if i==j==0 else bb if i==j==1 else ab);count+=1
    assert equal(cs(cm(aa,bb),cm(ab,ab)),cm(D,pp));count+=1
    out=dict(status='PASS_FORMAL_PRIVATE_SIBLING_EIGHT_VARIABLE_COMMON_RESPONSE_AND_DETERMINANT',identities=count,coefficient_domain='Q[i][t,rL,rR,rM,eL,eR,eM,gamma], NO endpoint equations used',determinant='detFc=P/(w^4 D); common response denominator w^2 D; TOTAL q+ell gamma retained',original_global='OPEN');(ROOT/'private-common-polynomial-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
