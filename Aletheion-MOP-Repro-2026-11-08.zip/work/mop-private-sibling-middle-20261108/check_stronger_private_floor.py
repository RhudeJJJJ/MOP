"""Stronger PRIVATE-role floor on ell>=2,total>=4; one additional true envelope case."""
from pathlib import Path
from fractions import Fraction as F
import json
import rational_grid
rational_grid.install()
import disk_interval as h,net_interval as n,exact as e
from private_coronal import polynomials
from private_budget_tools import add
P=Path(__file__).resolve().parent
def additional_envelope():
    C0,C1,M0,M1,_=polynomials(4,2);assert all(v>=0 for p in(C0,C1,M0,M1)for v in p)
    ratios=[(add(e.mul([0,1],M0),M1),add(e.mul([0,1],C0),C1)),(add(e.mul([1,0,1],M0),e.mul([0,1],M1)),add(e.mul([1,0,1],C0),e.mul([0,1],C1)))]
    cells=[]
    for a,b,step in((F(1,4),F(1),F(1,64)),(F(1),F(4),F(1,32)),(F(4),F(16),F(1,16)),(F(16),F(64),F(1,4))):
        while a<b:
            right=min(b,a+step);ratio=min(e.ev(num,a)/e.ev(den,right)for num,den in ratios);assert ratio>0
            area=(right-a)*a*n.atan_interval(h.con(ratio))[0];cells.append(dict(a=str(a),b=str(right),ratio_lower=str(ratio),area_lower=str(area)));a=right
    integral=sum((F(c['area_lower'])for c in cells),F(0));assert n.PI[1]<F(22,7);lower=F(14,11)*integral;assert lower>F(18,5)
    (P/'q4-ell2-envelope-cells.json').write_text(json.dumps(cells,separators=(',',':'))+'\n')
    return dict(q=4,ell=2,frequency_cells=len(cells),phase_integral_lower=str(integral),D_lower=str(lower),pi_upper='22/7',outside='Nonnegative actual D integrand omitted only for LOWER bound; all-p endpoint interval retained')
def main():
    small=json.loads((P/'small-private-floor-check.json').read_bytes());assert small['status']=='PASS_PRIVATE_SIBLING_ALL_p_SMALL_INTERNAL_TOTAL_MULTI_ROUTE_FLOORS'
    exception=json.loads((P/'exception-private-floor-check.json').read_bytes());extra=additional_envelope();rows=[];counts={}
    for r in small['rows']:
        if r['ell']<2 or r['total']<4:continue
        route=r['all_p_route']
        if route.startswith('nonnegative'):lower=F(r['exact_base']['D_lower'])/2;method='valid_phase_comparison'
        elif route.startswith('disjoint'):
            lower=F(r['exact_core']['D_lower'])/2-1;method='core_pinching'
            if lower<=F(9,5):
                assert(r['q'],r['ell'])==(4,2);lower=F(extra['D_lower'])/2;method='additional_q4_ell2_endpoint_minimum_envelope'
        else:lower=F(exception['D_lower'])/2;method='q3_ell2_endpoint_minimum_envelope'
        assert lower>F(9,5),(r['q'],r['ell']);counts[method]=counts.get(method,0)+1;rows.append(dict(q=r['q'],ell=r['ell'],method=method,private_surplus_lower=str(lower)))
    assert len(rows)==44
    out=dict(status='PASS_ALL_p_PRIVATE_SIBLING_ell_AT_LEAST2_TOTAL_AT_LEAST4_PRIVATE_BUDGET9_OVER5',finite_total_range=[4,11],ordered_pairs=len(rows),verified_routes=counts,extra_envelope=extra,rows=rows,infinite_total_from=12,infinite_tail='Written direct two-path core pinching g(S+1)+1>13726/7605>9/5 for ALLS>=12',all_length_theorem='For EVERY p>=1,q>=1,ell>=2 with q+ell>=4, private energy plus contact mass>2N+9/5. No full root payment.',ell1='NOT assigned this stronger floor at small total; belongs to external-role theorem where actually accepted.',original_global='OPEN')
    (P/'stronger-private-floor-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in('rows','extra_envelope')}))
if __name__=='__main__':main()
