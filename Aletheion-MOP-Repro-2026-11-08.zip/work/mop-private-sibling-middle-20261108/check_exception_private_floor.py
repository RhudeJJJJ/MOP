"""ALL p for q3,ell2, despite false p1 pointwise phase comparison."""
from fractions import Fraction as F
from pathlib import Path
import json
import rational_grid
rational_grid.install()
import disk_interval as h,net_interval as n,exact as e
from private_budget_tools import add
from private_coronal import polynomials
P=Path(__file__).resolve().parent
def main():
    C0,C1,M0,M1,cross=polynomials(3,2);assert all(v>=0 for a in(C0,C1,M0,M1)for v in a)
    # At endpoint r1=1/t and r2=t/(t^2+1), clear POSITIVE denominators.
    ratios=[(add(e.mul([0,1],M0),M1),add(e.mul([0,1],C0),C1)),(add(e.mul([1,0,1],M0),e.mul([0,1],M1)),add(e.mul([1,0,1],C0),e.mul([0,1],C1)))]
    for numerator,denominator in ratios:assert all(v>=0 for v in numerator+denominator)and any(numerator)and any(denominator)
    cells=[]
    for a,b,step in((F(1,4),F(1),F(1,64)),(F(1),F(4),F(1,32)),(F(4),F(16),F(1,16)),(F(16),F(64),F(1,4))):
        while a<b:
            right=min(b,a+step);ratio=min(e.ev(num,a)/e.ev(den,right)for num,den in ratios);assert ratio>0
            theta=n.atan_interval(h.con(ratio))[0];area=(right-a)*a*theta;cells.append(dict(a=str(a),b=str(right),ratio_lower=str(ratio),area_lower=str(area)));a=right
    integral=sum((F(c['area_lower'])for c in cells),F(0));lower=4*integral/n.PI[1];assert lower>F(17,5)
    out=dict(status='PASS_EXCEPTION_q3_ell2_ALL_p_PRIVATE_PHASE_ENVELOPE_FLOOR',frequency_cells=len(cells),compact_domain=['1/4','64'],phase_integral_lower=str(integral),D_lower=str(lower),proved_D='17/5',endpoint_domain='For EVERYp>=1, r_p in[t/(t^2+1),1/t]. Fractional-linear M/C minimum is at one endpoint; never assumes p1 phase dominates.',outside_compact='Discarded ONLY for this LOWER bound: exact C>0,M>0 make the full determinant phase negative and omitted D integrand nonnegative on ALLt>0.',full_graft_root_payment='OPEN',original_global='OPEN')
    (P/'exception-private-floor-cells.json').write_text(json.dumps(cells,separators=(',',':'))+'\n');(P/'exception-private-floor-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
