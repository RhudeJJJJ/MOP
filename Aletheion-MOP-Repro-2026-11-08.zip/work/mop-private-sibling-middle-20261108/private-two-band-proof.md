# PRIVATE sibling: fixed-total two-band payment bridge

8 November 2026. CONDITIONAL DRAFT: full compact exact reading is not yet
accepted. Original every finite simple UNIT MOP G,n>=8 satisfies
F(G)=splus(G)>=2n remains GLOBAL OPEN. No whole-domain cover is inferred.

TARGET. For every old UNIT MOP H,h>=3, ordered boundary ab and integers
p,q>=1,ell>=2 with 4<=S=q+ell<=49, add the actual parent abc,
external E_(p,q) child on ac with apices a,c and PRIVATE-c-apex sibling
fan ell on cb. Keep ab once. There are N=p+q+ell+2 new private vertices
and 2N new unit edges. The intended full increment is

                         DeltaF>2N+1/20.                    (1)

The theorem requires the terminal full exact certificate, not a prefix,
float partition, finite parameter experiment or target budget alone.
Every p is unbounded, including all four ordered residue classes.

1. Same actual graph and root. The proven private-model-proof.md gives
the FULL private B, contacts Ta=prefix0..p+e_c,Tb=e_c+e_last and
edges(B)=p+2S, Tr(TTt)=p+4, sum=2N. In particular, old b contacts only
c and the LAST sibling vertex. The distinct external-b role is not used.

The actual old-root sector and sharp root-ball phase theorem imply

 DeltaF>=F(B)+Tr(TTt)-(2/pi) integral_0^infinity t b(Fcap,t)dt.

Subtract only the left positive lossless ray (p-1)/(t+2i) from Fcap.
It preserves Wplus and increases the admissible phase upper bound.
No original energy is assigned to the normalized response. Both direct
and common denominator formulas, formal identities, full private inverse
controls, all five partials and physical chain tangents were accepted in
native run cb53d63787574eb2bf6ea745108119bc and replayed from its complete
source export. That acceptance alone did not prove the compact payment.

2. Choose ONE total band for the graph, for its WHOLE integral.
For 4<=S<=19 and ell>=2, the accepted private floor is
F(B)+Tr(TTt)>2N+9/5. It was proved for S4..11 by exact coronal/Sturm
and two valid endpoint envelopes, and for S>=12 analytically. The false
blanket p1 pointwise comparison at q3,ell2 is never invoked.

For S>=20 a stronger analytic floor is available. Pinch B into its actual
core J=c join(P_(q+1) disjoint P_ell) and pendant P_p. With r=S+1,
interlacing, the path-forest lower bound and an explicit Rayleigh vector give

 F(J)>2r+g(r), g(r)=2sqrt(r)-4/sqrt(r)-5-4/r+4/r^2.

The derivative of g is positive for r>=2. Since (457/100)^2<21,

 g21+1>2(457/100)-4/(457/100)-4-4/21+4/441
       =41147009/10076850>4.

Thus for ALL S>=20, F(B)+Tr(TTt)>2N+4. The finite phase work uses
only 20<=S<=49. A graph of small S never receives this larger reserve.
The two disjoint bands contain 152 and 975 ORDERED(q,ell) pairs,
respectively. Equal S does not identify their contacts or responses.

3. Entire high and low frequencies. V=(B-2I)Tt satisfies TV=-2I,
VtV=[[S+5,S+1],[S+1,S+5]] for ell>=2. Remove the hub star edges at c:
what remains is a disjoint path forest, uniformly in unbounded p. Hence
||B||<sqrt(S+1)+2. For S<=19 this is <13/2 (sqrt20<9/2);
for S<=49 it is <10. Therefore C=Vt(I+z^2 B^2)^-1V has diagonals[0,M]
and absolute off diagonal<=M, while D=Vt B(I+z^2 B^2)^-1V has all
absolute entries<=L M. Use M24,LM156 in the small band and M54,LM540
in the large band. The normalized leading Q is [[3,1],[1,2]].

bulk_small_tail.py and uniform_private_tail.py apply the same complete
signed sparse resolvent identity and support/nuclear-norm rationalization.
Every one of 64 exact z cells in[0,1/16] checks the positive-real response,
positive divisors and outward square roots. This bounds ALL t>=16.
Twenty full actual private inverse controls calibrate the formulas and
constants; the written star/forest and Gram proof supplies uniformity.
For 0<t<1/2, the universal b<2pi charges at most 1/2 in ENERGY.

4. Compact domain and genuine infinite p coverage. For both bands use
the 80 contiguous base frequency intervals of bulk-frequency-grid.json
covering[1/2,16]. Each base target is A/(1+t_mid^2), with A17/10 for
the small band and A9/2 for the large band. These are selection targets,
not phase theorems. Frequency splitting retains its parent's target.

The EXACT reader checks all64 ordered residue roots p1..4,q1..4,ell2..5.
Its finite q,ell AP boxes are intersected with the ACTUAL fixed band.
The scalar gamma=q+ell may be enlarged to its exact AP-sum interval;
this enlargement can weaken a bound but cannot omit an actual graph.
An empty code is legal only if the exact finite AP intersection is empty.
For each p residue the endpoint envelope represents EVERY p+4k,
k>=0. A p split checks BOTH the singleton anchor and the infinite tail
starting at anchor+4; the greatest anchor is not a length cutoff.

Per frequency leaf take the MAXIMUM over all length leaves, then multiply
by frequency width. Sum all frequencies separately in each band, with no
averaging over parameters or movement of reserve between bands. Directed
96-bit integer-grid arithmetic, complete code consumption and full input,
reader and certificate hashes are checked. Floating code proposes only
partitions; it is never imported by the exact reader. Failed artificial
phase boxes use safe caps or must be refined, never silently discarded.

The finite AP checker examines all2025 small-band and90000 large-band
boxes, checks disjoint unique coverage of1127 ordered pairs for EACH
p residue, and rejects14 damaged grammar artifacts in EACH band. These
checks establish arithmetic/grammar coverage, not the analytic leaf bounds.

5. Acceptance and original consequence. Let I_s,I_l be the exact complete
compact integral bounds, and T_s,T_l the complete high-tail bounds. The
full reader must prove BOTH

 9/5-1/2-2(I_s+T_s)/pi_lower>1/20,
 4  -1/2-2(I_l+T_l)/pi_lower>1/20.                         (2)

Current budget estimates with all targets met are about .08844 and .25557;
they are NOT accepted payments. Only full exact leaf reading proves(2).
Then (1) follows for each graph in its one fixed band. This does not prove
all-small-old WHOLE payment, unrestricted bare-fork payment or the original
global conjecture. Combined sibling roles require their own accepted ranges
and a literal graph coverage argument; no independent overlapping credit
is created by these calculations. Native intake of this new bridge remains
PENDING. No external formal audit, priority or LOTSE causal effect is claimed.
