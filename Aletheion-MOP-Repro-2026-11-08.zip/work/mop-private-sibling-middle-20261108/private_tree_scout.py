"""FLOAT selector only; PRIVATE ell>=2,total4..49 with p UNBOUNDED."""
import float_discovery
float_discovery.install()
import private_ad5 as direct,private_common_ad5 as common
from private_cover import total_range,roots,split
def solve(a,b,target,limit=30000):
    stats=dict(calls=0,leaves=0,empty=0,max_p_anchor=4,q_splits=0,ell_splits=0,common_leaves=0,direct_leaves=0);cache={};maximum=0.
    def visit(p,tail,q,Q,ell,L):
        nonlocal maximum
        band=total_range(q,Q,ell,L)
        if band is None:stats['empty']+=1;return'5'
        key=(p,tail,q,Q,ell,L)
        if key not in cache:
            if stats['calls']>=limit:raise ArithmeticError('bounded private node budget reached')
            stats['calls']+=1;stats['max_p_anchor']=max(stats['max_p_anchor'],p);best=None;proxy=None
            for module,symbol in((common,'0'),(direct,'4'))if a<2 else((direct,'4'),(common,'0')):
                got=module.bound(a,b,0. if tail else 1.,1.,0. if ell<L else 1.,1.,0. if q<Q else 1.,1.,float(band[0]),float(band[1]),p,ell,q);got['symbol']=symbol
                if 'grad_proxy'in got:proxy=got['grad_proxy']
                if best is None or got['upper']<best['upper']:best=got
                if best['upper']<=target:break
            if proxy is not None and'grad'not in best:best['grad_proxy']=proxy
            cache[key]=best
        got=cache[key]
        if got['upper']<=target:
            stats['leaves']+=1;stats['common_leaves'if got['symbol']=='0'else'direct_leaves']+=1;maximum=max(maximum,got['upper']);return got['symbol']
        if not tail and q==Q and ell==L:raise ArithmeticError('isolated PRIVATE triple needs frequency refinement '+str((p,q,ell,got['upper'],target)))
        if p>160:raise ArithmeticError('bounded heuristic p anchor reached')
        grad=got.get('grad',got.get('grad_proxy',(0.,1.,1.,1.,1.)));cq=(Q-q)//4+1;cl=(L-ell)//4+1
        scores=[float(grad[1])if tail else-1.,float(grad[3])+float(grad[4])*(Q-q)if q<Q else-1.,float(grad[2])+float(grad[4])*(L-ell)if ell<L else-1.]
        dim=(1 if cq>=cl else 2)if max(cq,cl)>=4 else max(range(3),key=lambda j:scores[j])
        if dim==0:return'1'+visit(p,False,q,Q,ell,L)+visit(p+4,True,q,Q,ell,L)
        if dim==1:
            stats['q_splits']+=1;left,right=split(q,Q);return'2'+visit(p,tail,*left,ell,L)+visit(p,tail,*right,ell,L)
        stats['ell_splits']+=1;left,right=split(ell,L);return'3'+visit(p,tail,q,Q,*left)+visit(p,tail,q,Q,*right)
    try:
        trees=[visit(p,True,q,Q,ell,L)for p,q,Q,ell,L in roots()];return dict(status='HEURISTIC_PRIVATE_BULK_COVER',maximum=maximum,trees=trees,stats=stats)
    except ArithmeticError as error:return dict(status='HEURISTIC_PRIVATE_REFINEMENT_REQUIRED',reason=str(error),stats=stats)
