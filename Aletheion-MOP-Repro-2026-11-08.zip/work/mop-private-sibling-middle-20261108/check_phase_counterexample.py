from fractions import Fraction as F
from pathlib import Path
import json
import exact as e,geometry as g
from private_coronal import polynomials
P=Path(__file__).resolve().parent
def main():
    q,ell,t=3,2,F(1,4);C0,C1,M0,M1,cross=polynomials(q,ell);assert cross==list(map(F,[0,0,-4,0,0,0,12,0,10,0,2]))
    value=e.ev(cross,t);assert value==F(-129455,524288)<0
    ratios=[]
    for p,r in((1,F(4)),(2,F(4,17))):
        c=e.ev(C0,t)+r*e.ev(C1,t);m=e.ev(M0,t)+r*e.ev(M1,t);assert c>0 and m>0
        B,_=g.cap(p,q,ell);cp=e.characteristic(B);units=((1,0),(0,1),(-1,0),(0,-1));got=tuple(sum(a*t**k*units[(k-len(B))%4][j]for k,a in enumerate(cp))for j in(0,1));factor=t if p==1 else t*t+1
        assert got==(factor*c,-factor*m);ratios.append(m/c)
    assert ratios[1]<ratios[0]
    out=dict(status='PASS_EXACT_REFUTATION_PRIVATE_ROLE_p1_POINTWISE_PHASE_COMPARISON',q=q,ell=ell,t=str(t),p1_endpoint='4',p2_endpoint='4/17',cross_polynomial=list(map(str,cross)),cross_value=str(value),p1_phase_ratio=str(ratios[0]),p2_phase_ratio=str(ratios[1]),refuted='For ALLp, the absolute negative determinant phase is at least the p1 private base phase, pointwise at every t>0.',not_refuted=['Integrated private energy minimum at p1','Private reserve17/10','External-b-role private phase theorem','Original global MOP conjecture'],next_route='Finite-core pinching where it pays; on exceptional q3 ell2 retain r_p in[t/(t^2+1),1/t] and integrate a rigorous endpoint-minimum lower envelope.',original_global='OPEN')
    (P/'private-phase-counterexample.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
