"""ALL p by a VERIFIED disjunction: phase comparison, core pinching, exceptional envelope."""
from pathlib import Path
from fractions import Fraction as F
import json
import exact as e,geometry as g
from private_budget_tools import add,scale,za,zm,root_lower
P=Path(__file__).resolve().parent

def main():
    D=[[F(1)],[F(0),F(1)]];E=[([F(0)],[F(0)]),([F(1)],[F(0)])];X=([F(1)],[F(0)])
    for m in range(2,12):
        dn=add(e.mul([0,1],D[-1]),D[-2]);en=za(za(zm(([0,1],[0]),E[-1]),E[-2]),za((D[-1],[0]),zm(([0],[-2]),X)));X=za((D[-1],[0]),zm(([0],[-1]),X));D.append(dn);E.append(en)
    rows=[];controls=0;routes={}
    for total in range(2,12):
        for q in range(1,total):
            ell=total-q;m=q+1;A=za((e.mul([0,1],D[ell]),[F(0)]),E[ell]);Z=[]
            for j in(m,m-1):Z.append(za(zm(A,(D[j],[F(0)])),zm((D[ell],[F(0)]),E[j])))
            C0,C1=Z[0][0],Z[1][0];M0,M1=scale(Z[0][1],-1),scale(Z[1][1],-1)
            cross=add(e.mul(M0,C1),e.mul(M1,C0),-1)
            assert all(v>=0 for poly in(C0,C1,M0,M1)for v in poly)and any(M0)and any(C0),(q,ell)
            monotone=all(v>=0 for v in cross)and any(cross)
            # Literal PRIVATE determinant versus coronal identity, including phases.
            for p in(1,2):
                B,_=g.cap(p,q,ell);char=e.characteristic(B);degree=len(B)
                for t in(F(1,4),F(1),F(4)):
                    dp=[F(1),t]
                    for j in range(2,p+1):dp.append(t*dp[-1]+dp[-2])
                    r=dp[-2]/dp[-1];units=((1,0),(0,1),(-1,0),(0,-1))
                    got=tuple(sum(cc*t**k*units[(k-degree)%4][j]for k,cc in enumerate(char))for j in(0,1))
                    want=(dp[-1]*(e.ev(C0,t)+r*e.ev(C1,t)),-dp[-1]*(e.ev(M0,t)+r*e.ev(M1,t)))
                    assert got==want;controls+=1
            B,_=g.cap(1,q,ell);base,lower=root_lower(B)
            if total>=4:assert lower>F(17,5),(q,ell,lower)
            elif total==3:assert lower>F(12,5),(q,ell,lower)
            else:
                bull=e.mul([0,1],e.mul([-3,-1,1],[-1,1,1]));assert e.characteristic(B)==bull
            row=dict(q=q,ell=ell,total=total,C0=list(map(str,C0)),C1=list(map(str,C1)),M0=list(map(str,M0)),M1=list(map(str,M1)),phase_derivative_cross=list(map(str,cross)),exact_base=base)
            if monotone:row['all_p_route']='nonnegative_phase_derivative_cross_and_p1_Sturm_base'
            else:
                assert total>=4
                core=[r[1:]for r in B[1:]];corebase,corelower=root_lower(core);row['exact_core']=corebase
                if corelower>F(27,5):row['all_p_route']='disjoint_core_plus_Pp_pinching_Dcore_over2_minus1'
                else:
                    assert(q,ell)==(3,2)
                    exception=json.loads((P/'exception-private-floor-check.json').read_bytes())
                    assert exception['status']=='PASS_EXCEPTION_q3_ell2_ALL_p_PRIVATE_PHASE_ENVELOPE_FLOOR'and F(exception['D_lower'])>F(17,5)
                    counter=json.loads((P/'private-phase-counterexample.json').read_bytes());assert counter['status']=='PASS_EXACT_REFUTATION_PRIVATE_ROLE_p1_POINTWISE_PHASE_COMPARISON'
                    row['all_p_route']='proved_two_endpoint_minimum_integral_envelope_despite_refuted_p1_pointwise_comparison'
            routes[row['all_p_route']]=routes.get(row['all_p_route'],0)+1;rows.append(row)
    assert len(rows)==55
    out=dict(status='PASS_PRIVATE_SIBLING_ALL_p_SMALL_INTERNAL_TOTAL_MULTI_ROUTE_FLOORS',internal_total_range=[2,11],ordered_internal_pairs=len(rows),full_private_determinant_controls=controls,verified_routes=routes,private_floor='For ALLp and total>=4: surplus>17/10, with total>=12 written analytic tail. Total3: surplus>6/5. Total2 bull floor c0, strict for p>1.',false_helper='Universal PRIVATE-role p1 pointwise phase comparison REFUTED at q3 ell2; not used for rows whose cross fails.',rows=rows,actual_full_root_payment='OPEN',original_global='OPEN')
    (P/'small-private-floor-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k!='rows'}))
if __name__=='__main__':main()
