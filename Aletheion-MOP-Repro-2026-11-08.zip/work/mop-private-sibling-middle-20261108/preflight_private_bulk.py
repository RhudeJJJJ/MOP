from pathlib import Path
from fractions import Fraction as F
import json,time
import private_tree_scout as scout
P=Path(__file__).resolve().parent
def main():
    a,b=F(1,2),F(9,16);tm=(a+b)/2;target=F(3,2)/(1+tm*tm);start=time.perf_counter();attempts=[]
    def build(a,b,depth=0):
        result=scout.solve(float(a),float(b),float(target)-1e-7);record=dict(a=str(a),b=str(b),depth=depth,status=result['status'],stats=result['stats'])
        if'reason'in result:record['reason']=result['reason']
        attempts.append(record);print(json.dumps(record),flush=True)
        if result['status']=='HEURISTIC_PRIVATE_BULK_COVER':return dict(a=str(a),b=str(b),trees=result['trees'],stats=result['stats'])
        assert depth<6,'bounded initial frequency refinement exhausted';mid=(a+b)/2
        return dict(a=str(a),b=str(b),split=[build(a,mid,depth+1),build(mid,b,depth+1)])
    part=build(a,b);part['target']=str(target);(P/'private-preflight-tree.json').write_text(json.dumps(part,separators=(',',':'))+'\n');(P/'private-preflight-attempts.json').write_text(json.dumps(attempts,indent=2)+'\n')
    print(json.dumps(dict(status='HEURISTIC_PRIVATE_BULK_PREFLIGHT_READY_REQUIRES_EXACT_READER',a=str(a),b=str(b),target=str(target),attempts=len(attempts),seconds=time.perf_counter()-start)),flush=True)
if __name__=='__main__':main()
