"""Calibrate narrower band constants against full actual private inverses."""
from pathlib import Path
from fractions import Fraction as F
import json
import exact as e,geometry as g,private_physical as phys
P=Path(__file__).resolve().parent
def main():
    result={}
    for name,triples,Cmax,Dmax in [('small',[(1,1,3),(2,3,2),(3,1,18),(2,17,2),(5,9,10)],24,156),('large',[(1,1,19),(2,18,2),(2,1,48),(3,47,2),(1,24,25)],54,540)]:
        cases=0
        for p,q,ell in triples:
            S=q+ell;B,T=g.cap(p,q,ell);N=len(B);c=p+q+1
            assert (4<=S<=19)if name=='small'else(20<=S<=49)
            assert sum(B[c])==S+1
            forest=[[B[i][j]if i!=c and j!=c else F(0)for j in range(N)]for i in range(N)]
            assert max(map(sum,forest))<=2
            V=e.mm(B,e.tr(T));V=[[x-2*y for x,y in zip(row,rr)]for row,rr in zip(V,e.tr(T))]
            assert e.mm(T,V)==[[-2,0],[0,-2]]and e.mm(e.tr(V),V)==[[S+5,S+1],[S+1,S+5]]
            for t in(F(16),F(32)):
                x=1/(t*t);BB=e.mm(B,B);R=e.inverse([[int(i==j)+x*BB[i][j]for j in range(N)]for i in range(N)])
                C=e.mm(e.mm(e.tr(V),R),V);D=e.mm(e.mm(e.mm(e.tr(V),B),R),V)
                assert 0<=C[0][0]<=Cmax and 0<=C[1][1]<=Cmax and abs(C[0][1])<=Cmax and all(abs(v)<=Dmax for row in D for v in row)
                full=phys.response(p,q,ell,t);aa=1+4*x;Q=[[3,1],[1,2]]
                for i in range(2):
                    for j in range(2):
                        qp=Q[i][j]/aa+8*x*int(i==j)/(aa*aa)-x*((1-4*x)*C[i][j]-4*x*D[i][j])/(aa*aa)
                        mp=2*Q[i][j]/aa-2*(1-4*x)*int(i==j)/(aa*aa)-x*((1-4*x)*D[i][j]+4*C[i][j])/(aa*aa)
                        assert qp==t*full[i][j][0]and mp==-t*t*full[i][j][1]
                cases+=1
        result[name]=dict(full_private_tail_cases=cases,geometry_states=len(triples),C_upper=Cmax,D_absolute_upper=Dmax)
    assert F(9,2)**2>20
    out=dict(status='PASS_TWO_BAND_FULL_PHYSICAL_TAIL_CONTROLS',bands=result,small_norm='star norm<=sqrt20 plus pathforest norm<2, hence <13/2',large_norm='star norm<=sqrt50 plus pathforest norm<2, hence <10',uniformity='Written all-length star/forest and Gram identities, not finite controls',original_global='OPEN')
    (P/'bulk-tail-controls.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
