from pathlib import Path
from fractions import Fraction as F
import json,hashlib,time
import rational_grid
rational_grid.install()
import private_ad5 as direct,private_common_ad5 as common
from private_cover import cell
P=Path(__file__).resolve().parent
def main():
    start=time.monotonic();part=json.loads((P/'private-preflight-tree.json').read_bytes());area,leaves,empty,anchor=cell(part,F(part['a']),F(part['b']),F(part['target']),direct,common)
    def count(x):return sum(map(count,x['split']))if'split'in x else 1
    out=dict(status='PASS_EXACT_PRIVATE_BULK_ONE_BASE_INTERVAL_PREFLIGHT_ONLY',frequency_domain=[part['a'],part['b']],frequency_leaves=count(part),area_upper=str(area),leaves=leaves,empty_arithmetic_leaves=empty,max_p_anchor=anchor,residue_roots=64,ordered_internal_pairs=1127,outer_p='UNBOUNDED',tree_sha256=hashlib.sha256((P/'private-preflight-tree.json').read_bytes()).hexdigest(),seconds=time.monotonic()-start,full_compact_root_payment='OPEN',original_global='OPEN')
    (P/'private-preflight-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
