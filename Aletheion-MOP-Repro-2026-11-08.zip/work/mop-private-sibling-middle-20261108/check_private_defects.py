"""Actual PRIVATE-c sibling sparse V, Gram and signed complete-tail response controls."""
from pathlib import Path
from fractions import Fraction as F
import json
import exact as e,geometry as g,private_physical as phys
P=Path(__file__).resolve().parent
def main():
    cases=0;triples=[(1,1,1),(1,1,3),(2,3,2),(2,5,1),(5,1,11),(3,6,6),(2,1,48),(2,24,25),(1,48,1),(3,25,24)]
    for p,q,ell in triples:
        B,T=g.cap(p,q,ell);N=len(B);c=p+q+1;total=q+ell;V=e.mm(B,e.tr(T));V=[[a-2*b for a,b in zip(row,rr)]for row,rr in zip(V,e.tr(T))]
        wanted=[[F(-int(i==0)+2*int(i==p+1)+sum(int(i==p+j)for j in range(2,q+1))-int(i==c)+sum(int(i==c+j)for j in range(1,ell+1))),F(int(i==p)+sum(int(i==p+j)for j in range(1,q+1))-int(i==c)+sum(int(i==c+j)for j in range(1,ell))+(int(ell>=2 and i==c+ell-1))-int(i==N-1))]for i in range(N)]
        assert V==wanted and e.mm(T,V)==[[-2,0],[0,-2]]
        assert e.mm(e.tr(V),V)==[[total+5,total+1-int(ell==1)],[total+1-int(ell==1),total+5-3*int(ell==1)]]
        assert e.mm(T,e.tr(T))==[[p+2,1],[1,2]]
        for t in(F(16),F(32)):
            x=1/(t*t);BB=e.mm(B,B);Ri=e.inverse([[int(i==j)+x*BB[i][j]for j in range(N)]for i in range(N)]);C=e.mm(e.mm(e.tr(V),Ri),V);D=e.mm(e.mm(e.mm(e.tr(V),B),Ri),V)
            assert 0<=C[0][0]<=54 and 0<=C[1][1]<=54 and abs(C[0][1])<=54
            assert all(abs(v)<=540 for row in D for v in row)
            full=phys.response(p,q,ell,t);aa=1+4*x;Q=[[3,1],[1,2]]
            for i in range(2):
                for j in range(2):
                    qp=Q[i][j]/aa+8*x*int(i==j)/(aa*aa)-x*((1-4*x)*C[i][j]-4*x*D[i][j])/(aa*aa)
                    mp=2*Q[i][j]/aa-2*(1-4*x)*int(i==j)/(aa*aa)-x*((1-4*x)*D[i][j]+4*C[i][j])/(aa*aa)
                    assert qp==t*full[i][j][0]and mp==-t*t*full[i][j][1]
            cases+=1
    out=dict(status='PASS_PRIVATE_SIBLING_LITERAL_DEFECT_GRAM_AND_FULL_PRIVATE_TAIL_CONTROLS',geometry_states=len(triples),full_private_tail_cases=cases,role='PRIVATE c sibling; old b contacts ONLY c and last sibling',all_length_proof='Written coordinate identities, star_c(total+1)+pathforest norm<10 for total<=49, Gram<=54 and actual sparse resolvent identity establish uniformity; finite controls calibrate signs.',compact_root_payment='OPEN',original_global='OPEN')
    (P/'private-defect-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
