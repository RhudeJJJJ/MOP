# Private sibling role: uniform private reserve above internal total12

8 November2026. ORIGINAL ALL-MOP F>=2n remains GLOBAL OPEN. General
PRIVATE-c sibling full root payment is also OPEN. This is an analytic
PRIVATE energy floor for an entire parameter range, before any root cost.

Use the SAME parent abc, external E_(p,q) child on ac with apices a,c,
and sibling fan ell on cb whose apex is PRIVATE c. Every p,q,ell>=1.
Let T=q+ell, N=p+T+2. Literal private B has core
J=c join(P_(q+1) disjoint_union P_ell), on path d,middle_q and the
separate sibling path, together with a pendant P_p attached at d.
Thus edges(B)=p+2T, root-contact mass=p+4, sum=2N. The last sibling
alone contacts old b, not all sibling vertices; old a contacts left_p,d,c.

THEOREM. For EVERY such triple with q+ell>=12, unbounded independently,

              F(B)>edges(B)+9/5,
              F(B)+Tr(TTt)>2N+9/5.                        (1)

Proof. For ANY r>=2, let P be a union of at most TWO paths on r vertices.
F(P)>=r-2 and its largest adjacency eigenvalue has square<4. Interlacing
gives F(K1 join P)>rho^2+r-6. The Rayleigh vector with hub sqrt(r) and
all path coordinates1 gives rho>=sqrt(r)+1-2/r>0. Hence

 F(K1 join P)>2r+g(r),
 g(r)=2sqrt(r)-4/sqrt(r)-5-4/r+4/r^2.

The derivative r^-1/2+2r^-3/2+4r^-2-8r^-3 is positive for r>=2.
Pinch the actual private graph into the TWO disjoint blocks J and P_p.
With r=T+1 this gives F(B)>2(T+1)+g(T+1)+p-1, or private surplus
strictly greater than g(T+1)+1 above its edges. At T12, sqrt13>18/5
gives

 g13+1>36/5-10/9-4-4/13+4/169=13726/7605>9/5.

Monotonicity proves(1) for the ENTIRE infinite internal-total range.
No finite spectra, generic edge-addition monotonicity, rootboost or
overlapping motif witnesses are used. The two contact roles remain literal.

For the next finite phase work one can restrict T<=49 by the accepted
full private-sibling large-tail theorem. On12<=T<=49, private c is a
star with T+1 leaves plus a path forest, so ||B||<sqrt50+2<10 uniformly
in unbounded p. Put V=(B-2I)Tt. Literal coordinate multiplication gives
TV=-2I, Gram diagonals T+5 and T+5-3indicator{ell=1}, and cross
T+1-indicator{ell=1}. Thus both Gram diagonals<=54. Subtract ONLY the
outer left lossless ray(p-1)/w; fixed leading Q is[[3,1],[1,2]]. All
internal bulk and the actual last-sibling old-b contact remain retained.

C=Vt(I+z^2 B^2)^-1V has diagonals[0,54], |C01|<=54. The corresponding
D0=Vt B(I+z^2 B^2)^-1V has all absolute entries<=540. These facts follow
from positive contraction, Cauchy and norm<10 for ALL actual lengths.
The uniform_private_tail.py uses these constants, not the different
external-b role's Gram formulas. ALL64 exact z cells now check the full
t>=16 rationalized tail. The role-specific sparse identities and signed
tail formulas are calibrated by10 actual geometries and20 FULL PRIVATE
tail controls in private-defect-check.json. The written norm/Gram proof
also applies to ALL2<=T<=49; this does not extend reserve9/5 below T12.

The compact root-phase proof for12<=T<=49 is OPEN. Small internal totals
2..11 are not assigned reserve9/5. There are45 ordered pairs with ell>=2
and q+ell<=11; p is still infinite. The ell1 graphs coincide literally
with the external sibling role at that single-triangle arm and can use
its accepted/pending actual ranges only after their own full acceptance.
Neither this private floor nor a tail integral alone pays a full graft.
No whole small-old theorem, global closure, priority or independent audit
is asserted. This new working package has not been centrally imported.
