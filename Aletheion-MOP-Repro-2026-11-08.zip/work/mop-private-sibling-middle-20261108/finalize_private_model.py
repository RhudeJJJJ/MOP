"""Full PRIVATE-role model/floor acceptance, explicitly NOT compact root payment."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib
P=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rd(n):return json.loads((P/n).read_bytes())
def main():
    statuses={'private-ad5-check.json':'PASS_PRIVATE_SIBLING_FIVE_VARIABLE_RESPONSE_ALL_PARTIALS_AND_FULL_PRIVATE_TANGENTS','private-common-ad5-check.json':'PASS_PRIVATE_SIBLING_COMMON_RESPONSE_ALL_PARTIALS_AND_FULL_PRIVATE_PHASE','private-common-polynomial-check.json':'PASS_FORMAL_PRIVATE_SIBLING_EIGHT_VARIABLE_COMMON_RESPONSE_AND_DETERMINANT','private-defect-check.json':'PASS_PRIVATE_SIBLING_LITERAL_DEFECT_GRAM_AND_FULL_PRIVATE_TAIL_CONTROLS','private-phase-counterexample.json':'PASS_EXACT_REFUTATION_PRIVATE_ROLE_p1_POINTWISE_PHASE_COMPARISON','exception-private-floor-check.json':'PASS_EXCEPTION_q3_ell2_ALL_p_PRIVATE_PHASE_ENVELOPE_FLOOR','small-private-floor-check.json':'PASS_PRIVATE_SIBLING_ALL_p_SMALL_INTERNAL_TOTAL_MULTI_ROUTE_FLOORS','private-budget-tail-check.json':'PASS_PRIVATE_ROLE_ANALYTIC_PRIVATE_RESERVE_AND_PROPOSED_COMPLETE_TAIL_CONSTANTS'}
    statuses['private-budget-tail-check.json']='PASS_PRIVATE_ROLE_PRIVATE_RESERVE_AND_VALIDATED_COMPLETE_TAIL'
    statuses['stronger-private-floor-check.json']='PASS_ALL_p_PRIVATE_SIBLING_ell_AT_LEAST2_TOTAL_AT_LEAST4_PRIVATE_BUDGET9_OVER5'
    statuses['special-support-check.json']='PASS_SPECIAL_PRIVATE_q1_ell2_TAIL_IDENTITIES_AND_DAMAGED_COVERAGE'
    statuses['special-reader-result.json']='PASS_EXACT_PRIVATE_q1_ell2_ALL_p_FULL_ROOT_PAYMENT'
    for n,status in statuses.items():assert rd(n)['status']==status,n
    small=rd('small-private-floor-check.json');assert small['ordered_internal_pairs']==55 and small['full_private_determinant_controls']==330
    row=next(r for r in small['rows']if r['q']==1 and r['ell']==2);assert F(row['exact_base']['D_lower'])>F(14,5)
    assert F(rd('exception-private-floor-check.json')['D_lower'])>F(17,5)
    special=rd('special-reader-result.json');cert=rd('special-certificate.json');manifest=rd('special-inputs.json')
    assert cert['source_sha256']==manifest and all(sha(P/n)==v for n,v in manifest.items())
    assert special['certificate_sha256']==sha(P/'special-certificate.json')and special['reader_sha256']==sha(P/'special_reader.py')
    from net_interval import PI
    assert PI[0]>F(157,50)
    special_coarse=F(7,5)-F(1,8)-2*(F(special['compact_integral_upper'])+F(special['tail_integral_upper']))/F(157,50);assert special_coarse>F(1,4)
    names=['private-model-proof.md','private-budget-proof.md','geometry.py','exact.py','complex_exact.py','poly8.py','private_budget_tools.py','private_coronal.py','private_physical.py','private_ad5.py','private_common_ad5.py','uniform_private_tail.py','disk_interval.py','net_interval.py','rational_grid.py','curve_interval.py','check_private_ad5.py','check_private_common_ad5.py','check_private_common_polynomials.py','check_private_defects.py','check_phase_counterexample.py','check_exception_private_floor.py','check_small_private_floors.py','check_private_budget_and_tail.py','check_stronger_private_floor.py','q4-ell2-envelope-cells.json','exception-private-floor-cells.json','failed-pointwise-floor-attempt.py.txt','prepare_private_head.py','prepare_private_tail.py','finalize_private_model.py']+list(statuses)
    names+=['special-payment-proof.md','special_produce.py','special_reader.py','special_tail.py','special-grid.json','special-budget.json','special-inputs.json','special-certificate.json','special-reader-cells.json','check_special_support.py','special-preflight-check.json','special-write-plan.json']
    names+=list(manifest)
    out=dict(status='PASS_PRIVATE_SIBLING_ALL_PRIVATE_FLOORS_HEAD_TAIL_AND_q1_ell2_ALL_p_ROOT_PAYMENT',private_floor='ALLp,q,ell: total>=4 surplus>17/10; total3>6/5 (q1ell2 stronger>7/5); total2 bull c0 with equality only all1; total>=12 stronger>9/5',false_pointwise_helper='REFUTED q3ell2,t1/4,p1versusp2; retained counter required before use',verified_finite_private_routes=small['verified_routes'],full_private_response_controls_per_variant=201,all_partial_components_per_variant=16080,true_tangent_components_per_variant=3216,tail_internal_total=[2,49],tail_integral_upper=rd('private-budget-tail-check.json')['tail_integral_upper'],special_root_payment='PROVEN ALLp,q1,ell2: actual increment>2N+1/4 for old UNIT MOP H>=3',special_surplus_lower_coarse=str(special_coarse),special_frequency_leaves=special['frequency_cells'],special_length_leaves=special['length_leaves'],compact_bulk_root_payment='OPEN ell>=2,total4..49',original_global='OPEN',original_goal_complete=False,native_intake='PENDING',source_sha256={n:sha(P/n)for n in dict.fromkeys(names)})
    out['stronger_new_role_floor']='ALLp,q>=1,ell>=2,total>=4: private/contact surplus>9/5;44 finite pairs plus analytic infinite tail'
    (P/'private-model-verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k!='source_sha256'}))
if __name__=='__main__':main()
