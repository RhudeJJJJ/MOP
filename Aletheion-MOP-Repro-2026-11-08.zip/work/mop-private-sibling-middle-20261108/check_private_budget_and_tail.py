"""Exact private reserve and complete tail inputs; compact root payment remains OPEN."""
from pathlib import Path
from fractions import Fraction as F
import json
import rational_grid
rational_grid.install()
import uniform_private_tail as tail
def main():
    P=Path(__file__).resolve().parent
    controls=json.loads((P/'private-defect-check.json').read_bytes())
    assert controls['status']=='PASS_PRIVATE_SIBLING_LITERAL_DEFECT_GRAM_AND_FULL_PRIVATE_TAIL_CONTROLS'and controls['full_private_tail_cases']==20
    lower=F(36,5)-F(10,9)-4-F(4,13)+F(4,169);assert lower==F(13726,7605)and lower>F(9,5)
    assert F(18,5)**2<13
    integral=sum((tail.tail(F(k,1024),F(k+1,1024))[1]/1024 for k in range(64)),F(0))
    pairs=[(q,ell)for q in range(1,11)for ell in range(2,11)if q+ell<=11];assert len(pairs)==45
    out=dict(status='PASS_PRIVATE_ROLE_PRIVATE_RESERVE_AND_VALIDATED_COMPLETE_TAIL',private_internal_total_from=12,private_reserve_lower=str(lower),proved_private_budget='9/5',tail_internal_total=[2,49],norm_bound='10',gram_diagonal_upper='54',D_absolute_upper='540',t_from=16,tail_cells=64,tail_integral_upper=str(integral),small_internal_pairs_ell_at_least2=len(pairs),full_role_specific_private_response_controls=controls['status'],compact_root_payment='OPEN',original_global='OPEN')
    (Path(__file__).resolve().parent/'private-budget-tail-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
