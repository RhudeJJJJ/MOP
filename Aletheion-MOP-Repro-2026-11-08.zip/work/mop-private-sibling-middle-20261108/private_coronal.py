"""Exact Gaussian path-coronal determinant coefficients for the PRIVATE sibling role."""
from fractions import Fraction as F
import exact as e
from private_budget_tools import add,scale,za,zm
def polynomials(q,ell):
    D=[[F(1)],[F(0),F(1)]];E=[([F(0)],[F(0)]),([F(1)],[F(0)])];X=([F(1)],[F(0)])
    for m in range(2,max(q+1,ell)+1):
        dn=add(e.mul([0,1],D[-1]),D[-2]);en=za(za(zm(([0,1],[0]),E[-1]),E[-2]),za((D[-1],[0]),zm(([0],[-2]),X)));X=za((D[-1],[0]),zm(([0],[-1]),X));D.append(dn);E.append(en)
    m=q+1;A=za((e.mul([0,1],D[ell]),[F(0)]),E[ell]);Z=[za(zm(A,(D[j],[F(0)])),zm((D[ell],[F(0)]),E[j]))for j in(m,m-1)]
    C0,C1=Z[0][0],Z[1][0];M0,M1=scale(Z[0][1],-1),scale(Z[1][1],-1)
    cross=add(e.mul(M0,C1),e.mul(M1,C0),-1)
    return C0,C1,M0,M1,cross
