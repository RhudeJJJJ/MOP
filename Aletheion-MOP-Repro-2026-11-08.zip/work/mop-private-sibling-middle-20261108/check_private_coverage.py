"""Exhaustive finite arithmetic-domain audit and damaged real-reader rejection."""
from fractions import Fraction as F
from pathlib import Path
import json
import rational_grid
rational_grid.install()
import private_ad5 as direct,private_common_ad5 as common
import private_cover as c
P=Path(__file__).resolve().parent
def rejected(fn):
    try:fn()
    except(AssertionError,ArithmeticError):return 1
    raise AssertionError('damaged PRIVATE cover accepted')
def main():
    states=0
    for q in range(1,48):
        for Q in range(q,48,4):
            for ell in range(2,49):
                for L in range(ell,49,4):
                    actual={x+y for x in range(q,Q+1,4)for y in range(ell,L+1,4)if 4<=x+y<=49};band=c.total_range(q,Q,ell,L)
                    assert actual==(set()if band is None else set(range(band[0],band[1]+1,4)));states+=1
    roots=c.roots();assert len(roots)==64
    for p in range(1,5):
        covered=[]
        for anchor,q,Q,ell,L in roots:
            if anchor==p:covered.extend((x,y)for x in range(q,Q+1,4)for y in range(ell,L+1,4)if 4<=x+y<=49)
        desired={(q,ell)for q in range(1,48)for ell in range(2,49)if 4<=q+ell<=49}
        assert len(covered)==len(set(covered))==len(desired)==1127 and set(covered)==desired
    a,b,target=F(1),F(1001,1000),F(1);oldD,oldC=direct.bound,common.bound
    def parse(code,p=1,q=1,Q=45,ell=2,L=46):return c.parse_tree(code,a,b,target,direct,common,p,q,Q,ell,L)
    try:
        direct.bound=common.bound=lambda *args:dict(upper=F(1,10),method='GRAMMAR_ONLY_STUB')
        part=dict(a=str(a),b=str(b),trees=['0']*64);assert c.cell(part,a,b,target,direct,common)==((b-a)/10,64,0,4)
        assert parse('100')[1]==2
        assert parse('200')[1]==2 and parse('300')[1]==2
        assert parse('5',q=47,Q=47,ell=6,L=6)[2]==1
        tests=[lambda:parse(''),lambda:parse('00'),lambda:parse('6'),lambda:parse('1'),lambda:parse('11000'),lambda:parse('200',q=1,Q=1),lambda:parse('300',ell=2,L=2),lambda:parse('5'),lambda:parse('0',q=47,Q=47,ell=6,L=6),lambda:parse('0',q=1,Q=46),lambda:parse('0',ell=1,L=45),lambda:parse('0',q=4,Q=48),lambda:c.cell(dict(part,trees=['0']*63),a,b,target,direct,common),lambda:c.cell(dict(part,a='0'),a,b,target,direct,common),lambda:c.cell(dict(a=str(a),b=str(b),split=[part]),a,b,target,direct,common),lambda:c.cell(dict(a=str(a),b=str(b),split=[part,part]),a,b,target,direct,common)]
        damage=sum(rejected(f)for f in tests)
    finally:direct.bound=oldD;common.bound=oldC
    damage+=rejected(lambda:c.parse_tree('0',a,b,F(0),direct,common,1,1,1,3,3))
    out=dict(status='PASS_EXHAUSTIVE_PRIVATE_TRIANGULAR_DOMAIN_AND_DAMAGED_COVERAGE',finite_AP_box_states=states,ordered_internal_pairs=1127,ordered_residue_roots=64,outer_p='UNBOUNDED analytic residue tail',damaged_cases_rejected=damage,domain='q>=1,ell>=2,4<=q+ell<=49; p>=1',scope='Complete finite arithmetic/grammar check; every future analytic leaf and full frequency integral still need exact replay. Grammar stubs alone prove no phase inequality.',original_global='OPEN')
    (P/'private-coverage-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
