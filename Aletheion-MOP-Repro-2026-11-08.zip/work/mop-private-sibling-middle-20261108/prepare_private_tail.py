"""Own new working files only; no edits to the running external certificate."""
from pathlib import Path
import shutil,hashlib
P=Path(__file__).resolve().parent;OLD=P.parent/'mop-finite-middle-20261108'
def main():
    for name in('exact.py','disk_interval.py','net_interval.py','rational_grid.py'):
        target=P/name
        if target.exists():assert target.read_bytes()==(OLD/name).read_bytes()
        else:shutil.copyfile(OLD/name,target)
    text=(OLD/'uniform_middle_tail.py').read_text()
    start=text.index('from pathlib import Path')
    text='"""PRIVATE-c sibling role, q+ell<=49: actual Gram<=54, norm<10."""\n'+text[start:]
    lo=text.index('    # Here z=1/t');hi=text.index('    x=(a*a,b*b)',lo)
    text=text[:lo]+'    # z=1/t; written actual-coordinate Gram/norm proof is obligatory.\n'+text[hi:]
    for before,after in(('F(51)','F(54)'),('F(48)','F(54)'),('F(-50)','F(-54)'),('F(50)','F(54)'),('F(-459)','F(-540)'),('F(459)','F(540)'),('F(-450)','F(-540)'),('F(450)','F(540)'),('F(-432)','F(-540)'),('F(432)','F(540)')):
        text=text.replace(before,after)
    target=P/'uniform_private_tail.py'
    if target.exists():assert target.read_text()==text
    else:target.write_text(text)
    print('PREPARED_PRIVATE_ROLE_TAIL_ONLY; full actual-response controls and compact root payment OPEN')
if __name__=='__main__':main()
