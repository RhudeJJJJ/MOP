"""Fixed PRIVATE q1 ell2, ALLp: Gram8,8, norm<=4; complete tail."""
from pathlib import Path
from fractions import Fraction as F
import json
P=Path(__file__).resolve().parent
import disk_interval as h
def matadd(A,B):return[[h.add(x,y)for x,y in zip(a,b)]for a,b in zip(A,B)]
def scale(A,k):return[[h.mul(v,k)for v in row]for row in A]
def determinant(A):return h.sub(h.mul(A[0][0],A[1][1]),h.square(A[0][1]))
def traceki(A):return h.times(h.sub(h.add(A[0][0],A[1][1]),A[0][1]),F(2,3))
def tail(a,b):
    # z=1/t; written actual-coordinate Gram/norm proof is obligatory.
    x=(a*a,b*b);one=h.con(1);I=[[one,h.con(0)],[h.con(0),one]];Q=[[h.con(3),one],[one,h.con(2)]]
    C=[[(F(0),F(8)),(F(-8),F(8))],[(F(-8),F(8)),(F(0),F(8))]];D=[[(F(-32),F(32)),(F(-32),F(32))],[(F(-32),F(32)),(F(-32),F(32))]]
    aa=h.add(one,h.times(x,4));aa2=h.square(aa);factor=h.sub(one,h.times(x,4));inv=h.div(one,aa);inv2=h.div(one,aa2)
    A=matadd(matadd(scale(Q,inv),scale(I,h.times(h.mul(x,inv2),8))),scale(matadd(scale(C,factor),scale(D,h.times(x,-4))),h.neg(h.mul(x,inv2))))
    M=matadd(matadd(scale(Q,h.times(inv,2)),scale(I,h.times(h.mul(factor,inv2),-2))),scale(matadd(scale(D,factor),scale(C,h.con(4))),h.neg(h.mul(x,inv2))))
    q,m=traceki(A),traceki(M);u,v=h.times(determinant(A),F(1,3)),h.times(determinant(M),F(1,3));assert A[0][0][0]>0 and u[0]>0 and q[0]>0,'uniform positive normalized real response'
    w=h.times(h.sub(h.add(h.mul(A[0][0],M[1][1]),h.mul(A[1][1],M[0][0])),h.times(h.mul(A[0][1],M[0][1]),2)),F(1,3))
    disc=h.positive(h.sub(h.square(w),h.times(h.mul(u,v),4)));zz=h.sqrt(h.add(h.square(h.sub(u,h.mul(x,v))),h.mul(x,h.square(w))))
    hh=h.div(disc,h.add(h.add(zz,u),h.mul(x,v)));fac=h.add(one,h.times(x,4));num=h.add(h.square(h.sub(h.times(q,2),m)),h.times(h.mul(fac,hh),2));den=h.times(h.add(h.add(h.sqrt(h.mul(fac,h.positive(h.add(h.square(q),h.mul(x,h.add(h.square(m),h.times(hh,2))))))),q),h.times(h.mul(x,m),2)),2)
    ans=h.positive(h.div(num,den));return ans
