# PRIVATE q1,ell2: the full graft is paid for EVERY outer length p

8 November2026. LOCAL EXACT ACCEPTANCE PASSED. ORIGINAL EVERY finite
simple UNIT maximal outerplanar G,n>=8 has F(G)=splus(G)>=2n remains
GLOBAL OPEN. This proves a full actual increment on an infinite family;
it is not a complete original counter-domain decomposition.

THEOREM. For EVERY old UNIT MOP H of order h>=3, EVERY ordered boundary
ab and EVERY integer p>=1, keep ab ONCE and add parent abc, an external
E_(p,1) child on ac with child apices a,c, and a two-face sibling fan on
cb whose apex is PRIVATE c. With N=p+5 private vertices and2N added unit
edges, the SAME complete graft satisfies

                         DeltaF>2N+1/4.                    (1)

Other old degrees, norm, order upper bound and spectrum are unrestricted.
The new private sibling apex is not identified with external old b.
Auxiliary K2 is not needed for the stated theorem. No whole all-small-old
payment is inferred from an increment on old h3..7.

1. Literal geometry and private reserve. geometry.py with q1,ell2 has
private order left_p,d,r1,c,s1,s2. Private B consists of triangles d,r1,c
and c,s1,s2 sharing c, with pendant P_p at d. Its edges=p+6=N+1,
contact mass=p+4=N-1. Ta contacts left_p,d,c; Tb contacts ONLY c,s2.
Thus all new edges and contacts are accounted once, totaling2N.

The proven all-p private floor for this particular pair is>7/5 above
edges. For completeness its determinant is Dp[(C0+rC1)-i(M0+rM1)],
r=D_(p-1)/Dp<=1/t, with

 C0=t^5+6t^3+5t, C1=t^4+4t^2+1,
 M0=4t^2+4, M1=2t,
 M0C1-M1C0=2t^6+8t^4+10t^2+4>0.

So this pair DOES admit the ordered p1 phase comparison for ALLp. The
separately refuted PRIVATE q3 ell2 comparison is not used. Exact full
multiplicity-aware Sturm isolation of the actual p1 private matrix, with
characteristic x^6-7x^4-4x^3+9x^2+6x-1, gives
Dbase>=773523549/268435456>14/5. All roots/zero modes are retained.
The all-p determinant phase comparison and Coulson identity therefore give

                    F(B)+Tr(TTt)>2N+7/5.                   (2)

2. Same actual old root and the distinct PRIVATE response. The accepted
all-MOP201 sector and sharp algebraic root-ball phase theorem imply

 DeltaF>=F(B)+Tr(TTt)-(2/pi)integral_0^infinity t b(Fcap,t)dt.

Subtract ONLY the positive outer-left lossless ray(p-1)/w, w=t+2i.
It preserves Wplus and increases the phase upper b by the accepted
LOSSLESS phase lemma; no graph energy is assigned to the normalized F.
Internal sibling bulk is retained. The exact two-head PRIVATE formula is
private-model-proof.md(3), with q1,ell2,gamma3. Its right direct term is
r2=t/(t^2+1), not the external-role coronal. The full actual root H is
fixed across the entire graft, not chosen independently for different modes.

Both direct and common-denominator representations, all five partials
and physical tangents, and all literal contacts are validated against full
private inverses. Generic net-phase determinant/quadrant prerequisites are
checked on EACH entire interval box. No PSD-clipped value is differentiated.
Unresolved boxes receive safe raw bounds or2pi*t; no physical graph is
discarded merely because an artificial extension is inconvenient.

3. Entire unbounded p and complete frequencies. D0=1,D1=t,
Dj=tD_(j-1)+D_(j-2), endpoint rj=D_(j-1)/Dj and
ej=(-i)^(j-1)/Dj have the residue envelope s=u/D_anchor,0<=u<=1,
ej=(-i)^(anchor-1)s and
rj=2(1+sign*s^2)/(t+sqrt(t^2+4+4sign*s^2)), sign=(-1)^(anchor+1).
Every length anchor+4k is represented; a tail splits into singleton anchor
and the infinite tail anchor+4. ALL FOUR ordered residue roots1..4 are
checked. Largest explicit anchor13 is NOT a length cutoff.

The float program only proposes trees. special_reader.py imports no float
selector and recomputes EVERY outward rational leaf inequality. It checks
all four roots, each singleton/tail split, full code consumption, contiguous
frequency intervals, both children of every midpoint split, exact complete
certificate/source bindings and unchanged reader/input hashes. Per frequency
take the MAXIMUM over p leaves, then multiply by width; no p averaging.
Ten damaged coverage artifacts are rejected by the real reader grammar.

The actual terminal exact pass covers214 frequency leaves,1231 length
leaves, compact t in[1/4,8], and gives integral upper

 Icompact=6596148805012700793077406479777/
          5070602400912917605986812821504.

At low0<t<1/4, the complete b<2pi bound charges at most1/8 in ENERGY.
At high t>=8, the literal PRIVATE matrix has maximum row degree4 for
EVERYp. Thus ||B||<=4. V=(B-2I)Tt has TV=-2I, Gram[[8,4],[4,8]],
and normalized leading Q=[[3,1],[1,2]]. The exact sparse resolvent gives
Cdiag[0,8],[0,8],|C01|<=8 and all absolute D0 entries<=32. Eight FULL
private tail cases calibrate these signs for p1,2,5,9 at t8,16; the
written coordinate/max-degree proof supplies the ALLp quantifier.

ALL64 exact cells z=1/t in[0,1/8] certify positive-real response,
every divisor and the complete infinite tail upper

 Itail=5118831585001759517509494432561/
       20282409603651670423947251286016.

No finite frequency cutoff is silently omitted. Arithmetic uses unbounded
integer outward GRID96, exact division/square roots and rational atan/pi
remainders. The full characteristic and negative-mode content are not
replaced by a sampled positive eigensystem.

4. Actual quarter surplus, stronger than the reader's requested gate.
Combining(2) with these COMPLETE phase bounds and pi>157/50 gives

 DeltaF-2N>
 7/5-1/8-2(Icompact+Itail)/(157/50)
 =1137110827382146072664661238764191/
  3980422884716640320699648064880640>1/4.

The exact reader's tighter pi enclosure gives approximately0.28617742944;
its full fraction is retained in special-reader-result.json. Its programmed
acceptance gate was1/10; the actual bounds justify the stronger(1), without
changing the ORIGINAL global target or selecting a different graph family.

5. Genuine original consequence and remaining scope. Where deleting this
closed cap from a minimal original counter leaves old h>=8, minimality pays
the SAME old H and(1) excludes the occurrence. Other prior cuts may overlap;
no independent additive motif credit or first payment is asserted. Old h3..7
is an increment domain only; its whole reserve has not been paid here.

Within the PRIVATE sibling route the small ordered case q1 ell2 is now
closed for ALLp. Ell1 coincides literally with the external role and uses
its actually accepted/pending ranges. Internal total>=50 has the accepted
separate analytic full-payment theorem. The compact bulk ell>=2,total4..49
is still OPEN: its first exact frequency preflight is not its completion.
The external q3..45 full certificate is still running, unchanged.

BareFork6, universal UB or adequate whole compensation, original all-small-old
coverage and global F>=2n remain OPEN. Source identity, local exact acceptance,
native export replay and actual session-entry delivery remain distinct.
No external formal audit, worldwide priority or LOTSE causal effect is claimed.
Native intake is the separate remaining storage/readback step.
