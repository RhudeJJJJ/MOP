"""Separate exact actual-edge/contact reader; finite calibration is not coverage."""
from pathlib import Path
from fractions import Fraction as F
import copy,hashlib,json,sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'mop-two-root-contact-20261104'))
import read_contact_certificates as prior

TABLE={
 (0,0):[(8,8,8),(7,7,14),(14,7,7),(13,5,13)],
 (0,1):[(6,5,10),(6,4,14),(12,3,9),(12,2,13)],
 (0,2):[(6,4,10),(6,4,14),(12,2,9),(12,2,13)],
 (1,0):[(10,5,6),(9,3,12),(14,4,6),(13,2,12)],
 (1,1):[(8,1,8),(8,0,12),(12,0,8),(12,-1,12)],
 (1,2):[(8,0,8),(8,0,12),(12,-1,8),(12,-1,12)],
 (2,0):[(10,4,6),(9,2,12),(14,4,6),(13,2,12)],
 (2,1):[(8,0,8),(8,-1,12),(12,0,8),(12,-1,12)],
 (2,2):[(8,-1,8),(8,-1,12),(12,-1,8),(12,-1,12)]}
def edge(u,v):return tuple(sorted((u,v)))
def zero(h):return [[0]*h for _ in range(h)]
def addouter(out,v,scale=1):
    for i,x in enumerate(v):
        if not x:continue
        for j,y in enumerate(v):
            if y:out[i][j]+=scale*x*y
def plus(a,b,k=1):return [[x+k*y for x,y in zip(ar,br)] for ar,br in zip(a,b)]
def scale(a,k):return [[k*x for x in row] for row in a]
def eye(h,k=1):return [[k*int(i==j) for j in range(h)] for i in range(h)]
def contacts(tags,es):
    h=len(tags[0]);q=zero(h);m=zero(h);walk=[[0]*h for _ in tags]
    for t in tags:addouter(q,t)
    for u,v in es:
        for i in range(h):
            walk[u][i]+=tags[v][i];walk[v][i]+=tags[u][i]
            for j in range(h):m[i][j]+=tags[u][i]*tags[v][j]+tags[v][i]*tags[u][j]
    n=zero(h)
    for t in walk:addouter(n,t)
    return q,m,n

def local(A,B,ja,jb):
    m=A+B+1;tags=[[int(i<=A),int(i>=A)] for i in range(m)]
    es={edge(i,i+1) for i in range(m-1)}
    for i in range(m-1):
        y=len(tags);tags.append([0,0]);es|={edge(i,y),edge(i+1,y)}
    for yes,v,tag in ((ja,0,[1,0]),(jb,m-1,[0,1])):
        if yes:y=len(tags);tags.append(tag);es.add(edge(v,y))
    q,mom,n=contacts(tags,es);d=plus(scale(q,8),n,-1)
    triple=TABLE[(min(A,2),min(B,2))][2*ja+jb];a,b,c=triple
    assert d==[[a,b],[b,c]] and prior.psd(d)
    k=int(A==0)*(1-ja)+int(B==0)*(1-jb)
    assert mom==plus(scale(q,2),[[2,k],[k,2]],-1)
    return dict(A=A,B=B,HU=[ja,jb],D=d,det=a*c-b*b)

def certify_domain(gmin):
    assert gmin>=64
    r=F(787,100)
    assert r*r<62 and F(3,2)**2>2
    reserve=2*r-14-F(19,2)/r-32/r**2
    assert reserve>F(1,100)
    return reserve

def read_graph(g,damaged_N=False):
    h,n=g['h'],g['n'];es={tuple(e) for e in g['edges']}
    assert all(u<v and 0<=u<v<n for u,v in es)
    assert len(es)==len(g['edges'])==2*n-3
    prior.outer_graph(n,es,g['boundary'])
    a=[set() for _ in range(n)]
    for u,v in es:a[u].add(v);a[v].add(u)
    cy=g['core_cycle'];assert len(cy)==h and set(cy)==set(range(h))
    ce={e for e in es if e[1]<h};assert ce=={tuple(e) for e in g['core_edges']}
    prior.outer_graph(h,ce,cy)
    assert len(ce)==2*h-3
    outside=list(range(h,n));oid={v:i for i,v in enumerate(outside)}
    tags=[[int(u in a[v]) for u in range(h)] for v in outside]
    les={edge(oid[u],oid[v]) for u,v in es if u>=h}
    q,mom,nn=contacts(tags,les)
    gvals=[sum(u in a[v] for v in outside) for u in range(h)]
    z=zero(h)
    for i,u in enumerate(cy):v=cy[(i+1)%h];z[u][v]=z[v][u]=1
    assert q==plus([[gvals[i]*int(i==j) for j in range(h)] for i in range(h)],z)
    ears={edge(*e['edge']):e['v'] for e in g['ears']}
    assert len(ears)==len(g['ears'])==n-g['base_n']
    expected=set(ce);baseverts=set(range(h));baseouter=[];bigD=zero(h);w=zero(h);tau=0
    for k,gap in enumerate(g['gaps']):
        u,v=gap['a'],gap['b'];A,B=gap['A'],gap['B'];path=gap['path']
        assert (u,v)==(cy[k],cy[(k+1)%h]) and len(path)==A+B+1 and A>=0 and B>=0
        assert not(baseverts&set(path));baseverts.update(path);baseouter.extend([u]+path)
        expected|={edge(x,y) for x,y in zip(path,path[1:])}
        expected|={edge(u,x) for x in path[:A+1]}|{edge(v,x) for x in path[A:]}
        for i,x in enumerate(path):assert a[x]&set(range(h))==({u} if i<A else {u,v} if i==A else {v})
        ja=int(edge(u,path[0]) in ears);jb=int(edge(path[-1],v) in ears)
        kap=int(A==0)*(1-ja)+int(B==0)*(1-jb);w[u][v]=w[v][u]=kap
        localdata=local(A,B,ja,jb);d=localdata['D']
        for ii,x in enumerate((u,v)):
            for jj,y in enumerate((u,v)):bigD[x][y]+=d[ii][jj]
        for x,y in zip(path,path[1:]):
            if edge(x,y) in ears:tau+=1
            else:addouter(bigD,[int(t in a[x])+int(t in a[y]) for t in range(h)])
    assert baseverts==set(range(g['base_n']))
    baseboundary={edge(x,baseouter[(i+1)%len(baseouter)]) for i,x in enumerate(baseouter)}
    assert set(ears)<=baseboundary
    for e,y in ears.items():
        x,z0=e;assert y>=g['base_n'] and a[y]=={x,z0} and e in es
        expected|={edge(x,y),edge(z0,y)}
    assert expected==es
    assert mom==plus(scale(q,2),plus(eye(h,4),w),-1)
    if damaged_N:nn[0][0]+=1
    assert plus(scale(q,8),nn,-1)==bigD
    ladj={v:{x for x in a[v] if x>=h} for v in outside}
    assert max(map(len,ladj.values()))<=4
    components=[];left=set(outside)
    while left:
        seen={next(iter(left))};todo=list(seen)
        for x in todo:
            for y in ladj[x]-seen:seen.add(y);todo.append(y)
        components.append(seen);left-=seen
    assert len(components)==h and len(les)-len(outside)+h==tau
    triangles=[(u,v,x) for u in outside for v in ladj[u] if u<v for x in ladj[u]&ladj[v] if v<x]
    assert len(triangles)==tau
    used=set()
    for tri in triangles:
        tes={edge(tri[i],tri[j]) for i in range(3) for j in range(i)}
        assert not(tes&used);used|=tes
    eligible=min(gvals)>=64
    if eligible:assert certify_domain(min(gvals))>F(1,100)
    return dict(label=g['label'],n=n,h=h,actual_external_degrees=gvals,core_max_degree=max(sum(u in e for e in ce) for u in range(h)),
        tau=tau,Q=q,M=mom,N=nn,positive_decomposition=bigD,kappa_matrix=w,
        original_theorem_eligible=eligible,whole_energy_reserve=str(F(h,100)+F(tau,6)) if eligible else None,
        evidence='Full unit-MOP/control contact identities and analytic theorem, not a numerical energy certificate')

def must_reject(action):
    try:action()
    except (AssertionError,ValueError,IndexError,KeyError):return True
    raise AssertionError('Damaged control accepted')

def main():
    fixture=HERE/'switch-controls.json';data=json.loads(fixture.read_text())
    basis=[local(A,B,ja,jb) for A in range(3) for B in range(3) for ja in range(2) for jb in range(2)]
    stable=[local(A,B,ja,jb) for A in range(9) for B in range(9) for ja in range(2) for jb in range(2)]
    checked=[read_graph(g) for g in data['graphs']]
    broken=copy.deepcopy(data['graphs'][0]);broken['edges'].pop()
    wrong=copy.deepcopy(data['graphs'][0]);wrong['gaps'][0]['A']+=1;wrong['gaps'][0]['B']-=1
    negatives=dict(missing_unit_edge=must_reject(lambda:read_graph(broken)),
        wrong_shared_switch=must_reject(lambda:read_graph(wrong)),
        wrong_N=must_reject(lambda:read_graph(data['graphs'][0],damaged_N=True)),
        threshold63=must_reject(lambda:certify_domain(63)),
        indefinite_local_matrix=must_reject(lambda:(_ for _ in ()).throw(AssertionError()) if not prior.psd([[1,2],[2,1]]) else None))
    assert sum(c['original_theorem_eligible'] for c in checked)==9
    assert not checked[-1]['original_theorem_eligible']
    out=dict(status='PASS_EXACT_JOINT_ARBITRARY_SWITCH_CONTROLS',local_PSD_cases=basis,
        all_36_PSD=True,stabilization_calibrations=len(stable),whole_graphs=checked,
        eligible_graphs=9,ineligible_geometry_control=1,damaged_controls_rejected=negatives,
        rational_uniform_reserve=str(certify_domain(64)),reserve_over_hundredth=str(certify_domain(64)-F(1,100)),
        fixture_sha256=hashlib.sha256(fixture.read_bytes()).hexdigest(),
        theorem='EVERY stated arbitrary-switch/ear-mask whole unit MOP with every actual external hub degree>=64 has F>2n+h/100+tau/6',
        original_global_status='OPEN',all_MOP_representation_or_degree_cover=False,
        external_formal_audit=False)
    (HERE/'switch-reader-check.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in out.items() if k not in ('local_PSD_cases','whole_graphs')}))

if __name__=='__main__':main()
