# Both normalized sectors: debt below 1.81 and the exact small-parent cover

5 November2026. Original ALL finite simple UNIT maximal outerplanar
G,n>=8,F=splus>=2n remains GLOBAL OPEN; goal ACTIVE. This improves the
universal external/external branch debt and its counter front. It does
not prove a nonnegative increment for every branch or global compensation.

1. Same physical state, with an additional exact inequality.
For the actual external/external cap p,q>=1,k=p+q+1 retain the preceding
two-dipole normalization: private B=P_k, prefix/suffix contactT,
G=TTt,K=2I+J=[[2,1],[1,2]],E=diag(p-1,q-1)>=0,
Fcap=(G+2iS)/(t+2i),Fstar=(K+2iS)/(t+2i),Fcap=Fstar+E/(t+2i).
Here S=Vt(tI+iC)^-1V with ONE fixed auxiliary Neumann-path C and
isometryV at ALL frequencies, spectrumC in(-2,2], VtV=I.
Fstar is signed and is NOT assigned a graph energy. Put
Q=Vt(t^2+C^2)^-1V>0,M=Vt C(t^2+C^2)^-1V, so S=tQ-iM.

The earlier proof gives Wplus(Fstar)=2ReFstar+tImFstar=2tQ>0.
The NEW other sign has the exact factorization

 Wminus(Fstar)
 =2t/(t^2+4)[2K+4M+(4-t^2)Q]
 =2t/(t^2+4)[2K-I+Vt(C+2I)^2(t^2+C^2)^-1V]>0.       (1)

The last compressed product is PSD because it is a real nonnegative
spectral function of the SAME Hermitian C. Also2K-I has eigenvalues1,5.
This proves BOTH normalized sectors for every p,q,t, not an extrapolation
from finite states or the old normalized-parent responses already refuted.

2. Retain the root-edge sector in the low-frequency phase bound.
Let F0 be the SAME old actual UNIT MOP boundary correction. Source201
gives both Wplus/Wminus(F0)>=0. Put Z0=tI+iJ+F0, Zstar=Z0+Fstar.
For either sign,

 2ReZ0 +/-tImZ0=t(2I+/-J)+Wsign(F0)>0,
 2ReZstar +/-tImZstar>0 by(1).                        (2)

Consequently each eigenvalue of either accretive two-by-two matrix has
argument strictly between -theta and theta, theta=atan(2/t). Their
accretive trace-log arguments lie between -2theta and2theta, so the
continuously anchored SAME-parent phase difference obeys

                    delta_star(t)<4atan(2/t).          (3)

This improves the former2pi low bound. Eigenvalues lie in that sector
because their eigenvectors evaluate the Hermitian form inequalities(2).
It is not a rewrapped determinant argument. The prior nonnegative-
shaving homotopy still gives delta_full<=delta_star and preserves its
nonnegative length reserve R; all its actual-parent assumptions remain.

On the ENTIRE tail the retained root-ball support bound is unchanged:
t delta_star<=V<=10/(9t^2). Thus with epsilon=3/5,

 Jstar=integral_0^infinity t delta_star(t)dt
 <pi*epsilon^2+4epsilon-(2epsilon^2+8)atan(epsilon/2)
                                      +10/(9epsilon). (4)

The low term is the EXACT integral of4t atan(2/t) from0toepsilon; the
tail is the entire epsilon-to-infinity interval. No mode, cutoff or
positive phase contribution is omitted. No quadrature accepts(4).

3. Exact constants and the stronger universal increment.
Let A8=sum_(j=0..7)(-1)^j(3/10)^(2j+1)/(2j+1), a strict alternating
series lower bound for atan(3/10). Exactly
A8=1458741256009833531/5005000000000000000.
Use the retained exact Machin bounds157/50<pi<22/7. The bracket in(4)
other than pi epsilon^2 is positive, as is seen using atan(x)<x.
The energy identity DeltaF=2k-(2/pi)I_full and I_full<=Jstar give

 DeltaF>2k-c,                                         (5)
 c=4798557033563059918267/2652024375000000000000
                                      <181/100=1.81.

This is universal for EVERY old finite simple UNIT MOP of order>=3,
EVERY ordered boundaryab and EVERYp,q>=1, with no old degree/order/norm
upper bound. A whole old reserve>=181/100 therefore pays the WHOLE new
graph. Old false barefan/C0/genericgluing and pointwise-sign claims are
not restored. Fork6/nonnegative fullUB remain OPEN.

The explicit integral upper in(4) is
Jstar<4800294483563059918267/1689187500000000000000.
The earlier length-reserve proof works already at sqrt(alpha)>=49,
alpha=max(p-1,q-1), ifalpha>=D0=max OLD root degrees. Its norm and
99/100 bounds hold at49, and reserve>=4851/1681. Hence

 alpha>=max(D0,2401) =>DeltaF>2k+1/50,                (6)

since(7/11)(4851/1681-Jupper)
=124953535630496277393173/4462109437500000000000000>1/50.
The earlier2601 result stays true, with a stronger sufficient threshold.

4. Exact finite old-parent cover, all8<=h<=13.
For every actual old UNIT MOP H of these orders and EVERY boundary edge
ab, at least ONE of the following holds:
  (a)Some at most two additional vertices u,v make {a,b,u,v} dominate H;
  (b)The WHOLE old graph satisfies F(H)>2h+93/50>2h+181/100.

The new finite proof objects are parent-cover.json. Actual polygons are
identified for ENERGY by a cyclic rotation/reflection of their complete
edge sets. Each representative retains EVERY boundary edge; domination
of the unordered root pair covers both orientations. No response functions,
root contacts or arbitrary apex assignments are identified by these orbits.

The complete domain/certificates are:
 h | cyclic triangulations | dihedral classes | all-root domination | energy
 8 |132                  |12                |12                   |0
 9 |429                  |27                |27                   |0
10 |1430                 |82                |82                   |0
11 |4862                 |228               |182                  |46
12 |16796                |733               |290                  |443
13 |58786                |2282              |261                  |2021

All2510 energy certificates are full integer PSD factors X=WWt/d^2 on
ALL vertices, checked with the ENTIRE Frobenius norm. The exact score is

 [4d^2 sum_edges dot(W_a,W_b)-sum_ij((WtW)_ij)^2]/d^4>2h+93/50.

Floating eigensystems only propose W. The minimum certified reserve is
93203291687738642676339/50000000000000000000000>93/50. A domination
witness is checked by actual closed neighborhoods, not a stored gamma label.

Coverage is independently reconstructed: the producer splits at the root
triangle; the reader inserts an ear in EACH possible boundary position of
every smaller triangulation. Every triangulation has an ear, and deleting
it is a smaller triangulation, so the reader's induction is complete.
It expands the actual dihedral orbits and compares the full sets from both
routes, including the stated Catalan populations. A count alone is not the
coverage proof. Missing representatives, missing root witnesses and broken
Gram factors are rejected by their real coverage/arithmetic contracts.

5. Whole new graphs and the original counter boundary.
For old8<=h<=13, add ANY actual external/externalbranchp,q>=1. In case(a),
the SAME {a,b,u,v} dominates the WHOLE new G: every new private vertex
sees a or b. The EXISTING gamma<=4 whole-original theorem244 pays G
for n>=8 at its EXACT named inherited boundary: B71,176 splitfan,190
charges/tail/wholehub and244finite72..159bridge. These inputs are NOT
freshly reaudited here and not made unconditional. In case(b), the new
unconditional increment(5) pays G directly with strict reserve. Thus every
such WHOLE G is paid using those stated inputs. No claim about its ENTIRE
increment in case(a) follows merely from domination.

Combine with the prior elementary smallold h2..7 whole payment for n>=72,
and the established all-terminal/mixed reductions. Under the SAME named
B71/gamma4 boundary, any minimal original counter n>=72 has every deepest
branch represented external/external with deleted old parentH satisfying

 h>=14, 0<=eta=F(H)-2h<c<181/100,
 max(p,q)<=max(D0,2401).                              (7)

Retain all own-arm retirement and coupled-payment cuts unchanged. Moreover
NOat-most-two extra vertices may supplement a,b to dominate H, since that
would pay the whole G by244. In particular the unseen old vertices number
z=h-d_a-d_b+1>=3, so d_a+d_b<=h-2. This last elementary consequence is
not claimed newly discovered or a replacement of the stronger actual
root-domination condition. It explains why large old root degrees require
a genuinely larger remaining parent here.

The older N1/N207 near-parent norm counterexamples remain TRUE on their
original domains; their small parents are now whole-paid for ANY branch
by this cover. This does not reopen the refuted M1/M2 statements or prove
those bounds on the newly smaller original-counter domain. The old
near-free-accretivity question likewise is not decided.

6. Proof scope and next work. The all-order improvement is the new
factorization(1), exact root-sector phase bound(3), complete integral(4),
and rational constants(5)--(6). Finite path controls calibrate the algebra;
the old-parent cover is a separate complete finite certificate, and its
whole-graph use has the explicit gamma4 dependency above. A local reader,
backup, native import and full readback are not external formal review,
worldwide priority, a full corpus/Drive refresh or automatic entry repair.

Original ALL-MOP2n/Fork6/fullUB/globalnonnegativecompensation remain OPEN.
The next actual work is the h>=14, near-energy, root-domination-resistant
parent region in(7), retaining actual noncrossing pockets and all previous
degree/length/joint bounds. No all-order absence of such parents is proved.
