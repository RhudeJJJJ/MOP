# Fan19 improves a method; it does not reopen or newly exclude mixed branches

8 November2026. ORIGINAL GLOBAL OPEN, goal ACTIVE.

The new exact theorem is preserved: for EVERY old UNIT MOP and actual
old apex degree<=3, every boundary fan of length r>=19 gains>2r+1/20.
Its nine complete integer Gram witnesses, analytic infinite tail and
retirement proof passed, and native export replay also passed.

Its comparison with the historical seven-length mixed-front statement
was incomplete as a statement of current work. The 5 November2026
all-mixed-payment-proof.md already proves, for EVERY outward p>=2,
EVERY inward q15..20 and every old UNIT MOP h>=3, full mixed-branch
increment>2k+3/4. uniform-q2-proof.md already pays EVERY p>=2 at q2
by>2k+1/20. The complete-dual-ledger-proof.md assembles those, the
other mixed ranges, first turns and whole-small-old stops. Its actual
remaining debt is the EXTERNAL/EXTERNAL deepest branch. These complete
original proof texts were now reread, including the exact original
finite-base/domination boundaries. They are not promoted to freshly
reaudited unconditional global results.

Thus the new set{2,15,16,17,18} is a true weaker necessary description
relative to the older seven-length statement, but it is already excluded
by later existing results. It gives NO new current original-counter cut.
The new fan threshold19 is useful as a stronger separately applicable
old-degree-controlled increment and simpler alternative for q19,20.
It does NOT narrow the current global frontier beyond its existing
external/external description. The actual next global work stays on
bare external-branch integral/serial compensation and a justified use
of the ongoing grouped-family payments, retaining whole-small-old limits.

The correction must accompany BOTH new fan19 mixed-front and scope nodes.
Only the implied current-front novelty is corrected; the all-r fan
theorem, the mathematical truth of the weaker five-length statement,
all prior mixed payments and all original hypotheses remain unchanged.
Two exact curated revises bindings name the affected phrases, their
declared domains and this successor effect. Import, binding, native
readback and actual session-entry delivery are separate checks.

Origin: direct comparison of the newly imported fan19-front against the
existing original all-mixed and complete-dual-ledger sources, not a new
energy counterexample. Counterfinding: universal prior payments already
exclude the purported remaining mixed cases. Next application: before
assigning a new front improvement, compare against the assembled current
theorem, not only its older reduction lemma. Source hashes certify text
identity; they do not establish mathematical truth or independent review.
