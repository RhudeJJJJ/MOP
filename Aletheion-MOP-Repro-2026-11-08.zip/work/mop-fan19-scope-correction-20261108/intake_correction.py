from pathlib import Path
import json,hashlib,sqlite3,shutil,sys
P=Path(__file__).resolve().parent;DB=Path('C:/Users/jonas/Aletheion/aletheion/aletheion.db');PRE='math:mop:fan19-current-scope:'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dig(s):return hashlib.sha256(s.encode()).hexdigest()
def save(n,v):(P/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def rd(n):return json.loads((P/n).read_bytes())
def prepare():
    folders=['mop-degree3-fan19-20261108','mop-mixed-q15-20-20261105','mop-mixed-q2-uniform-20261105','mop-dual-debt-20261105'];known={n['node_id']:n for folder in folders for n in json.loads((P.parent/folder/'packet.json').read_bytes())['nodes']}
    parents=['math:mop:degree3-fan19:mixed-front:20261108','math:mop:degree3-fan19:scope:20261108','math:mop:degree3-fan19:payment:20261108','math:mop:degree3-fan19:proofsource:20261108','math:mop:all-mixed-branches:payment:20261105','math:mop:all-mixed-branches:regime:20261105','math:mop:all-mixed-branches:scope:20261105','math:mop:mixed-q2-all-outward:payment:20261105','math:mop:complete-dual-ledger:grammar:20261105','math:mop:complete-dual-ledger:compensation:20261105']
    c=sqlite3.connect('file:'+str(DB)+'?mode=ro',uri=True);c.execute('BEGIN');snap=[]
    assert not c.execute('select node_id from weave_nodes where node_id like ?',(PRE+'%',)).fetchall()
    for i in parents:
        body=c.execute('select body from weave_nodes where node_id=?',(i,)).fetchone()[0];assert body==known[i]['body'];snap.append(dict(node_id=i,sha256=dig(body),body=body if known[i]['kind']!='source'else'Canonical full source remains required; complete original proof copied here.'))
    c.rollback();c.close();save('parent-snapshot.json',snap);save('parent-bindings.json',{x['node_id']:x['sha256']for x in snap})
    (P/'inherited').mkdir(exist_ok=True)
    for folder,name in zip(folders,['fan19-proof.md','all-mixed-payment-proof.md','uniform-q2-proof.md','complete-dual-ledger-proof.md']):
        src=P.parent/folder/name;dst=P/'inherited'/name
        if dst.exists():assert dst.read_bytes()==src.read_bytes()
        else:shutil.copyfile(src,dst)
    shutil.copyfile(P.parent/'mop-degree3-fan19-20261108/run_guarded_native.py',P/'run_guarded_native.py')
    ids={k:PRE+k+':20261108'for k in ['qualification','proofsource']};nodes=[];edges=[]
    effect='The fan19 theorem improves the separately applicable degree-controlled retirement METHOD, but gives NO new current original-counter cut: all mixed branches were already excluded by existing all-mixed payments and complete grammar. The current global frontier remains external/external bare-branch integral/serial compensation; the weaker five-length statement stays mathematically true.'
    body=effect+' ORIGINAL every finite simple UNIT MOP n>=8 has F>=2n remains GLOBAL OPEN, goal ACTIVE. Exact fan19 theorem and its full witnesses remain unchanged. Existing EVERYp>=2 q15..20 mixed increment>2k+3/4 and q2>2k+1/20 apply to old h>=3; the assembled n>=72 whole-small-old/finite-base boundaries are retained, not freshly removed. Correction affects ONLY implied current-front novelty in the new fan19 mixed-front/scope wording, not the old true seven-length theorem, original target or any energy bound. Read the complete correction and four original proof texts.'
    provenance=json.dumps([dict(path=str(P/'correction.md'),sha256=sha(P/'correction.md'))])
    nodes.append(dict(node_id=ids['qualification'],kind='claim',title='Fan19 current-scope correction: historical mixed front was already closed',body=body,epistemic='PROVEN source-status correction; fan19 mathematical theorem preserved; original global OPEN',provenance=provenance))
    def edge(a,b,rel,why):
        eid='edge:'+dig(a+'|'+rel+'|'+b);edges.append(dict(edge_id=eid,from_id=a,to_id=b,relation=rel,rationale=why,status='curated'));return eid
    revisions=[]
    specs=[('front',parents[0],'This is a strictly sharper NECESSARY representation, not existence or a complete graph cover; external/external remains open.','In the inherited minimal original UNIT-MOP counter n>=72'),('scope',parents[1],'Prior true seven-length necessary set remains valid but weaker; no false historical theorem alleged.','ORIGINAL EVERY finite simple UNIT MOP n>=8 has F=splus>=2n remains GLOBAL OPEN; goal ACTIVE.')]
    for key,old,quote,scope in specs:
        assert quote in known[old]['body']and scope in known[old]['body']
        eid=edge(ids['qualification'],old,'revises','Correct ONLY implied new current-front improvement; later existing all-mixed payments had already closed these cases. Preserve true fan theorem and necessary weaker set.')
        binding=dict(version=1,reviewer='Codex exact original-source status reconciliation 20261108',affected_prior_claim=dict(node_id=old,field='body',quote=quote),prior_scope=dict(node_id=old,field='body',quote=scope),successor_effect=dict(node_id=ids['qualification'],field='body',quote=effect))
        name='revision-'+key+'.json';save(name,binding);revisions.append(dict(key=key,edge_id=eid,binding_file=name,prior=old,successor=ids['qualification']))
    save('revision-edges.json',revisions)
    edge(ids['qualification'],ids['proofsource'],'requires','Complete new qualification and original all-mixed/grammar proof sources, preserving hypotheses.')
    for i in parents[2:]:edge(ids['qualification'],i,'requires','Actual stored theorem/source and assembled global status checked; no smaller helper treated as current frontier.')
    names=['correction.md','intake_correction.py','run_guarded_native.py','parent-snapshot.json','parent-bindings.json','revision-edges.json','revision-front.json','revision-scope.json']+['inherited/'+name for name in ['fan19-proof.md','all-mixed-payment-proof.md','uniform-q2-proof.md','complete-dual-ledger-proof.md']]
    env=dict(format='full-source-envelope-v2-relative-files',files=[dict(path=str(P/n),relative=n,bytes=(P/n).stat().st_size,sha256=sha(P/n),content=(P/n).read_bytes().decode())for n in names]);payload=json.dumps(env,ensure_ascii=True,separators=(',',':'));pieces=[payload[j:j+72000]for j in range(0,len(payload),72000)];parts=[PRE+'sourcepart'+str(j)+':20261108'for j in range(len(pieces))]
    header=dict(format='complete-source-envelope-chunks-v1',payload_utf8_bytes=len(payload.encode()),payload_sha256=dig(payload),parts=[dict(node_id=i,part=j+1,bytes=len(s.encode()),sha256=dig(s))for j,(i,s)in enumerate(zip(parts,pieces))])
    nodes.append(dict(node_id=ids['proofsource'],kind='source',title='Fan19 correction complete source header',body=json.dumps(header,separators=(',',':')),epistemic='ALL numbered raw bodies required',provenance=provenance))
    for j,(i,s)in enumerate(zip(parts,pieces),1):
        nodes.append(dict(node_id=i,kind='source',title='Fan19 correction complete source part'+str(j),body=s,epistemic='FULL source fragment incomplete alone',provenance=provenance));edge(ids['proofsource'],i,'requires','Every raw source part required.')
    assert max(len(n['body'].encode())for n in nodes)<95000
    save('packet.json',dict(schema_version=1,nodes=nodes,edges=edges));save('source-hashes.json',{n:sha(P/n)for n in names})
    raw=sum((P/n).stat().st_size for n in names);backup=DB.stat().st_size+16*1024**2;free=shutil.disk_usage(P).free;assert free-3*backup-raw>8*1024**3
    save('write-plan.json',dict(raw_bytes=raw,backup_count=3,backup_upper_each=backup,free_before=free,explicit_members=names,no_expected_deduplication=True));print(json.dumps(dict(status='PREPARED_EXACT_SCOPE_CORRECTION_TWO_REVISES',nodes=len(nodes),edges=len(edges),parts=len(parts),raw_bytes=raw,backup_upper_each=backup,free_before=free)))
def audit():
    assert all(sha(P/n)==h for n,h in rd('source-hashes.json').items());packet=rd('packet.json');c=sqlite3.connect('file:'+str(DB)+'?mode=ro',uri=True);c.row_factory=sqlite3.Row;c.execute('BEGIN');actual=[];nodes={}
    for table,key,item in [('weave_nodes','node_id',n)for n in packet['nodes']]+[('weave_edges','edge_id',n)for n in packet['edges']]:
        row=dict(c.execute('select * from '+table+' where '+key+'=?',(item[key],)).fetchone());assert all(row[k]==v for k,v in item.items());actual.append(dict(table=table,row=row))
        if table=='weave_nodes':nodes[row['node_id']]=row
    for i,h in rd('parent-bindings.json').items():assert dig(c.execute('select body from weave_nodes where node_id=?',(i,)).fetchone()[0])==h
    bindings=[]
    for rev in rd('revision-edges.json'):
        rows=c.execute('select * from weave_revision_bindings where edge_id=?',(rev['edge_id'],)).fetchall();assert len(rows)==1;bindings.append(dict(rows[0]))
    c.rollback();c.close();save('actual-readback.json',actual);save('revision-readback.json',bindings)
    header=json.loads(nodes[PRE+'proofsource:20261108']['body']);pieces=[]
    for j,item in enumerate(header['parts'],1):
        body=nodes[item['node_id']]['body'];assert item['part']==j and len(body.encode())==item['bytes']and dig(body)==item['sha256'];pieces.append(body)
    payload=''.join(pieces);assert len(payload.encode())==header['payload_utf8_bytes']and dig(payload)==header['payload_sha256'];env=json.loads(payload)
    for f in env['files']:
        data=f['content'].encode();assert data==(P/f['relative']).read_bytes()and len(data)==f['bytes']and hashlib.sha256(data).hexdigest()==f['sha256'];dst=P/'native-export'/f['relative'];dst.parent.mkdir(parents=True,exist_ok=True)
        if dst.exists():assert dst.read_bytes()==data
        else:dst.write_bytes(data)
    labels=['scope-dryrun','scope-import']+['scope-'+r['key']+'-'+suffix for r in rd('revision-edges.json')for suffix in ['dryrun','bind']]
    for label in labels:assert rd(label+'.process.json')['exit_code']==0
    backups=[]
    for label in ['scope-import','scope-front-bind','scope-scope-bind']:
        path=Path(rd(label+'.stdout.json')['backup']);assert path.is_file()and path.stat().st_size<=rd('write-plan.json')['backup_upper_each'];backups.append(str(path))
    receipt=rd('scope-import.stdout.json');assert receipt['inserted']==dict(nodes=len(packet['nodes']),edges=len(packet['edges']),reviews=0)
    out=dict(status='PASS_NATIVE_FAN19_SCOPE_CORRECTION_TWO_EXACT_BOUND_REVISIONS',native_run_id=receipt['run_id'],all_sources_byte_identical=True,parents_unchanged=True,revision_bindings=len(bindings),backups=backups,free_after=shutil.disk_usage(P).free,fan19_theorem='PRESERVED',new_current_counter_cut=False,current_original_front='EXTERNAL/EXTERNAL bare branch or serial compensation',original_global='OPEN',entry_delivery='PENDING actual checks over BOTH affected earlier IDs')
    save('native-audit.json',out);print(json.dumps(out))
if __name__=='__main__':prepare()if len(sys.argv)==1 or sys.argv[1]=='prepare'else audit()
