# Every mixed inward-two branch pays, at every outward length

5 November 2026. Fixed original target: every finite simple UNIT maximal
outerplanar graph G, n>=8, has F(G)=splus(G)>=2n (equivalently D>=6).
The original is GLOBAL OPEN; goal ACTIVE. This is a universal incremental
lemma and a necessary-structure improvement, not a global selector.

1. Actual graph, count and theorem. Retain closing boundary edge ab.
Add triangle abc, with c private. On ac put a p-face fan with apex a,
ordinary arc a,L1,...,Lp,c. On cb put a two-face fan with apex c and
ordinary arc b,R1,R2,c. Thus private B_p has vertices
c,L1,...,Lp,R1,R2, triangle cR1R2 and pendant path c,Lp,...,L1.
Its two contact rows are a:{c,L1,...,Lp}, b:{c,R1}. All these private
vertices have no outside contacts. There are k=p+3 new vertices, 2k new
edges, m(B_p)=k and Tr(TT^t)=k. These identities retain both root roles.

THEOREM: for EVERY integer p>=2, EVERY old finite simple UNIT MOP of
order>=3, and EVERY ordered boundary edge ab, this actual graft has

                 F(new)-F(old)>2k+1/20.                    (1)

No old degree/order/spectral upper bound is imposed. Whole reflection
is allowed. This does not assert (1) for a bare external fan, C0 or
balanced Fork6, whose private/contact matrices are different.

2. A uniform private-energy floor. Let D0=1,D1=t and
D_j=t D_(j-1)+D_(j-2), for t>0. The endpoint response of the p-path is
f_p=D_(p-1)/D_p>0. Let lambda=(sqrt(t^2+4)-t)/2. Continued fractions give
f_(2j) increasing to lambda and f_(2j+1) decreasing to lambda. In
particular f_p<=f3 for ALL p>=2. This also follows by applying twice the
decreasing map x ->1/(t+x), noting f2<lambda<f3 and f_(j+2)-f_j has the
sign of lambda-f_j. No p cutoff occurs.

Elimination of the pendant path gives

 det(tI+iB_p)=D_p [t^3+3t+(t^2+1)f_p-2i].             (2)

Its real bracket is positive. The lifted phase, continuously anchored
at infinity, is -Theta_p, where
Theta_p=atan(2/[t^3+3t+(t^2+1)f_p])>=Theta3. D_p is positive, so it
contributes no phase wrap. The equal-trace phase identity gives

 F(B_p)-k=(2/pi) integral_0^infinity t Theta_p(t)dt
         >=F(B3)-6>17/20.                              (3)

The last strict inequality is a SINGLE exact six-by-six integer PSD
Gram in private-p3-gram.json. For X=WW^t/d^2, the reader checks
2Tr(B3 X)-Tr(X^2)>137/20, with the ENTIRE squared norm. Floating
eigenvectors merely proposed W. No floating value accepts this bound.
Equation (2) and the phase comparison prove the unbounded p range.

3. Root support and the zero-cost path direction. Use J=[[0,1],[1,0]],
K=2I+J, Ki=K^-1. For any complex symmetric 2-by-2 matrix F set

 V(t,F)=ImTr(Ki F)-t ReTr(Ki F)/2
          +sqrt(t^2+4)||K^-1/2 F K^-1/2||_*/2.          (4)

This is the support function of the same closed root matrix ball as
the inherited complete-cap homotopy proof, multiplied by t. It is
nonnegative, positively homogeneous and subadditive for ALL F, without
requiring F to be a physical response or to satisfy a sector condition.
For alpha>=0 a direct substitution gives

                  V(t,alpha/(t+2i) e_a e_a^t)=0.        (5)

Indeed its trace norm is 2alpha/(3sqrt(t^2+4)); the other terms cancel.
For the physical old parent and physical full cap, source201 gives
2ReF+tImF>=0. Accretive Schur homotopy therefore gives, with no
rewrapping and all positive/negative modes retained,

 F(new)-F(old)>=F(B_p)+k-(2/pi) integral V(t,Fcap_p)dt. (6)

This is Sections2..4 of full-cap-matrix-disk-proof.md applied to the
actual B_p,T_p. The same parent is retained throughout; no energy
theorem is applied to a weighted intermediate graph. Shaving below
only enlarges a support bound AFTER this physical inequality.

4. Four continuous curves cover EVERY p. Put Z=t+2i and
e_p=(-i)^(p-1)/D_p, g=[1+i(f_p+e_p)]/Z. The path all-ones response is
p/Z+2ig/Z. Eliminating the path leaves the triangle matrix
M=tI+i(K3 adjacency)+f_p e_c e_c^t, and effective contact rows
(1-ig,0,0),(1,1,0). Thus

 Fcap_p=(p/Z+2ig/Z)e_a e_a^t+T_eff M^-1 T_eff^t.      (7)

The last transpose is not an adjoint. For r in{2,3,4,5}, p=r mod4,
p>=r, let Ffree_r replace p/Z in (7) by r/Z but retain f_p,e_p.
By(4),(5), V(t,Fcap_p)<=V(t,Ffree_r). The coefficient p-r is nonnegative;
these four residue classes cover all p>=2 without identifying their
physical graphs. The fixed phase of e is respectively -i,-1,+i,+1.
The path Wronskian gives e_p^2=f_p^2+t f_p-1.

Use bounded h=f/(1+f), j=e/(1+f), and h0=lambda/(1+lambda). Put
delta_r=s lambda^(r+1)/[(D_r+D_(r-1))(1+lambda)], with s=-1 for even r
and +1 for odd r. Exactly h_r-h0=delta_r. All actual h_p lie between
h0 and h_r. With a continuous parameter v in[0,1] the whole enlarged
curve is

 h=h0+v^2 delta_r,
 j=phase_r v sqrt(|delta_r|[2+t(1-2h0)-t v^2 delta_r]). (8)

This follows by factoring the quadratic identity for j^2; it is the
correct fixed phase and includes the actual response at every p in
its class. It also regularizes the square root at v0. It is enough
to upper-bound every v, regardless of whether it is attained by a graph.

5. Explicit nonsingular scalar formulas. Let o=1-h and
D=(t^3+3t)o+(t^2+1)h-2io. Define
N0=t^4-t^2+2+i(4t^3+8t),
Nf=t(t^2-3)+4i(t^2+2), Ne=-4t+2i(t^2+3), N=N0 o+Nf h+Ne j.
Then (7), using the Wronskian, simplifies EXACTLY to

 Faa=r/Z+N/(Z^2 D),
 Fab=t(t-i)[(t+i)o+h+j]/(Z D),
 Fbb=[(2t^2-2it)o+t h]/D.                            (9)

For h in[0,1], |D|^2>=h^2+4(1-h)^2>=4/5. These are the formulas
evaluated on the compact domain 0<=t<=4, including its continuous
endpoint. For R=ReF,I=ImF the nuclear norm squared in(4) is
Tr(Ki R Ki R)+Tr(Ki I Ki I)+2|detF|/3. This retains all noncommuting
terms and the absolute determinant; no PSD assumption on R is used
here. Exact rational direct inversions of actual B_p for p2..13 at
t1/4,1,4 separately check (7),(9) and the tail formulas (36 controls).
These controls support the written identities, not extrapolation in p.

6. Entire infinite tail, with a sign proof valid for free curves. Set
z=1/t, y=z^2, 0<=z<=1/4, L=2/(1+sqrt(1+4y)). Let d0=d1=1,
d_j=d_(j-1)+y d_(j-2). Define
A=L^(r+1)/[(d_r+z d_(r-1))(1+zL)],
h0=zL/(1+zL), delta=s z^(2r+1) A,
H=L/(1+zL)+s v^2 z^(2r)A,
gamma=v sqrt(A[1+2z-2h0-v^2 delta]).
Then h=zH, j=phase_r z^r gamma. In scaled complex notation a+izb,
Jsmall=j/z has components
(phase_real z^(r-1)gamma,0) for odd r, and
(0,phase_imag z^(r-2)gamma) for even r. All exponents are nonnegative.

Normalize (9) with U=F/z=Qhat-i z Mhat. curve_interval.tail_raw is
obtained just by substituting t=1/z,h=zH,j=z Jsmall and cancelling
common powers; its denominators and coefficients are finite at z0.
The scaled arithmetic (a,b)(c,d)=(ac-ybd,ad+bc) verifies this algebra
without ever dividing by z. At z0, Qhat=[[r+1,1],[1,2]],
Mhat=[[2r,2],[2,2]]. On EVERY retained interval cell the reader proves
Qhat positive definite by Q11>0 and detQ>0. Thus positivity on the
ENTIRE tail parameter rectangle is certified, not inferred from samples.

For these hatted symmetric matrices write
q=TrKiQ,m=TrKiM,u=detQ/3,vv=detM/3,
w=(Q11M22+Q22M11-2Q12M12)/3. Set
haux=(w^2-4u vv)/[sqrt((u-y vv)^2+yw^2)+u+y vv].
The generalized eigenvalues of symmetric M relative to Q>0 are real,
so w^2-4u vv>=0. The denominator is >=2u>0, since the square root is
>=|u-y vv|. Unlike the physical bounded-cap proof, no bound on those
generalized eigenvalues is required. Rationalizing(4) gives

 W=[(2q-m)^2+2(1+4y)haux] /
   [2(sqrt((1+4y)[q^2+y(m^2+2haux)])+q+2ym)].         (10)

The full denominator is >=4q>0: the square root is >=|q-2ym|, because
(1+4y)(q^2+ym^2)-(q-2ym)^2=y(2q+m)^2>=0. This proves the lower clamps
used by the interval reader even when M is indefinite. Exactly
V(t,F)=yW and integral_4^infinity V dt=integral_0^(1/4)W dz. No infinite
tail, near-zero interval or parameter endpoint is omitted.

7. Complete finite integration of the continuous families. Each of
the four curves is covered by disjoint slabs partitioning [0,4] and
[0,1/4]; EVERY slab partitions the ENTIRE v interval[0,1]. On each
rectangle directed rational 72-bit interval arithmetic encloses (4)
or(10). Integer square roots are outward. The slab upper bound is the
MAXIMUM of all parameter-cell upper bounds, multiplied by slab width.
Thus it bounds the pointwise parameter supremum, a stronger quantity
than any single actual p integral. Certificate files preserve every
cell and exact endpoint; the separate reader recomputes EVERY cell,
every partition and total, and obtains for EACH r

                      I_r<5/4.                       (11)

No floating value accepts any certificate. Legitimate positivity clamps
use h in[0,1], nonnegative radicands, support>=0, and the sign proofs
above. A positive denominator and tail SPD enclosure are mandatory;
otherwise subdivision is required. Missing parameter cells, a missing
whole tail and a broken private Gram are rejected. Producer and reader
share the interval implementation and inherited algebra utilities;
different control flow is not independent human/formal peer review.

Combining(3),(6),(11), with pi>157/50,

 DeltaF>2k+17/20-125/157
       =2k+169/3140>2k+1/20,

proving(1) for ALL p>=2 and ALL allowed old parents.

8. Effect on the SAME original minimal-counter domain. If deleting
the entire branch leaves old order>=8, original minimality and(1)
exclude this actual closed branch. If the old order h is2..7, do not
assume the original 2h bound. Every MOP of order3..7 has a dominating
pair: the reader independently enumerates all64 polygon triangulations
(1,2,5,14,42) and supplies a pair for each. K2 needs one vertex.
Add the actual external apex a and R1 to such an old dominating set.
The vertex a dominates every L_j and c; R1 dominates R2 and c. This is
a whole-graph dominating set of size<=4, for EVERY p, independently of
the old boundary choice. The EXISTING gamma<=4 whole-original theorem244
then pays this G,n>=8, at its explicitly declared inherited-input
boundary (all-MOP8..71 finite cover;176/190/the connected n-1 input and
the retained gamma4 finite bridge). That source is reread in full here;
its finite286769-profile bridge is not freshly reaudited or silently
made unconditional. No small-old energy extension is inferred from(1).

Consequently, combined with the prior mixed/common-private/all-terminal-
fan reductions, every deepest branch in a minimal original counter of
order>=72 admits external/external fan apices OR a mixed assignment
with inward q in{15,16,17,18,19,20}, outward p>=2, including coherent
whole reflection. These descriptions need not be disjoint. No existence
of such a counter is asserted. The external/external regime includes
the still-open unrestricted balanced Fork6. The six inward lengths,
unbounded outward lengths, arbitrary assemblies and the ORIGINAL global
energy/extraction claim remain OPEN. Old low-degree fan theorem and
historical seven-length necessary statement remain true; the new result
strengthens that necessary statement. No target switch is completion.

9. Provenance and next use. Sources are the prior full-cap homotopy,
source201 physical root sector, the seven-length mixed theorem, the
terminal-fan/common-private reductions and the exact-scope gamma4 source.
The new useful operation is the zero-support shaving of a repeated
positive path direction: it reduces an unbounded physical integer family
to four bounded continuous support problems, preserving individual graph
identities and every contact. This changes the next mixed-branch work
by removing q2 entirely, rather than adding further finite p samples.
It is not known yet whether the same compression pays q15..20; their
private triangle/path responses differ and must be derived anew.
No external priority, complete-corpus/Drive refresh, repaired automatic
entry delivery, background continuation or new subagent is claimed.
