# All six remaining inward lengths pay at every outward length

5 November 2026. Original EVERY finite simple UNIT maximal outerplanar
G,n>=8 has F(G)=splus(G)>=2n, equivalently D>=6: GLOBAL OPEN/goal ACTIVE.
This proves a universal increment and strengthens necessary structure.
It does not close the original global claim or unrestricted Fork6.

1. Literal graph and uniform conclusion. Keep root edge ab, add triangle
abc with c PRIVATE. The ac child is a p-face fan with apex EXTERNAL a,
outer arc a,L1,...,Lp,c. The cb child is a q-face fan with apex PRIVATE c,
outer arc b,R1,...,Rq,c. No private vertex has any other outside contact.
Put k=p+q+1. The private graph B consists of a UNIT fan on c,R1,...,Rq
with a pendant p-path Lp,...,L1 attached at c. The two contact rows are
a:{c,L1,...,Lp}, b:{c,R1}. There are 2k new edges,
m(B)=p+2q-1 and contact mass Tr(TT^t)=p+3. Root orientation is retained.

THEOREM: for EVERY p>=2, EVERY q in{15,16,17,18,19,20}, EVERY old finite
simple UNIT MOP of order>=3, and EVERY ordered boundary edge ab,

                      F(new)-F(old)>2k+3/4.             (1)

There is no upper bound on old order, degrees, norm or spectrum. Whole
reflection is included. This is not an unrestricted bare-fan/C0 theorem.

2. A common private floor without a conjectural phase premise. Pinch
B into its actual (q+1)-vertex fan and its actual p-vertex path. The
variational PSD formula gives F(B)>=F(fan_(q+1))+F(P_p). The path is
bipartite and has p-1 edges, so F(P_p)=p-1 EXACTLY. Six complete integer
PSD Grams establish, individually for q15..20,

              F(fan_(q+1))>2q+23/5.

For every W/d the reader uses X=WW^t/d^2 and checks
2Tr(A X)-Tr(X^2)>2q+23/5, including the ENTIRE squared norm. Numerical
eigensystems only propose these factors. Thus for ALL p>=2,

          F(B)>m(B)+23/5,
          F(B)+Tr(TT^t)>2k+23/5.                       (2)

This is an unbounded p proof by pinching; it does not extrapolate the
finite proposed private spectra. It needs neither the original energy
conjecture nor a full-monomer phase theorem for arbitrary MOPs.

3. Root phase and a low-frequency estimate independent of p. For the
SAME physical parent and cap let Z0=tI+iJ+F0, Z1=Z0+Fcap, J=[[0,1],[1,0]].
Their Hermitian real parts are strictly positive for t>0, since each
physical response has positive Hermitian real part. The principal
accretive trace-log is continuous and anchored at infinity; its two
eigenvalue arguments lie in(-pi/2,pi/2). Thus

 delta_root=ImTrLog Z1-ImTrLog Z0<2pi                 (3)

at every t>0, independent of private order, any zero modes or root
degrees. These are two 2-by-2 trace logs, not rewrapped determinant
arguments of large matrices. The equal-trace determinant/energy identity,
already derived in the inherited complete-cap homotopy proof, gives

 DeltaF=F(B)+TrTT^t-(2/pi) integral_0^infinity t delta_root(t)dt. (4)

Choose epsilon=1/100. By(3), the entire omitted-low-frequency ENERGY
cost is at most 2epsilon^2=1/5000. No pointwise sign of delta_root is
assumed. In particular this is valid when Fcap has a private-zero-mode
pole and its larger root-ball support is not integrable down to zero.

For t>=epsilon use the proven201 physical sector condition and the
complete-cap Schur homotopy, retaining ALL private modes. With
K=2I+J and Ki=K^-1 the bound is

 t delta_root(t)<=V(t,Fcap),
 V(t,F)=ImTr(KiF)-t ReTr(KiF)/2
               +sqrt(t^2+4)||K^-1/2 F K^-1/2||_*/2.   (5)

V is a nonnegative support function for every complex symmetric F,
positively homogeneous and subadditive. Its algebraic domain is larger
than physical responses. This uses one actual parent throughout the
homotopy; no energy conclusion is applied to an intermediate weighted
graph. Equation(4) includes zero modes and is integrated on the original
full unit graphs, not on separately optimized graph witnesses.

4. The unbounded outer length reduces to four bounded continuous curves.
This is the preceding q2 theorem's length compression, now with the
DIFFERENT right fan retained explicitly. Set Z=t+2i. For a path define
D0=1,D1=t,D_j=tD_(j-1)+D_(j-2),
f_j=D_(j-1)/D_j, e_j=(-i)^(j-1)/D_j,
g_j=[1+i(f_j+e_j)]/Z, s_j=j/Z+2i g_j/Z.
These are respectively endpoint diagonal, opposite endpoint, all-ones
to endpoint, and all-ones quadratic responses of (tI+iP_j)^-1. They
follow from the tridiagonal recurrence; f_j>0 and
e_j^2=f_j^2+t f_j-1. Eliminate both paths at the private hub c. Write
S=s_q, Bsmall=1-i g_q, A=1-i g_p, d=t+f_p+S. Exactly

 Faa=s_p+A^2/d, Fab=A Bsmall/d, Fbb=f_q+Bsmall^2/d.   (6)

For p=r mod4, r in{2,3,4,5}, p>=r, shave
(p-r)/Z e_a e_a^t from F. This coefficient is nonnegative and its V
is EXACTLY zero, by direct substitution in(5). Hence support can only
increase when it is removed. The rest depends on p only through f_p,e_p.
Individual physical graphs are NOT identified by this response bound.

Put lambda=2/(t+sqrt(t^2+4)), h0=lambda/(1+lambda),
delta=s lambda^(r+1)/[(D_r+D_(r-1))(1+lambda)], with s=-1 for even r
and +1 for odd r. The continued-fraction monotonicity proves f_p lies
between f_r and lambda on each residue class. Consequently the enlarged
curve, for EVERY v in[0,1], is

 h=h0+v^2 delta,
 j=phase_r v sqrt(|delta|[2+t(1-2h0)-t v^2 delta]),
 phase_2=-i, phase_3=-1, phase_4=i, phase_5=1.          (7)

Here h=f/(1+f), j=e/(1+f), 0<=h<=1. The quadratic Wronskian proves
this formula and the nonnegative radicand, not a numerical fit. The
four whole curves cover ALL actual p>=2, with no length cutoff.

5. Compact formulas and arithmetic. Let o=1-h, D=(t+S)o+h. Expanding
(6) and eliminating e^2 with its Wronskian yields

 N0=t^2-2+4it+2iS, Nf=t+4i-2S, Ne=2i-2S,
 N=N0 o+Nf h+Ne j,
 Faa=r/Z+N/(Z^2 D),
 Fab=[(t+i)o+h+j]Bsmall/(Z D),
 Fbb=f_q+o Bsmall^2/D.                               (8)

This exact cancellation removes all divisions by o, including odd-p
endpoints. RealS>=0 because S is a physical path resolvent quadratic,
so ReD>=t o+h>0 for t>0. The right-path responses are evaluated by
f1=1/t,e1=1/t, f_j=1/(t+f_(j-1)), e_j=-i e_(j-1)/(t+f_(j-1)), then
the displayed g_q,s_q formulas. All positive denominators must be
enclosed strictly; otherwise subdivision is mandatory. For R=ReF,I=ImF,

 ||K^-1/2 F K^-1/2||_*^2
 =Tr(Ki R Ki R)+Tr(Ki I Ki I)+2|detF|/3.

Both contacts, noncommuting terms and absolute determinants are kept.
These formulas are enclosed on the complete compact domain[epsilon,4].

6. Complete infinite tail and its sign contract. Set z=1/t,y=z^2 and
use scaled complex arithmetic a+izb, whose product is(ac-ybd,ad+bc).
For each fixed q write d0=d1=1,d_j=d_(j-1)+y d_(j-2). Then
f_q=z d_(q-1)/d_q, e_q=phase_q z^q/d_q. Define
G=g_q/z=[1+iz(f_q/z+e_q/z)]/(1+2iz),
Shat=S/z=q/(1+2iz)+2izG/(1+2iz), Bsmall=1-izG.
These have finite scaled coefficients at z0 because q>=15.

Normalize (7) by h=zH,j=zJsmall, using the prior exact tail parameters:
L=2/(1+sqrt(1+4y)), A=L^(r+1)/[(d_r+z d_(r-1))(1+zL)],
delta=s z^(2r+1)A, h0=zL/(1+zL),
H=L/(1+zL)+s v^2 z^(2r)A,
gamma=v sqrt(A[1+2z-2h0-v^2 delta]),
Jsmall=phase_r z^(r-1)gamma. In scaled notation the even-r imaginary
coefficient uses exponent r-2, also nonnegative. Put o=1-zH,
Dhat=(1+y Shat)o+yH. The normalized numerator z^2N is

 Nhat=[1-2y+4iz+2iyz Shat]o
       +yH[1+4iz-2y Shat]+2iyz Jsmall-2y^2 Shat Jsmall.

For U=F/z the response is EXACTLY

 Uaa=r/(1+2iz)+Nhat/[(1+2iz)^2 Dhat],
 Uab=[(1+iz)o+yH+yJsmall]Bsmall/[(1+2iz)Dhat],
 Ubb=d_(q-1)/d_q+o Bsmall^2/Dhat.                    (9)

No division by z occurs. Write U=Qhat-iz Mhat with real symmetric Q,M.
On EVERY accepted interval cell the reader certifies Q11>0,detQ>0;
this proves SPD on the ENTIRE parameter rectangle. With q0=TrKiQ,
m0=TrKiM,u=detQ/3,v0=detM/3,w=(Q11M22+Q22M11-2Q12M12)/3, set
haux=(w^2-4u v0)/[sqrt((u-yv0)^2+yw^2)+u+yv0].
The generalized eigenvalues of symmetric M relative to SPD Q are real,
so w^2-4u v0>=0. The denominator is >=2u>0. Exact rationalization gives

 V(t,F)=yW,
 W=[(2q0-m0)^2+2(1+4y)haux] /
    [2(sqrt((1+4y)[q0^2+y(m0^2+2haux)])+q0+2ym0)].    (10)

The full denominator is >=4q0>0, since
(1+4y)(q0^2+ym0^2)-(q0-2ym0)^2=y(2q0+m0)^2>=0.
Thus no physical eigenvalue/norm bound on the enlarged free curve is
silently assumed. The ENTIRE tail is
integral_4^infinity Vdt=integral_0^(1/4)Wdz, including z0. Qhat at z0
is [[r+1,1],[1,2]], so there is no hidden singular endpoint there.

7. Full coverage certificates and the final numerical constants. Each
of the 24 actual (q,r) pairs has disjoint compact slabs partitioning
[1/100,4] and tail slabs partitioning[0,1/4]. EVERY slab partitions
ALL of v in[0,1]. Directed rational 72-bit arithmetic and integer square
roots enclose(5),(8),(10) on every rectangle. The max parameter-cell
upper bound times slab width bounds the pointwise parameter supremum.
Every cell/end point/upper bound is retained. The independent-control-
flow reader recomputes ALL cells, both full partitions and every sum,
obtaining for EACH of the 24 pairs I_(q,r)<6. This is not quadrature
or acceptance by sampled v, p, t. Shared interval/algebra helpers are
declared; software replay is not external human/formal peer review.

It also independently inverts 48 actual rational private matrices,
checks all 72 closed-unit-cap geometries p2..13/q15..20 and all six full
fan Grams. Missing parameter cells, missing tail, missing (q,r), broken
Gram, omitted low-t cost and negative shaving coefficients are rejected.
The written recurrences/Schur identities prove the all-order part;
finite matrix/geometry controls do not substitute for that proof.

Combining(2)..(5) with I<6 and pi>157/50 gives

 DeltaF>2k+23/5-600/157-1/5000>2k+3/4,

which proves(1). ALL low frequencies, zero modes and the infinite tail
have been accounted for, while the outward integer p remains unbounded.

8. Original minimal-counter consequence, without changing target.
If removing the entire branch leaves old order>=8, minimality plus(1)
exclude this branch. If old order h is2..7, do not assume F(old)>=2h.
Every old MOP of order3..7 has a dominating pair, verified over all64
polygon triangulations by the preceding independent all-diagonals
enumerator; K2 needs one vertex. Add a and c: a dominates ALL L_j and
c dominates ALL R_j. This is a whole-graph dominating set of size<=4
for ANY p,q. The existing gamma<=4 original theorem244/4133 pays this
whole G,n>=8, at its EXACT named inherited-input boundary. Its original
finite8..71 cover,176/190 bounds, connected n-1 theorem and gamma4
finite bridge are retained, not freshly reaudited or silently made
unconditional. The original n>=72 residue has the same declared status.

Now assemble the ACTUAL deepest branch. The inherited all-terminal-path
theorem makes both children external-apex straight fans relative to
their own closing edge. Relative to the branch triangle these apices
can be external a,b or internal c. The prior both-internal theorem
excludes that assignment except balanced p=q1, which also admits an
external/external description. For a mixed assignment, if p1 the one-
face outward triangle can choose c, reducing to that prior case. If q1
the inward triangle can choose its external root. For p,q>=2:
q2 is paid by the preceding ALL-p theorem; q3..14 is excluded by the
actual C0 tip with WHOLE degree sum q+6<=20 and source256; q15..20 by
(1); q>=21 by the previous old-apex-degree3 fan retirement theorem,
including its separately paid small-old remainder case.

Therefore EVERY deepest branch in a minimal original counter n>=72
admits BOTH fan apices EXTERNAL, including whole reflection. This is
a necessary REPRESENTATION, not disjoint assignment classes or an
assertion that any such counter exists. No global payment follows
merely by giving this remaining structure a name.

9. Remaining hard structure and changed next work. In the remaining
external/external description the private graph is a PATH on k=p+q+1
vertices, its energy is k-1, and contact mass is k+1. The baseline in
(4) is EXACTLY2k. A nonnegative enlarged root-ball support by itself
therefore gives no positive surplus, unlike the mixed cases. This is
an exact distinction, not an unperformed numerical claim of failure.
The unrestricted balanced Fork6 is included; its already refuted
pointwise phase nonincrease is not revived. Universal C0/barefan and
fixed cap-only selector counterexamples remain true on whole paid W.
The global energy claim, extraction/compensation for arbitrary such
assemblies, and the external/external universal integral sign question
remain OPEN. No claim of first payment, exhaustive corpus/Drive refresh,
worldwide priority, repaired automatic entry, new subagent or background
work is made. The next justified work is this path-baseline regime,
not further finite sampling of already excluded mixed lengths.
