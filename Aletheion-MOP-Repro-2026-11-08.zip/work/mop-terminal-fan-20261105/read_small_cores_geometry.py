from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
import hashlib,json,sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'mop-singular-turns-20261105'));import classify_four_face_caps as c
m=c.m;mm=m.mm;tr=m.tr
def edge(a,b):return tuple(sorted((a,b)))
def allsets(n):
    boundary={edge(i,(i+1)%n) for i in range(n)};diags=[p for p in combinations(range(n),2) if p not in boundary];out=set()
    for chosen in combinations(diags,n-3):
        if any(a<x<b<y or x<a<y<b for (a,b),(x,y) in combinations(chosen,2)):continue
        out.add(frozenset(boundary|set(chosen)))
    return out
def model(ell,turn):
    # Child fan hasellfaces, rootsu0,a1; ordinary arc a1,v2,..,v_(ell+1).
    e={edge(0,j) for j in range(1,ell+2)}|{edge(j,j+1) for j in range(1,ell+1)}
    x=ell+2;e|={edge(x,0),edge(x,1)}
    roots=(1,x) if turn else (0,x);private=[j for j in range(x+1) if j not in roots]
    # Parent triangle lies outside the new root chord.
    y=x+1;whole=e|{edge(y,roots[0]),edge(y,roots[1])}
    boundary=list(range(1,ell+2))+[0,x,y] if turn else list(range(1,ell+2))+[0,y,x]
    m.rat.prior.outer_graph(y+1,whole,boundary)
    assert all(not set(z)&set(private) or set(z)<=set(private)|set(roots) for z in whole)
    if turn:
        order=[0]+list(range(2,ell+2));L=ell+1;B=[[int(edge(i,j) in e) if i!=j else 0 for j in order] for i in order]
        expected=[[int((i==0 and j>0) or (j==0 and i>0) or (i>0 and j>0 and abs(i-j)==1)) for j in range(L)] for i in range(L)]
        assert B==expected
        T=[[int(edge(root,j) in e) for j in order] for root in roots]
        assert T==[[int(i in (0,1)) for i in range(L)],[int(i==0) for i in range(L)]]
        #An extra outside contact invalidates THIS named closed cap.
        damaged=whole|{edge(y,2)};assert any(set(z)&set(private) and not set(z)<=set(private)|set(roots) for z in damaged)
    else:assert sum(0 in z for z in e)==ell+2 and 0 in roots
def main():
    p=HERE/'small-core-grams.json';data=json.loads(p.read_text());scores=[];counts=[]
    for n in range(3,8):
        expected=allsets(n);recursive=set(c.triangulations(tuple(range(n))));assert expected==recursive
        rows=[r for r in data['cases'] if r['n']==n];assert {frozenset(tuple(e) for e in r['edges']) for r in rows}==expected and len(rows)==len(expected)
        for row in rows:
            W=row['factor'];D=row['denominator'];assert len(W)==n and all(type(z) is int for r in W for z in r)
            Z=mm(W,tr(W));G=mm(tr(W),W);value=F(4*sum(Z[a][b] for a,b in row['edges']),D**2)-F(sum(z*z for r in G for z in r),D**4)
            assert value>2*n-3;scores.append(dict(n=n,lower=str(value)))
        counts.append(dict(n=n,triangulations=len(rows)))
    assert sum(r['triangulations'] for r in counts)==64 and len(scores)==64
    for ell in range(4,101):model(ell,False);model(ell,True)
    #Strict whole-graph reserve for old orderk2..7and originaln>=72:
    #L=n-k>=65, sqrt(L-2)>7, F(fanL)>2L+4 and F(H)>=2k-3.
    assert 65-2>7**2 and (2*65-3+7)+(2*7-3)>2*(65+7)
    out=dict(status='PASS_ALL64_EXACT_SMALL_CORES_AND_FIRST_TURN_ACTUAL_GEOMETRY_CONTROLS',counts=counts,full_small_core_scores=scores,
      exact_K2='F(K2)=1=2k-3',geometry_controls=194,geometry_range=[4,100],missing_outside_contact_rejected=True,
      small_core_global_reserve='For originaln>=72andoldk2..7,L>=65: F(new)>=F(H)+F(fanL)>2n+1 by exactpinching+analyticfanDtail.',
      limit='Finite geometrycontrols calibrate the separate all-order chord-side induction, not its proof. OriginalGLOBALOPEN; shortbranchends andwholeglobalextraction remainOPEN.',
      fixture_sha256=hashlib.sha256(p.read_bytes()).hexdigest())
    (HERE/'small-core-geometry-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:out[k] for k in ('status','counts','geometry_controls','small_core_global_reserve')}))
if __name__=='__main__':main()
