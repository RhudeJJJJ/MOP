"""Import-only leaf code closure in a fresh process; never invoke its main."""
from pathlib import Path
import importlib.util,sys,json,types
root=Path(sys.argv[1]).resolve();entry=Path(sys.argv[2]).resolve();sys.dont_write_bytecode=True
sys.path.insert(0,str(entry.parent));spec=importlib.util.spec_from_file_location('_repro_entry',entry);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
seen=set();files=set();todo=list(sys.modules.values())
while todo:
    obj=todo.pop()
    if not isinstance(obj,types.ModuleType)or id(obj)in seen:continue
    seen.add(id(obj));name=getattr(obj,'__file__',None)
    if name:
        p=Path(name).resolve()
        if p.is_relative_to(root)and p.is_file():files.add(str(p));todo.extend(v for v in vars(obj).values()if isinstance(v,types.ModuleType))
print(json.dumps(dict(entry=str(entry),files=sorted(files))))
