# Quantitative path-state bounds: a sharp Fork resolvent comparison

5 November2026. ORIGINAL unchanged: every finite simple UNIT maximal
outerplanar G,n>=8 satisfies F(G)=splus(G)>=2n. GLOBAL OPEN / goal ACTIVE.
This proves two all-length bounds on the exact new path state, a stronger
universal branch increment and qualified ledger consequences. It does
not prove universal nonnegative Fork6, full UB or global compensation.
No external formal audit, worldwide priority or full-corpus claim.

## 1. Preserve the actual operation and the fixed state

Use the existing literal external/external branch, attached at ANY ordered
actual boundary ab of ANY old UNIT MOP H,order>=3. Its p,q>=1 fan arms
give k=p+q+1 private vertices, private B=P_k, and contact rows T equal
to prefix0..p and suffixp..k-1. Keep ab once, add2k UNIT edges, and
allow no other private outside contacts. The same-parent theorem gives

 K=2I+J=[[2,1],[1,2]], Ki=K^-1,
 S=V^t(tI+iC)^-1V, V=W/sqrt2,
 W=(e_(p+1)-e0,e_k-e_p),
 Fcap=T(tI+iB)^-1T^t=(TT^t+2iS)/(t+2i).

C is the SAME fixed Neumann path at all t>0, of orderk+1, with unit
offdiagonal and endpoint diagonal1; V^tV=I. All private zero modes are
retained. Signed Fstar=(K+2iS)/(t+2i) is an algebraic normalization,
never assigned an original graph energy. The physical old H stays fixed.

Put x=t^2, a=ImTr(KiS), and Q=V^t(t^2+C^2)^-1V=ReS/t.
The new ALL-LENGTH statements are

       -a >= x/[3(x+1)^2] =:g(x),                     (1)
       Tr(Ki^2 Q) <= 1/x+1/[9(x+2)] =:h(x).          (2)

The right side of (2) is EXACTLY the value at the balanced Fork p=q1.
Thus (2) is sharp for this weighted real resolvent, at EVERY t>0.
It does NOT identify other path states with the Fork or prove a minimum
of ACTUAL graph-energy increments at the Fork.

The resulting universal physical increment is

                    Delta F>2k-184/157>2k-59/50.      (3)

No old degree, order or norm upper bound occurs. This improves the earlier
194/157 debt, retaining its true theorem. The sufficient long-arm threshold
improves from1156 to1024, as specified below. The original target remains open.

## 2. Complete polynomial identities, not a finite-length assumption

The previous weighted-trace proof gives exact complex numerators
S_ij=Nij/(2D_k), where D0=1,D1=t,D_n=tD_(n-1)+D_(n-2),D_-1=0,
U_p=sum_(r=0)^p(-i)^rD_(p-r),U_-1=0, and

 Naa=2D_qU_p+D_(q-1)(U_(p-1)+iU_p),
 Nbb=2D_pU_q+D_(p-1)(U_(q-1)+iU_q),
 Nab=[(-i)^q+D_q]U_p-D_(q+1)U_(p-1)+iD_(p-1)D_q.

These are the actual path-cofactor identities, with every contact retained.
For nu=k mod2 define polynomials in x=t^2 by

 d=D_k/t^nu>0,
 N=-Im(Naa+Nbb-Nab)/t^nu,
 R=Re(5Naa+5Nbb-8Nab)/t^(1-nu).

Parity follows from the actual cofactor expansion, including zero
coefficients. The exact scalar identities are

            -a=N/(3d),
            Tr(Ki^2 Q)=R/[18 x^nu d].                (4)

Consequently (1),(2) follow from nonnegativity on x>0 of

 A_(p,q)=(x+1)^2 N-xd,
 B_(p,q)=2(10x+18)d-x^(1-nu)(x+2)R.                 (5)

We prove the stronger statement that EVERY coefficient of BOTH polynomial
families in (5) is nonnegative, for ALL positive p,q.

The all-index recurrence is licensed by the completed proper generating
function argument, not inferred from the certificate. At fixed q the Nij
are linear combinations of D_p,D_(p-1),U_p,U_(p-1). Their generating
denominator is (1+iz)(1-tz-z^2), with a proper numerator of degree<=2.
Taking real or imaginary parts adds the conjugate pole. On EACH residue
class p mod4 the characteristic therefore divides

          (mu-1)(mu^2-(x^2+4x+2)mu+1).               (6)

Reflection gives the same q recurrence. D_k itself has only the two path
poles, so also satisfies (6). Every factor in (5), including nu and
x^(1-nu), is constant along a residue-four subsequence. Thus BOTH A and
B satisfy (6) in p AND q for every index. Division by t^nu is valid
at all t>0 and does not delete a zero eigenvalue. The resulting identities
are polynomial identities in x by equality at every positive t.

## 3. Two complete144-jet cone certificates

Let z=x^2+4x+2, b=z-2=x^2+4x. For a sequence Z_m with
Z_(m+2)-zZ_(m+1)+Z_m=L constant, use the three initial objects

 Z0, Delta0=Z1-Z0, K0=Z2-zZ1+(z-1)Z0.

If they have nonnegative coefficients, all Z_m and all successive
differences do: Delta_(m+1)=Delta_m+K0+b(Z_(m+1)-Z0). The cone is closed
under sums and multiplication by b. This is the previous exact cone
lemma; L alone is not assumed nonnegative.

For EACH of A,B check ALL

 O_q O_p Z(r,s), r,s in{1,2,3,4}, O_p,O_q in{I,Delta4,K4}. (7)

There are144 jets per family,288 in total, retaining every coefficient.
First apply the cone lemma in q to all three p-initial objects, then
in p. The operators commute and (6) supplies every required recurrence.
The complete nonnegative coefficient check in (7) proves (1),(2) for
ALL lengths. The B polynomial at p=q1 is identically zero, proving the
claimed all-frequency equality/sharpness of (2).

The floor producer uses the previous hash-bound actual N-grid as DATA;
the real-resolvent producer uses the complex continuants directly.
The separate stdlib reader imports neither producer. It rebuilds actual
B,T, all matrix-power traces and Newton characteristic coefficients,
and all moments M_j=T(2I-B)B^jT^t. Expansion at infinity uses
Maa+Mbb-Mab for N and5Maa+5Mbb-8Mab for the real numerator R.
It independently reconstructs EVERY A,B at1<=p,q<=12, compares both
complete grids, and recomputes ALL288 jets. The algebraic recurrence
argument, rather than the144 finite length pairs, supplies unbounded scope.

## 4. Retain the real and imaginary quantitative information together

Set L=Ki^(1/2)S Ki^(1/2), beta=||L||_F^2. In a real Ki eigenbasis,
with weights1,1/3, the entrywise inequality2uv<=u^2+v^2 and symmetry
of the COMPLEX symmetric S give

 beta=sum_ij w_iw_j|Sij|^2
      <=sum_i w_i^2 sum_j|Sij|^2
      =Tr(Ki^2 S^*S).

Compression of the SAME full Hermitian resolvent gives S^*S<=Q:
insert0<=VV^t<=I between the adjoint/full resolvent factors. Therefore

                         beta<=Tr(Ki^2 Q)<=h(x).      (8)

No commutation between Ki and S is assumed. The first inequality uses
the equal row/column norm diagonals of complex symmetric S, not a
false entrywise PSD assertion. Bound (2) is sharp for the real trace;
(8) is NOT asserted sharp for beta.

The existing exact root-ball support for the same old parent is

 t delta_star<=V=a-1+||I+2iL||_*/2.

The sum of its TWO singular values is at most
2sqrt(1-2a+2beta). As a function of a<=0,
a-1+sqrt(1-2a+2beta) is nondecreasing. Use (1),(8) to obtain

 t delta_star<=V<=-g(x)-1+sqrt(1+2g(x)+2h(x)).          (9)

This is stronger than the previous sign-only support. It retains two
proved bounds on the same actual path state, without claiming their
extrema are simultaneously attained. No matrix sign ImS<=0, contrast
sign, constant-metric replacement or universal old AMP is used. Those
stronger/helper routes have actual counterexamples and remain excluded.

## 5. Entire-frequency integration and rational constants

The existing same-parent bound delta_star<2atan(2/t) pays the ENTIRE
low interval0..epsilon,epsilon=5/8. Its exact weighted integral is

 pi epsilon^2/2+2epsilon-(epsilon^2+4)atan(epsilon/2).

For the WHOLE remaining axis put u=1/t and y=u^2. Write

 g(t^2)=u^2 G(u), G(u)=1/[3(1+u^2)^2],
 h(t^2)=u^2 H(u), H(u)=1+1/[9(1+2u^2)].

Rationalizing (9) and substituting dt=-du/u^2 gives the complete tail
upper integral on0..8/5 of

 W(u)=2(G+H)/[sqrt(1+2u^2(G+H))+1]-G.                 (10)

There is no omitted infinite tail or private zero-mode deletion. At u0
the continuous value is10/9. Both G,H are positive nonincreasing.
At fixed u the displayed function decreases with G, increases with H;
at fixed G,H it decreases with u. Thus on a cell[l,r],

 W(u)<=2(G(r)+H(l))/[sqrt(1+2l^2(G(r)+H(l)))+1]-G(r).  (11)

These monotonicities follow directly by differentiation, or from the
equivalent expression(sqrt(1+2u^2(G+H))-1)/u^2-G with its continuous u0
extension. In particular the G derivative is1/sqrt(...)-1<=0.

The certificate gives ALL256 equal cells covering0..8/5. For each it
stores the80bit dyadic square-root lower bracket and an outward dyadic
upper value of (11). The reader verifies the squared bracket, evaluates
the exact rational upper and checks the final ceiling, then sums ALL
upper areas. This bounds a function throughout each cell, not just at
sample points. An8-term alternating LOWER sum for atan(5/16) and the
retained pi<22/7 complete the exact bound

                        Jstar<46/25.                 (12)

Actual nonnegative shaving still gives I_full<=Jstar-Rlen, Rlen>=0.
The actual graph energy identity remains
DeltaF=2k-(2/pi)I_full. With pi>157/50, (12) yields

 DeltaF>2k-(100/157)(46/25)=2k-184/157>2k-59/50,

proving (3). This is an unconditional all-parent increment on the literal
UNIT operation, not an assertion of nonnegative surplus in every case.

## 6. Long arm and the unchanged global ledger obligation

For alpha=max(p-1,q-1),D0=max TWO OLD root degrees, if

                         alpha>=max(D0,1024),         (13)

then l=sqrt(alpha)>=32. The retained same-parent reserve proof gives
Rlen>=99l/1681>=3168/1681. Its assumptions are checked at32:
4l+1+4/l<=(41/10)l and l^2/(l^2+4)>=99/100, monotone thereafter.
Since

                  (7/11)(3168/1681-46/25)>1/50,

and2/pi>7/11, the physical branch has DeltaF>2k+1/50 under (13).
The other arm and the far graph remain arbitrary. All true old thresholds
1156,1521,2401,2601 remain true weaker sufficient conditions.

With the EXACT named inherited B71 finite input, the already completed
actual dual-removal grammar may use c=184/157 for each potentially negative
external/external branch. Counting one distinct removed unrooted degree3
dual face per debt gives, on ONE actual serial chain, B<=initial b(T).
The unchanged argument proves

                   F(G)>=2n-(184/157)b(T),             (14)

strict if n>=72 or b(T)>0. B71 and the other inherited payment proofs
retain their original audit boundaries; none is freshly upgraded here.
Final actual reserve plus justified positive credits must still cover
cB to establish the original2n target. Existence of such a nonnegative
compensation chain for EVERY graph remains OPEN.

Under the SAME existing B71/gamma<=4/old-parent8..13-cover boundary,
every deepest branch of a minimal original counter n>=72 is representable
external/external with actual deleted parent H satisfying

 h>=14, 0<=F(H)-2h<184/157,
 max(p,q)<=max(D0,1024).

Own-root retirement, coupled joint payment and root-pair-plus-two extras
nondomination exclusions remain. No all-order absence/existence of these
large near-reserve parents is proved. The full Fork6/UB/original global
target remains OPEN and the goal remains ACTIVE.

## 7. Verification and limitations

Both complete grids/288 jets, all256 tail cells and exact constants are
read by the separate stdlib checker. Three actual rational complete-
required-column states are reused from the previous hash-bound rigidity
certificate, with every equation row rechecked. They include both
indefinite-imaginary states and the Fork equality case. Direct exact
beta, real trace and imaginary trace satisfy all bounds; these controls
are not the proof of ALL lengths. A damaged floor numerator, omitted
real-resolvent jet and a tail gap are rejected. Shared/basic arithmetic
methods and earlier complete state data are declared; there is no external
human/formal audit or exhaustive priority claim.

The universal amplitude premise and doubled row induction were ALREADY
REFUTED by the actual71vertex source3998; its full original was read before
this work selected a next route. An exploratory new8vertex row2 witness
is not presented as a new status correction or a reopened AMP problem.
The new66089-evaluation adversarial branch-minimum scout and900-point
protected-ear-phase scout are discovery only. The latter's positive
phase does not decide the integrated ear payment. No numerical minimum,
all-parent graph-energy extremality of the Fork or original counterexample
is claimed. Bound (2) concerns ONLY the named weighted real resolvent.

The actual next global work is still integrated payment on the actual
large, near-reserve, nondominated old parent, or whole-sequence debt
compensation. The quantitative state bounds reduce the debt without
substituting a smaller target for the original. No automatic entry repair,
complete Drive/corpus refresh, background or subagent work is claimed.
