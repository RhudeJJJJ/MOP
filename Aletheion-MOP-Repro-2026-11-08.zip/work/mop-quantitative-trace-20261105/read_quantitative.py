"""Separate stdlib actual-path Newton/moment reconstruction of both bounds."""
from pathlib import Path
from fractions import Fraction as F
import json,sys,hashlib
P=Path(__file__).resolve().parent
fp=Path(sys.argv[1])if len(sys.argv)>1 else P/'floor-certificate.json'
rp=Path(sys.argv[2])if len(sys.argv)>2 else P/'resolvent-certificate.json'
rawf,rawr=fp.read_bytes(),rp.read_bytes();CF,CR=json.loads(rawf),json.loads(rawr)
def trim(a):
 if not a:return[0]
 while len(a)>1 and a[-1]==0:a.pop()
 return a
def add(a,b):return trim([(a[i]if i<len(a)else 0)+(b[i]if i<len(b)else 0)for i in range(max(len(a),len(b)))])
def scale(a,s):return trim([s*x for x in a])
def times(a,b):
 v=[0]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):v[i+j]+=x*y
 return trim(v)
def mm(A,B):return[[sum(x*y for x,y in zip(row,col))for col in zip(*B)]for row in A]
def tr(A):return sum(A[i][i]for i in range(len(A)))
def actual_polynomials(p,q):
 k=p+q+1;nu=k%2;adj=[([i-1]if i else[])+([i+1]if i+1<k else[])for i in range(k)]
 power=[[int(i==j)for j in range(k)]for i in range(k)];walks=[k]
 for r in range(1,k+1):
  power=[[sum(power[z][j]for z in adj[i])for j in range(k)]for i in range(k)];walks.append(tr(power))
 char=[1]
 for r in range(1,k+1):
  v=-sum(char[r-j]*walks[j]for j in range(1,r+1));assert v%r==0;char.append(v//r)
 det=[]
 for j,c in enumerate(char):assert j%2==0 or c==0;det.append(c*(-1)**(j//2)if j%2==0 else 0)
 detlow=det[::-1];d=trim(detlow[nu::2]);assert all(z>=0 for z in d)and any(d)
 Tm=[[int(i<=p)for i in range(k)],[int(i>=p)for i in range(k)]]
 U=[[2*row[i]-sum(row[z]for z in adj[i])for i in range(k)]for row in Tm];mtrace=[];mreal=[]
 for j in range(k):
  M=[[sum(Tm[a][i]*U[b][i]for i in range(k))for b in range(2)]for a in range(2)];assert M[0][1]==M[1][0]
  mtrace.append(M[0][0]+M[1][1]-M[0][1]);mreal.append(5*(M[0][0]+M[1][1])-8*M[0][1])
  U=[[sum(row[z]for z in adj[i])for i in range(k)]for row in U]
 negimag=[0]*k;re=[0]*k
 for r in range(k):
  negimag[k-1-r]=-sum(det[j]*mtrace[r-j]*(-1 if(r-j)%4==1 else 1)for j in range(r+1)if(r-j)%2==1)
  re[k-1-r]=sum(det[j]*mreal[r-j]*(-1)**((r-j)//2)for j in range(r+1)if(r-j)%2==0)
 assert all(v==0 for j,v in enumerate(negimag)if j%2!=nu)
 assert all(v==0 for j,v in enumerate(re)if j%2!=1-nu)
 N=trim(negimag[nu::2]);R=trim(re[1-nu::2])
 A=add(times([1,2,1],N),scale([0]+d,-1))
 B=add(times([36,20],d),scale(times([0,2,1]if nu==0 else[2,1],R),-1))
 return A,B,N,d,R
GA={};GB={};parts={}
for p in range(1,13):
 for q in range(1,13):
  key=str(p)+','+str(q);A,B,N,d,R=actual_polynomials(p,q);GA[key]=A;GB[key]=B;parts[key]=(N,d,R)
  assert A==CF['grid'][key]and B==CR['grid'][key]
assert set(GA)==set(CF['grid'])and set(GB)==set(CR['grid'])and GB['1,1']==[0]
def operators(v):return[v[0],add(v[1],scale(v[0],-1)),add(add(v[2],scale(times([2,4,1],v[1]),-1)),times([1,4,1],v[0]))]
counts=[]
for grid,C in[(GA,CF),(GB,CR)]:
 jets=[];count=0
 for p in range(1,5):
  for q in range(1,5):
   rows=[operators([grid[str(p+4*i)+','+str(q+4*j)]for i in range(3)])for j in range(3)]
   for i in range(3):
    for j,coeff in enumerate(operators([row[i]for row in rows])):
     assert all(type(c)is int and c>=0 for c in coeff);count+=len(coeff);jets.append(dict(p=p,q=q,op_p=i,op_q=j,coefficients=coeff))
 assert len(jets)==144 and jets==C['jets']and C['negative_jets']==[];counts.append(count)
# Nine local moment calibrations; no extrapolation from this finite table.
for rec in CF['moment_classes']:
 p,q=rec['p_class'],rec['q_class'];k=p+q+1;n=k+1
 C=[[int(abs(i-j)==1)+int(i==j and i in(0,k))for j in range(n)]for i in range(n)]
 W=[[int(i==p+1)-int(i==0),int(i==k)-int(i==p)]for i in range(n)]
 CW=mm(C,W);G=[[sum(row[a]*row[b]for row in CW)for b in range(2)]for a in range(2)]
 assert G==rec['gram']and F(5*(G[0][0]+G[1][1])-8*G[0][1],18)==F(rec['m2'])
# Every full tail cell: formula is bounded throughout its interval.
eps=F(CF['epsilon']);unit=int(CF['dyadic_scale']);num=CF['tail_cell_count'];assert eps==F(5,8)and unit==2**80 and num==256
assert len(CF['tail_cells'])==num;previous=F(0);tail=F(0)
for j,cell in enumerate(CF['tail_cells']):
 assert cell['index']==j;lo=F(j,num)/eps;hi=F(j+1,num)/eps;assert lo==previous and hi>lo
 gl=1/(3*(1+hi*hi)**2);hu=1+1/(9*(1+2*lo*lo));rad=1+2*lo*lo*(gl+hu)
 sl=F(int(cell['sqrt_floor_integer']),unit);sh=sl+F(1,unit);assert sl>0 and sl*sl<=rad<sh*sh
 value=2*(gl+hu)/(1+sl)-gl;vu=F(int(cell['integrand_upper_integer']),unit);assert vu-F(1,unit)<value<=vu and value>=0
 tail+=(hi-lo)*vu;previous=hi
assert previous==1/eps and tail==F(CF['tail_upper'])
atanlo=sum(((-1)**j*F(5,16)**(2*j+1)/F(2*j+1)for j in range(8)),F(0));assert atanlo==F(CF['atan_lower'])
J=F(22,7)*eps*eps/2+2*eps-(eps*eps+4)*atanlo+tail
assert J==F(CF['J_upper'])and 100*J/157==F(CF['debt_upper'])and J<F(46,25)
assert F(184,157)<F(59,50)
assert 1+F(4,32)<=F(32,10)and F(1024,1028)>=F(99,100)
assert F(7,11)*(F(3168,1681)-F(46,25))>F(1,50)
# Reuse complete actual state columns as DATA and verify every required equation.
sp=P.parent/'mop-fork-parent-bridge-20261105/rigidity-certificate.json';sr=sp.read_bytes();assert hashlib.sha256(sr).hexdigest()=='4c7a73c2f5f76db9e3b4d84844dba4c5073dc976653bad68865b50942591004f'
SC=json.loads(sr);Ki=[[F(2,3),F(-1,3)],[F(-1,3),F(2,3)]];Ki2=mm(Ki,Ki);controls=[]
for rec in SC['states']:
 p,q=rec['p'],rec['q'];k=p+q+1;n=k+1;C=[[int(abs(i-j)==1)+int(i==j and i in(0,k))for j in range(n)]for i in range(n)];W=[[int(i==p+1)-int(i==0),int(i==k)-int(i==p)]for i in range(n)]
 for row in rec['positive_t_columns']:
  t=F(row['t']);Re=[[F(z[0])for z in zrow]for zrow in row['entries']];Im=[[F(z[1])for z in zrow]for zrow in row['entries']]
  CRi,CRr=mm(C,Im),mm(C,Re)
  assert all(t*Re[i][a]-CRi[i][a]==W[i][a]and t*Im[i][a]+CRr[i][a]==0 for i in range(n)for a in range(2))
  Sre=[[sum(W[i][a]*Re[i][b]for i in range(n))/2 for b in range(2)]for a in range(2)]
  Sim=[[sum(W[i][a]*Im[i][b]for i in range(n))/2 for b in range(2)]for a in range(2)]
  assert Sre[0][1]==Sre[1][0]and Sim[0][1]==Sim[1][0]
  x=t*t;minus_a=-tr(mm(Ki,Sim));qq=tr(mm(Ki2,Sre))/t;beta=tr(mm(mm(mm(Ki,Sre),Ki),Sre))+tr(mm(mm(mm(Ki,Sim),Ki),Sim))
  assert minus_a>=x/(3*(x+1)**2)and 0<=beta<=qq<=1/x+1/(9*(x+2))
  if(p,q)==(1,1):assert qq==1/x+1/(9*(x+2))
  N,d,R=parts[str(p)+','+str(q)];ev=lambda a:sum(v*x**j for j,v in enumerate(a))
  assert minus_a==ev(N)/(3*ev(d))and qq==ev(R)/(18*x**(k%2)*ev(d))
  controls.append(dict(p=p,q=q,t=str(t),negative_trace=str(minus_a),beta=str(beta),weighted_real_trace=str(qq),whole_required_column_residual_zero=True,Fork_real_upper_equality=(p,q)==(1,1)))
assert len(controls)==3
out=dict(status='PASS_ALL_LENGTH_QUANTITATIVE_TRACE_AND_FORK_RESOLVENT',floor_certificate_sha256=hashlib.sha256(rawf).hexdigest(),resolvent_certificate_sha256=hashlib.sha256(rawr).hexdigest(),actual_moment_pairs=144,cone_jets=288,nonnegative_coefficients_by_family=counts,tail_cells=256,Jstar_lt='46/25',uniform_branch_debt='184/157<59/50',longarm_alpha_threshold=1024,longarm_surplus_gt='1/50',sharp_Fork_real_resolvent=True,actual_state_controls=controls,original='GLOBAL_OPEN',Fork6='OPEN',global_compensation='OPEN',global_ledger='F>=2n-(184/157)b(T) at EXACT inherited B71 boundary')
print(json.dumps(out))
