from pathlib import Path
import json,copy,sys,subprocess
P=Path(__file__).resolve().parent;F=json.loads((P/'floor-certificate.json').read_text());R=json.loads((P/'resolvent-certificate.json').read_text());out=[]
for label in('corrupt-floor-polynomial','missing-real-resolvent-jet','tail-gap'):
 A,B=copy.deepcopy(F),copy.deepcopy(R)
 if label=='corrupt-floor-polynomial':A['grid']['1,1'][0]+=1
 elif label=='missing-real-resolvent-jet':B['jets'].pop()
 else:A['tail_cells'][30]['index']=31
 a=P/(label+'-floor.json');b=P/(label+'-real.json');a.write_text(json.dumps(A,separators=(',',':')));b.write_text(json.dumps(B,separators=(',',':')))
 r=subprocess.run([sys.executable,'-B','-X','utf8',str(P/'read_quantitative.py'),str(a),str(b)],capture_output=True,text=True);assert r.returncode!=0
 out.append(dict(label=label,exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr))
(P/'damage-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(status='PASS_THREE_QUANTITATIVE_DAMAGE_REJECTIONS',cases=[dict(label=z['label'],exit_code=z['exit_code'])for z in out])))
