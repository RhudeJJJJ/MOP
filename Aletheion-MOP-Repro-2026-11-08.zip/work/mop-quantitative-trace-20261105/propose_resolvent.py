from pathlib import Path
import json
P=Path(__file__).resolve().parent
def tr(a):
 if not a:return[0]
 while len(a)>1 and a[-1]==0:a.pop()
 return a
def add(a,b):return tr([(a[i]if i<len(a)else 0)+(b[i]if i<len(b)else 0)for i in range(max(len(a),len(b)))])
def sc(a,s):return tr([s*x for x in a])
def mul(a,b):
 c=[0]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):c[i+j]+=x*y
 return tr(c)
D=[[1],[0,1]]
for j in range(2,26):D.append(add([0]+D[-1],D[-2]))
def U(p):
 re=[0];im=[0]
 for r in range(p+1):
  if r%2==0:re=add(re,sc(D[p-r],1 if r%4==0 else -1))
  else:im=add(im,sc(D[p-r],-1 if r%4==1 else 1))
 return re,im
grid={}
for p in range(1,13):
 for q in range(1,13):
  rp,ip=U(p);rm,im=U(p-1);rq,iq=U(q);rn,inn=U(q-1)
  aa=add(sc(mul(D[q],rp),2),mul(D[q-1],add(rm,sc(ip,-1))))
  bb=add(sc(mul(D[p],rq),2),mul(D[p-1],add(rn,sc(iq,-1))))
  unit=[rp,ip,sc(rp,-1),sc(ip,-1)][q%4]
  ab=add(add(unit,mul(D[q],rp)),sc(mul(D[q+1],rm),-1))
  num=add(sc(add(aa,bb),5),sc(ab,-8));k=p+q+1;nu=k%2
  assert all(v==0 for j,v in enumerate(num)if j%2!=1-nu)
  rnum=tr(num[1-nu::2]);d=D[k][nu::2]
  grid[str(p)+','+str(q)]=add(mul([36,20],d),sc(mul(([0,2,1]if nu==0 else [2,1]),rnum),-1))
def op(v):return[v[0],add(v[1],sc(v[0],-1)),add(add(v[2],sc(mul([2,4,1],v[1]),-1)),mul([1,4,1],v[0]))]
jets=[]
for p in range(1,5):
 for q in range(1,5):
  rows=[op([grid[str(p+4*i)+','+str(q+4*j)]for i in range(3)])for j in range(3)]
  for i in range(3):
   for j,c in enumerate(op([row[i]for row in rows])):jets.append(dict(p=p,q=q,op_p=i,op_q=j,coefficients=c))
bad=[z for z in jets if min(z['coefficients'])<0];out=dict(status='PROPOSAL_ONLY',grid=grid,jets=jets,negative_jets=bad)
(P/'resolvent-certificate.json').write_text(json.dumps(out,separators=(',',':')))
print(json.dumps(dict(status='PROPOSED_FORK_RESOLVENT_UPPER',jets=len(jets),negative_jets=len(bad),first_bad=bad[:3],bytes=(P/'resolvent-certificate.json').stat().st_size)))
