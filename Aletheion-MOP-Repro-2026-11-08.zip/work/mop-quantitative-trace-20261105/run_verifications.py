from pathlib import Path
import json,sys,time,subprocess
P=Path(__file__).resolve().parent
for name in('read_quantitative','check_damage'):
 start=time.monotonic();r=subprocess.run([sys.executable,'-B','-X','utf8',str(P/(name+'.py'))],capture_output=True,text=True,encoding='utf-8')
 (P/(name+'.stdout.json')).write_text(r.stdout,encoding='utf-8');(P/(name+'.stderr.txt')).write_text(r.stderr,encoding='utf-8')
 out=dict(argv=[sys.executable,'-B','-X','utf8',str(P/(name+'.py'))],exit_code=r.returncode,wall_time_seconds=time.monotonic()-start,stdout=r.stdout,stderr=r.stderr)
 (P/(name+'.process.json')).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
 if r.returncode:sys.exit(r.returncode)
