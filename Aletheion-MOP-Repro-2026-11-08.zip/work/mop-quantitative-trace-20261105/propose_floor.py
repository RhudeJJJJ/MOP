from pathlib import Path
import json,hashlib
from fractions import Fraction as F
from math import isqrt
P=Path(__file__).resolve().parent;old=P.parent/'mop-weighted-state-trace-20261105/trace-certificate.json'
assert hashlib.sha256(old.read_bytes()).hexdigest()=='f85325fbb03ba5e2750a6c7aea0536289d75fc532af94da35ddee0c480a151e9'
C=json.loads(old.read_text())
def tr(a):
 if not a:return[0]
 while len(a)>1 and a[-1]==0:a.pop()
 return a
def add(a,b):return tr([(a[i]if i<len(a)else 0)+(b[i]if i<len(b)else 0)for i in range(max(len(a),len(b)))])
def sc(a,s):return tr([s*x for x in a])
def mul(a,b):
 v=[0]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):v[i+j]+=x*y
 return tr(v)
D=[[1],[0,1]]
for j in range(2,26):D.append(add([0]+D[-1],D[-2]))
grid={}
for p in range(1,13):
 for q in range(1,13):
  key=str(p)+','+str(q);k=p+q+1;d=D[k][k%2::2]
  grid[key]=add(mul([1,2,1],C['grid'][key]),sc([0]+d,-1))
def ops(v):return[v[0],add(v[1],sc(v[0],-1)),add(add(v[2],sc(mul([2,4,1],v[1]),-1)),mul([1,4,1],v[0]))]
jets=[]
for p in range(1,5):
 for q in range(1,5):
  rows=[ops([grid[str(p+4*i)+','+str(q+4*j)]for i in range(3)])for j in range(3)]
  for i in range(3):
   for j,c in enumerate(ops([row[i]for row in rows])):jets.append(dict(p=p,q=q,op_p=i,op_q=j,coefficients=c))
bad=[z for z in jets if min(z['coefficients'])<0]
moment=[]
for p in(1,2,3):
 for q in(1,2,3):
  k=p+q+1;n=k+1
  CW=[[int(i==p)+int(i==p+2)-int(i==0)-int(i==1),int(i==k-1)+int(i==k)-int(i==p-1)-int(i==p+1)]for i in range(n)]
  G=[[sum(CW[i][a]*CW[i][b]for i in range(n))for b in range(2)]for a in range(2)]
  moment.append(dict(p_class=p,q_class=q,gram=G,m2=str(F(5*(G[0][0]+G[1][1])-8*G[0][1],18))))
eps=F(5,8);N=256;unit=2**80;cells=[];tail=F(0)
for j in range(N):
 lo=F(j,N)/eps;hi=F(j+1,N)/eps;gl=1/(3*(1+hi*hi)**2);hu=1+1/(9*(1+2*lo*lo));rad=1+2*lo*lo*(gl+hu)
 root=isqrt(rad.numerator*unit*unit//rad.denominator);sl=F(root,unit);assert sl*sl<=rad<(sl+F(1,unit))**2
 value=2*(gl+hu)/(1+sl)-gl;vu=(value.numerator*unit+value.denominator-1)//value.denominator
 assert F(vu,unit)>=value>=0;tail+=(hi-lo)*F(vu,unit);cells.append(dict(index=j,sqrt_floor_integer=str(root),integrand_upper_integer=str(vu)))
atanlo=sum(((-1)**j*F(5,16)**(2*j+1)/F(2*j+1)for j in range(8)),F(0));J=F(22,7)*eps*eps/2+2*eps-(eps*eps+4)*atanlo+tail
out=dict(status='PROPOSAL_ONLY',grid=grid,jets=jets,negative_jets=bad,moment_classes=moment,epsilon=str(eps),dyadic_scale=str(unit),tail_cell_count=N,tail_cells=cells,tail_upper=str(tail),atan_lower=str(atanlo),J_upper=str(J),debt_upper=str(100*J/157))
(P/'floor-certificate.json').write_text(json.dumps(out,separators=(',',':')))
print(json.dumps(dict(status='PROPOSED_QUANTITATIVE_TRACE_FLOOR',jets=len(jets),negative_jets=len(bad),J_lt_183_100=J<F(183,100),J_lt_37_20=J<F(37,20),debt_lt_6_5=100*J/157<F(6,5),longarm32_bonus=F(7,11)*(F(99*32,1681)-J)>F(1,50),bytes=(P/'floor-certificate.json').stat().st_size)))
