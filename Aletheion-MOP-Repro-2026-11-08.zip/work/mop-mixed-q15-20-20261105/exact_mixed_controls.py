from fractions import Fraction as F
from pathlib import Path
import sys
import mixed_interval as m
c=m.c;P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'mop-mixed-q2-uniform-20261105'));from exact_controls import inverse,inside,a,n,d
def actual(p,q):
 k=p+q+1;aroot=k;broot=k+1;left=list(range(1,p+1));right=list(range(p+1,k))
 edge=lambda a,b:tuple(sorted((a,b)))
 e={edge(aroot,broot),edge(aroot,0),edge(broot,0),edge(0,p),edge(broot,p+1)}|{edge(aroot,j)for j in left}|{edge(0,j)for j in right}|{edge(j,j+1)for j in range(1,p)}|{edge(j,j+1)for j in range(p+1,k-1)}
 boundary=[aroot]+left+[0]+list(reversed(right))+[broot]
 c.h.rat.prior.outer_graph(k+2,e,boundary)
 B=[[F(int(i!=j and edge(i,j)in e))for j in range(k)]for i in range(k)];T=[[F(int(edge(root,j)in e))for j in range(k)]for root in(aroot,broot)]
 assert T==[[F(int(j<=p))for j in range(k)],[F(int(j in(0,p+1)))for j in range(k)]]
 assert sum(B[i][j]for i in range(k)for j in range(i))==p+2*q-1
 assert sum(x*x for row in T for x in row)==p+3 and len(e)-1==2*k
 whole=e|{edge(k+2,aroot),edge(k+2,broot)};priv=set(range(k));roots={aroot,broot}
 assert all(not(set(z)&priv)or set(z)<=priv|roots for z in whole)
 return B,T
def controls():
 total=0
 for q in range(15,21):
  for p in(2,3,4,5):
   B,T=actual(p,q);k=len(B);r=p
   for t in(F(1),F(4)):
    inv=inverse([[(t if i==j else F(0),B[i][j])for j in range(k)]for i in range(k)])
    cap=[[tuple(sum(T[i][u]*inv[u][v][part]*T[j][v]for u in range(k)for v in range(k))for part in range(2))for j in range(2)]for i in range(2)]
    prev,cur=F(1),t
    for j in range(2,p+1):prev,cur=cur,t*cur+prev
    f=prev/cur;phase=[(1,0),(0,-1),(-1,0),(0,1)][(p-1)%4];e=(F(phase[0],cur),F(phase[1],cur));hh=c.C(f/(1+f));jj=(c.C(e[0]/(1+f)),c.C(e[1]/(1+f)))
    raw=m.compact_raw(c.C(t),r,hh,jj,q)
    for i in range(2):
     for j in range(2):
      for part in range(2):inside(cap[i][j][part],raw[i][j][part])
    if t==4:
     H=c.C(f/(1+f)*t);J=(c.C(e[0]/(1+f)*t),c.C(e[1]/(1+f)*t*t));raw=m.tail_raw(c.C(1/t),r,H,J,q)
     for i in range(2):
      for j in range(2):
       for part in range(2):inside(cap[i][j][part],(raw[i][j][part][0]/t**(part+1),raw[i][j][part][1]/t**(part+1)))
    total+=1
 for q in range(15,21):
  for p in range(2,14):actual(p,q)
 return dict(exact_direct_response_controls=total,actual_closed_unit_cap_controls=72)
if __name__=='__main__':print(controls())
