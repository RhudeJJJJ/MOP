from pathlib import Path
from fractions import Fraction as F
import json,time,heapq
import mixed_interval as m
P=Path(__file__).resolve().parent
def slab(region,r,q,a,b,nv):
 rows=[]
 for j in range(nv):
  lo,hi=m.enclosure(region,r,q,a,b,F(j,nv),F(j+1,nv));rows.append([str(F(j,nv)),str(F(j+1,nv)),str(lo),str(hi)])
 return dict(a=str(a),b=str(b),v=rows,lower=str(max(F(x[2])for x in rows)),upper=str(max(F(x[3])for x in rows)))
def integrate(r,q,nv=8):
 leaves={};heap=[];counter=0;upper=F(0);cells=0
 def insert(region,a,b,depth=0):
  nonlocal counter,upper,cells
  try:row=slab(region,r,q,a,b,nv)
  except (ArithmeticError,AssertionError):
   assert depth<24,(q,r,region,str(a),str(b),'inspect sign or parameter-dependency rather than infinite subdivision')
   mid=(a+b)/2;insert(region,a,mid,depth+1);insert(region,mid,b,depth+1);return
  row['region']=region;leaves[counter]=row;high=(b-a)*F(row['upper']);low=(b-a)*F(row['lower']);upper+=high;cells+=nv
  heapq.heappush(heap,(-(high-low),counter));counter+=1
 stops=[F(1,100),F(1,50),F(1,25),F(2,25),F(4,25),F(8,25),F(16,25),F(1),F(2),F(4)]
 for a,b in zip(stops,stops[1:]):
  for j in range(4):insert('compact',a+(b-a)*j/4,a+(b-a)*(j+1)/4)
 for j in range(8):insert('tail',F(j,32),F(j+1,32))
 print(json.dumps(dict(q=q,r=r,stage='initial',upper=float(upper),slabs=len(leaves))),flush=True);last=time.time()
 while upper>=6:
  _,key=heapq.heappop(heap);row=leaves.pop(key);a,b=F(row['a']),F(row['b']);upper-=(b-a)*F(row['upper']);mid=(a+b)/2
  insert(row['region'],a,mid);insert(row['region'],mid,b)
  if time.time()-last>35:print(json.dumps(dict(q=q,r=r,stage='refining',upper=float(upper),slabs=len(leaves),cells_evaluated=cells)),flush=True);last=time.time()
  assert len(leaves)<15000,'inspect v-width before expensive repetition'
 rows=sorted(leaves.values(),key=lambda z:(z['region'],F(z['a'])))
 return dict(q=q,r=r,nv=nv,leaves=rows,upper=str(upper),cells=len(rows)*nv,evaluated=cells)
def main():
 out=[]
 for q in range(15,21):
  for r in(2,3,4,5):
   data=integrate(r,q);out.append(data);(P/f'q{q}-r{r}-certificate.json').write_text(json.dumps(data,separators=(',',':'))+'\n')
   print(json.dumps(dict(q=q,r=r,status='PRODUCED_NOT_YET_FULLY_READ',upper=float(F(data['upper'])),cells=data['cells'])),flush=True)
 (P/'mixed-certificates.json').write_text(json.dumps(dict(format='q15to20-four-residue-full-v-epsilon-to-infinity-v1',curves=out),separators=(',',':'))+'\n')
if __name__=='__main__':main()
