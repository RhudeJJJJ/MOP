from pathlib import Path
from fractions import Fraction as F
import json,hashlib,copy,sys
import mixed_interval as m
from exact_mixed_controls import controls
P=Path(__file__).resolve().parent;c=m.c
def curve(row,recompute=True):
 assert row['q']in range(15,21)and row['r']in(2,3,4,5);total=F(0);cells=0
 for region,start,end in [('compact',F(1,100),F(4)),('tail',F(0),F(1,4))]:
  pos=start;rows=[z for z in row['leaves']if z['region']==region];assert rows
  for z in rows:
   a,b=F(z['a']),F(z['b']);assert a==pos and a<b<=end;pos=b;vp=F(0);uppers=[];lowers=[]
   for cell in z['v']:
    v,w,lo,hi=map(F,cell);assert v==vp and 0<=v<w<=1 and lo<=hi;vp=w
    if recompute:assert m.enclosure(region,row['r'],row['q'],a,b,v,w)==(lo,hi)
    uppers.append(hi);lowers.append(lo);cells+=1
   assert vp==1 and len(z['v'])==row['nv'] and max(uppers)==F(z['upper'])and max(lowers)==F(z['lower'])
   total+=(b-a)*max(uppers)
  assert pos==end
 assert all(z['region']in('compact','tail')for z in row['leaves'])
 assert total==F(row['upper'])<6 and cells==row['cells'];return total,cells
def membership(rows):assert [(z['q'],z['r'])for z in rows]==[(q,r)for q in range(15,21)for r in(2,3,4,5)]
def gram(row):
 q=row['q'];assert q in range(15,21);k=q+1;W=row['factor'];D=row['denominator'];assert len(W)==k and all(len(line)==k and all(type(x)is int for x in line)for line in W)
 Z=c.h.mm(W,c.h.tr(W));G=c.h.mm(c.h.tr(W),W);edges={(0,j)for j in range(1,k)}|{(j,j+1)for j in range(1,k-1)}
 value=F(4*sum(Z[a][b]for a,b in edges),D**2)-F(sum(x*x for line in G for x in line),D**4)
 assert value>2*q+F(23,5);return dict(q=q,fan_F_lower=str(value),private_surplus_lower=str(value-2*q))
def low_contract(epsilon,cost):assert epsilon==F(1,100)and cost==2*epsilon**2
def shaving(p,r):assert p>=2 and r in(2,3,4,5)and p>=r and(p-r)%4==0
def rejected(fn):
 try:fn()
 except (AssertionError,ArithmeticError):return True
 return False
def main():
 data=json.loads((P/'mixed-certificates.json').read_text());assert data['format']=='q15to20-four-residue-full-v-epsilon-to-infinity-v1';membership(data['curves']);bounds=[];cells=0
 for row in data['curves']:
  upper,n=curve(row);bounds.append(dict(q=row['q'],r=row['r'],upper=str(upper),cells=n));cells+=n
  print(json.dumps(dict(q=row['q'],r=row['r'],recomputed_cells=n,upper=float(upper))),flush=True)
 gd=json.loads((P/'six-fan-grams.json').read_text())['cases'];assert[z['q']for z in gd]==list(range(15,21));scores=[gram(z)for z in gd]
 checks=controls();sys.path.insert(0,str(P.parent/'mop-mixed-q2-uniform-20261105'));from read import oldsmall
 small=oldsmall();assert len(small)==64;low=F(1,5000);low_contract(F(1,100),low)
 for p in range(2,100):shaving(p,2+(p-2)%4)
 L,U=c.h.machin_pi();assert L>F(157,50);margin=F(23,5)-F(600,157)-low;assert margin>F(3,4)
 bad=copy.deepcopy(data['curves'][0]);bad['leaves'][0]['v'].pop();tail=copy.deepcopy(data['curves'][0]);tail['leaves']=[z for z in tail['leaves']if z['region']!='tail'];broken=copy.deepcopy(gd[0]);broken['factor']=[[0]*16 for _ in range(16)]
 damage=dict(missing_v_cell=rejected(lambda:curve(bad,False)),missing_whole_tail=rejected(lambda:curve(tail,False)),missing_qr_family=rejected(lambda:membership(data['curves'][:-1])),broken_fan_Gram=rejected(lambda:gram(broken)),omitted_low_t_cost=rejected(lambda:low_contract(F(1,100),F(0))),negative_shaving_coefficient=rejected(lambda:shaving(2,3)))
 assert all(damage.values())
 out=dict(status='PASS_EXACT_ALL_SIX_MIXED_INWARD_LENGTHS_ALL_OUTWARD_P',fully_recomputed_cells=cells,curve_bounds=bounds,six_fan_full_norm_Grams=scores,low_t_uniform_energy_cost=str(low),margin_lower=str(margin),universal_increment='>2(p+q+1)+3/4 for EVERY p>=2,q15..20, ANYoldUNITMOPorder>=3/orderedboundary; noolddegree/order upperbound',controls=checks,small_old_domination_cases=64,damaged_rejected=damage,structural_effect='EVERYdeepestbranch inminimal originalcounter n>=72admits external/external fanapices. All mixed assignments excluded or triangle-representable externally; descriptions not disjoint. Oldsmallh2..7 useswholegamma4 with its named inheritedinputs.',original_status='GLOBAL_OPEN',external_external='OPEN, includes unrestricted balanced Fork6',source_scope='Written all-order continued-fraction/shaving/Schur identities and rank-two accretive low-phase proof; exact full parameter/integral coverage. Shared interval/algebra helpers, noexternalformalreview or exhaustivepriorityclaim.',proof_sha256=hashlib.sha256((P/'all-mixed-payment-proof.md').read_bytes()).hexdigest(),certificate_sha256=hashlib.sha256((P/'mixed-certificates.json').read_bytes()).hexdigest())
 (P/'reader-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:out[k]for k in('status','fully_recomputed_cells','margin_lower','damaged_rejected','original_status')}))
if __name__=='__main__':main()
