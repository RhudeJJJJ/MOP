"""All-p four-curve extension for q15..20; low t handled by rank-two phase."""
from pathlib import Path
from fractions import Fraction as F
import sys
from functools import lru_cache
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'mop-mixed-q2-uniform-20261105'));import curve_interval as c
C=c.C;add=c.add;sub=c.sub;mul=c.mul;div=c.div;sq=c.sq;scale=c.scale;sqrt=c.sqrt
ca=c.ca;cs=c.cs;cm=c.cm;cd=c.cd;cr=c.cr;real=c.real
def iz(a,y):return c.h.neg(mul(y,a[1])),a[0]
@lru_cache(maxsize=8192)
def right(t,q):
 f=div(C(1),t);e=(f,C(0))
 for j in range(2,q+1):
  den=add(t,f);f=div(C(1),den);e=(div(e[1],den),c.h.neg(div(e[0],den)))
 Z=(t,C(2));fg=ca(real(f),e);g=cd(ca(real(C(1)),(c.h.neg(fg[1]),fg[0])),Z)
 S=ca(cd(real(C(q)),Z),cd(cr((c.h.neg(g[1]),g[0]),C(2)),Z))
 #Physical resolvent of a real symmetric path: Re(1^T C 1)>0.
 S=(c.h.positive(S[0]),S[1]);B=(add(C(1),g[1]),c.h.neg(g[0]));return f,S,B
def compact_raw(t,r,hh,j,q):
 f,S,B=right(t,q);o=sub(C(1),hh);Z=(t,C(2));D=ca(cr(ca(real(t),S),o),real(hh))
 N0=ca((sub(sq(t),C(2)),scale(t,4)),cr((c.h.neg(S[1]),S[0]),C(2)))
 Nf=cs((t,C(4)),cr(S,C(2)));Ne=cs((C(0),C(2)),cr(S,C(2)))
 N=ca(ca(cr(N0,o),cr(Nf,hh)),cm(Ne,j))
 faa=ca(cd(real(C(r)),Z),cd(N,cm(cm(Z,Z),D)))
 An=ca(ca(cr((t,C(1)),o),real(hh)),j)
 fab=cd(cm(An,B),cm(Z,D));fbb=ca(real(f),cd(cr(cm(B,B),o),D))
 return [[faa,fab],[fab,fbb]]
@lru_cache(maxsize=8192)
def right_tail(z,q):
 y=sq(z);prev,cur=c.pathpol(z,q,True);fq=div(prev,cur);mag=div(c.powi(z,q-1),cur)
 E=(scale(mag,-1 if q%4==3 else 1),C(0))if q%2 else(C(0),scale(div(c.powi(z,q-2),cur),-1 if q%4==2 else 1))
 Z=(C(1),C(2));G=cd(ca(real(C(1)),iz(ca(real(fq),E),y)),Z,y)
 S=ca(cd(real(C(q)),Z,y),cd(cr(iz(G,y),C(2)),Z,y));B=cs(real(C(1)),iz(G,y))
 return fq,S,B
def tail_raw(z,r,H,J,q):
 y=sq(z);o=sub(C(1),mul(z,H));fq,S,B=right_tail(z,q);Z=(C(1),C(2))
 D=ca(cr(ca(real(C(1)),cr(S,y)),o),real(mul(y,H)))
 N0=ca((sub(C(1),scale(y,2)),C(4)),cr(iz(S,y),scale(y,2)))
 Nf=cs((C(1),C(4)),cr(S,scale(y,2)))
 N=ca(ca(cr(N0,o),cr(Nf,mul(y,H))),cs(cr(iz(J,y),scale(y,2)),cr(cm(S,J,y),scale(sq(y),2))))
 uaa=ca(cd(real(C(r)),Z,y),cd(N,cm(cm(Z,Z,y),D,y),y))
 An=ca(ca(cr((C(1),C(1)),o),real(mul(y,H))),cr(J,y))
 uab=cd(cm(An,B,y),cm(Z,D,y),y);ubb=ca(real(fq),cd(cr(cm(B,B,y),o),D,y))
 return [[uaa,uab],[uab,ubb]]
def enclosure(region,r,q,a,b,v,w):
 assert r in(2,3,4,5)and q in range(15,21) and 0<=v<w<=1 and a<b
 x=(F(a),F(b));vv=(F(v),F(w))
 if region=='compact':
  assert F(1,100)<=a<b<=4
  H,J=c.compact_params(x,r,vv);return c.support(x,compact_raw(x,r,H,J,q))
 assert region=='tail'and 0<=a<b<=F(1,4)
 H,J=c.tail_params(x,r,vv);return c.tail_support(x,tail_raw(x,r,H,J,q))
