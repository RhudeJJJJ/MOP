# A complete actual removal grammar and one debt per dual branch

5 November 2026. The original target remains EVERY finite simple UNIT
maximal outerplanar graph G,n>=8: F(G)=splus(G)>=2n, equivalently D>=6.
GLOBAL OPEN; goal ACTIVE. This note assembles the already proved universal
payments into a terminating, all-graph removal procedure. It proves a
quantitative global lower bound with a branch correction, at the stated
inherited finite-base boundary. It does NOT compensate every branch debt.

1. Units, hypotheses, and the result. Fix an outerplane embedding of G.
Its weak dual T has one vertex for each bounded triangular face, with
adjacency exactly when two faces share an internal edge. T is a tree
of maximum degree three. Let b(T) be the number of its UNROOTED degree-three
vertices. Counts use actual faces in ONE graph, not possible apex assignments,
isomorphic cap types, or overlapping extraction candidates. Such assignments
can describe the same cap and must not be counted as different branches.

Write e(G)=F(G)-2|G| and c=130966/69237<19/10. Use the named inherited
original finite cover B71: F(H)>=2|H| for every UNIT MOP with 8<=|H|<=71.
This note does not freshly replay B71 or remove its declared source boundary.
All other ingredients used below are previously proved universal increments
or explicit whole-graph bounds; no desired all-order 2n claim is assumed.

THEOREM (with precisely B71 as finite input). Every UNIT MOP G,n>=8 has

                 F(G)>=2n-c b(T)>=2n-(19/10)b(T).       (1)

The first inequality is strict if n>=72, and is also strict when b(T)>0.
More information is retained by an actual serial ledger. There is a finite
chain G=G0,G1,...,Gr=H of actual induced MOPs, all of order>=8, ending
either at B71 or at an explicitly whole-paid graph. For B actual external/
external debt removals and individually justified positive credits gamma_i,

 e(G) >= e(H)+sum_i gamma_i-c B,       B<=b(T).          (2)

The inequality is strict if the chain is nonempty. One may take gamma_i=0
for each positive removal; specified stronger credits are retained below.
If the final graph is whole-paid its actual known nonnegative reserve can
replace e(H). There is NO assertion that e(H)+sum gamma_i>=cB always holds.
That is a still-open sufficient compensation obligation for the original
target on a suitably chosen actual sequence. Complete coverage is now
separate from this inequality; coverage alone does not imply compensation.

2. Legal geometry and termination. Root the current weak dual at a leaf
face, using one of that face's boundary edges as the external root. In a
nontrivial tree a rooted vertex with two children has unrooted degree three;
the root has at most one child. A closed terminal cap is the side of a chord
consisting of a connected terminal subtree, retaining the two chord ends.
The private vertices have NO contacts outside that cap except these roots.
Deleting its k private vertices leaves the complementary induced MOP (or
an auxiliary K2) and deletes precisely k faces and 2k edges. Remaining faces
and adjacencies are exactly an induced connected subtree of the old dual.
Every actual deletion below is of this form, including a two-vertex tip.
Thus dual degree cannot increase. Rerooting does not change its unrooted
degree counts. Each deletion lowers graph order, ensuring termination.

Run the following procedure only when current n>=72. Stop as soon as the
current order is 8..71. Small-old cases below are whole stops rather than
deletions into an unpaid graph of order2..7.

3. Terminal unary paths, before any branch classification. Follow each
leaf upwards until the first branching face (excluded), or through the
root if the entire dual is a path. Keep actual chord roots on each prefix.
One or two triangles always form a fan with an external apex. As long as
a prefix is such a fan, its triangles have the form
u,v0,v1; u,v1,v2; ...; u,v_(ell-1),v_ell, with rootuv0.
Across this root the next triangle u,v0,x either preserves external apexu
(parent rootux), or makes u private (parent rootv0x). The latter is the
FIRST turn. For ell>=2 the new cap has L=ell+1 private vertices and is
exactly fan_L with rootsa=v0,b=x and contactsau,av1,bu. No other contacts
are possible by chord separation. For the ambiguous one-triangle prefix
choose the external apex of the two-triangle prefix first.

At L3 this is the previously proved private-K3 triangle wing, gaining
>6.07 for three vertices. At L4 it is literally singular turn D, or its
WHOLE coherent reflection, gaining>8.3 for four vertices. For example,
the canonical outer order a,v1,v2,v3,u,b gives edges
01,12,23,34,45,05,14,24,04, identical to D in its own outer order
0,1,5,4,2,3. This is edge identity with root roles retained, not equality
of private spectra alone. At every L>=5 it is the universal first-turn
private-fan theorem, gaining>2L. All increments apply to ANY actual old
UNIT MOP of order>=3, independently of old degree, order or spectrum.

If old order h>=8, remove this cap with strictly positive surplus. If
h2..7, currentn>=72 forces L>=65. The prior small-core bound
F(H)>=2h-3 and analytic private-fan floor F(fan_L)>2L+4 pay the WHOLE
current graph by disjoint-principal-block superadditivity, with reserve>1.
Stop there. Thus a terminal nonfan always supplies an actual valid step
or a whole stop; minimal-counter reasoning is not needed by this procedure.

4. If no terminal path turns, choose a deepest branch. Its two child
subtrees contain no further branches, and by step3 each is a straight
external-apex fan relative to its own closing edge. In roottrianglea,b,c,
c private, the left ac-child has p>=1 faces and the right cb-child q>=1.
Their apices can be a/c and c/b respectively. These four POSSIBLE
assignments overlap when a child is a single triangle. Use one valid
assignment, never a multiplicity count. Put d=p+q,k=d+1, and let H be
the complement of the whole branch.

4a. Both child apices can be c. For d>=17 the private graph
B=c join(Pp disjoint Pq) satisfies F(B)>2k+R(d), R(d)>0. For d16 the
15 ordered private integer Gram certificates each give F(B)>34=2k.
Block pinching therefore gives a positive increment without assuming a
global theorem for H. If d<=15 and max(p,q)>=3, use the last two vertices
of a long child instead. This is an actual C0 tip with whole root degrees
d+2 and3, summing d+5<=20. The universal bounded-root theorem256 gives
increment>4.01. Here its actual old order is n-2>=70, so the excluded
rank-one triangle Gram cannot occur. The roots are private to the large
branch, and their WHOLE degrees are used. For remaining p,q<=2:
(1,2)/(2,1) are the literal B operation with surplus>0.07;
(2,2) is the private bowtie with surplus>0.8. Only(1,1) is left; both
triangles may choose external apices, so process it in4c.
If h2..7 and n>=72, d>=64. The same private-block bound gives R(d)>3;
F(H)>=2h-3 pays the WHOLE graph instead. No small H is assumed to meet2h.

4b. A mixed assignment, after reflecting the WHOLE graph if necessary,
has external a on the p-child and private c on the q-child. If p1,
reassign that triangle to c and use4a. If q1, reassign it to b and use4c.
Otherwise p,q>=2. For q2 the universal mixed theorem gives surplus>1/20
on the whole k-vertex branch. For3<=q<=14 the right two-vertex tip has
WHOLE root degrees q+3 and3, summing q+6<=20, so256 gives surplus>1/100.
For15<=q<=20 the universal whole-branch theorem gives surplus>3/4.
For q>=21 remove only the q right private vertices: after their removal
the OLD degree of c is EXACTLY3, independently of p. The low-old-degree
fan retirement theorem gives strictly positive surplus. If h>=8 that
last old graph has h+p+1>=11 vertices. If whole-branch h2..7 instead,
the elementary two-disjoint-fans/small-core theorem pays the WHOLE current
graph with reserve>1/10, for everyp,q and currentn>=72. Stop rather than
assuming any desired inequality on the small old core.

4c. Both external apices a,b. If h2..7, the same elementary whole-graph
two-fan theorem gives reserve>1/10. If h>=8, delete the whole branch.
The two-dipole normalization theorem gives

                      e(current)-e(H)>-c.             (3)

This is the ONLY potentially negative operation in the procedure. Count
it as one debt step. Its subtree contains exactly ONE current unrooted
degree-three vertex, the chosen branch, because both children are paths.
That vertex disappears, and no new degree-three vertex is created. If
alpha=max(p-1,q-1)>=max(D0,2601), with D0=max OLD root degrees in H,
the stronger long-arm result gives surplus>1/50: classify this instance
as positive instead of debt. The other arm and the far graph are unbounded.

5. No branch. The current dual is a path. Step3 either finds a first turn
or its complete leaf-to-root path is an external-apex fan. Then the WHOLE
current graph is a fan. At currentn>=72 the analytic fan bound pays2n
strictly; stop. Choosing a different boundary edge at the root may turn
the last prefix into a private fan; its small-old whole case is already
handled by step3. Thus the root choice leaves no uncovered geometry.

6. Count and telescope on ONE sequence. Every debt step removes one
distinct current degree-three face; identify it with its persistent face
in the initial graph. All other steps can only remove more such faces
or reduce their degree. Faces are never reinserted and degree never grows.
This is an injective map from actual debt steps to initial degree-three
faces, proving B<=b(T). Do not substitute candidate counts or four apex
representations for this injection. Sum the proven increments along the
actual removals, in reverse to rebuild the SAME original graph. This
gives(2). The final graph has nonnegative reserve either by B71 or by
the explicit whole stop. Dropping positive credits proves(1). When n>=72
there is at least one strict removal or a strict whole stop. When n<=71
and b(T)>0, B71>=2n>2n-cb(T). These prove the stated strictness claims.

7. Verification and scope. serial_tree_ledger.py reconstructs actual
triangles and their shared-edge dual, uses literal closed cap contacts,
and records each chosen private set, face set, retained edges, root roles,
old degrees and branch count. A separate replay checks actual deletion
identities and the count injection. Finite exhaustive triangulations and
targeted arbitrary-length/random controls calibrate the written geometry;
they are not acceptance by floating eigenvalues or a replay of B71.
The all-order coverage/count/telescoping argument is sections2..6, using
the explicitly named inherited universal payment theorems at their exact
boundaries. Shared graph helpers are declared; no external human/formal
audit, first-payment priority or exhaustive corpus/Drive refresh is claimed.

The original global conjecture, unrestricted nonnegative Fork6 and the
full external/external increment UB remain OPEN. The uniform branch
correction may be weaker than other known bounds on some graphs. This
note makes no optimality or priority claim. Earlier universal C0/barefan,
generic edge-gluing and pointwise phase counterexamples remain valid.
An exact actual ledger with reserve+credits>=cB would pay its graph; a
proof that some such ledger always exists would settle the original
target, but that new existence statement is NOT established here.
