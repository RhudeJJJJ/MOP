"""Replay retained representative ledgers using independent ear peeling.
No floating spectra and no assertion that finite controls prove B71.
"""
from pathlib import Path
from itertools import combinations
from collections import defaultdict
from fractions import Fraction as Q
import copy,json,hashlib
P=Path(__file__).resolve().parent
def key(a,b):return tuple(sorted((a,b)))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def peel(cycle,edges):
    cyc=list(cycle); E={tuple(e)for e in edges}; original=E.copy(); V=set(cyc)
    assert len(V)==len(cyc)>=3 and len(E)==2*len(V)-3
    assert all(a in V and b in V and a<b for a,b in E)
    faces=set(); nb={v:set()for v in V}
    for a,b in E:nb[a].add(b);nb[b].add(a)
    while len(cyc)>3:
        choices=[v for v in cyc if len(nb[v])==2];assert choices
        v=min(choices);j=cyc.index(v);a,b=cyc[j-1],cyc[(j+1)%len(cyc)]
        assert nb[v]=={a,b} and key(a,b)in E
        faces.add(tuple(sorted((a,b,v))))
        for u in (a,b):nb[u].remove(v);E.remove(key(u,v))
        del nb[v];cyc.pop(j)
    assert E=={key(a,b)for a,b in combinations(cyc,2)}
    faces.add(tuple(sorted(cyc)));assert len(faces)==len(V)-2
    owner=defaultdict(list)
    for t in faces:
        for a,b in combinations(t,2):owner[key(a,b)].append(t)
    assert set(owner)==original and all(len(x)in(1,2)for x in owner.values())
    boundary={key(cycle[j],cycle[(j+1)%len(cycle)])for j in range(len(cycle))}
    assert {e for e,ts in owner.items()if len(ts)==1}==boundary
    adj={t:set()for t in faces}
    for ts in owner.values():
        if len(ts)==2:a,b=ts;adj[a].add(b);adj[b].add(a)
    assert sum(map(len,adj.values()))==2*(len(faces)-1)
    initialnb={v:set()for v in V}
    for a,b in original:initialnb[a].add(b);initialnb[b].add(a)
    return faces,adj,initialnb

def path(S,nb):
    assert S and all(len(nb[v]&S)<=2 for v in S)
    assert sum(len(nb[v]&S)for v in S)==2*(len(S)-1)
    seen=set(); todo=[min(S)]
    while todo:
        v=todo.pop()
        if v in seen:continue
        seen.add(v);todo.extend((nb[v]&S)-seen)
    assert seen==S

def private_first_turn(priv,roots,nb):
    L=len(priv);assert L>=3
    for u in priv:
        if not priv-{u}<=nb[u]:continue
        ordinary=priv-{u}
        try:path(ordinary,nb)
        except AssertionError:continue
        for a,b in (roots,roots[::-1]):
            aa=nb[a]&priv;bb=nb[b]&priv
            if len(aa)==2 and u in aa and bb=={u}:
                v=next(iter(aa-{u}));assert len(nb[v]&ordinary)<=1
                return True
    raise AssertionError('not literal first-turn private fan')

def twofans(priv,roots,nb,p,q):
    a,b=roots;common=nb[a]&nb[b]&priv;assert len(common)==1;c=next(iter(common))
    S=priv-{c};comps=[]
    while S:
        comp=set();todo=[min(S)]
        while todo:
            v=todo.pop()
            if v in comp:continue
            comp.add(v);todo.extend((nb[v]&S)-comp)
        comps.append(comp);S-=comp
    assert len(comps)==2
    L=next(x for x in comps if nb[a]&x);R=next(x for x in comps if nb[b]&x)
    assert L!=R and len(L)==p and len(R)==q
    assert not nb[a]&R and not nb[b]&L
    assignments=[]
    for U,root in ((L,a),(R,b)):
        path(U,nb);rt=nb[root]&U;ct=nb[c]&U;opts=[]
        if rt==U and len(ct)==1 and len(nb[next(iter(ct))]&U)<=1:opts.append('E')
        if ct==U and len(rt)==1 and len(nb[next(iter(rt))]&U)<=1:opts.append('I')
        assert opts;assignments.append(opts)
    return {x+y for x in assignments[0]for y in assignments[1]}

def replay(ex):
    cycle=ex['order'].copy();edges={tuple(e)for e in ex['edges']};r=ex['ledger']
    faces,adj,nb=peel(cycle,edges);initial_b=sum(len(adj[t])==3 for t in faces)
    assert r['initial_n']==len(cycle)and r['initial_b']==initial_b
    used=set();count=0;checked=0
    for step in r['steps']:
        faces,adj,nb=peel(cycle,edges);b=sum(len(adj[t])==3 for t in faces)
        assert step['n']==len(cycle)and step['b_before']==b
        kind=step['kind'];priv=set(step['private']);capfaces={tuple(f)for f in step['faces']}
        if kind=='whole-fan':
            assert any(len(nb[v])==len(cycle)-1 for v in cycle)
        else:
            roots=tuple(step['roots']);assert len(set(roots))==2 and not set(roots)&priv
            assert step['k']==len(priv)==len(capfaces)and priv
            U=priv|set(roots);assert key(*roots)in edges
            assert all(nb[v]<=U for v in priv)
            assert {t for t in faces if set(t)<=U}==capfaces
            crossing=[(t,u)for t in capfaces for u in adj[t]if u not in capfaces]
            assert len(crossing)<=1
            if crossing:assert set(crossing[0][0])&set(crossing[0][1])==set(roots)
            if kind.startswith('first-turn-')or kind=='whole-first-turn-small':
                private_first_turn(priv,roots,nb)
            elif kind=='bounded-tip':
                assert len(priv)==2 and key(*priv)in edges
                a,broot=roots;assert nb[a]&priv==priv and len(nb[broot]&priv)==1
                assert sum(len(nb[v])for v in roots)==step['degree_sum']<=20
            elif kind in ('mixed-low-apex','whole-low-apex-small'):
                a,broot=roots;path(priv,nb);assert nb[a]&priv==priv and len(nb[broot]&priv)==1
                assert len(nb[a]-priv)==3
            else:
                p,q=step['p'],step['q'];assert len(priv)==p+q+1
                opts=twofans(priv,roots,nb,p,q)
                if kind in ('external-debt','external-long-arm','whole-external-small'):assert 'EE'in opts
                elif kind.startswith('mixed-')or kind=='whole-mixed-small':
                    assert {'EI','IE'}&opts
                    inward=q if 'EI'in opts else p
                    if kind=='mixed-q2':assert inward==2
                    if kind=='mixed-q15-20':assert 15<=inward<=20
                else:
                    assert 'II'in opts
                    if kind=='private-block':assert p+q>=16
                    elif kind=='private-bowtie':assert p==q==2
                    elif kind=='private-B':assert (p,q)in((1,2),(2,1))
                    else:assert kind=='whole-private-small'
        if kind.startswith('whole-'):
            assert step['threshold']==72
            assert step['energy_threshold_met']==(len(cycle)>=72)
            if kind!='whole-fan':assert 2<=len(cycle)-len(priv)<=7
            assert step is r['steps'][-1]
            checked+=1;break
        remain=[v for v in cycle if v not in priv];newedges={e for e in edges if not priv&set(e)}
        ff,aa,nn=peel(remain,newedges);newb=sum(len(aa[t])==3 for t in ff)
        assert faces-capfaces==ff and len(edges)-len(newedges)==2*len(priv)
        assert step['b_after']==newb<=b and step['old_order']==len(remain)>=8
        assert {tuple(e)for e in step['old_edges']}==newedges
        if kind in('external-debt','external-long-arm'):
            D0=max(len(nn[v])for v in step['roots']);assert D0==step['D0']
            if kind=='external-long-arm':assert max(step['p']-1,step['q']-1)>=max(D0,2601)
        if kind=='external-debt':
            removed={t for t in capfaces if len(adj[t])==3};assert len(removed)==1 and not removed&used
            used|=removed;count+=1;assert b-newb>=1 and step['credit']=='-19/10'
        cycle,edges=remain,newedges;checked+=1
    assert count==r['debt_steps']<=initial_b
    assert cycle==r['base_cycle']and len(cycle)==r['base_order']and edges=={tuple(e)for e in r['base_edges']}
    return checked

def rejects(fn):
    try:fn()
    except (AssertionError,KeyError,StopIteration):return True
    return False

def main():
    r=json.loads((P/'ledger-controls.json').read_text());assert r['status']=='PASS_ACTUAL_POLYGON_DUAL_SERIAL_LEDGER'
    totals=sum(replay(e)for e in r['examples'].values());assert r['graphs']==7853
    c=Q(130966,69237);assert 0<c<Q(19,10)
    debt=copy.deepcopy(r['examples']['external-debt']);debt['ledger']['debt_steps']+=1
    changed=copy.deepcopy(r['examples']['whole-first-turn-small']);st=changed['ledger']['steps'][-1];st['energy_threshold_met']=not st['energy_threshold_met']
    badbranch=copy.deepcopy(r['examples']['external-debt']);badbranch['ledger']['initial_b']+=1
    badcontact=copy.deepcopy(r['examples']['bounded-tip']);badcontact['ledger']['steps'][0]['private'][0]=badcontact['ledger']['steps'][0]['roots'][0]
    badlong=copy.deepcopy(r['examples']['external-long-arm']);next(s for s in badlong['ledger']['steps']if s['kind']=='external-long-arm')['D0']=100000
    damage=dict(candidate_debt_count=rejects(lambda:replay(debt)),small_stop_promoted_below72=rejects(lambda:replay(changed)),
                altered_initial_branch_count=rejects(lambda:replay(badbranch)),private_root_overlap=rejects(lambda:replay(badcontact)),
                altered_old_degree=rejects(lambda:replay(badlong)))
    assert all(damage.values())
    out=dict(status='PASS_INDEPENDENT_EAR_PEELING_REPLAY_AND_SCOPE_GUARDS',producer_graphs=r['graphs'],
      representative_ledgers=len(r['examples']),replayed_steps=totals,operation_counts=r['operation_counts'],damaged_rejected=damage,
      c=str(c),finite_base='B71 inherited, not reaudited',original_status='GLOBAL_OPEN',full_original_goal_complete=False,
      sources={n:digest(P/n)for n in('serial_tree_ledger.py','ledger-controls.json','complete-dual-ledger-proof.md')},
      scope='Reader reconstructs representative actual polygons by ear peeling; producer controls7853graphs. All-order theorem is written proof using named inherited universal payments, not finite extrapolation or external formal audit.')
    (P/'ledger-reader-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
