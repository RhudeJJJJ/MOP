from pathlib import Path
import json,hashlib,sqlite3,shutil,sys,subprocess,time
P=Path(__file__).resolve().parent
DB=Path('C:/Users/jonas/Aletheion/aletheion/aletheion.db')
PRE='math:mop:analytic-gamma2:'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dig(s):return hashlib.sha256(s.encode()).hexdigest()
def rd(p):return json.loads(p.read_bytes())
def save(n,v):(P/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def prepare():
    check=rd(P/'gamma2-check.json');assert check['status']=='PASS_ALL2055_POLYGONS_ALL_ORDERED_DOMINATING_PAIRS_AND_ANALYTIC_TRANSFER_CHECKS'
    assert all(sha(P/n)==h for n,h in check['source_sha256'].items())
    parent='math:mop:fresh-finite71:scope:20261108'
    con=sqlite3.connect('file:'+str(DB)+'?mode=ro',uri=True);con.execute('BEGIN')
    assert not con.execute('select node_id from weave_nodes where node_id like ?',(PRE+'%',)).fetchall()
    body=con.execute('select body from weave_nodes where node_id=?',(parent,)).fetchone()[0];con.rollback();con.close()
    save('parent-snapshot.json',dict(node_id=parent,body=body,sha256=dig(body)))
    shutil.copyfile(P.parent/'mop-finite-input-dp-20261108/run_guarded_native.py',P/'run_guarded_native.py')
    names=['gamma2-analytic-proof.md','check_gamma2_geometry.py','gamma2-check.json','intake_gamma2.py','run_guarded_native.py','parent-snapshot.json']
    files=[dict(name=n,bytes=(P/n).stat().st_size,sha256=sha(P/n),content=(P/n).read_bytes().decode('utf8'))for n in names]
    assert all(len(f['content'].encode())==f['bytes']for f in files)
    nodes=[];edges=[];ids={k:PRE+k+':20261108'for k in ['analytic','geometry','complete','scope','source']}
    def node(k,kind,body,ep):nodes.append(dict(node_id=ids[k],kind=kind,title='Analytic domination-two input: '+k,body=body,epistemic=ep,provenance=json.dumps([dict(path=str(P/'gamma2-analytic-proof.md'),sha256=sha(P/'gamma2-analytic-proof.md'))])))
    def edge(a,b,rel,why):edges.append(dict(edge_id='edge:'+dig(a+'|'+rel+'|'+b),from_id=a,to_id=b,relation=rel,rationale=why,status='curated'))
    node('analytic','claim','Every finite simple UNIT maximal outerplanar graph with domination number at most2 and n>=61 has splus>2n. Pure analytic proof: for an actual hub joined to at most2 paths on q leaves, interlacing and uniform compression give splus>=2q-2 for ALLq>=0, and splus>2q+6 for ALLq>=30. Exact small-q Rayleigh checks plus monotone analytic tails; no finite Gram kernels or connected-graph energy premise in n>=61.','PROVEN written all-order spectral argument')
    node('geometry','claim','For every ordered dominating pair u,v in a UNIT MOP, assign all nonhub neighbors of u to u and the remaining vertices to v. Both actual induced pieces are hub joins of at most2 paths, with q1+q2=n-2. Nonadjacent hubs have at most2 common neighbors; when2, chordality makes them consecutive. Adjacent hubs delete one consecutive neighbor-path run. Thus n>=61 forces one q>=30; PSD disjoint pinching gives strict splus>2n. Full calibration: ALL2055 cyclic triangulations n3..10 and ALL7804 ordered dominating pairs passed; finite diagnostics are not the all-size geometric proof.','PROVEN geometry plus separately scoped finite calibration')
    node('complete','claim','Every finite simple UNIT maximal outerplanar graph G,n>=8,gamma(G)<=2 satisfies splus(G)>=2n. Use the fresh accepted finite8..71 theorem ONLY for n8..60, and the self-contained analytic argument for n>=61. The valid older184/185 domination-two theorem is retained. This alternative removes its special finite-kernel dependencies from the current global assembly; it is not the first closure of that class.','PROVEN composition at exact stated scopes')
    node('scope','claim','Original EVERY finite simple UNIT MOP n>=8,splus>=2n remains GLOBAL OPEN / goalACTIVE. The new input simplifies a previously proved gamma<=2 subclass; it does not prove gamma3, gamma4, the two remaining parent families, or global closure. Scalar and finite geometry replay do not constitute independent human/formal review. No external priority or causal LOTSE benefit asserted. New next work: use this analytic proof in the global dependency ledger and finish the actual outstanding full certificates.','PROVEN scope and dependency change; original global OPEN')
    node('source','source',json.dumps(dict(format='complete-source-envelope-v1',files=files),ensure_ascii=True,separators=(',',':')),'FULL proof/controller/result/intake/guard/parent snapshot; B71 requires its existing full source closure')
    for k in['analytic','geometry','complete','scope']:edge(ids[k],ids['source'],'requires','Complete written proof, exact controller and source scope required.')
    edge(ids['analytic'],ids['geometry'],'requires','Actual disjoint one/two-path joins, not arbitrary relaxed path allocations.')
    edge(ids['complete'],ids['analytic'],'requires','Analytic strict theorem n>=61.')
    edge(ids['complete'],parent,'requires','Accepted original finite basis used only n8..60; full parent source dependencies remain required.')
    edge(ids['scope'],parent,'qualifies','Simpler domination-two proof does not alter finite theorem or close global target.')
    raw=sum(f['bytes']for f in files);backup=DB.stat().st_size+16*1024**2;free=shutil.disk_usage(P).free
    assert raw<1024**2 and free-backup-5*raw>8*1024**3
    save('write-plan.json',dict(explicit_members=names,raw_bytes=raw,backup_count=1,backup_upper_each=backup,free_before=free,reserve_bytes=8*1024**3))
    save('source-hashes.json',{n:sha(P/n)for n in names});save('packet.json',dict(schema_version=1,nodes=nodes,edges=edges))
    print(json.dumps(dict(status='PREPARED_ANALYTIC_GAMMA2_INPUT',nodes=len(nodes),edges=len(edges),files=len(files),raw_bytes=raw,free_before=free)))
def audit():
    assert all(sha(P/n)==h for n,h in rd(P/'source-hashes.json').items());packet=rd(P/'packet.json')
    con=sqlite3.connect('file:'+str(DB)+'?mode=ro',uri=True);con.row_factory=sqlite3.Row;con.execute('BEGIN');actual=[]
    for table,key,item in [('weave_nodes','node_id',n)for n in packet['nodes']]+[('weave_edges','edge_id',e)for e in packet['edges']]:
        row=dict(con.execute('select * from '+table+' where '+key+'=?',(item[key],)).fetchone());assert all(row[k]==v for k,v in item.items());actual.append(dict(table=table,row=row))
    parent=rd(P/'parent-snapshot.json');assert dig(con.execute('select body from weave_nodes where node_id=?',(parent['node_id'],)).fetchone()[0])==parent['sha256'];con.rollback();con.close();save('actual-readback.json',actual)
    source=next(a['row']['body']for a in actual if a['table']=='weave_nodes'and a['row']['node_id']==PRE+'source:20261108');env=json.loads(source);root=P/'native-export';root.mkdir(exist_ok=True)
    for f in env['files']:
        b=f['content'].encode();assert Path(f['name']).name==f['name']and len(b)==f['bytes']and hashlib.sha256(b).hexdigest()==f['sha256']and b==(P/f['name']).read_bytes();dest=root/f['name']
        if dest.exists():assert dest.read_bytes()==b
        else:dest.write_bytes(b)
    argv=[sys.executable,'-B','-X','utf8',str(root/'check_gamma2_geometry.py')];start=time.monotonic();r=subprocess.run(argv,cwd=root,capture_output=True,text=True,encoding='utf8');save('export-process.json',dict(argv=argv,exit_code=r.returncode,wall_time_seconds=time.monotonic()-start,stdout=r.stdout,stderr=r.stderr));assert r.returncode==0,r.stderr
    a=rd(P/'gamma2-check.json');b=rd(root/'gamma2-check.json');assert {k:v for k,v in a.items()if k!='seconds'}=={k:v for k,v in b.items()if k!='seconds'}
    for n in['gamma2-dryrun','gamma2-import']:assert rd(P/(n+'.process.json'))['exit_code']==0
    receipt=rd(P/'gamma2-import.stdout.json');assert receipt['inserted']==dict(nodes=len(packet['nodes']),edges=len(packet['edges']),reviews=0);backup=Path(receipt['backup']);assert backup.is_file()and backup.stat().st_size<=rd(P/'write-plan.json')['backup_upper_each']
    out=dict(status='PASS_NATIVE_ANALYTIC_GAMMA2_FULL_SOURCE_AND_PORTABLE_GEOMETRY_SCALAR_REPLAY',native_run_id=receipt['run_id'],nodes=len(packet['nodes']),edges=len(packet['edges']),files=len(env['files']),all_source_bytes_identical=True,all2055_graphs_and7804_ordered_pairs_replayed_identically=True,parent_unchanged=True,analytic_proof='written all-order argument, finite diagnostics not extrapolated',backup=str(backup),free_after=shutil.disk_usage(P).free,original_global='OPEN');save('native-audit.json',out);print(json.dumps(out))
if __name__=='__main__':prepare()if len(sys.argv)==1 or sys.argv[1]=='prepare'else audit()
