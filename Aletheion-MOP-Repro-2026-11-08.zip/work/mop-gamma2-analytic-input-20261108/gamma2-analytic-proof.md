# A short analytic replacement of the domination-two input

8 November2026. ORIGINAL ALL UNIT MOP n>=8,F=splus>=2n GLOBAL OPEN.
The domination-two class was already proved in the retained184/185 work.
This is a simpler proof of the actual input, not a first class closure or
the original global theorem. It removes the old special finite kernels
from this input's dependency path. The new hand proof imports no energy
conjecture or published connected-graph bound in its large-order range.

THEOREM. Every finite simple UNIT maximal outerplanar graph G with a
dominating set of size at most two and n>=61 has F(G)>2n.
Together with the already completely proved original finite basis8..71,
this pays EVERY such original graph n>=8. In particular the global
minimal-counter proof at n>=72 needs only the analytic part below.

1. Elementary spectral facts, with actual principal pieces.

For any real symmetric A,
F(A)=max over X>=0 of 2Tr(AX)-Tr(X^2). Choosing a block-supported PSD
matrix proves superadditivity over disjoint induced vertex sets and
monotonicity under principal extension. No edge-deletion monotonicity.
For a path forest L with q vertices,m edges, bipartite spectral symmetry
gives F(L)=m. Every finite path has spectral radius<2: the quadratic
forms2I-A and2I+A are sums of consecutive squared differences/sums and
the two endpoint squares, strictly positive on a nonzero vector.
For an isolated vertex both endpoint squares give2x^2. Direct sums
preserve this property.

Put J=K1 join L, with L consisting of one or two nonempty paths (and
allow the empty forest q0). Interlacing on deletion of the hub gives

               F(J)>=rho(J)^2+F(L)-rho(L)^2.           (1)

Compress to the hub and the uniform unit leaf vector. If q>0 and
h=m/q, the top compression eigenvalue is theta=h+sqrt(q+h^2), since
its matrix is[[0,sqrt(q)],[sqrt(q),2h]]. Thus rho(J)>=theta.

2. A uniform weak floor with no finite Gram data.

For EVERY such forest, including q0,

                         F(J)>=2q-2.                  (2)

For q0 this reads0>=-2; q1 is an edge of energy1. At q2, the two
possibilities are P3 (energy2) and K3 (energy4), so(2) holds.
For q3,4,5 use the Rayleigh vector weight2 at the hub and1 at every
leaf. Since there are at most two path components,m>=q-2. Its norm
square is q+4 and its adjacency quadratic form4q+2m>=6q-4.
Consequently F(J)>=rho(J)^2>=((6q-4)/(q+4))^2, giving respectively
4,25/4,676/81, each at least2q-2. These are exact rational comparisons.

For q>=6, put h0=1-2/q. Equations(1) and theta's monotonicity in h>=0,
with m>=q-2 and rho(L)^2<4, give

 F(J)>2q+2h0^2+2h0 sqrt(q+h0^2)-6.

The positive expression2h0^2+2h0 sqrt(q+h0^2) increases with q>=6.
At q6 it equals(8+4sqrt58)/9>4, since58>49. This proves strict(2)
for every q>=6, without extrapolating a finite spectral calculation.

3. A strong floor for the one large piece, also purely analytic.

For EVERY q>=30 and the SAME one/two-path join,

                         F(J)>2q+6.                   (3)

The positive root theta solves z^2-cz-q=0,c=2m/q>=2-4/q.
At x=sqrt(q+12), this polynomial is12-cx. Both positive factors of
(2-4/q)^2(q+12) increase for q>=30. At30,

 (28/15)^2*42-144=528/225>0.

Hence cx>12,theta>x and rho(J)^2>q+12. Substituting into(1), with
m>=q-2,rho(L)^2<4, yields F(J)>2q+6. This is the analytic tail of
the previously retained SF6 argument; q28/q29 certificates are not
needed for the present theorem.

4. Two disjoint actual joins cover a dominating pair.

Choose distinct u,v whose closed neighborhoods cover G. If the minimum
domination number is one, add any second vertex; no minimum/lexicographic
normalization or degree premise is used. Assign all neighbors of u other
than v to u, and every remaining nonhub vertex to v. The actual partition
is S={u} union(N(u) minus{v}),
T={v} union(N(v) minus(N(u) union{u})). Then q_S+q_T=n-2.

In any polygon triangulation the neighbors of a vertex induce a path,
with consecutive neighbors joined by its incident faces. An extra chord
between nonconsecutive neighbors would cross a spoke. Deleting v from
N(u) therefore leaves at most two paths, so G[S] is a one/two-path join
or a single hub.

If u,v are adjacent, their common neighbors are the one or two vertices
immediately beside u in v's neighbor path. The deleted set consisting of
u and those common neighbors is ONE consecutive run. In the boundary
case it is an end run. Thus the remaining leaves of v form at most two
paths. If u,v are nonadjacent, they have at most two common neighbors,
since three would give a K2,3 subgraph. If two, those common neighbors
are adjacent: the four-cycle through u,v and them has no uv diagonal,
so chordality of a polygon triangulation forces the other diagonal.
They are consecutive in the induced neighbor path. Removing zero, one
or two consecutive vertices again leaves at most two paths. This proves
that G[T] has the same join form, including an empty leaf set.

For n>=61,q_S+q_T>=59, so one integer leaf count is>=30. Apply(3) to
that actual piece and(2) to the other. PSD superadditivity gives

 F(G)>=F(G[S])+F(G[T])
      >2q_large+6+2q_small-2=2(n-2)+4=2n.

Strictness comes from the large piece, even when the small weak bound
is an equality or negative. Neither selected hub, any shared leaf, nor
the root edge is counted twice. Cross edges are ignored only by the
PSD block witness. This completes the all-order theorem n>=61.

5. Exact scope, checks and changed next work.

The graph controller enumerates complete cyclic polygon families n3..10
and every ordered dominating pair, constructs the actual partition and
tests both one/two-path forests and the exact leaf count. An independent
Catalan cardinality/domain check prevents a sampled family being called
complete. These finite diagnostics calibrate the all-order geometric
argument; they do not establish it by extrapolation. Exact scalar checks
cover all small q cases, analytic base squares and the integer threshold.

For n8..60 use the already accepted fresh B71 theorem at its actual
scope and named paper inputs. For larger n this proof is self-contained.
The valid older domination-two theorem and its finite certificates are
retained. They need no rerun or refutation: the global input is now paid
through this analytic argument plus B71. No claim about gamma>=3 or the
two remaining unbounded parent families is made. No new external first
priority, independent human/formal audit or causal LOTSE effect asserted.
