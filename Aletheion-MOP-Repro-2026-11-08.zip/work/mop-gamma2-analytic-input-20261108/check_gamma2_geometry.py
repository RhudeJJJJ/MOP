from pathlib import Path
from functools import lru_cache
from fractions import Fraction as F
from math import comb
import json,time,hashlib
P=Path(__file__).resolve().parent
@lru_cache(None)
def triangulations(a,b):
    if b-a==1:return(frozenset([(a,b)]),)
    out=[]
    for c in range(a+1,b):
        for L in triangulations(a,c):
            for R in triangulations(c,b):out.append(L|R|{(a,b)})
    assert len(set(out))==len(out)
    return tuple(out)
def paths(V,adj):
    V=set(V);seen=set();parts=0
    for x in V:
        assert len(adj[x]&V)<=2
        if x in seen:continue
        parts+=1;stack=[x];component=set()
        while stack:
            u=stack.pop()
            if u in component:continue
            component.add(u);stack.extend(adj[u]&V-component)
        seen|=component
        assert sum(len(adj[u]&component)for u in component)==2*(len(component)-1)
    assert seen==V and parts<=2
    return parts
def main():
    start=time.monotonic();rows=[];total=ordered=0
    for n in range(3,11):
        graphs=triangulations(0,n-1);assert len(graphs)==comb(2*n-4,n-2)//(n-1);count=0;adjacent=nonadjacent=0
        for E in graphs:
            boundary={(i,i+1)for i in range(n-1)}|{(0,n-1)};assert len(E)==2*n-3 and boundary<=E
            diagonals=E-boundary;assert all(not(a<c<b<d or c<a<d<b)for a,b in diagonals for c,d in diagonals)
            A=[set()for _ in range(n)]
            for x,y in E:A[x].add(y);A[y].add(x)
            for u in range(n):
                for v in range(n):
                    if u==v or(A[u]|A[v]|{u,v})!=set(range(n)):continue
                    L=A[u]-{v};R=A[v]-(A[u]|{u});S=L|{u};T=R|{v};assert not S&T and S|T==set(range(n));assert len(L)+len(R)==n-2
                    paths(L,A);paths(R,A);common=A[u]&A[v];assert len(common)<=2
                    if v in A[u]:assert 1<=len(common)<=2;adjacent+=1
                    else:
                        nonadjacent+=1
                        if len(common)==2:
                            x,y=sorted(common);assert(x,y)in E
                    count+=1
        rows.append(dict(n=n,graphs=len(graphs),ordered_dominating_pairs=count,adjacent=adjacent,nonadjacent=nonadjacent));total+=len(graphs);ordered+=count
    assert total==2055
    for q in[3,4,5]:assert F((6*q-4)**2,(q+4)**2)>=2*q-2
    assert 58>49 and 28**2*42-144*15**2==528>0
    checked=0
    for n in range(61,257):
        for q in range(n-1):
            r=n-2-q;assert max(q,r)>=30
            assert 2*max(q,r)+6+2*min(q,r)-2==2*n;checked+=1
    out=dict(status='PASS_ALL2055_POLYGONS_ALL_ORDERED_DOMINATING_PAIRS_AND_ANALYTIC_TRANSFER_CHECKS',graphs=total,ordered_dominating_pair_presentations=ordered,rows=rows,integer_threshold_presentations=checked,analytic_threshold=61,small_q_rayleigh_floor={q:str(F((6*q-4)**2,(q+4)**2))for q in[3,4,5]},q6_weak_floor='sqrt58>7',q30_strong_margin='528/225',source_sha256={n:hashlib.sha256((P/n).read_bytes()).hexdigest()for n in['gamma2-analytic-proof.md','check_gamma2_geometry.py']},seconds=time.monotonic()-start,scope='Complete finite geometry calibration and exact scalar transfer only; all-size proof is the written interlacing/compression/neighbor-path argument. New full gamma<=2 input also uses accepted B71 only below61; original all-MOP global staysOPEN.',original_global='OPEN');(P/'gamma2-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in['rows','source_sha256']},indent=2))
if __name__=='__main__':main()
