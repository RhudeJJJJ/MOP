"""Same exact formal Schur expressions, with actual finite q,r and lambda=1/(q+r)."""
from pathlib import Path
import sys
from fractions import Fraction as F
BASE=Path(__file__).resolve().parent.parent/'mop-double-reciprocal-20261108'
sys.path.insert(0,str(BASE))
import ad6_tools as ad,reciprocal_common as common,reciprocal_model as direct
def roots():
    return[(p,s,q,m-q)for m in range(14,42)for q in range((m+1)//2,m)for p in range(1,5)for s in range(1,5)]
def variables(a,b,pa,pb,sa,sb,q,r):
    assert 14<=q+r<=41 and q>=r>=1 and q>=7
    ad.set_box(((b-a)/2,(pb-pa)/2,(sb-sa)/2,F(0),F(0),F(0)))
    return[ad.variable(a,b,0),ad.variable(pa,pb,1),ad.variable(sa,sb,2),ad.asA(1),ad.asA(1),ad.asA(F(1,q+r))]
def bound(a,b,pa,pb,sa,sb,p,s,q,r,mode='0'):
    assert 0<a<=b and 0<=pa<=pb<=1 and 0<=sa<=sb<=1 and p>=1 and s>=1
    args=variables(a,b,pa,pb,sa,sb,q,r);cap=ad.h.up(2*ad.n.PI[1]*b)
    try:
        value=common.expression(*args,p,s,q,r)if mode=='0'else ad.phase(args[0],direct.response(*args,p,s,q,r))
        return dict(upper=min(cap,max(F(0),value.v[1])),grad=tuple(max(abs(v)for v in row)for row in value.d[:3]),method='same-formal-'+mode+'-actual-fixed-middle')
    except(AssertionError,ArithmeticError):return dict(upper=cap,method='physical-2pi-cap')
