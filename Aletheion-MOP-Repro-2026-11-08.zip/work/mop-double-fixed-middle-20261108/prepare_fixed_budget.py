from pathlib import Path
from fractions import Fraction as F
import sys,json,hashlib,time
P=Path(__file__).resolve().parent;BASE=P.parent/'mop-double-reciprocal-20261108';sys.path.insert(0,str(BASE))
import rational_grid
rational_grid.install()
import double_tail as tail,net_interval as net
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
start=time.monotonic();full=json.loads((BASE/'frequency-grid.json').read_bytes());grid=[r for r in full if F(r['b'])<=10];assert len(grid)==56 and F(grid[0]['a'])==F(1,2)and F(grid[-1]['b'])==10
A=F(14,5);I=sum(((F(r['b'])-F(r['a']))*A/(1+((F(r['a'])+F(r['b']))/2)**2)for r in grid),F(0));bands=[]
for lo,hi,c in[(14,19,F(269,100)),(20,41,F(43,10))]:
    step=F(1,1280);T=sum((tail.tail(k*step,(k+1)*step,1,hi-1)[1]*step for k in range(128)),F(0));gain=c-F(1,2)-2*(I+T)/net.PI[0];assert gain>F(1,20)
    bands.append(dict(actual_total=[lo,hi],private_reserve=str(c),tail_integral_upper=str(T),target_surplus=str(gain),target_surplus_float=float(gain)))
obj=dict(status='PASS_EXACT_FIXED_MIDDLE_SELECTION_BUDGET_PHASE_STILL_OPEN',frequency_grid=grid,amplitude=str(A),compact_target_integral_upper=str(I),low_frequency_energy_cost='1/2',tail_z_partition=dict(cells=128,width='1/1280',whole_domain=['0','1/10']),bands=bands,source_sha256={n:sha(BASE/n)for n in ['double_tail.py','double-analytic-proof.md','rational_grid.py','disk_interval.py','net_interval.py','frequency-grid.json']},new_reader_sha256=sha(Path(__file__)),seconds=time.monotonic()-start,original_global='OPEN');(P/'fixed-budget.json').write_text(json.dumps(obj,indent=2)+'\n');print(json.dumps({k:v for k,v in obj.items()if k not in ['frequency_grid','source_sha256','compact_target_integral_upper']},indent=2))
