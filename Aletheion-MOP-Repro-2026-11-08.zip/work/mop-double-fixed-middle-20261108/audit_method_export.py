"""Portable source/coverage/budget audit; does NOT rerun numerical phase leaves."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,sys
P=Path(__file__).resolve().parent;W=P.parent;BASE=W/'mop-double-reciprocal-20261108';sys.path.insert(0,str(BASE))
import rational_grid
rational_grid.install()
import double_tail as tail,net_interval as net,fixed_cover
def rd(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
hashes=rd(P/'full-inputs.json');assert len(hashes)==67 and all(sha(W/n)==h for n,h in hashes.items())
pre=rd(P/'preflight-result.json');data=rd(P/'preflight-certificate.json');assert pre['status']=='PASS_EXACT_COMPLETE_FIXED_MIDDLE_ONE_FREQUENCY_PREFLIGHT'and pre['certificate_sha256']==sha(P/'preflight-certificate.json')and pre['reader_sha256']==sha(P/'read_preflight.py')
assert all(sha(P/n)==h for n,h in pre['source_sha256'].items())and all(sha(BASE/n)==h for n,h in pre['inherited_source_sha256'].items())
assert pre['ordered_roots']==6048 and pre['all_actual_middle_pairs']==378 and len(data['trees'])==6048 and fixed_cover.check_grammar()==13
count=anchor=depth=0
for root,code in zip(fixed_cover.roots(),data['trees']):
    _,leaves,pa,dp=fixed_cover.tree(code,F(data['a']),F(data['b']),F(data['target']),root,lambda*args:dict(upper=F(0)));count+=leaves;anchor=max(anchor,pa);depth=max(depth,dp)
assert count==pre['length_frequency_leaves']==12285 and anchor==5 and depth==1
b=rd(P/'fixed-budget.json');grid=b['frequency_grid'];assert len(grid)==56 and F(grid[0]['a'])==F(1,2)and F(grid[-1]['b'])==10 and all(grid[i]['b']==grid[i+1]['a']for i in range(55))
I=sum(((F(r['b'])-F(r['a']))*F(14,5)/(1+((F(r['a'])+F(r['b']))/2)**2)for r in grid),F(0));assert I==F(b['compact_target_integral_upper'])
for saved,(lo,hi,reserve)in zip(b['bands'],[(14,19,F(269,100)),(20,41,F(43,10))]):
    step=F(1,1280);T=sum((tail.tail(k*step,(k+1)*step,1,hi-1)[1]*step for k in range(128)),F(0));gain=reserve-F(1,2)-2*(I+T)/net.PI[0];assert gain==F(saved['target_surplus'])>F(1,20)and T==F(saved['tail_integral_upper'])and saved['actual_total']==[lo,hi]
print(json.dumps(dict(status='PASS_PORTABLE_METHOD_SOURCE_GRAMMAR_AND_COMPLETE_SIGNED_BUDGET_AUDIT',source_files=67,actual_middle_pairs=378,outer_residue_roots=6048,preflight_tree_leaves=count,all_exact_target_budgets_identical=True,scope='All raw sources, complete preflight grammar and both full signed selection budgets. Prior terminal exact numerical ONE-slab check is source-bound input, NOT rerun here. Full56-slab family remains pending.')))
