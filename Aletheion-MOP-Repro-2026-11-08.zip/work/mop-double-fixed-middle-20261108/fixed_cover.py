from fractions import Fraction as F
def roots():
    return[(p,s,m-r,r)for m in range(14,42)for r in range(m//2,0,-1)for p in range(1,5)for s in range(1,5)]
def tree(code,a,b,target,root,bound):
    pos=leaves=anchor=depthmax=0;maximum=F(0);p,s,q,r=root
    def visit(p,s,tails,lo,hi,depth):
        nonlocal pos,leaves,anchor,depthmax,maximum
        assert pos<len(code),'truncated fixed tree';symbol=code[pos];pos+=1;anchor=max(anchor,p,s);depthmax=max(depthmax,depth)
        if symbol in'06':
            params=[v for tail in tails for v in(F(0)if tail else F(1),F(1))];value=bound(lo,hi,*params,p,s,q,r,symbol)['upper'];assert value<=target,'fixed leaf above target';maximum=max(maximum,value);leaves+=1;return
        if symbol in'12':
            j=int(symbol)-1;assert tails[j],'singleton split';one=list(tails);one[j]=False;later=[p,s];later[j]+=4
            visit(p,s,tuple(one),lo,hi,depth);visit(*later,tails,lo,hi,depth)
        elif symbol=='3':
            assert lo<hi;mid=(lo+hi)/2;visit(p,s,tails,lo,mid,depth+1);visit(p,s,tails,mid,hi,depth+1)
        else:raise AssertionError('unknown fixed tree symbol')
    visit(p,s,(True,True),a,b,0);assert pos==len(code),'fixed tree suffix'
    return maximum,leaves,anchor,depthmax
def read_cell(data,bound):
    a,b,target=map(F,(data['a'],data['b'],data['target']));assert a<b and target==F(14,5)/(1+((a+b)/2)**2);ordered=roots();assert len(ordered)==len(set(ordered))==6048 and len(data['trees'])==6048
    maximum=F(0);leaves=anchor=depth=0
    for code,root in zip(data['trees'],ordered):
        value,count,pa,dp=tree(code,a,b,target,root,bound);maximum=max(maximum,value);leaves+=count;anchor=max(anchor,pa);depth=max(depth,dp)
    return(b-a)*maximum,leaves,anchor,depth
def check_grammar():
    root=(1,1,7,7);zero=lambda*args:dict(upper=F(0));a,b,target=F(1),F(2),F(1)
    for code in['0','6','100','200','300','13000']:tree(code,a,b,target,root,zero)
    rejected=0
    for code in['','1','2','3','4','5','7','9','00','11000','22000','1000','3000']:
        try:tree(code,a,b,target,root,zero)
        except AssertionError:rejected+=1
        else:raise AssertionError(('accepted damaged grammar',code))
    assert rejected==13;return rejected
