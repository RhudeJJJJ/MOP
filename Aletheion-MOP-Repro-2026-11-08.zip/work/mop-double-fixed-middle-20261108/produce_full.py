from pathlib import Path
from fractions import Fraction as F
import sys,json,time,hashlib
P=Path(__file__).resolve().parent;W=P.parent;BASE=W/'mop-double-reciprocal-20261108';sys.path.insert(0,str(BASE))
import float_discovery
float_discovery.install()
import fixed_bound as bound
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def atomic(p,v):
    tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(v,separators=(',',':'))+'\n');tmp.replace(p)
def main():
    start=time.monotonic();hashes=json.loads((P/'full-inputs.json').read_bytes());assert all(sha(W/n)==h for n,h in hashes.items());grid=json.loads((P/'fixed-budget.json').read_bytes())['frequency_grid']
    for index,row in enumerate(grid):
        path=P/f'full-checkpoints/{index:04}.json'
        if path.exists():continue
        assert 16<=index<56 and index!=23;a,b=F(row['a']),F(row['b']);target=F(14,5)/(1+((a+b)/2)**2);calls=leaves=max_anchor=0;t=time.monotonic()
        print(json.dumps(dict(status='HEURISTIC_FULL_FIXED_SLAB_STARTED',index=index,total=56,a=str(a),b=str(b))),flush=True)
        def solve(p,s,q,r,tails=(True,True),lo=a,hi=b,depth=0):
            nonlocal calls,leaves,max_anchor
            calls+=1;assert calls<=100000 and max(p,s)<=120,'bounded full fixed solver exhausted';params=[v for tail in tails for v in(0. if tail else 1.,1.)];best=None
            for mode in['0','6']:
                got=bound.bound(float(lo),float(hi),*params,p,s,q,r,mode);got['symbol']=mode
                if best is None or got['upper']<best['upper']:best=got
                if best['upper']<=float(target)-1e-7:break
            if best['upper']<=float(target)-1e-7:leaves+=1;max_anchor=max(max_anchor,p,s);return best['symbol']
            grad=best.get('grad');scores=[float(grad[j+1])if grad and tails[j]else 1/(v+1)if tails[j]else-1. for j,v in enumerate([p,s])];scores.append(float(grad[0])*float(hi-lo)if grad and depth<6 else float(hi-lo)if depth<6 else-1.);dim=max(range(3),key=lambda j:scores[j]);assert scores[dim]>=0,'bounded frequency refinement exhausted'
            if dim==2:
                mid=(lo+hi)/2;return'3'+solve(p,s,q,r,tails,lo,mid,depth+1)+solve(p,s,q,r,tails,mid,hi,depth+1)
            one=list(tails);one[dim]=False;later=[p,s];later[dim]+=4;return str(dim+1)+solve(p,s,q,r,tuple(one),lo,hi,depth)+solve(*later,q,r,tails,lo,hi,depth)
        trees=[]
        for count,root in enumerate(bound.roots(),1):
            trees.append(solve(*root))
            if count%1024==0:print(json.dumps(dict(status='HEURISTIC_FULL_FIXED_SLAB_PROGRESS',index=index,roots=count,total_roots=6048,calls=calls,leaves=leaves,slab_seconds=time.monotonic()-t)),flush=True)
        assert all(sha(W/n)==h for n,h in hashes.items());atomic(path,dict(format='actual-fixed-middle-two-infinite-outer-v1',index=index,a=str(a),b=str(b),target=str(target),trees=trees,calls=calls,leaves=leaves,max_anchor=max_anchor,source_sha256=hashes,seconds=time.monotonic()-t))
        print(json.dumps(dict(status='HEURISTIC_FULL_FIXED_SLAB_COMPLETED',index=index,leaves=leaves,seconds=time.monotonic()-start)),flush=True)
    cells=[dict(index=i,method='old-four-infinite'if i<16 else'exact-preflight-reuse'if i==23 else'actual-fixed-middle',sha256=sha(P/f'full-checkpoints/{i:04}.json'))for i in range(56)]
    assert all(sha(W/n)==h for n,h in hashes.items());atomic(P/'full-certificate.json',dict(format='hybrid56-old-low-fixed-actual-middle-v1',cells=cells,source_sha256=hashes,actual_energy_domain='p,s>=1 unbounded;q,r>=1,14<=q+r<=41;coherent whole reflection q>=r',seconds=time.monotonic()-start,original_global='OPEN'));print(json.dumps(dict(status='HEURISTIC_FULL_HYBRID56_REQUIRES_EXACT_READER',seconds=time.monotonic()-start)),flush=True)
if __name__=='__main__':main()
