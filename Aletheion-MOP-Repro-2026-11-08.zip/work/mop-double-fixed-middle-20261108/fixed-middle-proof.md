# Actual bounded middle lengths, two unbounded outer arms, and a shorter tail

8 November2026. ORIGINAL UNIT-MOP n>=8,F=splus>=2n GLOBAL OPEN.
This is a conditional full-family payment method. A completed single-slab
preflight is not a complete compact integral or an original global proof.

Target: for every actual old UNIT MOP H,order>=3, ordered boundary ab,
the actual grouped cap B(E_(p,q),E_(r,s)), p,s>=1 unbounded and
14<=q+r<=41, has DeltaF>2N+1/20,N=p+q+r+s+3. Keep ab once and allow
no private outside contacts except its two closing roots. The existing
whole-small-old gamma4 bridge remains separate from the increment domain.

1. Actual identities and the correct equality rule.

The complete literal private B,T are double_geometry.py. The private path
order is left_p,d,middle_q,c,middle_r,e,right_s, with every c-to-middle
edge and cd,ce present. Its edges count is p+s+2(q+r)+2; contact mass is
p+s+4, so their sum is2N. All four arm positions remain distinguished.
A coherent WHOLE reflection exchanges a,b and p,s and q,r simultaneously.
The graph and root response change by this relabeling/permutation, without
requiring the old graph itself to have a symmetry. K=2I+J is invariant.
We may therefore choose q>=r, which implies q>=7. There are exactly378
such actual middle pairs with14<=q+r<=41, and16 ordered outer residues
p,s1..4, hence6048 literal residue roots. Reflection never identifies
unmatched private response matrices or transfers credit between graphs.

The formal all-length Schur expressions and ten-symbol polynomial identity
are the unchanged reciprocal_model.py and reciprocal_common.py with all
their frozen33-source checks. Here q,r are their ACTUAL positive integers,
their endpoint amplitudes are exactly1, and lambda=1/(q+r) is fixed. Only
the two outer endpoint amplitudes vary in their complete covering curves.

For a path of length j, D0=1,D1=t,Dj=tD_(j-1)+D_(j-2),
f_j=D_(j-1)/Dj,e_j=(-i)^(j-1)/Dj,g_j=(1+i(f_j+e_j))/(t+2i).
With w=t+2i, set A=t+f_p+f_q,E=t+f_s+f_r,
b=i+g_q,f=i+g_r,alpha=1-i g_p,beta=1-i g_s,
ell=(1+2i g_p)/w,z=(1+2i g_s)/w,
z0=t+2i(g_q+g_r)/w-b^2/A-f^2/E,
eta=(w/(q+r))/(1+(w/(q+r))z0),
v_a=1-alpha b/A,v_b=1-beta f/E. Then the complete normalized response is

 Faa=ell+alpha^2/A+v_a^2 eta,
 Fab=v_a v_b eta,
 Fbb=z+beta^2/E+v_b^2 eta.

These are successive scalar Schur eliminations of the four actual paths,
the two child centers and parent c. Normalization subtracts only the two
nonnegative rays(p-1)/w and(s-1)/w on the respective root diagonals.
The accepted algebraic lossless-ray LemmaL makes the phase upper larger;
Wplus is unchanged. No energy or finite norm is assigned to fake free
curves, signed normalized matrices, or lambda0.

2. Infinite outer-arm coverage and exact finite middle data.

The continuant identity gives f_j^2+t f_j-1=(-1)^(j+1)/D_j^2.
For any outer residue anchor a1..4 and actual length j=a+4h, define
u=D_a/D_j. For t>0,D_(n+2)=tD_(n+1)+D_n>D_n, so0<u<=1; the limit0
is safely included. With sign=(-1)^(a+1),d=u/D_a,

 f=2(1+sign*d^2)/(t+sqrt(t^2+4+4sign*d^2)),
 e=(-i)^(a-1)*d.

This is exactly ad6_tools.endpoints. It represents every actual infinite
outer progression; it need not assert every u is graph-realizable. For an
actual fixed q or r, use a=q or r and u1. Splitting an outer tail at a
means the singleton j=a plus the complete tail a+4,a+8,...; no largest
anchor is a length cutoff. fixed_bound.py uses only independent variables
t,u_p,u_s; q,r and lambda have zero derivative in their own slots, with
their TRUE t dependence retained through the finite path recurrence.
The response calibration checks15 complete private inverses and4 coherent
reflection states, not only sampled eigenvalues. The written recurrence
and Schur identity supply the all-length part.

3. Fixed actual energy regime and full signed high tail.

For a join of a hub with two nonempty paths totaling R, interlacing and
hub/uniform compression give F>2R+G(R), where
G=2h^2+2h sqrt(R+h^2)-6,h=1-2/R; G increases for R>2.
Pinch the actual private B into c join(P_(q+1) union P_(r+1)) and the
two pendant paths. The resulting reserve is F(B)>edges(B)+G(q+r+2).
Exact square comparisons at R16 and22 give

 reserve>269/100 for14<=q+r<=19,
 reserve>43/10 for20<=q+r<=41.

These are proved in the preserved double-analytic-proof.md. Each graph
chooses its ONE actual regime for the ENTIRE integral, never a different
reserve at each frequency. Delete the c-star to leave a path forest;
||B||<sqrt(q+r+2)+2, hence norm<7 in the first regime and<9 in the second,
uniformly in BOTH infinite outer arms. For V=(B-2I)Tt,
TV=-2I,VtV=[[m+6,m+3],[m+3,m+6]],m=q+r. After lossless normalization the
leading Q=[[3,1],[1,3]]. Put C=Vt(I+xB^2)^-1V,D=VtB(I+xB^2)^-1V,
x=1/t^2. Then C>=0,|Cij|<=m+6,|Dij|<=(m+6)||B||.

The original exact signed resolvent identity is algebraic at EVERY t>0;
the root-ball nuclear-norm rationalization requires its positive real
matrix and strict positive divisors. double_tail.py checks these on all
128 exact z=1/t intervals of width1/1280 covering[0,1/10]. It therefore
bounds the ENTIRE tail t>=10, including z0, using constants m19/norm7 or
m41/norm9 to enlarge the respective actual regimes. It is not a check
at128 sampled frequencies, and it makes no norm claim for fake infinite
internal states. The exact integral bounds are retained as Fractions.

4. The56-slab compact budget and what remains to be executed.

For0<t<1/2 the general root-ball bound b<2pi gives ENERGY cost<=1/2.
Use the56 contiguous original base slabs covering[1/2,10]. At each slab
[a,b], choose target (14/5)/(1+((a+b)/2)^2). This constant is a selection
target to be established uniformly on the whole slab, not numerical
quadrature. The exact budget sums width*target. Combining with the actual
signed regime tails and private reserves yields target surpluses
approximately0.09720184 and0.80596256; BOTH exact Fractions exceed1/20.
Thus complete validation of every one of these56 targets suffices for
the full stated double-parent family. The smaller tail cutoff is justified
by the actual regime-specific constants, not by dropping frequencies.

The producer proposes binary preorder trees on all6048 literal roots.
Symbols1/2 split an infinite outer progression into its singleton and
anchor+4 tail; symbol3 bisects the current frequency interval; leaves0/6
choose the common/direct formal expression. Frequency splits retain the
parent target. The independent rational reader consumes each complete
tree, checks every directed96-bit enclosure and full parameter coverage,
and rejects a missing child, suffix, forbidden singleton split or leaf
above target. It takes a maximum across the whole covering leaf family,
so the whole slab is bounded by width*maximum<=width*target. No average
over graph lengths or frequencies certifies a pointwise statement.

The current REPRESENTATIVE preflight is only slab23,[23/8,3]. It checks
all378 actual middle pairs and both outer arms infinite. Full family
acceptance requires all56 slabs plus the precise signed tail and regime
inequalities. A successful preflight alone is not that acceptance.

5. Costs, source lineage and unchanged global goal.

The original four-infinite-curve proof at slab23 has16431 partition
leaves. The new proposal has12285, with a different, independently
justified selection target(old5/2,new14/5). Old elapsed reader progress
includes waits for its producer, so it is not a pure arithmetic benchmark.
The fixed-middle float proposal took676.297seconds in the actual shared
workload. Full exact timing is retained only after its terminal result.
One slab does not determine performance of the entire route.

A bounded endpoint-cache experiment preserved every64 exact bound and
derivative but measured3.39seconds uncached versus3.25seconds cached,
with no clear material advantage. It is NOT adopted in the exact reader;
its separate source/results are preserved as a cost finding. The optional
direct evaluator spelling was corrected before it was exercised; the
prior response-only control and source version are preserved, and full
physical controls were rerun at the actual corrected source hashes.

All original five foreground jobs continue unchanged. No accepted finite
B71 computation is repeated by this method. Any later route replacement
must name the observed cost/coverage reason and preserve source versions,
actual process states and outstanding proof obligations. The original
global n>=8 theorem still needs both unbounded family payments and the
exact full parent dependencies; no first-priority, independent human or
formal-assistant review, or causal LOTSE effect is asserted here.
