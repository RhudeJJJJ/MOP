from pathlib import Path
import json,hashlib,shutil
import fixed_cover
P=Path(__file__).resolve().parent;W=P.parent;BASE=W/'mop-double-reciprocal-20261108'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rd(p):return json.loads(p.read_bytes())
def main():
    pre=rd(P/'preflight-result.json');assert pre['status']=='PASS_EXACT_COMPLETE_FIXED_MIDDLE_ONE_FREQUENCY_PREFLIGHT'and sha(P/'preflight-certificate.json')==pre['certificate_sha256']and sha(P/'read_preflight.py')==pre['reader_sha256']
    assert all(sha(P/n)==h for n,h in pre['source_sha256'].items())and all(sha(BASE/n)==h for n,h in pre['inherited_source_sha256'].items());assert fixed_cover.check_grammar()==13
    budget=rd(P/'fixed-budget.json');assert budget['status']=='PASS_EXACT_FIXED_MIDDLE_SELECTION_BUDGET_PHASE_STILL_OPEN'and all(sha(BASE/n)==h for n,h in budget['source_sha256'].items())
    names=['fixed_bound.py','check_fixed_bound.py','fixed-controls.json','produce_preflight.py','preflight-certificate.json','read_preflight.py','preflight-result.json','prepare_fixed_budget.py','fixed-budget.json','fixed-middle-proof.md','hybrid-middle-proof.md','fixed_cover.py','prepare_full.py','produce_full.py','read_full.py']
    paths=[P/n for n in names]+[BASE/n for n in pre['inherited_source_sha256']]+[BASE/f'checkpoints/{i:04}.json'for i in range(16)]
    paths += [W/'mop-private-sibling-middle-20261108/inherited/port_sector_201_proof.txt',W/'mop-net-phase-20261106/net-phase-proof.md',W/'mop-fork-fan-20261106/fork-fan-proof.md']
    hashes={p.relative_to(W).as_posix():sha(p)for p in paths};raw=sum(p.stat().st_size for p in paths);free=shutil.disk_usage(P).free;planned=32*1024**2;assert raw<8*1024**2 and free-planned>8*1024**3
    manifest=P/'full-inputs.json'
    if manifest.exists():assert rd(manifest)==hashes
    else:manifest.write_text(json.dumps(hashes,indent=2)+'\n')
    for n in['full-checkpoints','exact-slabs']:(P/n).mkdir(exist_ok=True)
    for index in list(range(16))+[23]:
        source=BASE/f'checkpoints/{index:04}.json'if index<16 else P/'preflight-certificate.json';dest=P/f'full-checkpoints/{index:04}.json'
        if dest.exists():assert dest.read_bytes()==source.read_bytes()
        else:shutil.copyfile(source,dest)
    (P/'full-write-plan.json').write_text(json.dumps(dict(explicit_sources=list(hashes),input_raw_bytes=raw,maximum_additional_raw_bytes=planned,free_before=free,reserve_bytes=8*1024**3,method='old four-infinite cells0..15; actual fixed-middle cells16..55; exact preflight23 reused',source_hashes_immutable=True,no_old_job_or_source_mutation=True),indent=2)+'\n')
    print(json.dumps(dict(status='PREPARED_FULL_HYBRID56_TWO_INFINITE_OUTER_ARMS',source_files=len(paths),input_raw_bytes=raw,old_slabs_copied=16,exact_prefight23_reused=True,new_slabs_to_produce=39,free_before=free,grammar_damage_rejections=13)))
if __name__=='__main__':main()
