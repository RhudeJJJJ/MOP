from pathlib import Path
from fractions import Fraction as F
import sys,json,time,hashlib
P=Path(__file__).resolve().parent;BASE=P.parent/'mop-double-reciprocal-20261108';sys.path.insert(0,str(BASE))
import rational_grid
rational_grid.install()
import fixed_bound as plain,cached_bound as cached
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
roots=plain.roots()[:64];pairs=[(F(0),F(1),F(0),F(1)),(F(1),F(1),F(0),F(1)),(F(0),F(1),F(1),F(1))];queries=[(F(23,8),F(3),*pairs[j%3],*root)for j,root in enumerate(roots)]
t=time.monotonic();old=[plain.bound(*args)for args in queries];uncached=time.monotonic()-t
cached.install();t=time.monotonic();new=[cached.bound(*args)for args in queries];first=time.monotonic()-t;assert old==new,'any exact bound or derivative changed'
t=time.monotonic();repeat=[cached.bound(*args)for args in queries];warm=time.monotonic()-t;assert repeat==old
assert len(cached.CACHE)<=1024 and cached.HITS>0 and cached.MISSES>0
out=dict(status='PASS_ENDPOINT_CACHE_ALL_EXACT_BOUNDS_AND_DERIVATIVES_IDENTICAL',complete_queries=len(queries),uncached_seconds=uncached,first_cached_seconds=first,warm_cached_seconds=warm,hits=cached.HITS,misses=cached.MISSES,retained_keys=len(cached.CACHE),source_sha256={n:sha(P/n)for n in ['fixed_bound.py','cached_bound.py','check_endpoint_cache.py']},scope='Transparent same-input cache only, after fixed arithmetic backend. Key retains t interval,center,all derivatives,j,backend and complete RAD/RINT state; constant u1 and zero u derivatives are required. No full phase payment or general benchmark claim.');(P/'cache-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
