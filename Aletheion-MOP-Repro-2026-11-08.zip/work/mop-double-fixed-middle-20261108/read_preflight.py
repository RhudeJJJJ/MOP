"""Independent rational full-tree reader for the fixed-middle preflight slab."""
from pathlib import Path
from fractions import Fraction as F
import sys,json,hashlib,time
P=Path(__file__).resolve().parent;BASE=P.parent/'mop-double-reciprocal-20261108';sys.path.insert(0,str(BASE))
import rational_grid
rational_grid.install()
import fixed_bound as bound
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    start=time.monotonic();r=json.loads((P/'preflight-certificate.json').read_bytes());assert r['status']=='HEURISTIC_FIXED_MIDDLE_PREFLIGHT_REQUIRES_FULL_EXACT_READER'
    assert all(sha(P/n)==h for n,h in r['source_sha256'].items())and all(sha(BASE/n)==h for n,h in r['inherited_source_sha256'].items())
    a,b,target=F(r['a']),F(r['b']),F(r['target']);assert r['index']==23 and(a,b)==(F(23,8),F(3))and target==F(14,5)/(1+((a+b)/2)**2)
    ordered=[]
    for total in range(14,42):
        for right in range(total//2,0,-1):
            for left_outer in range(1,5):
                for right_outer in range(1,5):ordered.append((left_outer,right_outer,total-right,right))
    assert len(ordered)==6048 and len(r['trees'])==6048 and len(set(ordered))==6048
    leaves=maximum_anchor=fdepth=0;upper=F(0)
    for number,(root,code)in enumerate(zip(ordered,r['trees']),1):
        pos=0;p,s,q,rr=root
        def visit(p,s,tails,lo,hi,depth):
            nonlocal pos,leaves,maximum_anchor,fdepth,upper
            assert pos<len(code),'truncated tree';symbol=code[pos];pos+=1;maximum_anchor=max(maximum_anchor,p,s);fdepth=max(fdepth,depth)
            if symbol in'06':
                intervals=[v for tail in tails for v in(F(0)if tail else F(1),F(1))];value=bound.bound(lo,hi,*intervals,p,s,q,rr,symbol)['upper'];assert value<=target,('exact leaf missed target',root,pos,value,target);upper=max(upper,value);leaves+=1;return
            if symbol in'12':
                j=int(symbol)-1;assert tails[j],'split singleton';single=list(tails);single[j]=False;larger=[p,s];larger[j]+=4
                visit(p,s,tuple(single),lo,hi,depth);visit(*larger,tails,lo,hi,depth)
            elif symbol=='3':
                assert lo<hi;mid=(lo+hi)/2;visit(p,s,tails,lo,mid,depth+1);visit(p,s,tails,mid,hi,depth+1)
            else:raise AssertionError('invalid fixed-middle grammar symbol')
        visit(p,s,(True,True),a,b,0);assert pos==len(code),'unconsumed tree suffix'
        if number%256==0:print(json.dumps(dict(status='EXACT_FIXED_MIDDLE_PREFLIGHT_PROGRESS',roots=number,total=6048,leaves=leaves,max_anchor=maximum_anchor,max_frequency_depth=fdepth,seconds=time.monotonic()-start)),flush=True)
    assert all(sha(P/n)==h for n,h in r['source_sha256'].items())and all(sha(BASE/n)==h for n,h in r['inherited_source_sha256'].items())
    out=dict(status='PASS_EXACT_COMPLETE_FIXED_MIDDLE_ONE_FREQUENCY_PREFLIGHT',index=23,a=str(a),b=str(b),ordered_roots=6048,all_actual_middle_pairs=378,length_frequency_leaves=leaves,max_outer_anchor=maximum_anchor,max_frequency_depth=fdepth,target=str(target),maximum_phase_integrand_upper=str(upper),whole_slab_integral_upper=str((b-a)*upper),certificate_sha256=sha(P/'preflight-certificate.json'),reader_sha256=sha(Path(__file__)),source_sha256=r['source_sha256'],inherited_source_sha256=r['inherited_source_sha256'],seconds=time.monotonic()-start,scope='COMPLETE single frequency slab only, with ALL actual middle pairs and both outer arms infinite. Full56-slab compact and signed tail acceptance remains required. No original all-order energy conclusion.',original_global='OPEN');(P/'preflight-result.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in ['source_sha256','inherited_source_sha256']},indent=2),flush=True)
if __name__=='__main__':main()
