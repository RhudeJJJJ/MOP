from pathlib import Path
from fractions import Fraction as F
import sys,json,time,hashlib
P=Path(__file__).resolve().parent;W=P.parent;BASE=W/'mop-double-reciprocal-20261108';sys.path.insert(0,str(BASE))
import rational_grid
rational_grid.install()
import fixed_bound as fixed,fixed_cover,reciprocal_model as direct,reciprocal_common as common,reciprocal_cover as old,double_tail as tail,net_interval as net
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def atomic(p,v):
    tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(v,separators=(',',':'))+'\n');tmp.replace(p)
def waitfile(p):
    deadline=time.monotonic()+7200
    while not p.exists():assert time.monotonic()<deadline,'bounded hybrid reader wait expired';time.sleep(.25)
    return json.loads(p.read_bytes())
def main():
    start=time.monotonic();hashes=json.loads((P/'full-inputs.json').read_bytes());assert all(sha(W/n)==h for n,h in hashes.items())and fixed_cover.check_grammar()==13;budget=json.loads((P/'fixed-budget.json').read_bytes());grid=budget['frequency_grid'];records=[];end=F(1,2)
    for index,row in enumerate(grid):
        path=P/f'full-checkpoints/{index:04}.json';data=waitfile(path);a,b=F(row['a']),F(row['b']);assert a==end;end=b;dest=P/f'exact-slabs/{index:04}.json';datahash=sha(path)
        if dest.exists():
            r=json.loads(dest.read_bytes());assert r['source_sha256']==hashes and r['data_sha256']==datahash and r['index']==index and(r['a'],r['b'])==(str(a),str(b));origin='REUSED_SAME_COMPLETED_EXACT_SLAB_SOURCE_SNAPSHOT'
        elif index<16:
            target=F(5,2)/(1+((a+b)/2)**2);assert data['index']==index and F(data['target'])==target
            value,count,pa,xd,nf=old.frequency(data['partition'],a,b,target,direct,common);assert value<=(b-a)*target
            r=dict(index=index,a=str(a),b=str(b),area=str(value),leaves=count,max_anchor=pa,frequency_cells=nf,method='FULL_EXACT_OLD_FOUR_INFINITE_COVER_LOW_SLAB',source_sha256=hashes,data_sha256=datahash);atomic(dest,r);origin='FRESH_FULL_OLD_LOW_SLAB_READING'
        elif index==23:
            pre=json.loads((P/'preflight-result.json').read_bytes());assert pre['status']=='PASS_EXACT_COMPLETE_FIXED_MIDDLE_ONE_FREQUENCY_PREFLIGHT'and pre['certificate_sha256']==datahash and pre['reader_sha256']==sha(P/'read_preflight.py')and all(sha(P/n)==h for n,h in pre['source_sha256'].items())and all(sha(BASE/n)==h for n,h in pre['inherited_source_sha256'].items());assert(pre['a'],pre['b'])==(str(a),str(b))and pre['ordered_roots']==6048 and pre['all_actual_middle_pairs']==378
            r=dict(index=index,a=str(a),b=str(b),area=pre['whole_slab_integral_upper'],leaves=pre['length_frequency_leaves'],max_anchor=pre['max_outer_anchor'],frequency_depth=pre['max_frequency_depth'],method='REUSED_COMPLETE_EXACT_PREFLIGHT_IDENTICAL_DOMAIN_AND_TARGET',source_sha256=hashes,data_sha256=datahash);atomic(dest,r);origin='REUSED_VALIDATED_PREFLIGHT_NO_RECOMPUTATION'
        else:
            assert data['format']=='actual-fixed-middle-two-infinite-outer-v1'and data['source_sha256']==hashes and data['index']==index and(data['a'],data['b'])==(str(a),str(b));value,count,pa,depth=fixed_cover.read_cell(data,fixed.bound)
            r=dict(index=index,a=str(a),b=str(b),area=str(value),leaves=count,max_anchor=pa,frequency_depth=depth,method='FULL_EXACT_ACTUAL378_MIDDLE_PAIRS_TWO_INFINITE_OUTER_ARMS',source_sha256=hashes,data_sha256=datahash);atomic(dest,r);origin='FRESH_FULL_FIXED_ACTUAL_MIDDLE_READING'
        assert F(r['area'])<=(b-a)*F(14,5)/(1+((a+b)/2)**2)and all(sha(W/n)==h for n,h in hashes.items());records.append(dict(index=index,result_file=dest.relative_to(P).as_posix(),sha256=sha(dest),area=r['area'],leaves=r['leaves'],origin=origin));print(json.dumps(dict(status='EXACT_FULL_HYBRID56_SLAB_PASSED',index=index,total=56,leaves=sum(v['leaves']for v in records),seconds=time.monotonic()-start)),flush=True)
    assert len(records)==56 and end==10;cert=waitfile(P/'full-certificate.json');assert cert['format']=='hybrid56-old-low-fixed-actual-middle-v1'and cert['source_sha256']==hashes and cert['cells']==[dict(index=i,method='old-four-infinite'if i<16 else'exact-preflight-reuse'if i==23 else'actual-fixed-middle',sha256=sha(P/f'full-checkpoints/{i:04}.json'))for i in range(56)]
    compact=sum((F(r['area'])for r in records),F(0));bands=[]
    for lo,hi,reserve in[(14,19,F(269,100)),(20,41,F(43,10))]:
        step=F(1,1280);T=sum((tail.tail(k*step,(k+1)*step,1,hi-1)[1]*step for k in range(128)),F(0));gain=reserve-F(1,2)-2*(compact+T)/net.PI[0];assert gain>F(1,20);bands.append(dict(actual_total=[lo,hi],private_reserve=str(reserve),tail_integral_upper=str(T),surplus_lower=str(gain)))
    assert all(sha(W/n)==h for n,h in hashes.items());out=dict(status='PASS_EXACT_COMPLETE_DOUBLE_PARENT_M14_TO41_HYBRID56_TWO_INFINITE_OUTER_ARMS',actual_energy_domain=cert['actual_energy_domain'],compact_integral_upper=str(compact),bands=bands,proved_surplus='1/20',records=records,source_sha256=hashes,certificate_sha256=sha(P/'full-certificate.json'),seconds=time.monotonic()-start,scope='ALL actual old UNIT MOP H>=3 and ordered boundary, all independent positive outer lengths p,s and all middle totals14..41. Low0..1/2 and complete infinite tailt>=10 included, no parameter/frequency sampling. Other parent families and original global assembly remain separate.',original_global='OPEN');atomic(P/'full-result.json',out);print(json.dumps({k:v for k,v in out.items()if k not in ['records','source_sha256']},indent=2),flush=True)
if __name__=='__main__':main()
