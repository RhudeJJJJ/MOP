from pathlib import Path
from fractions import Fraction as F
import sys,json,time,hashlib
P=Path(__file__).resolve().parent;BASE=P.parent/'mop-double-reciprocal-20261108';sys.path.insert(0,str(BASE))
import rational_grid
rational_grid.install()
import fixed_bound as f,ad6_tools as ad,double_physical as phys,reciprocal_common as common,reciprocal_model as direct
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def D(t,n):
    old,v=F(0),F(1)
    for _ in range(n):old,v=v,t*v+old
    return v
def main():
    start=time.monotonic();rootset=f.roots();assert len(rootset)==len(set(rootset))==6048
    assert{(q,r)for p,s,q,r in rootset}=={(q,r)for q in range(7,41)for r in range(1,q+1)if 14<=q+r<=41}
    checked=0
    for p,q,r,s in[(1,7,7,1),(5,7,7,6),(2,10,4,3),(3,40,1,2),(8,21,20,1)]:
        ap,as_=1+(p-1)%4,1+(s-1)%4
        for t in[F(1,2),F(1),F(3)]:
            up,us=D(t,ap)/D(t,p),D(t,as_)/D(t,s);args=f.variables(t,t,up,up,us,us,q,r);actual=phys.response(p,q,r,s,t)
            for module in[common,direct]:
                got=module.response(*args,ap,as_,q,r)
                for i in range(2):
                    for j in range(2):
                        for component in range(2):assert got[i][j][component].v[0]<=actual[i][j][component]<=got[i][j][component].v[1]
            for mode in['0','6']:
                bounded=f.bound(t,t,up,up,us,us,ap,as_,q,r,mode)
                assert 0<=bounded['upper']<=ad.h.up(2*ad.n.PI[1]*t)
            checked+=1
    # Coherent whole reflection swaps all four lengths and old closing roots.
    for p,q,r,s in[(1,7,8,2),(3,20,21,2)]:
        for t in[F(1),F(3)]:
            a=phys.response(p,q,r,s,t);b=phys.response(s,r,q,p,t);assert all(a[i][j]==b[1-i][1-j]for i in range(2)for j in range(2))
    out=dict(status='PASS_FIXED_ACTUAL_MIDDLE_ALL378_PAIRS_6048_OUTER_RESIDUES_AND_EXACT_PHYSICAL_CONTROLS',actual_internal_pairs=378,ordered_outer_roots=6048,full_private_inverse_states=checked,whole_reflection_states=4,source_sha256={str(p):sha(p)for p in[P/'fixed_bound.py',Path(__file__)]},seconds=time.monotonic()-start,scope='Finite calibration of unchanged formal response with q,r actual and lambda fixed; all-order outer length coverage comes from preserved path recurrence/curve proof. No full phase payment.',original_global='OPEN');(P/'fixed-controls.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
