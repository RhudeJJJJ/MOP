# Selected complete hybrid56 certificate: original physical target unchanged

8 November2026. CONDITIONAL on the terminal full exact reader. Original
global target is OPEN. This document selects the executed full route from
the alternatives in fixed-middle-proof.md; it does not assert completion.

For ALL actual old UNIT MOP H>=3 and all p,q,r,s>=1 with14<=q+r<=41,
the intended increment is DeltaF>2N+1/20,N=p+q+r+s+3. A coherent whole
reflection fixes q>=r for the ENTIRE actual graph and integral. Both root
directions and all outside contacts are retained. All preceding universal
sector, phase, path and signed-tail proofs keep their exact scopes.

1. The exact completed preflight and why another route is justified.

The fixed-middle full rational preflight is terminal0 at slab23,
[23/8,3], ALL378 actual middle pairs and ALL16 ordered infinite outer
residues. It passed every12285 leaf, with maximum outer anchor5 and
frequency depth1. Float proposal took676.297seconds; full exact reading
463.781seconds. Its COMPLETE source-bound result is preflight-result.json.
The same original slab has16431 old partition leaves. The old reader's
elapsed progress includes producer waits; it is not a pure arithmetic
timing comparator. Targets differ(old5/2,new14/5), but the new exact
regime-specific signed-tail budget proves that both methods suffice for
the SAME desired actual positive increment. This is not substituting an
easier graph target or merely relabeling the old partial computation.

The old low-frequency certificates are especially cheap: below t2 their
leaf counts are621..6023, compared with the new method's6048 base roots.
Repeating all those slabs with the fixed-middle enumeration would add
unnecessary work. Keep those existing complete raw partitions as DATA
and validate them explicitly in the new full reader. Above t2 use the
finite-middle method, where the actual preflight saves leaf operations.
One measured slab is not a claim of optimality or guaranteed total time.

2. One physical graph, two complete compact enclosures, one tail.

The56 original base frequency slabs partition[1/2,10]. At indices0..15,
covering[1/2,2], read the existing original four-infinite-curve partitions
and their original stronger target(5/2)/(1+t_mid^2). Their compact phase
enlargement covers all actual q>=7,r>=1 and lambda=1/(q+r) in[0,1/14].
The retained whole reflection q>=r implies q>=7, so EVERY actual graph
used by the new fixed-middle route is included. No private-energy or
finite-norm assertion is applied to a fake lambda0/infinite middle state.

At indices16..55, covering[2,10], use the actual378 finite middle pairs
and two infinite outer progressions with target(14/5)/(1+t_mid^2).
The normalized response is the SAME physical cap in both descriptions.
The actual old root remains fixed over the entire graft; the frequency
enclosures may use different mathematical supersets. Taking an upper
bound at each frequency does not require that all those upper witnesses
come from one graph. Each actual graph keeps its own one whole-integral
private reserve and signed-tail regime, as in fixed-middle-proof.md.

The two compact pieces are disjoint except their shared endpoint2.
All lower slab targets are smaller than the common14/5 budget. Thus the
complete exact selected sum is bounded by the already proved fixed-budget
target sum. Low t0..1/2 costs at most1/2 energy. The entire t>=10 signed
tail is checked on all128 z intervals for each actual regime14..19 and
20..41, with respectively private reserves269/100 and43/10. Both final
exact surplus Fractions must exceed1/20. This proves the complete actual
family only AFTER all56 compact slabs have passed and the final exact
inequalities are verified. No interval is silently dropped at the join.

3. Reuse, coverage and executable acceptance.

prepare_full.py freezes every original33 computation source, all16 old
partition files, new mathematical/control sources and the exact actual
sector/net-phase/lossless proofs. It checks the completed preflight's
reader, certificate and full source hashes. The old16 data files are
copied byte-for-byte to the new folder. The one exact preflight23 is
also copied and its complete result reused without recalculating it.
Only39 new higher-frequency partitions need to be produced.

The new reader fully validates all old16 partitions with the unchanged
old exact frequency parser. For the new cells it uses the independent
fixed_cover parser, calibrated on valid mixed-frequency/length trees and
13 damaged artifacts. The q,r enumeration is independent of the producer
loop order and has exactly6048 roots. Every accepted slab gets an atomic
result with full source snapshot and raw certificate hash; a resumed run
can reuse only an identical completed exact slab. This avoids repeating
verified arithmetic after a purely observational interruption.

The final source-bound certificate must contain exactly56 indexed data
hashes and the declared physical domain. The reader checks the entire
frequency chain from1/2 to10, every exact area, both signed tails and
both final inequalities, and rechecks all frozen source hashes. A missing
file wait is bounded; neither a wait nor an intermediate result is the
completed family theorem. A budget failure is a method gap unless an
actual original graph with a certified negative target is supplied.

All original jobs continue unchanged while this complete alternative is
executed. No foreign process, subagent, timer or publication is started.
The endpoint-cache test was not adopted because its measured difference
was small. Completion of this hybrid family alone would still leave the
private sibling family and the final exact original assembly obligations.
