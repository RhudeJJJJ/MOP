"""Bounded FLOAT partition proposal only: one representative frequency slab."""
from pathlib import Path
from fractions import Fraction as F
import sys,json,time,hashlib
P=Path(__file__).resolve().parent;BASE=P.parent/'mop-double-reciprocal-20261108';sys.path.insert(0,str(BASE))
import float_discovery
float_discovery.install()
import fixed_bound as f
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    start=time.monotonic();control=json.loads((P/'fixed-controls.json').read_bytes());assert all(sha(Path(p))==h for p,h in control['source_sha256'].items());frozen=json.loads((BASE/'checkpoints/producer-inputs.json').read_bytes());assert all(sha(BASE/n)==h for n,h in frozen.items())
    index=23;grid=json.loads((BASE/'frequency-grid.json').read_bytes());a,b=F(grid[index]['a']),F(grid[index]['b']);target=F(14,5)/(1+((a+b)/2)**2);calls=leaves=0;max_anchor=0
    def solve(p,s,q,r,tails=(True,True),lo=a,hi=b,depth=0):
        nonlocal calls,leaves,max_anchor
        calls+=1;assert calls<=100000 and max(p,s)<=120,'bounded preflight exhausted'
        intervals=[v for tail in tails for v in(0. if tail else 1.,1.)];best=None
        for mode in['0','6']:
            got=f.bound(float(lo),float(hi),*intervals,p,s,q,r,mode);got['symbol']=mode
            if best is None or got['upper']<best['upper']:best=got
            if best['upper']<=float(target)-1e-7:break
        if best['upper']<=float(target)-1e-7:leaves+=1;max_anchor=max(max_anchor,p,s);return best['symbol']
        grad=best.get('grad');scores=[float(grad[j+1])if grad and tails[j]else 1/(v+1)if tails[j]else-1. for j,v in enumerate([p,s])]
        scores.append(float(grad[0])*float(hi-lo)if grad and depth<6 else float(hi-lo)if depth<6 else-1.);dim=max(range(3),key=lambda j:scores[j]);assert scores[dim]>=0,'bounded isolated pair frequency refinement exhausted'
        if dim==2:
            mid=(lo+hi)/2
            return'3'+solve(p,s,q,r,tails,lo,mid,depth+1)+solve(p,s,q,r,tails,mid,hi,depth+1)
        single=list(tails);single[dim]=False;lengths=[p,s];lengths[dim]+=4
        return str(dim+1)+solve(p,s,q,r,tuple(single),lo,hi,depth)+solve(*lengths,q,r,tails,lo,hi,depth)
    trees=[]
    for number,(p,s,q,r)in enumerate(f.roots(),1):
        trees.append(solve(p,s,q,r))
        if number%256==0:print(json.dumps(dict(status='HEURISTIC_FIXED_MIDDLE_PREFLIGHT_PROGRESS',roots=number,total=6048,calls=calls,leaves=leaves,max_anchor=max_anchor,seconds=time.monotonic()-start)),flush=True)
    assert all(sha(BASE/n)==h for n,h in frozen.items());hashes={n:sha(P/n)for n in ['fixed_bound.py','check_fixed_bound.py','fixed-controls.json','produce_preflight.py']}
    out=dict(status='HEURISTIC_FIXED_MIDDLE_PREFLIGHT_REQUIRES_FULL_EXACT_READER',index=index,a=str(a),b=str(b),target=str(target),target_amplitude='14/5',roots=6048,trees=trees,calls=calls,leaves=leaves,max_anchor=max_anchor,source_sha256=hashes,inherited_source_sha256=frozen,seconds=time.monotonic()-start,original_global='OPEN');(P/'preflight-certificate.json').write_text(json.dumps(out,separators=(',',':'))+'\n');print(json.dumps({k:v for k,v in out.items()if k not in ['trees','source_sha256','inherited_source_sha256']}),flush=True)
if __name__=='__main__':main()
