"""Bounded transparent cache ONLY for exact finite middle endpoint evaluations."""
from collections import OrderedDict
import fixed_bound as base
ad=base.ad
original=ad.endpoints
CACHE=OrderedDict();HITS=MISSES=0
def endpoint(t,u,n):
    global HITS,MISSES
    if u.v[0]==u.v[1]==u.c[0]==u.c[1]==1 and all(ad.iszero(x)for x in u.d):
        key=(getattr(ad.h,'BACKEND',None),tuple(ad.RAD),tuple(ad.RINT),t.v,t.c,t.d,n)
        if key in CACHE:
            HITS+=1;CACHE.move_to_end(key);return CACHE[key]
        MISSES+=1;value=original(t,u,n);CACHE[key]=value
        if len(CACHE)>1024:CACHE.popitem(last=False)
        return value
    return original(t,u,n)
def install():
    assert ad.endpoints is original,'cache must be installed exactly once after the arithmetic backend'
    ad.endpoints=endpoint
bound=base.bound
roots=base.roots
