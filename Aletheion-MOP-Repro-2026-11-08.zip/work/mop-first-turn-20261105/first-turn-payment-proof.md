# Every first-turn cap with private fan of order L>=5 is paid

5 November2026. Original every UNIT MOPn>=8,F>=2n remains GLOBALOPEN.
This is an all-parent incremental theorem, not a global decomposition.

Let H be ANY finite simple UNIT MOP,nH>=3, with ordered boundary ab.
Retainab. Add PRIVATE u,v1,..,v_(L-1), L>=5, with fan edges uvi and
vivi+1, and contacts au,av1,bu. The outer arc is a,v1,..,v_(L-1),u,b.
There are Lnew vertices,2Lnew unit edges, and NOother private contacts.
Coherent WHOLEreflection is allowed. Then

                   F(new)-F(H)>2L.

For L5,6,7 the exact lower increments are respectively10.138571,
12.468411,14.876347. No old order/degree/norm/spectrum bound occurs.

Proof for L5..7: use the already proved one-sided anisotropic mode
filter (universal-C3-anisotropic-filter-proof.md,equation9). Install all
nonpositive modes first, and positive modes ascending. The actual private
fan is connected; its positive Perron root rho is simple. Exact root
intervals give rho>2. With sigma=rho every already installed private
eigenvalue is<=sigma; the favorable-sign floor is therefore preserved.
Equation8then gives the FULLtop contact reward g=Tr(T P_rho T^t).
All other private positive energies are retained, even when their contact
rewards are dropped. Thus DeltaF>=F(fan_L)+g. The exact reader computes
g=N(rho)/p'(rho),N=Tr(T adj(xI-B)T^t),using direct contact moments.
It checks actual B,T, Newton characteristic, ALLprivate real-root intervals
and multiplicities, exact rational interval division and the three stated
strict comparisons. This is the SAMEphysicalgraft and common old parent.

For L8..20 the reader checks F(fan_L)>2L directly. Disjoint-principal-
block superadditivity gives F(new)>=F(H)+F(fan_L), so contacts need no
additional reward. For ALL L>=21 use the ANALYTICtail of the retained
fan_direct_D_bound_proof.txt: D(fan_L)>2sqrt(L-2)>6. Since the fan has
2L-3edges, F(fan_L)=2L-3+D/2>2L. This is an unbounded analytic tail,
not extrapolation from the16finite orders.

The finite reader reuses the retained rational isolation intervals as
DATA and checks their actual polynomial and multiplicities by a separate
stdlib Newton/Sturm route. Repeated-root gcd layers are counted; zeros
remain in the actual matrix. A missing private eigenvalue is rejected.
Exact arithmetic helpers are shared with the earlier work; no external
formal audit or exhaustive first-payment/priority comparison is claimed.

Intended geometric use: a FIRSTunary turn above an otherwise straight
terminal fan of>=4faces has this privatefan_L form, L>=5. The complete
all-length geometric implication remains to be written and independently
calibrated against actual plane weak-dual paths. Do not promote a word or
degree profile to an actual closed region without that check.

Minimal-counter pruning additionally REQUIRES nH>=8. If removing a very
long cap leaves3..7vertices, the displayed increment alone cannot assume
that small H has F(H)>=2nH. That remaining whole-graph case needs its own
reserve/payment argument. The original global goal, short branching ends,
whole fan-region compensation and sufficient actual extraction stayOPEN.
The older external-apex bare-fan cap counterexample retains its scope:
here the fan apex u is PRIVATE, not an external root.
