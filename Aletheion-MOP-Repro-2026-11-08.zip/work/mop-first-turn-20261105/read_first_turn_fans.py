from pathlib import Path
from fractions import Fraction as F
import hashlib,json,sys
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(HERE.parent/'mop-root-sector-20261105'));import read_anisotropic_cap_certificates as old
r=old.rat
def count(p,a,b):
    if len(p)==1:return 0
    if a==b:return int(r.ev(p,a)==0)
    assert r.ev(p,a)!=0 and r.ev(p,b)!=0
    seq=r.sturm(p);return r.variations(seq,a)-r.variations(seq,b)
def check(row):
    n=row['n'];B=[[F(int((i==0 and j>0) or (j==0 and i>0) or (i>0 and j>0 and abs(i-j)==1))) for j in range(n)] for i in range(n)]
    p=r.characteristic(B);assert p==list(reversed(row['characteristic_polynomial_coefficients']))
    levels=[p]
    while len(levels[-1])>1:
        g=r.gcd(levels[-1],r.derivative(levels[-1]))
        if len(g)==1:break
        levels.append(g)
    intervals=[];energy=F(0);multiplicities=0
    for z in row['rational_root_intervals']:
        a,b=F(*z['lower']),F(*z['upper']);assert a<=b
        counts=[count(q,a,b) for q in levels];assert all(k in (0,1) for k in counts)
        assert counts==sorted(counts,reverse=True) and counts[0]==1 and sum(counts)==z['multiplicity']
        intervals.append((a,b,z['multiplicity']));multiplicities+=z['multiplicity']
        if a>0:energy+=z['multiplicity']*a*a
        else:assert b<=0
    intervals.sort();assert multiplicities==n and all(intervals[i][1]<intervals[i+1][0] for i in range(len(intervals)-1))
    reward=F(0)
    if n<=7:
        a,b,mult=intervals[-1];assert a>2 and mult==1
        T=[[F(int(i in (0,1))) for i in range(n)],[F(int(i==0)) for i in range(n)]]
        N=old.weighted_numerator(B,T,old.util.eye(2),p);reward=r.idiv(r.iev(N,(a,b)),r.iev(r.derivative(p),(a,b)))[0]
        assert reward>0 and energy+reward>2*n
    else:assert energy>2*n
    return dict(private_n=n,private_energy_lower=str(r.lower(energy)),top_contact_reward_lower=str(r.lower(reward)),
      gain_lower=str(r.lower(energy+reward)),target=2*n,all_private_roots_and_multiplicities_checked=True)
def main():
    source=ROOT/'fan-direct-D-bound-verification.json';d=json.loads(source.read_text());rows=[check(row) for row in d['rows'] if 5<=row['n']<=20]
    assert [z['private_n'] for z in rows]==list(range(5,21))
    # Missing one actual eigenvalue must be caught before accepting energy.
    damaged=json.loads(json.dumps(next(z for z in d['rows'] if z['n']==5)));damaged['rational_root_intervals'].pop()
    try:check(damaged)
    except AssertionError:rejected=True
    else:rejected=False
    assert rejected
    out=dict(status='PASS_EXACT_FIRST_TURN_PRIVATE_FAN_PAYMENTS_L5_TO20_WITH_RETAINED_ANALYTIC_TAIL',rows=rows,
      source=str(source),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),damaged_missing_private_eigenvalue_rejected=True,
      analytic_tail='L>=21: retained fan_direct_D_bound_proof analytic Rayleigh/interlacing tail givesD>2sqrt(L-2)>6, henceF(fan_L)>2L; principal pinching pays actualgraft. No finite base extrapolation.',
      finite_bridge='L5..7: existing one-sided anisotropic filter installs allnonpositive modes first; positive Perron rho>2 gets FULLactualcontact reward; other positive private energies preserved. L8..20: exactprivateenergy alone exceeds2L.',
      geometry='A first unary turn above a pure terminal fan of>=4faces has privatefan_L,L>=5 and contactrows e_u+e_v1,e_u. Exact all-length topological argument still must be written and checked before claiming a global structural consequence.',
      original_status='GLOBAL_OPEN',native_intake='NOT_YET_PREPARED')
    (HERE/'first-turn-exact-check.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(status=out['status'],small=rows[:3],checked_orders=16,missing_eigenvalue_rejected=True,original_status='GLOBAL_OPEN',native_intake='NOT_YET_PREPARED')))
if __name__=='__main__':main()
