"""Stdlib Q(i) exact reader; independent ear-insertion catalogue coverage."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
import json,hashlib,sys
ROOT=Path(__file__).resolve().parent
sha=lambda n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest()

class QI:
    __slots__=('r','i')
    def __init__(self,r=0,i=0):
        if isinstance(r,QI):self.r,self.i=r.r,r.i
        else:self.r,self.i=F(r),F(i)
    def __add__(self,z):z=QI(z);return QI(self.r+z.r,self.i+z.i)
    __radd__=__add__
    def __neg__(self):return QI(-self.r,-self.i)
    def __sub__(self,z):return self+-QI(z)
    def __rsub__(self,z):return QI(z)+-self
    def __mul__(self,z):z=QI(z);return QI(self.r*z.r-self.i*z.i,self.r*z.i+self.i*z.r)
    __rmul__=__mul__
    def __truediv__(self,z):
        z=QI(z);q=z.r*z.r+z.i*z.i;assert q
        return QI((self.r*z.r+self.i*z.i)/q,(self.i*z.r-self.r*z.i)/q)
    def __eq__(self,z):z=QI(z);return self.r==z.r and self.i==z.i

def solve(M,B):
    n=len(M);k=len(B[0]);A=[[QI(z) for z in row]+[QI(z) for z in b] for row,b in zip(M,B)]
    for j in range(n):
        pivot=next(i for i in range(j,n) if A[i][j]!=0);A[j],A[pivot]=A[pivot],A[j];d=A[j][j]
        A[j]=[z/d for z in A[j]]
        for i in range(n):
            if i==j or A[i][j]==0:continue
            d=A[i][j];A[i]=[u-d*v for u,v in zip(A[i],A[j])]
    return [row[n:] for row in A]

def catalogue():
    old={((0,1),(0,2),(1,2))};out={3:old}
    for n in range(3,8):
        new=set()
        for E in old:
            for i in range(n):
                B=list(range(n));B.insert(i+1,n);pos={v:j for j,v in enumerate(B)};es=set(E)|{tuple(sorted((i,n))),tuple(sorted(((i+1)%n,n)))}
                new.add(tuple(sorted(tuple(sorted((pos[a],pos[b]))) for a,b in es)))
        out[n+1]=old=new
    return out

def psd(M):
    return M[0][0]>=0 and M[1][1]>=0 and M[0][0]*M[1][1]>=M[0][1]*M[1][0]

def root_response(n,E,a,b,t):
    assert tuple(sorted((a,b))) in E
    interior=[v for v in range(n) if v not in(a,b)];es=set(E)
    R=[[int(tuple(sorted((u,v))) in es) for v in interior] for u in(a,b)]
    C=[[QI(t if u==v else 0,int(tuple(sorted((u,v))) in es)) for v in interior] for u in interior]
    X=solve(C,list(map(list,zip(*R))))
    return [[sum((R[i][k]*X[k][j] for k in range(n-2)),QI()) for j in range(2)] for i in range(2)],R

def cap(t):
    # Direct private3-by-3 inverse, independent of +/- response formula.
    M=[[QI(t),QI(0,1),QI(0,1)],[QI(0,1),QI(t),QI()],[QI(0,1),QI(),QI(t)]]
    T=[[1,1,0],[1,0,1]];X=solve(M,list(map(list,zip(*T))))
    return [[sum((T[i][k]*X[k][j] for k in range(3)),QI()) for j in range(2)] for i in range(2)]

def theta_interval(S,t):
    W=cap(t);det=lambda X:X[0][0]*X[1][1]-X[0][1]*X[1][0]
    N=[[S[i][j]+W[i][j] for j in range(2)] for i in range(2)];q=det(N)/det(S)
    assert q.r>0 and q.i<0
    x=q.i/q.r;error=abs(x)**3/3
    return x-error,x+error

def check_bound(lo,hi,t,D):
    mid=F(-6,t**3);radius=F(35*D+430,t**5)
    assert mid-radius<=lo<=hi<=mid+radius

def topology(n,E):
    assert len(E)==2*n-3 and len(set(E))==len(E)
    assert all(0<=a<b<n for a,b in E) and all(tuple(sorted((v,(v+1)%n))) in E for v in range(n))
    for (a,b),(c,d) in combinations(E,2):
        if len({a,b,c,d})==4:assert not(a<c<b<d or c<a<d<b)

def main():
    if '--manifest' in sys.argv:
        for n,h in json.loads((ROOT/'local-tail-246-manifest.json').read_text())['artifact_sha256'].items():assert sha(n)==h,n
    c=json.loads((ROOT/'local-tail-246-certificate.json').read_text());cats=catalogue();listed={n:set() for n in cats}
    for z in c['graphs']:listed[z['n']].add(tuple(map(tuple,z['edges'])))
    assert listed==cats and len(c['graphs'])==sum(map(len,cats.values()))==196
    assert {n:len(z) for n,z in cats.items()}=={int(k):v for k,v in c['counts'].items()}
    roots=tests=0;min_margin=None
    for n,graphs in cats.items():
        for E in sorted(graphs):
            topology(n,E);degrees=[sum(v in e for e in E) for v in range(n)]
            for a in range(n):
                b=(a+1)%n;D=max(degrees[a],degrees[b]);roots+=1
                for t in (max(8,D),D+16,2*(D+16)):
                    F0,R=root_response(n,E,a,b,t);P=[[z.r for z in row] for row in F0];Q=[[z.i for z in row] for row in F0];G=[[sum(x*y for x,y in zip(R[i],R[j])) for j in range(2)] for i in range(2)]
                    assert G==[[degrees[a]-1,1],[1,degrees[b]-1]]
                    assert psd([[D*int(i==j)-G[i][j] for j in range(2)] for i in range(2)])
                    assert psd(P) and psd([[F(G[i][j],t)-P[i][j] for j in range(2)] for i in range(2)])
                    for sign in(-1,1):assert psd([[2*P[i][j]+sign*t*Q[i][j] for j in range(2)] for i in range(2)])
                    S=[[F0[i][j]+QI(t*int(i==j),int(i!=j)) for j in range(2)] for i in range(2)]
                    lo,hi=theta_interval(S,t);check_bound(lo,hi,t,D);assert hi<0
                    margin=F(35*D+430,t**5)-max(abs(lo+F(6,t**3)),abs(hi+F(6,t**3)))
                    min_margin=margin if min_margin is None else min(min_margin,margin);tests+=1
        print('LOCAL_TAIL_EXACT246',n,'graphs',len(graphs),'roots',roots,'points',tests,flush=True)
    assert roots==c['boundary_roots']==1470 and tests==c['rational_frequency_tests']==4410
    # Audit the literal rational constants in the analytic remainder.
    assert F(41,2)+F(441,8)+F(343,96)==F(7603,96)<80 and F(1512,5)<303
    assert 8+12+24+80+303==427<430
    for D in range(2,101):assert 6*(D+16)**2-(35*D+430)==6*D**2+157*D+1106>0
    # Scalar real-symmetric response: only the PLUS wedge is positive.
    t=16;f=QI(t,100)/F(t*t+100**2);P=f.r;Q=f.i
    assert 2*P+t*Q>0 and 2*P-t*Q<0 and Q>2*P/t
    # Missing old rootedge changes leading cubic coefficient from6 to4.
    t=100;lo,hi=theta_interval([[QI(t),QI()],[QI(),QI(t)]],t)
    try:check_bound(lo,hi,t,2)
    except AssertionError:missing=True
    else:raise AssertionError('Missing rootedge accepted as cubic6')
    # Missing graph defeats the independent insertion catalogue comparison.
    damaged={n:set(es) for n,es in listed.items()};damaged[8].pop();assert damaged!=cats
    assert c['proof_sha256']==sha('local_degree_fork_tail_246_proof.txt')
    out=dict(status='PASS_EXACT_LOCAL_ROOT_DEGREE_FORK_TAIL246',original='GLOBAL OPEN',certificate_sha256=sha('local-tail-246-certificate.json'),proof_sha256=c['proof_sha256'],complete_small_graphs=196,boundary_roots=roots,rational_frequency_tests=tests,minimum_outward_bracket_margin=str(min_margin),controls=dict(bothsector_and_original_contact_moment_bounds=True,one_sign_scalar_response_rejected=True,missing_rootedge_wrong_cubic_coefficient_rejected=missing,missing_catalogue_graph_rejected=True,noncommuting_log_constants_exact=True),scope='WrittenALLoriginalrootlocal-degreetail independentfarorder/degrees.196smallgraphs/4410exactpointsCALIBRATIONnotglobalFork6floor/2ncoverage. Allorderusesnamed201bothsectorpremise.')
    (ROOT/'local-tail-246-verification.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf8');print('PASS_LOCAL_ROOT_UNIFORM_FORK_TAIL246',tests,'exactpoints; originalGLOBALOPEN',flush=True)
if __name__=='__main__':main()
