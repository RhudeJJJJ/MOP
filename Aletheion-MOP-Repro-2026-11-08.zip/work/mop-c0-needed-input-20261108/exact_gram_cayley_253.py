"""Intrinsic Q(i) rank-two envelope, retaining its nonorthonormal Gram metric."""
from fractions import Fraction as F
from exact_cayley_envelope_249 import QI,eye,add,sub,scale,mul,adj,trace,det,sqrt_interval
from exact_phase_quadrature_248 import atan_interval,argument

def inverse(A):
    assert len(A)==len(A[0])==2
    d=det(A);assert d!=0
    return [[A[1][1]/d,-A[0][1]/d],[-A[1][0]/d,A[0][0]/d]]
def gram(r,p):return [[QI(r),QI(1)],[QI(1),QI(p)]]
def metric_adjoint(V,G):return mul(mul(inverse(G),adj(V)),G)
def data(r,p,t,wrong_metric=False):
    assert isinstance(r,int) and isinstance(p,int) and r>=1 and p>=1 and r*p>1 and t>0
    t=F(t)
    G=gram(r,p);I=eye(2)
    sp=QI(t,1)+QI(3*t/(t*t+2),-4/(t*t+2));sm=QI(t+1/t,-1)
    qp=QI(1)/sp;qm=QI(1)/sm
    Q1=scale([[qp+qm,qp-qm],[qp-qm,qp+qm]],F(1,2))
    Q0=scale([[QI(t),QI(0,-1)],[QI(0,-1),QI(t)]],1/(t*t+1))
    A=[];H=[]
    for Q in(Q0,Q1):
        re=[[QI(v.r) for v in row] for row in Q];im=[[QI(v.i) for v in row] for row in Q]
        A.append(add(scale(I,t),mul(re,G)));H.append(mul(im,G))
    for X in A:
        Z=mul(G,X);assert Z==adj(Z) and Z[0][0].i==0 and Z[0][0].r>0 and det(Z).i==0 and det(Z).r>0
    diff=sub(H[1],H[0]);B=add(add(A[0],A[1]),scale(diff,QI(0,1)));E=add(sub(A[1],A[0]),scale(diff,QI(0,1)))
    V=mul(inverse(B),E);star=adj(V) if wrong_metric else metric_adjoint(V,G)
    M=mul(mul(mul(A[0],V),inverse(A[0])),star);tr=trace(M);tr2=trace(mul(M,M))
    if wrong_metric:return tr,tr2
    assert tr.i==tr2.i==0
    a=tr.r;b=(a*a-tr2.r)/2;disc=a*a-4*b
    assert b>=0 and disc>=0 and a<2 and 1-a+b>0
    return dict(trace=a,product=b,discriminant=disc,center_det=det(B),base_det=sp*sm)
def node(r,p,t,terms=12,D=10**14):
    z=data(r,p,t);sl,su=sqrt_interval(z['discriminant'],D)
    lam=[(z['trace']+su)/2,(z['trace']-sl)/2];assert all(0<=x<1 for x in lam)
    upper=F()
    for x in lam:
        _,a=sqrt_interval(x,D);b,_=sqrt_interval(1-x,D);assert b>0
        upper+=atan_interval(a/b,terms)[1]
    upper+=argument(z['center_det'],terms)[1]+argument(z['base_det'],terms)[1]
    return F(-((-upper.numerator*10**9)//upper.denominator),10**9),z
def error(N=320,T=20):
    h=(F(T)-F(1,10))/N
    assert T==20 and N>0
    # log(T/a)=log200<6, not the old [a,10] log100<5 estimate.
    return F(159,384)*(10*h**3+6*h**2)
def tail(g,T=20):
    assert T>=10 and g<T*T
    return -F(6,T)+F(3*g,T*T-g)+F(41,3*T**3)
def domain():
    return [(r,p) for r in range(1,11) for p in range(max(r,2),22-r)]
