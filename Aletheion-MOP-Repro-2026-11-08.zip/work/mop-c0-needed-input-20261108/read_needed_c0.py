from pathlib import Path
from fractions import Fraction as F
import json,hashlib,time
from exact_serial_cayley_256 import node,data,error,tail
from exact_cayley_envelope_249 import QI,eye,mul,adj,scale,det
from exact_gram_cayley_253 import inverse
P=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    start=time.monotonic();original=json.loads((P/'original-source-inputs.json').read_bytes());assert all(sha(P/n)==h for n,h in original['members'].items());source={n:sha(P/n)for n in list(original['members'])+['needed-c0-proof.md','read_needed_c0.py','prepare_sources.py','original-source-inputs.json']}
    for t in[F(1,10),F(1),F(20)]:
        T=[[QI(1),QI(1)],[QI(1),QI(0)]];S=[[QI(t),QI(0,1)],[QI(0,1),QI(t)]];actual=mul(mul(T,inverse(S)),adj(T));assert actual==scale([[QI(2*t,-2),QI(t,-1)],[QI(t,-1),QI(t)]],1/(t*t+1))
    good=data(3,1,F(7,10));wrong=data(3,1,F(7,10),True);assert wrong[0].r!=good['trace']or wrong[0].i!=0;assert data(3,1,F(7,10))['trace']!=data(1,3,F(7,10))['trace']
    N=192;h=F(199,1920);rows=[]
    for r in range(3,15):
        values=[];total=F(0)
        for j in range(N):
            t=F(1,10)+(j+F(1,2))*h;upper,_=node(r,1,t);values.append(str(upper));total+=h*t*upper
        high=total+error(N)+F(11,700)+tail(r+1);gain=4-F(7,11)*high;assert high<0 and gain>F(409,100);rows.append(dict(apex_gram=r,other_gram=1,node_upper_bounds=values,midpoint_upper=str(total),error_upper=str(error(N)),low_upper='11/700',tail_upper=str(tail(r+1)),integral_upper=str(high),gain_lower=str(gain)));print(json.dumps(dict(status='FRESH_USED_C0_ORDERED_GRAM_PASSED',r=r,p=1,gain_lower=str(gain),gain_float=float(gain))),flush=True)
    assert all(sha(P/n)==h for n,h in source.items());out=dict(status='PASS_FRESH_ALL12_ACTUALLY_USED_ORDERED_C0_GRAMS_UNBOUNDED_HERMITIAN_INTERIOR',ordered_grams=12,fresh_exact_node_envelopes=2304,rows=rows,source_sha256=source,uniform_gain='409/100',minimum_exact_gain=str(min(F(r['gain_lower'])for r in rows)),matrix_domain='ALL finite Hermitian C and real R with RRt=[[r,1],[1,1]],integer3<=r<=14; literal asymmetric unit serialP2,T[[1,1],[1,0]]',actual_original_tip_domain='Unaryq3..14 and doubletotal<=13 with one innerlength>=3, n>=72 gives retainedn-2>=70. Actual whole-to-retained root degrees differ2and1,oldgram(r,1) in the12cases.',scope='New smaller fresh finite kernel for already proved bounded serial class; stronger4.09on actual used subset. No R0/E10/old finite-energy premise, no universal all-root serial payment, no first class closure or original global completion.',seconds=time.monotonic()-start,original_global='OPEN');(P/'needed-c0-result.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in['rows','source_sha256']},indent=2))
if __name__=='__main__':main()
