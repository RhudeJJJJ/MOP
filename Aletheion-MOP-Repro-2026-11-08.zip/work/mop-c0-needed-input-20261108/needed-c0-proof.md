# The twelve ordered serial inputs actually used by the global assembly

8 November2026. ORIGINAL EVERY finite simple UNIT MOP n>=8,F=splus>=2n
GLOBAL OPEN. This is a standalone bounded serial input, not a new first
closure of that already proved class and not a global theorem. It avoids
using the old R0/46-to10/E10 selector as a premise of this particular step.

THEOREM. For EVERY finite Hermitian C and real R with
R R^t=[[r,1],[1,1]], integer3<=r<=14, let Aold=[[J,R],[R^t,C]],
J=[[0,1],[1,0]]. Append two private vertices with private adjacencyP2
and root contact rows T=[[1,1],[1,0]], retaining every old entry. Then

                    F(Anew)-F(Aold)>409/100.

No dimension, far-degree, norm, trace, spectrum or graph hypothesis on C
is used. The matrix extension is allowed as a stronger lemma; the target
global graph class is still finite simple UNIT maximal outerplanar.

1. A complete generic matrix argument behind the finite certificate.

Put S0=tI+iJ, K=T(tI+iP2)^-1T^t,
K=[[2t-2i,t-i],[t-i,t]]/(t²+1), S1=S0+K, t>0.
ReK is positive definite. Let Lj=tI+R^t Sj^-1R=Aj+iHj; Aj>0.
Root-first Schur elimination gives the anchored complete phase increment
delta=ArgdetS1+phase(L1+iC)-phase(L0+iC), since detS0 and the private
P2 determinant t²+1 are positive. Every phase is a continuous trace-log
phase fixed at infinity; the argument of a product ratio is not reset.

Congruence by A0^-1/2 gives Hermitian X=A0^-1/2(C+H0)A0^-1/2 and
strictly accretive L=A0^-1/2(A1+i(H1-H0))A0^-1/2. With
U=(I-iX)(I+iX)^-1 unitary, Tcal=(I+L)^-1(L-I), Ccal=(I+L)/2,

(L+iX)(I+iX)^-1=Ccal(I+Tcal U),
I-Tcal* Tcal=4(L+I)^(-*)(ReL)(L+I)^-1>0.

The rowspace W=rangeR^t supports every nonidentity term. Its dimension
is two; the zero complement contributes no phase or singular values.
C itself need not preserve W. The two nonzero eigenvalue moduli of
Tcal U are log-majorized by its two singular values sigma1,sigma2:
the larger modulus<=sigma1, and their product<=sigma1*sigma2 by the
determinant of the two-by-two contraction compression U_WW. Since
arg(1+z)<=asin|z| for |z|<1, and x->asin(exp x) is increasing/convex,
the summed phase is at most asin(sigma1)+asin(sigma2). This remains true
for zero singular values by continuity. Thus for the SAME actual C,

delta(t)<=ArgdetS1+phase(Ccal)+asin(sigma1)+asin(sigma2).       (1)

The identity's additive constant is fixed by X=sI,s->infinity: U->-I,
I-Tcal=Ccal^-1, so the center and logarithm phases cancel. Connectedness
of Hermitian X and nonvanishing accretive determinants preserve this
constant for every actual C. No common maximizing C at different t is
asserted: (1) bounds the same actual phase separately at each frequency.

2. Exact intrinsic arithmetic, with root roles retained.

In the basis z->R^t z, the metric is G=R R^t, and
Aj=tI+Re(Sj^-1)G,Hj=Im(Sj^-1)G. Set
B0=A0+A1+i(H1-H0),E0=A1-A0+i(H1-H0),V=B0^-1E0.
The correct adjoint is Vsharp=G^-1 V*G. The matrix
M=A0 V A0^-1 Vsharp is similar to Tcal Tcal*. Its real invariants
a=TrM,b=((TrM)²-Tr(M²))/2 give squared singular values
(a+-sqrt(a²-4b))/2. The center phase is ArgdetB0, with only positive
determinant factors omitted. It is added separately to ArgdetS1.
The asymmetric rows of T are never interchanged to identify r with1.

The copied five source modules are byte-identical to the retained256
reader inputs. At each rational node they use exact Gaussian Q(i)
arithmetic, verify positive GAj principal minors, nonnegative singular
discriminants and singular squares in[0,1), and enclose square roots by
rational integer-square-root intervals of denominator10^14. The smaller
singular square uses the LOWER discriminant-root endpoint. Rational
atan/Machin-pi bounds give upper angle endpoints. Each final node phase
upper is rounded UP to denominator10^9. No float accepts an inequality.

3. Whole-frequency integration, independent of the far matrix.

A Hermitian principal extension by two has spectral counting difference
0<=xi<=2. Its lifted delta satisfies |delta|<pi, |delta'|<=2/t and
|delta''|<=3sqrt3/(2t²). These follow by differentiating
-pi+integral t*xi(x)/(t²+x²)dx; positive-part derivative integrals are
1/t and3sqrt3/(4t²). Consequently |(t delta)''|<53/(8t).
This is a derivative of the ACTUAL common-source phase, not of envelope(1).

On[1/10,20], N192 midpoints have width h=199/1920 and summed error
E=(53/192)(10h³+6h²), using log200<6, certified by
sum_(j=0..6)6^j/j!>200. The exact node upper endpoints bound each actual
midpoint value. The entire low interval contributes <pi/200<11/700.

For t>=10, with g=r+1<=15<t², the complete high tail satisfies
delta<=-4/t³+6g/[t^4(1-g/t²)]+41/t^5.
Indeed the literal root/private diamond has characteristic
x(x+1)(x²-x-4),TrA²10,TrA³12,norm<8/3. Its trace-arctangent remainder
after-4/t³ is<41/t^5. Resolvent accretivity gives ||Sj^-1||<=1/t,
||K||<=3/t and ||L-I||<=3g/t^4. The two center/singular-value angles
are bounded by6g/[t^4(1-g/t²)] using asin x<=x/(1-x). This argument
uses no bound on C. Integrating the entire tail from T20 gives

                   -4/T+3g/(T²-g)+41/(3T³).

The new reader FRESHLY evaluates all12*192=2304 exact node envelopes
and combines them with E,low11/700 and this signed infinite tail.
For every ordered(r,1),r3..14, its exact total I_upper is negative and
4-(7/11)I_upper>409/100. Since pi<22/7 and I_upper<0,
the equal-trace spectral identity
DeltaF=4-(2/pi)integral t delta dt proves the theorem. Repeated/zero
eigenvalues and nonzero TrC are allowed: old/new traces agree and their
linear terms cancel. The four new unit edges give the constant4 exactly.

4. Exact original-domain transfer, with no R0 selector assumption.

In a unit MOP of order>=4, a boundary edge has exactly one common old
neighbor. Thus R R^t=[[dH(a)-1,1],[1,dH(b)-1]]. The used C0 tip has
two private adjacent vertices, apex a seeing both and b only the first.
Deleting it lowers the actual root degrees by2 and1 respectively.

For the unary parent, q3..14 gives whole degrees(q+3,3), retained
degrees(q+1,2), hence G=[[q,1],[1,1]]. For the small double middle,
m=q+r<=13 with one inner length>=3 gives whole degrees(m+4,3),
retained(m+2,2), hence G=[[m+1,1],[1,1]],m>=4. Both are among the
twelve ordered cases. The closing edge and asymmetric contact roles
are the literal retained ones. No private tip vertex has outside contacts.
Original counter order n>=72 leaves an actual retained MOP n-2>=70;
minimality supplies its original energy, and gain>4.09 excludes the tip.
No E10/R0,46-to10,balanced-fork cut or earlier finite energy result is
assumed inside this matrix input. The full global reduction retains its
own separate other premises and fresh B71 theorem.

The prior actual UNIT order2402 prescribed-serial counter has old Gram
(2370,8),not(r,1),r3..14. Its exact negative certificate remains valid
and is not rerun or retracted. This theorem is not unrestricted serial
payment. Earlier full104 bounded-Gram theorem256 remains true; the new
input only rederives a stronger uniform bound on the twelve actually used
cases, with a smaller standalone fresh certificate and explicit dependencies.
Original global closure and both pending complete families are separate.
