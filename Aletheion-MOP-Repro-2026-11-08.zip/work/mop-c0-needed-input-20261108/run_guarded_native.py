"""ONE unchanged native main, with its OWN guard, after bounded observation.

No observer lease, retry, repair, mutex deletion or foreign process control.
Full observation/exit/output metadata are retained even before native entry.
"""
from pathlib import Path
import contextlib,importlib.util,io,json,sys,time,traceback
HERE=Path(__file__).resolve().parent
APP=Path('C:/Users/jonas/Aletheion/aletheion')
LEARNING=Path('C:/Users/jonas/plugins/grundlagenwerkstatt/skills/grundlagenwerkstatt/scripts/aletheion_learning.py')

def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(spec);sys.modules[name]=m
    spec.loader.exec_module(m);return m

label,family=sys.argv[1:3];args=sys.argv[3:]
start=time.monotonic();out=io.StringIO();err=io.StringIO();code=0
observation=[];entered=False
native_path=LEARNING if family=='learning' else APP/'aletheion_weave.py'
with contextlib.redirect_stdout(out),contextlib.redirect_stderr(err):
    try:
        assert family in ('learning','weave')
        gate=module('contact_readonly_owner_observer',APP/'aletheion_coordination.py')
        native=module('contact_native_'+family,native_path)
        deadline=time.monotonic()+30
        while True:
            state=gate.read(APP/'aletheion.db.coordination/state.json')
            p=APP/'aletheion.db.coordination/mutex.json'
            try:owner=gate.read(p) if p.exists() else None
            except FileNotFoundError:owner=None
            if owner is None:
                if state['status']!='stable':raise RuntimeError('State not stable; no recovery')
                break
            pid=owner.get('pid')
            if not gate.alive(pid):
                try:again=gate.read(p) if p.exists() else None
                except FileNotFoundError:again=None
                if again!=owner:continue
                raise RuntimeError('Unchanged nonlive owner; preserve without recovery')
            seen=dict(pid=pid,label=owner.get('label'),verified_live=True)
            if seen not in observation:observation.append(seen)
            if time.monotonic()>=deadline:raise RuntimeError('Bounded live-owner observation ended; no second call')
            time.sleep(.25)
        sys.argv=[str(native_path),*args]
        entered=True
        result=native.main()
        if isinstance(result,int):code=result
    except SystemExit as ex:code=int(ex.code or 0)
    except Exception:traceback.print_exc();code=1
stdout,stderr=out.getvalue(),err.getvalue()
(HERE/(label+'.stdout.json')).write_text(stdout,encoding='utf-8')
(HERE/(label+'.stderr.txt')).write_text(stderr,encoding='utf-8')
meta=dict(label=label,family=family,argv=[str(native_path),*args],exit_code=code,
          wall_time_seconds=time.monotonic()-start,stdout_bytes=len(stdout.encode()),
          stderr_bytes=len(stderr.encode()),native_main_entered=entered,
          observation=observation,
          invocation='One unchanged native main with its OWN normal guard; bounded readonly owner observation, no retry or protection change')
(HERE/(label+'.process.json')).write_text(json.dumps(meta,indent=2)+'\n')
report=dict(process=meta)
for key,body in [('native_result',stdout),('native_error',stderr)]:
    if len(body.encode())<=12000:
        try:report[key]=json.loads(body)
        except ValueError:report[key]=body
print(json.dumps(report,ensure_ascii=False,indent=2),flush=True)
sys.exit(code)
