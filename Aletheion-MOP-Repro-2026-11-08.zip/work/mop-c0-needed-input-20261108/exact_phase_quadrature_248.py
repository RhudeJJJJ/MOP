"""Exact actual triangle response and outward phase midpoint arithmetic."""
from fractions import Fraction as F
from verify_local_tail_246 import QI,cap

def small_atan(x,terms):
    assert abs(x)<=F(1,2);v=sum(((-1)**j*x**(2*j+1)/F(2*j+1) for j in range(terms)),F());e=abs(x)**(2*terms+1)/F(2*terms+1)
    return v-e,v+e
def pi_interval():
    a=small_atan(F(1,5),18);b=small_atan(F(1,239),18)
    return 16*a[0]-4*b[1],16*a[1]-4*b[0]
PI=pi_interval()
def atan_interval(x,terms):
    if x<0:
        a,b=atan_interval(-x,terms);return -b,-a
    if x<=F(1,2):return small_atan(x,terms)
    if x<=2:
        a,b=small_atan((x-1)/(x+1),terms);return PI[0]/4+a,PI[1]/4+b
    a,b=small_atan(1/x,terms);return PI[0]/2-b,PI[1]/2-a
def argument(z,terms):
    if z.r==0:
        assert z.i!=0
        return (PI[0]/2,PI[1]/2) if z.i>0 else(-PI[1]/2,-PI[0]/2)
    a,b=atan_interval(z.i/z.r,terms)
    if z.r>0:return a,b
    assert z.i!=0,'Negative-real Schur determinant contradicts strict accretivity'
    return(a+PI[0],b+PI[1]) if z.i>0 else(a-PI[1],b-PI[0])
def root_arc(outer,a,b):
    n=len(outer);i=outer.index(a);step=-1 if outer[(i+1)%n]==b else 1
    arc=[outer[(i+step*j)%n] for j in range(n)];assert arc[-1]==b
    return arc
def triangle_response(outer,E,a,b,t):
    arc=root_arc(outer,a,b);pos={v:i for i,v in enumerate(arc)};es={tuple(sorted((pos[x],pos[y]))) for x,y in E};zero=lambda:[[QI(),QI()],[QI(),QI()]];calls=0
    def rec(l,r):
        nonlocal calls
        if r==l+1:return zero()
        choices=[j for j in range(l+1,r) if(l,j) in es and(j,r) in es];assert len(choices)==1
        j=choices[0];calls+=1;L=rec(l,j);R=rec(j,r)
        M=[[QI(t*int(u==v),int(u!=v)) for v in range(3)] for u in range(3)]
        for F0,U in((L,(0,1)),(R,(1,2))):
            for u in range(2):
                for v in range(2):M[U[u]][U[v]]=M[U[u]][U[v]]+F0[u][v]
        U=(0,2);S=[[M[u][v]-M[u][1]*M[1][v]/M[1][1] for v in U] for u in U]
        return [[S[u][v]-QI(t*int(u==v),int(u!=v)) for v in range(2)] for u in range(2)]
    F0=rec(0,len(arc)-1);assert calls==len(arc)-2
    return F0
def phase_interval(F0,t,terms,denominator):
    det=lambda X:X[0][0]*X[1][1]-X[0][1]*X[1][0]
    S=[[F0[i][j]+QI(t*int(i==j),int(i!=j)) for j in range(2)] for i in range(2)];C=cap(t);N=[[S[i][j]+C[i][j] for j in range(2)] for i in range(2)]
    a=argument(det(S),terms);b=argument(det(N),terms);lo=b[0]-a[1];hi=b[1]-a[0]
    return F(lo.numerator*denominator//lo.denominator,denominator),F(-((-hi.numerator*denominator)//hi.denominator),denominator)
def error_bound(N):
    h=F(99,10*N);return F(159,384)*(10*h**3+5*h**2)
def integrate_case(case,N,terms,denominator):
    h=F(99,10*N);lo=hi=F();E=set(map(tuple,case['edges']));a,b=case['root']
    for j in range(N):
        t=F(1,10)+(j+F(1,2))*h;F0=triangle_response(case['outer'],E,a,b,t);L,U=phase_interval(F0,t,terms,denominator);lo+=h*t*L;hi+=h*t*U
    err=error_bound(N)
    return dict(midpoint_lower=str(lo),midpoint_upper=str(hi),quadrature_error=str(err),integral_lower=str(lo-err),integral_upper=str(hi+err),paid_by_compact_criterion=hi+err<=F(541,1400))
