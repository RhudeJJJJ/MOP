"""Q(i) outward upper envelope for arbitrary Hermitian interiors, light root Gram."""
from fractions import Fraction as F
from math import isqrt
from verify_local_tail_246 import QI,solve,cap
from exact_phase_quadrature_248 import argument,atan_interval,phase_interval,error_bound

def adj(A):return [[QI(A[j][i].r,-A[j][i].i) for j in range(len(A))] for i in range(len(A[0]))]
def mul(A,B):return [[sum((x*y for x,y in zip(r,c)),QI()) for c in zip(*B)] for r in A]
def add(A,B):return [[x+y for x,y in zip(r,s)] for r,s in zip(A,B)]
def sub(A,B):return [[x-y for x,y in zip(r,s)] for r,s in zip(A,B)]
def scale(A,c):return [[x*c for x in r] for r in A]
def eye(n):return [[QI(i==j) for j in range(n)] for i in range(n)]
def trace(A):return sum((A[i][i] for i in range(len(A))),QI())
def det(A):
    B=[[QI(z) for z in r] for r in A];v=QI(1);n=len(A)
    for j in range(n):
        k=next((i for i in range(j,n) if B[i][j]!=0),None)
        if k is None:return QI()
        if k!=j:B[j],B[k]=B[k],B[j];v=-v
        d=B[j][j];v=v*d
        for i in range(j+1,n):
            x=B[i][j]/d
            for k in range(j+1,n):B[i][k]=B[i][k]-x*B[j][k]
            B[i][j]=QI()
    return v
def sqrt_interval(x,D=10**14):
    assert x>=0;q=isqrt(x.numerator*D*D//x.denominator);a=F(q,D)
    return(a,a) if a*a==x else(a,F(q+1,D))
def envelope_data(p,t):
    assert p in(2,3) and t>0;I=eye(p);R=[[QI(int(i==0)) for i in range(p)],[QI(1) for i in range(p)]];Rt=adj(R)
    S=[[QI(t),QI(0,1)],[QI(0,1),QI(t)]];K=cap(t)
    assert K[0][0]==K[1][1] and K[0][1]==K[1][0]
    assert K[0][0]+K[0][1]==QI(3*t/(t*t+2),-4/(t*t+2)) and K[0][0]-K[0][1]==QI(1/t)
    N=add(S,K)
    L0=add(scale(I,t),mul(Rt,solve(S,R)));L1=add(scale(I,t),mul(Rt,solve(N,R)))
    A0=scale(add(L0,adj(L0)),F(1,2));A1=scale(add(L1,adj(L1)),F(1,2));H0=scale(sub(L0,adj(L0)),QI(0,-F(1,2)));H1=scale(sub(L1,adj(L1)),QI(0,-F(1,2)));D=sub(H1,H0)
    B=add(add(A0,A1),scale(D,QI(0,1)));E=add(sub(A1,A0),scale(D,QI(0,1)))
    # M is similar to T T*, with T=A0^(1/2) B^-1 E A0^(-1/2).
    V=solve(B,E);M=mul(mul(A0,V),solve(A0,adj(V)))
    tr=trace(M);tr2=trace(mul(M,M));assert tr.i==tr2.i==0
    a=tr.r;b=(a*a-tr2.r)/2;disc=a*a-4*b;assert 0<=b and disc>=0
    if p==3:assert det(E)==0 and det(M)==0
    # Sylvester positivity: A0>0, A1>0, and hence strict Cayley contraction.
    for A in(A0,A1):
        for k in range(1,p+1):z=det([r[:k] for r in A[:k]]);assert z.i==0 and z.r>0
    assert 1-a+b>0 and a<2
    return dict(trace=a,product=b,discriminant=disc,center_det=det(B),base_det=det(N))

def upper_at_node(p,t,terms=12,D=10**14):
    z=envelope_data(p,t);sl,su=sqrt_interval(z['discriminant'],D)
    # Upper eigenvalues: lambda_plus uses upper sqrt, lambda_minus lower sqrt.
    lam=[(z['trace']+su)/2,(z['trace']-sl)/2];assert all(0<=x<1 for x in lam)
    upper=F()
    for x in lam:
        _,r=sqrt_interval(x,D);s,_=sqrt_interval(1-x,D);assert s>0
        upper+=atan_interval(r/s,terms)[1]
    upper+=argument(z['center_det'],terms)[1]+argument(z['base_det'],terms)[1]
    return F(-((-upper.numerator*10**9)//upper.denominator),10**9),z

def midpoint_upper(p,N=128):
    h=F(99,10*N);v=F();nodes=[]
    for j in range(N):
        t=F(1,10)+(j+F(1,2))*h;u,z=upper_at_node(p,t);v+=h*t*u
        nodes.append(dict(t=str(t),upper=str(u),trace=str(z['trace']),product=str(z['product'])))
    return dict(p=p,N=N,midpoint_upper=str(v),quadrature_error=str(error_bound(N)),integral_upper=str(v+error_bound(N)),nodes=nodes)
