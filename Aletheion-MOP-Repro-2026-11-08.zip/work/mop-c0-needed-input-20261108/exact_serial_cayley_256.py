"""Intrinsic rank-two Q(i) envelope for the ASYMMETRIC serialP2 graft."""
from fractions import Fraction as F
from exact_gram_cayley_253 import inverse,gram,metric_adjoint
from exact_cayley_envelope_249 import QI,eye,add,sub,scale,mul,adj,trace,det,sqrt_interval
from exact_phase_quadrature_248 import atan_interval,argument

def data(r,p,t,wrong_metric=False):
    assert isinstance(r,int) and isinstance(p,int) and r>=1 and p>=1 and r*p>1 and t>0
    t=F(t);G=gram(r,p);I=eye(2)
    S0=[[QI(t),QI(0,1)],[QI(0,1),QI(t)]]
    K=scale([[QI(2*t,-2),QI(t,-1)],[QI(t,-1),QI(t)]],1/(t*t+1))
    S1=add(S0,K);A=[];H=[]
    for S in (S0,S1):
        Q=inverse(S);re=[[QI(x.r) for x in row] for row in Q];im=[[QI(x.i) for x in row] for row in Q]
        A.append(add(scale(I,t),mul(re,G)));H.append(mul(im,G))
    for X in A:
        Z=mul(G,X);assert Z==adj(Z) and Z[0][0].i==0 and Z[0][0].r>0 and det(Z).i==0 and det(Z).r>0
    DH=sub(H[1],H[0]);B=add(add(A[0],A[1]),scale(DH,QI(0,1)));E=add(sub(A[1],A[0]),scale(DH,QI(0,1)))
    V=mul(inverse(B),E);star=adj(V) if wrong_metric else metric_adjoint(V,G)
    M=mul(mul(mul(A[0],V),inverse(A[0])),star);tr=trace(M);tr2=trace(mul(M,M))
    if wrong_metric:return tr,tr2
    assert tr.i==0 and tr2.i==0;a=tr.r;b=(a*a-tr2.r)/2;disc=a*a-4*b
    assert b>=0 and disc>=0 and a<2 and 1-a+b>0
    return dict(trace=a,product=b,discriminant=disc,center_det=det(B),base_det=det(S1))

def node(r,p,t,terms=12,D=10**14):
    z=data(r,p,t);sl,su=sqrt_interval(z['discriminant'],D)
    lambdas=[(z['trace']+su)/2,(z['trace']-sl)/2];assert all(0<=x<1 for x in lambdas)
    hi=F()
    for x in lambdas:
        _,numer=sqrt_interval(x,D);denom,_=sqrt_interval(1-x,D);assert denom>0
        hi+=atan_interval(numer/denom,terms)[1]
    hi+=argument(z['center_det'],terms)[1]+argument(z['base_det'],terms)[1]
    return F(-((-hi.numerator*10**9)//hi.denominator),10**9),z

def error(N=192,T=20):
    assert T==20 and N>0;h=F(199,10*N)
    return F(53,192)*(10*h**3+6*h*h)

def tail(g,T=20):
    assert T>=10 and 0<=g<T*T
    return -F(4,T)+F(3*g,T*T-g)+F(41,3*T**3)

def domain():return [(r,p) for r in range(1,15) for p in range(1,16-r) if r*p>1]
