from pathlib import Path
import json,hashlib,shutil
P=Path(__file__).resolve().parent;R=P.parent.parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    names=['exact_serial_cayley_256.py','exact_gram_cayley_253.py','exact_cayley_envelope_249.py','exact_phase_quadrature_248.py','verify_local_tail_246.py','serial_and_ten_caps_256_proof.txt','cayley_envelope_249_proof.txt','common_source_quadrature_248_proof.txt','gram_cayley_fork_253_proof.txt'];manifest=json.loads((R/'serial-ten-256-manifest.json').read_bytes())['artifact_sha256'];raw=sum((R/n).stat().st_size for n in names);free=shutil.disk_usage(P).free;assert raw<1024**2 and free-4*raw>8*1024**3
    for n in names:
        assert sha(R/n)==manifest[n];dest=P/n
        if dest.exists():assert dest.read_bytes()==(R/n).read_bytes()
        else:shutil.copyfile(R/n,dest)
    out=dict(status='PREPARED_EXPLICIT_NINE_ORIGINAL_C0_SOURCE_MEMBERS',members={n:sha(P/n)for n in names},raw_bytes=raw,free_before=free,scope='Original code/proof bytes preserved; no ZIP copy,old selector adopted or mathematical result produced.')
    (P/'original-source-inputs.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k!='members'}))
if __name__=='__main__':main()
