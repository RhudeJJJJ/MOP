# Fork with a straight fan: private-apex payment, T5 cut, external reduction

6 November 2026. ORIGINAL target: EVERY finite simple UNIT maximal
outerplanar graph G on n>=8 vertices has F(G)=sum(lambda>0)lambda^2>=2n,
equivalently D(G)=splus-sminus>=6. This ORIGINAL remains GLOBAL OPEN;
goal ACTIVE. The all-length private-apex theorem below is a genuine
uniform subfamily result. The external-apex root payment remains OPEN.
No external formal/human audit, literature priority or exhaustive corpus
reading is asserted.

## 1. Literal graph and the unit of this decision

Keep the ordered boundary edge ab of ANY old unit MOP H, h>=3 (auxiliary
K2 also allowed as increment domain). Add parent triangle abc, a balanced
Fork child on ac and a straight fan child on cb of length ell>=1. Label
a=0,b=1,c=2, Fork private x=3,y=4,z=5 and fan vertices6..ell+5. The edges
apart from the fan are
01,02,12,03,04,24,25,34,45. The fan's outer path is c,z1,..,zell,b;
its hub is EITHER b (external) OR c (private). Every private outside
contact is forbidden except the explicitly retained two roots a,b.
The new cap has k=ell+4 private vertices,2k added unit edges. The edge ab
is retained exactly ONCE. Full outer boundary is0,3,4,5,2,z1,..,zell,1.
geometry.py validates ALL unit edges, vertex ownership and noncrossing.

For this decision an occurrence is a closed actual two-root cap, identified
by its ordered boundary arc and every actual edge/contact. At ell1 the
two hub assignments are the SAME literal graph T5; count it once. This
does not identify other hub assignments or erase root roles needed for
increments. T5 has private bull graph (5private edges/contactmass5).
It is not the earlier named F5 with7private edges/contactmass3. A change
in private outside contacts would invalidate the payment. These exact
identities determine which next cap reductions can be used.

Let B be the complete private adjacency, T the two contact rows,
Fc=T(tI+iB)^-1 T^t, K=2I+J, J the retained unit rootedge. The accepted
root201 theorem and sharp net-phase proof give, for the SAME actual old
root throughout the complete graft,

 DeltaF >= F(B)+Tr(TT^t)-(2/pi) integral_0^infinity t b(Fc,t)dt,        (1)
 b=ImTrLog(I+cL)+sum_j asin(sigma_j(rho L(I+cL)^-1)),
 L=K^-1/2 Fc K^-1/2, c=1/t-i/2, rho=sqrt(1/t^2+1/4),
 0<=b<2pi, and t b<=V_old.

The whole lifted phase is used; no reset to a principal argument of a
product. The existing one-sided all-mode filter is an alternative:

 DeltaF>=F(B)+sum_distinct beta>0 max(0,g_beta-c(beta)zeta_beta),        (2)
 c(beta)=(2-beta)^2/[4(sqrt(2beta)+beta)] for beta<2, otherwise0.

All nonpositive modes are installed first. Negative private eigenvalues
are unrestricted below. Complete projectors carry their weights once;
energy alone uses algebraic multiplicity. The source parents are the
native sharp net-phase, root201, and anisotropic filter proofs, not a
numerical survey. Standard-library readers reconstruct every spectrum,
matrix and interval from the actual graph. Shared exact arithmetic
helpers and their scope are explicit.

## 2. The smallest cap T5 and its original-counter boundary

THEOREM T. Every such old H gains DeltaF>101/10 for T5 (k5), with no old
degree/order/norm bound. All5private roots including the exact zero are
isolated by rational Sturm checks. Both complete contact-resolvent
polynomial constructions agree. The192bit directed certificate covers
ALL21170 leaves, compact[1/8,4] and the complete old normalized tail
z=1/t in[0,1/4]. The private norm is<4 by the full Sturm intervals.
The omitted low interval is explicitly CHARGED2(1/8)^2=1/32 using b<2pi.
Gain lower:
64146156383950888693675084728923394621381653241456485288605 /
6277101735386680763835789423207666416102355444464034512896 >101/10.
The older mode-only sufficient bound is insufficient, not a counterexample.

For every old rooted labeled polygon of order h3..7, a FRESH full whole
Gram X=WW^t/16^2 certifies F(G)>=2Tr(AX)-Tr(X^2)>2(h+5). Counts1,2,5,14,42
sum64. Unique root-triangle enumeration proposes them; a separate nonroot
ear-growth enumerator checks EXACT labeled edge-set coverage. All whole
vertices/old edges/full Gram norm are counted. Minimum margin1861/8192.
These are64 T5 grafts of whole orders8..12, not all MOPs at those orders.
OldK2 gives whole7 outside the original range; it is not a paid original base.

COROLLARY. NO minimal ORIGINAL counterexample at ANY original order
contains a closed T5. For n>=13 its deletion leaves h=n-5>=8, paid by
minimality, and Theorem T pays the increment. For n8..12 the fresh64
whole cases pay it directly. Thus this cut has no inherited B71 boundary.
It extends the retained C1/S3-free frontier; it does not prove that every
remaining weak-dual configuration contains a paid motif.

## 3. ALL lengths for the PRIVATE apex c

THEOREM P. For EVERY integer ell>=1 and EVERY old H as in section1,
the private-apex Fork-fan cap satisfies DeltaF>2(ell+4)+1/10.

Proof. ell1 is T. For ell2,3 use the complete net certificate as above,
but compact[1/2,4] and the low charge2(1/2)^2=1/2. The full spectra prove
private norm<4 despite max private degree5 at ell3. The two trees have
24943 leaves total, no truncation of the infinite tail. For ell4..12,
formula(2) with ALL private roots and exact projector weights gives the
claimed gain. Do NOT use the old private-norm4 tail for these cases:
norm actually exceeds4 from ell8 onward; formula(2) needs no such bound.
For ell13..27, full private Grams X=WW^t/64^2 give F(B)>2k+1/10. Their
entire variational costs are recomputed rationally. PSD pinching between
the actual OLD block H and complete private B then gives DeltaF>=F(B),
with no old restrictions. ell12 private-Gram proposal FAILED its sufficient
test and is not used; its all-mode certificate above pays it.

For ALL ell>=28, partition B into the actual induced Fan_(ell+1) on c
plus the ell fan vertices, and actual induced P3 on x,y,z. Since F(P3)=2,
convex spectral pinching and the retained all-r fan inequality give

 F(B)>=F(Fan_(ell+1))+2 >2ell+f(ell)+2,
 f(r)=2sqrt(r)-2/sqrt(r)-4-2/r+1/r^2.

Put s529/100, s^2<28. Function g(s)=2s-2/s-4-2/s^2 is strictly increasing
on s>0 (derivative2+2/s^2+4/s^3). For ell>=28,
f(ell)>g(s)=85777689/13992050>61/10. Thus F(B)>2(ell+4)+1/10, and the SAME
old/private pinching finishes EVERY large length. This is an analytic
uniform proof, not extrapolation from ell<=27. QED.

In a minimal original counter with the deleted parent h>=8, this complete
private-apex family is therefore absent. No all-small-parent theorem for
every private-apex length is asserted here. T5 alone has the fresh
unconditional original-order boundary proved in section2.

## 4. ALL external lengths: a uniform private-energy theorem

For external hub b reorder B as x,y,z,c,z1,..,zell. Then exactly

 B_N=P_N+edge(1,3), N=ell+4,
 Ta=indicator{0,1,3}, Tb=indicator{3,..,N-1}.                         (3)

THEOREM E. For EVERY ell>=1,

 F(B_N)>=N+(sqrt13-sqrt5)/2,                                       (4)

with strict inequality for ell>=2. This theorem concerns private energy,
not the universal root-graft increment.

Proof. Compare with the bipartite path P_N, whose D=0 and edge countN-1.
Let r_ell=e1^t(tI+iP_ell)^-1e1. The positive continued fraction gives
r1=1/t and r_ell=1/(t+r_(ell-1)), so0<r_ell<=1/t, strict ell>=2.
Eliminate vertices0,2 and the ell-path, keeping coordinates1,3. The path's
Schur matrix is real positive definite

 Z=[[t+2/t,1/t],[1/t,t+1/t+r_ell]].

Adding shortcut13 makes it Z+iJ. Exact determinant ratio is
(detZ+1-2i/t)/detZ with positive REAL part. Its continuous phase, anchored
at infinity, is

 delta_ell=-atan[2/(t^3+4t+1/t+(t^2+2)r_ell)].                       (5)

No winding or branch reset is hidden: that ratio stays in the open right
half-plane for all t>0. Since r_ell<=r1, delta_ell<=delta1<0 pointwise,
strict for ell>=2. The equal-trace square-energy phase identity gives
D(B_N)=-(4/pi)integral t delta_ell dt>=D(B5). Both endpoints converge;
at infinity delta=O(t^-3) and near zero its magnitude is bounded bypi/2.
For ell1 the bull characteristic is exactly
lambda(lambda^2+lambda-1)(lambda^2-lambda-3), hence
D(B5)=sqrt13-sqrt5. Since B_N has exactlyN edges and F=N+D/2, this proves
(4), including strictness. QED. This changes the next work: only a bounded
root-phase loss remains to be controlled uniformly in the external length.

## 5. Lossless positive rays for the NET phase bound

At fixed t the algebraic root-ball theorem(1) extends to EVERY complex
matrix F with Wplus(F)=2ReF+tImF>=0, whether or not F is a physical graph
response. This follows from its exact identity
A*A-rho^2 L*L=I+K^-1/2 Wplus(F)K^-1/2/t>=I. It does NOT assign graph energy
to a signed auxiliary F. Define b(F,t) by that same ball maximum and the
lifted phase anchored at F=0.

LEMMA L. For EVERY real v and gamma>=0,

 b(F+gamma vv^t/(t+2i),t)<=b(F,t).                                  (6)

Proof. P=vv^t/(t+2i) has Wplus(P)=0. For every invertible old point H in
the ball, inverse congruence gives2Re(H^-1)+tIm(H^-1)>=tK. Adding F+sP
preserves that inequality. All determinants stay nonzero by the exact
factorization above. Thus H_s=(H^-1+F+sP)^-1 stays in the same ball. For
f=v^t H_s v, the disk's linear support gives2Re f-tIm f>=0. Consequently

 d_s ImLogdet(I+H(F+sP))=Im[f/(t+2i)]
                        =(t Im f-2Re f)/(t^2+4)<=0.

The phase is continuous on the connected convex sector of F and on the
ray, with the origin normalization, so no2pi jump is possible. Taking
the ball maximum proves(6); singular H follow by continuity of the
nonvanishing determinant factorization. General positive real symmetric
rays follow by rank-one decomposition. QED.

This is LOSSLESS-RAY monotonicity for an algebraic PHASE upper bound.
The earlier generic rootboost energy monotonicity is FALSE and remains
false. Lemma L is neither that claim nor an original-graph energy transfer.

## 6. Length normalization and four compact correlated endpoint curves

Use(3), R=T^t, V=(B-2I)R, z=t+2i. Direct local multiplication, valid for
EVERY ell, gives

 Va=-e0+2e2-e3+e4, Vb=e1+e2-e3-e_(N-1),
 T V=-2I,
 V^tV=[[7,2],[2,4]] if ell1, else[[7,3],[3,4]],
 Q=TT^t=[[3,1],[1,ell+1]],
 Fc=Q/z+2iI/z^2-S/z^2, S=V^t(tI+iB)^-1 V.                         (7)

Fix integer L>=1. For all ell>=L subtract the positive lossless bulk
(ell-L)e_b e_b^t/z. The normalized auxiliary response F_L has the SAME
Wplus as Fc, and (6) gives b(Fc,t)<=b(F_L,t). Its leading matrix in(7)
is Q_L=[[3,1],[1,L+1]], INDEPENDENT of ell. No graph energy is assigned to
F_L; it is only a legal upper bound for the same actual graft phase.

There is also an exact head of dimension4 independent of ell. Let C4 be
the induced private head on x,y,z,c, namely path0-1-2-3 plus shortcut13.
Define D0=1,D1=t,Dj=t D_(j-1)+D_(j-2). Tail endpoints are

 r=D_(ell-1)/D_ell, e=(-i)^(ell-1)/D_ell,
 h=(1+i(r+e))/z,
 Zh=tI+iC4+r e3e3^t,
 U=[[1,1,0,1],[0,0,0,1-i h]],
 F_L=(L+2i h)e_b e_b^t/z+U Zh^-1 U^t.                             (8)

The last transpose is NOT an adjoint. Elimination of the actual tail
proves(8): its first-row sum is h, total sum ell/z+2i h/z, and its
coupling to c is i. The continuant determinant identity, proved by the
recurrence with alternating sign, gives EXACT correlation

 e^2=r^2+t r-1.                                                   (9)

Thus for odd ell, e=+/-s real and r=(-t+sqrt(t^2+4+4s^2))/2;
for even ell, e=+/-i s and r=(-t+sqrt(t^2+4-4s^2))/2.
Signs in residues ell=1,2,3,0 mod4 are+s,-i s,-s,+i s. Also
D_(j+2)-D_j=t D_(j+1)>0, so for all ell>=L, each residue's s lies in
[0,1/D_j], where j is the smallest integer>=L in that residue. The limit
s0 includes the infinite-tail endpoint r=(-t+sqrt(t^2+4))/2.

This gives FOUR compact one-parameter curves per t enclosing EVERY actual
length, with the endpoint correlation retained. Interpolated curve points
are NOT automatically physical or sector-valid. A future enlarged bound
must retain Wplus(F_L)>=0 on its domain, prove that constraint, or certify
only its valid subset; do not silently apply(1) to an invalid state.

If an exact uniform phase integral for these states proves
integral t b(F_L,t)dt < pi(sqrt13-sqrt5)/4 (with a margin if desired),
then(1),(4),(6) pay EVERY external-apex length. This remaining inequality
is OPEN. endpoint_scout.py is NUMERICAL DISCOVERY ONLY; its finite samples
and quadrature do not certify the curves, their continuous tails, or the
global graph conjecture. They motivate a bounded interval attack rather
than an unbounded list of cap lengths.

## 7. Verification, source state and remaining original obligation

Separate standard-library readers pass ALL46113 net leaves across T5,
private ell2,3, the9 mode cases ell4..12,15 full private Grams ell13..27,
and all64 small whole T5 grafts. bridge_checks.py checks60 direct exact
full resolvents/determinant ratios and180 fixed-root lossless-ray states,
the endpoint signs/correlation, the exceptional ell1 overlap, actual
private fan/P3 partitions and exact rational constants. These finite
controls test implementation; the ALL-length statements rest on the
written analytic arguments above, not on those60 states.

The first producer observation was lost to output truncation: no shell
terminal metadata was delivered for that original observation. A later
read-only state check found no matching producer process and a partial
artifact; the resumable producer then explicitly completed. That initial
observation gap is not erased. Independent full readers and eventual
native-export replays provide their own complete acceptance evidence.

The original target, all-parent bare Fork6 and global compensation stay
OPEN. New private-apex payment and unconditional T5 exclusion do not
establish the original inequality for C1/S3/T5-free arbitrary MOPs.
No new subagent, background job, timer, foreign message or process control
was used. No LOTSE causal method_effect or session-entry delivery claim
is made. Next justified work is the exact external four-curve phase
bound, with a uniform complete high-frequency tail and explicit sector
restriction, while preserving all original minimal-counter hypotheses.
