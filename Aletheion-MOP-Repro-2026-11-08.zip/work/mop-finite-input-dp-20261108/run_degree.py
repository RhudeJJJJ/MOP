from pathlib import Path
from fractions import Fraction as F
import hashlib,json,sys,time,shutil
import all_mass_dp as dp
P=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def atomic(p,v):
    t=p.with_suffix('.tmp');t.write_text(json.dumps(v,separators=(',',':'))+'\n');t.replace(p)
def main():
    start=time.monotonic();d=int(sys.argv[1]);assert d==40,'initial explicit preflight degree only; broaden only after reviewing its result'
    control=json.loads((P/'small-check.json').read_bytes());assert control['status']=='PASS_ALL_MASS_ALL_GAPS_EXACT_COMPLETE_POLYGON_CONTROLS_n3_TO9'
    source=P.parent/'mop-global-input-audit-20261108/remaining-positive-dp-rows.json';target_bytes=source.read_bytes();target_hash=hashlib.sha256(target_bytes).hexdigest();allrows=json.loads(target_bytes)['rows'];assert len(allrows)==328
    rows=[r for r in allrows if r['d']==d];assert len(rows)==1 and rows[0]['n']==71 and rows[0]['k']==30 and rows[0]['l']==3
    # Verify the extracted target against its actual current original source.
    original_hashes={}
    for r in rows:
        basepath=P.parent.parent/r['source'];basebytes=basepath.read_bytes();original_hashes[r['source']]=hashlib.sha256(basebytes).hexdigest();base=json.loads(basebytes)
        hit=[x for x in base['rows']if x['maximum_degree']==d and x['nonneighbors']==r['k']and x['nonempty_gaps']==r['l']]
        assert len(hit)==1 and hit[0]['M2_R_exact_max']==r['M2_R']and hit[0]['positive_squared_margin']==r['margin']
    K=max(r['k']for r in rows);L=max(r['l']for r in rows)
    names=['all_mass_dp.py','check_small.py','small-check.json','all-mass-proof.md','run_degree.py'];hashes={n:sha(P/n)for n in names}
    frozen=P/'producer-inputs.json'
    if frozen.exists():assert json.loads(frozen.read_bytes())==hashes
    else:atomic(frozen,hashes)
    free=shutil.disk_usage(P).free;assert free-16*1024**2>8*1024**3
    atomic(P/'write-plan.json',dict(explicit_sources=names,target_file=str(source),target_sha256=target_hash,original_source_sha256=original_hashes,d=d,K=K,L=L,maximum_planned_new_raw_bytes=16*1024**2,free_before=free,reserve_bytes=8*1024**3,no_archive_or_backup_database_write=True))
    def progress(stage,index,states):
        if stage=='chain'and index%5 or stage=='polygon'and index%5:return
        print(json.dumps(dict(status='EXACT_ALL_MASS_PROGRESS',d=d,stage=stage,index=index,states=states,seconds=time.monotonic()-start)),flush=True)
    T=dp.polygons(K+2,d,progress);result,layers=dp.chain(d,K,L,T,progress);checked=[]
    for r in rows:
        actual=result[r['k'],r['l']];assert actual==r['M2_R'],(r,actual)
        checked.append(dict(target=r,actual_maximum=actual))
    assert all(sha(P/n)==h for n,h in hashes.items())and sha(source)==target_hash
    assert all(sha(P.parent.parent/n)==h for n,h in original_hashes.items())
    out=dict(status='PASS_FRESH_ALL_MASS_D40_ACTUAL_ORIGINAL_INPUT',d=d,K=K,L=L,checked=checked,all_final_mass_gap_maxima=[dict(k=k,l=l,maximum=v)for(k,l),v in sorted(result.items())],layer_state_counts=layers,polygon_state_counts={str(p):len(t)for p,t in T.items()},source_sha256=hashes,target_list_sha256=target_hash,original_source_sha256=original_hashes,seconds=time.monotonic()-start,remaining_full328_reconstruction='NOT_COMPLETED_BY_THIS_SINGLE_DEGREE',original_global='OPEN')
    atomic(P/'d40-result.json',out);print(json.dumps({k:v for k,v in out.items()if k not in ['source_sha256','all_final_mass_gap_maxima','layer_state_counts','polygon_state_counts']},indent=2))
if __name__=='__main__':main()
