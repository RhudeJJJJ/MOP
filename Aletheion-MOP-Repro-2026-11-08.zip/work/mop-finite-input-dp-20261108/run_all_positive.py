from pathlib import Path
from fractions import Fraction as F
import hashlib,json,time,shutil
import all_mass_dp as dp
P=Path(__file__).resolve().parent;A=P.parent/'mop-global-input-audit-20261108';ROOT=P.parent.parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def atomic(p,v):
    t=p.with_suffix('.tmp');t.write_text(json.dumps(v,separators=(',',':'))+'\n');t.replace(p)
def payment(d,k,l,M,r):
    m=d-1+2*k;mu2=2*m;mu3=6*k;mu4=2*M-2*m+8*(k-l)
    den=mu4+4*r*mu3+6*r*r*mu2+(d+k)*r**4;assert den>0
    q=(mu3+2*r*mu2)**2/den-(d+k-1);h=F(d-1,d)
    required=k+5+F(2*(k+3*l),d)-F(6,d*d)-q
    return F(1)if required<=0 else 4*h*h*(d+h*h)-required**2
def prepare():
    indexbytes=(A/'order50-to71-index.json').read_bytes();index=json.loads(indexbytes)
    envelopebytes=(A/'finite-degree-envelope-check.json').read_bytes();env=json.loads(envelopebytes)
    assert env['status']=='PASS_ALL29_FINITE_DEGREE_ENVELOPES_FULL_HISTOGRAM_AND_KNAPSACK_READER'
    caps={r['n']:r['D']for r in env['rows']};targets=[];blobs={}
    for item in index['orders']:
        n=item['n'];path=ROOT/item['rows'];data=path.read_bytes();assert hashlib.sha256(data).hexdigest()==item['rowfile_sha256'];blobs[item['rows']]=data
        for r in json.loads(data)['rows']:
            if r['rule']!='exact_catalan_degree_dp'or r['maximum_degree']<=caps[n]:continue
            d,k,l=r['maximum_degree'],r['nonneighbors'],r['nonempty_gaps'];assert d+k+1==n
            targets.append(dict(n=n,d=d,k=k,l=l,M2_R=r['M2_R_exact_max'],shift=r['shift'],margin=r['positive_squared_margin'],source=item['rows']))
    assert len(targets)==len({(r['n'],r['d'],r['k'],r['l'])for r in targets})==328
    assert len({(r['d'],r['k'])for r in targets})==90 and len({r['d']for r in targets})==13
    expected=(A/'remaining-positive-dp-rows.json').read_bytes();assert json.loads(expected)['rows']==targets
    blobs['order50-to71-index.json']=indexbytes;blobs['finite-degree-envelope-check.json']=envelopebytes;blobs['remaining-positive-dp-rows.json']=expected
    names=['all_mass_dp.py','check_small.py','small-check.json','all-mass-proof.md','run_degree.py','d40-result.json','producer-inputs.json','full-positive-proof.md','run_all_positive.py']
    raw=sum(len(v)for v in blobs.values())+sum((P/n).stat().st_size for n in names);planned=raw+4*1024**2;free=shutil.disk_usage(P).free;assert planned<64*1024**2 and free-planned>8*1024**3
    atomic(P/'full-write-plan.json',dict(explicit_math_sources=names,explicit_original_inputs=list(blobs),input_raw_bytes=raw,maximum_planned_new_raw_bytes=planned,free_before=free,reserve_bytes=8*1024**3,no_archive_or_database_write=True))
    for name,data in blobs.items():
        dest=P/'inputs'/name;dest.parent.mkdir(exist_ok=True)
        if dest.exists():assert dest.read_bytes()==data
        else:dest.write_bytes(data)
    targetfile=P/'positive-targets.json'
    if targetfile.exists():assert json.loads(targetfile.read_bytes())==targets
    else:atomic(targetfile,targets)
    hashes={n:sha(P/n)for n in names};hashes['positive-targets.json']=sha(targetfile);hashes.update({'inputs/'+n:sha(P/'inputs'/n)for n in blobs})
    frozen=P/'full-producer-inputs.json'
    if frozen.exists():assert json.loads(frozen.read_bytes())==hashes,'full source snapshot changed'
    else:atomic(frozen,hashes)
    return targets,hashes
def main():
    start=time.monotonic();targets,hashes=prepare();assert json.loads((P/'small-check.json').read_bytes())['graphs']==625;degree_results=[]
    for d in sorted({r['d']for r in targets},reverse=True):
        needed=[r for r in targets if r['d']==d];K=max(r['k']for r in needed);L=max(r['l']for r in needed);dest=P/f'full-d{d}.json'
        if dest.exists():
            saved=json.loads(dest.read_bytes());assert saved['source_sha256']==hashes and saved['needed_targets']==needed
        elif d==40:
            pre=json.loads((P/'d40-result.json').read_bytes());assert pre['status']=='PASS_FRESH_ALL_MASS_D40_ACTUAL_ORIGINAL_INPUT'and pre['K']==K and pre['L']==L
            assert [r['target']for r in pre['checked']]==needed and all(sha(P/n)==h for n,h in pre['source_sha256'].items())
            result={(r['k'],r['l']):r['maximum']for r in pre['all_final_mass_gap_maxima']}
            saved=dict(d=d,K=K,L=L,needed_targets=needed,maxima=pre['all_final_mass_gap_maxima'],layer_state_counts=pre['layer_state_counts'],source_sha256=hashes,origin='REUSED_ACTUAL_SOURCE_BOUND_D40_PREFLIGHT_NO_RECOMPUTATION');atomic(dest,saved)
        else:
            t=time.monotonic()
            def progress(stage,index,states):
                if index%5:return
                print(json.dumps(dict(status='EXACT_FULL_POSITIVE_INPUT_PROGRESS',d=d,stage=stage,index=index,states=states,degree_seconds=time.monotonic()-t,total_seconds=time.monotonic()-start)),flush=True)
            print(json.dumps(dict(status='EXACT_FULL_POSITIVE_DEGREE_STARTED',d=d,K=K,L=L,targets=len(needed))),flush=True)
            T=dp.polygons(K+2,d,progress);result,layers=dp.chain(d,K,L,T,progress)
            saved=dict(d=d,K=K,L=L,needed_targets=needed,maxima=[dict(k=k,l=l,maximum=v)for(k,l),v in sorted(result.items())],layer_state_counts=layers,polygon_state_counts={str(p):len(v)for p,v in T.items()},source_sha256=hashes,origin='FRESH_INTEGER_ALL_MASS_ALL_GAP_COMPUTATION',seconds=time.monotonic()-t);atomic(dest,saved)
        result={(r['k'],r['l']):r['maximum']for r in saved['maxima']};checks=[]
        for r in needed:
            M=result[r['k'],r['l']];assert M==r['M2_R'],(r,M)
            gain=payment(d,r['k'],r['l'],M,F(r['shift']));assert gain==F(r['margin'])>0
            checks.append(dict(n=r['n'],d=d,k=r['k'],l=r['l'],M2_R=M,positive_squared_margin=str(gain)))
        assert all(sha(P/n)==h for n,h in hashes.items())
        degree_results.append(dict(d=d,result_file=dest.name,result_sha256=sha(dest),checks=checks,origin=saved['origin']))
        print(json.dumps(dict(status='PASS_EXACT_NEEDED_POSITIVE_DEGREE_INPUTS',d=d,rows=len(checks),total_checked=sum(len(v['checks'])for v in degree_results),seconds=time.monotonic()-start)),flush=True)
    assert len(degree_results)==13 and sum(len(v['checks'])for v in degree_results)==328
    out=dict(status='PASS_FRESH_ALL328_REMAINING_POSITIVE_CATALAN_MAXIMA_AND_ACTUAL_ENERGY_PAYMENTS',target_rows=328,target_degree_mass_pairs=90,degree_groups=13,source_sha256=hashes,results=degree_results,seconds=time.monotonic()-start,scope='Every UNIT graph in these328 actual parameter classes has F>2n by fresh exact degree maxima and actual PSD/hub energy payment. The126 baseline repairs, special restricted cases, other finite stages and unbounded parent obligations remain separate.',original_global='OPEN',native_intake='PENDING')
    atomic(P/'full-positive-result.json',out);print(json.dumps({k:v for k,v in out.items()if k not in ['source_sha256','results']},indent=2))
if __name__=='__main__':main()
