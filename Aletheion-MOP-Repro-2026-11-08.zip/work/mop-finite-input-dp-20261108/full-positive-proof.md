# Fresh reconstruction of every remaining positive Catalan payment input

8 November2026. ORIGINAL ALL UNIT MOP n>=8 GLOBAL OPEN; goal ACTIVE.
Terminal acceptance below is required before claiming the328-case result.

The previous exact d40 preflight passed: for actual n71,d40,k30,l3,
the complete maximum M2(G-v) is1388, agreeing with the original source.
It took13.25 seconds. The all-size Catalan and all-mass hub-chain proof
is all-mass-proof.md. Its independent complete polygon calibration checks
625 graphs and896 maximum-degree-root presentations n3..9. A preflight
does not establish the other degrees.

1. Precise remaining target set and no target substitution.

Read the original COMPLETE parameter rows of each order50..71 at their
recorded current hashes. The new proven finite degree envelope pays the
low-degree subset. Retain exactly those rows with rule
exact_catalan_degree_dp and actual maximum degree STRICTLY greater than
that order's new permitted degree cap. No original negative method-gap
or special restricted-DP case is silently included or excluded as paid.
The resulting set contains328 distinct(n,d,k,l) tuples,90(d,k) pairs,
13 degrees28..40, and n56..71. The relation k=n-d-1 is checked.
The original extracted328 list is separately compared with this fresh
selection, not trusted as a substitute for coverage.

For fixed d choose K=max needed k and L=max needed l. The exact method
computes ALL masses<=K and gap counts<=L simultaneously. State dominance
preserves the correct ordered endpoint information and all cap constraints,
as proved in all-mass-proof.md. Reuse the already completed d40 result
only after every source hash, target and original-source hash matches.
Every other needed degree is freshly computed. Nothing changes the
UNIT original graph or its root contacts merely because a degree tuple
is an adequate interface for this scalar optimization.

2. Exact original energy payment from each reconstructed maximum.

Fix an actual UNIT MOP with maximum-degree hub v, degree d, k=n-d-1
and l nonempty polygon gaps. Write R=G-v, N=d+k. R is the block chain
of the gap MOPs and intervening edges, hence

 m(R)=d-1+2k, triangles(R)=k, quadrilateral cycles(R)=k-l.

Each gap of mass m contributes m triangular faces and m-1 internal
diagonals/quadrilateral cycles. Cycles cannot cross a block cut vertex.
Thus for A_R, mu2=2(d-1+2k), mu3=6k,
mu4=2M2(R)-2(d-1+2k)+8(k-l).

With any retained positive rational shift r, the PSD witness
X=t(A_R+rI)^2 and its optimal t give

 F(R)>=[mu3+2r mu2]^2/
       [mu4_upper+4r mu3+6r^2 mu2+N r^4].

Here mu4_upper uses the NEW exact maximum M>=M2(R). All other quantities
are exact graph identities. The denominator is positive; replacing mu4
by an upper bound can only lower this valid PSD-witness payment. Put
q=that lower bound-(N-1). No connected n-1 theorem is needed for this
individual lower bound; it comes directly from the displayed PSD witness.

Let u=1_N(v)/sqrt(d) in R, h=(d-1)/d. Its neighbor path gives
u^T A_R u=2h and ||A_R u||^2=(4d-6+S)/d. If a nonneighbor w lies
in a gap, its neighbors among N(v) are only the two gap roots. Exactly
one vertex in each nonempty gap sees both roots; the endpoint degrees
in that gap sum to at most m+3. Consequently S=sum c_w^2<=k+3l.

For any symmetric B, compression to u-perp loses at most
2||Bu||^2-(u^TBu)^2 positive square energy. Proof: its negative square
energy cannot increase under orthogonal compression, while its total
square trace drops by exactly that expression. Pinch the whole adjacency
matrix into the span of the hub and u, and its orthogonal complement.
The two-dimensional positive eigenvalue is h+sqrt(d+h^2). Therefore

 F(G)-2n >= q+2h sqrt(d+h^2)-k-5-2S/d+6/d^2.

Set required=k+5+2(k+3l)/d-6/d^2-q. If required<=0 this is strictly
positive. Otherwise the exact positive squared margin

                    4h^2(d+h^2)-required^2>0

proves F(G)>2n. This is the same actual target, not merely an input
moment statement. The driver recomputes this rational margin using the
fresh exact maximum and requires agreement with each stored positive
margin as an additional original-source check.

3. Terminal evidence and scope.

Full acceptance requires all13 degree groups, all328 literal tuples,
all90(d,k) pairs, unchanged complete sources and exact positive margins.
Only then may every UNIT graph in these328 parameter classes be called
paid by this fresh reconstruction. A subset or elapsed time is not that
result. The current original global conjecture remains OPEN throughout.
The126 baseline repairs, remaining special restricted-DP/triangle inputs,
other finite stages and unbounded parent payments are distinct obligations.
This does not establish all of B71 or the global original theorem.

The computation has an explicit finite target and raw-member plan and
runs in the foreground of the active authorized work. It changes no
foreign process, timer, protection rule or older frozen source. Native
storage and portable source-export replay remain separate later steps.
