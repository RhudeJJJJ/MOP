from pathlib import Path
import hashlib,json,sqlite3,shutil,subprocess,sys,time
P=Path(__file__).resolve().parent;DB=Path('C:/Users/jonas/Aletheion/aletheion/aletheion.db');PRE='math:mop:fresh-positive-catalan:'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dig(s):return hashlib.sha256(s.encode()).hexdigest()
def rd(n):return json.loads((P/n).read_bytes())
def save(n,v):(P/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def prepare():
    r=rd('full-positive-result.json');assert r['status']=='PASS_FRESH_ALL328_REMAINING_POSITIVE_CATALAN_MAXIMA_AND_ACTUAL_ENERGY_PAYMENTS'
    assert all(sha(P/n)==h for n,h in r['source_sha256'].items())
    assert all(sha(P/v['result_file'])==v['result_sha256']for v in r['results'])
    parents=['math:mop:finite-degree-envelope:payment:20261108','math:mop:grouped-parent-payments:scope:20261108','legacy:essays:3023:r1:38807ebb1296ae02']
    c=sqlite3.connect('file:'+str(DB)+'?mode=ro',uri=True);c.execute('BEGIN');assert not c.execute('select node_id from weave_nodes where node_id like ?',(PRE+'%',)).fetchall();snap=[]
    for i in parents:
        body=c.execute('select body from weave_nodes where node_id=?',(i,)).fetchone()[0];snap.append(dict(node_id=i,body=body,sha256=dig(body)))
    c.rollback();c.close();save('positive-parent-snapshot.json',snap)
    ids={k:PRE+k+':20261108'for k in ['payment','coverage','scope','proofsource','certificate']};nodes=[];edges=[]
    def node(k,kind,body,status):nodes.append(dict(node_id=ids[k],kind=kind,title='Fresh finite positive Catalan reconstruction: '+k,body=body,epistemic=status,provenance=json.dumps([dict(path=str(P/'full-positive-acceptance.md'),sha256=sha(P/'full-positive-acceptance.md'))])))
    def edge(a,b,rel,why):edges.append(dict(edge_id='edge:'+dig(a+'|'+rel+'|'+b),from_id=a,to_id=b,relation=rel,rationale=why,status='curated'))
    node('payment','claim','For EVERY finite simple UNIT MOP with an ACTUAL maximum-degree hub whose literal(n,d,k,l) tuple occurs in the explicit positive-targets.json set, F=splus>2n. All328 tuples,90(d,k)pairs,13 degrees28..40 and original n56..71 are freshly reconstructed, not inferred from saved status. Exact all-size Catalan degree tables and all-mass/gap interface maxima reproduce EVERY original M2(G-v) maximum, then the actual PSD residual moment plus hub-compression criterion reproduces EVERY strictly positive rational margin. Full terminal original run exit0,523.828seconds. No other finite class or original global conclusion inferred.','PROVEN complete fresh maxima and actual energy for all328 listed classes')
    node('coverage','claim','Targets are reselected from ALL original order50..71 parameter rows at their complete recorded byte snapshots, retaining only exact_catalan_degree_dp rows above the newly PROVEN degree cap of that order. This yields328 DISTINCT(n,d,k,l),90(d,k)pairs and13d values, all checked. Copied original sources, complete target JSON, every full degree result and exact source manifest are preserved. The d40 preflight is reused only after full source/target checks; all other groups freshly computed. Degree-state merging is justified by identical future interface effects for this moment optimization, NOT equality of graphs. Complete small calibration625graphs/896max-root presentations supports, but does not replace, the written all-size proof.','PROVEN full target coverage relative to exact actual remaining positive input clauses')
    node('scope','claim','ORIGINAL EVERY finite simple UNIT MOP n>=8 F=splus>=2n remains GLOBAL OPEN; goal ACTIVE. These328 formerly inherited positive Catalan maxima and their actual energy payments are now freshly discharged. The125 capped profiles and5 restricted mask0 cases have a separate running reconstruction; dominating-triangle and high-second-hub complements, earlier finite stages, gamma4 and the two unbounded parent families retain their actual obligations. Native complete source, fresh export replay, automatic entry delivery and truth remain distinct. No first-priority, independent human/formal certification or causal LOTSE effect asserted.','PROVEN scope; complete original still OPEN')
    for k in ['payment','coverage','scope']:edge(ids[k],ids['proofsource'],'requires','Every exact target, full degree result, actual energy argument and source mandatory.')
    edge(ids['payment'],ids['certificate'],'requires','Complete original terminal all328 result and exact rational payments.')
    edge(ids['coverage'],parents[0],'requires','The proved finite degree envelope licenses only removal of covered low-degree obligations.')
    for i in parents[1:]:edge(ids['scope'],i,'qualifies','These328 positive original input clauses are freshly reconstructed; other original cover and global obligations retained.')
    shutil.copyfile(P.parent/'mop-global-input-audit-20261108/run_guarded_native_low.py',P/'run_guarded_native.py')
    names=list(r['source_sha256'])+[v['result_file']for v in r['results']]+['full-producer-inputs.json','full-positive-result.json','full-positive-acceptance.md','read_positive_native.py','intake_positive.py','run_guarded_native.py','positive-parent-snapshot.json'];files=[P/n for n in dict.fromkeys(names)]
    env=dict(format='full-source-envelope-v2-relative-files',files=[dict(path=str(f),relative=f.relative_to(P).as_posix(),bytes=f.stat().st_size,sha256=sha(f),content=f.read_bytes().decode())for f in files]);payload=json.dumps(env,ensure_ascii=True,separators=(',',':'));parts=[payload[j:j+72000]for j in range(0,len(payload),72000)]
    header=dict(format='complete-source-envelope-chunks-v1',payload_utf8_bytes=len(payload.encode()),payload_sha256=dig(payload),parts=[dict(node_id=PRE+'sourcepart'+str(j)+':20261108',part=j+1,bytes=len(s.encode()),sha256=dig(s))for j,s in enumerate(parts)])
    node('proofsource','source',json.dumps(header,separators=(',',':')),'FULL source header; all numbered raw fragments required')
    for j,(v,s)in enumerate(zip(header['parts'],parts),1):
        nodes.append(dict(node_id=v['node_id'],kind='source',title='Fresh328 complete source '+str(j),body=s,epistemic='FULL raw source fragment; incomplete alone',provenance=json.dumps([dict(payload_sha256=dig(payload),part=j)])));edge(ids['proofsource'],v['node_id'],'requires','Complete raw source fragment obligatory.')
    node('certificate','source',json.dumps(r,separators=(',',':')),'FULL original terminal all328 exact maxima/energy result; complete source envelope required')
    assert max(len(n['body'].encode())for n in nodes)<95000
    save('positive-packet.json',dict(schema_version=1,nodes=nodes,edges=edges));save('positive-source-hashes.json',{str(f):sha(f)for f in files});raw=sum(f.stat().st_size for f in files);backup=DB.stat().st_size+16*1024**2;free=shutil.disk_usage(P).free;assert raw<16*1024**2 and free-backup-3*raw>8*1024**3
    save('positive-write-plan.json',dict(explicit_members=[str(f)for f in files],raw_bytes=raw,backup_count=1,backup_upper_each=backup,free_before=free,no_expected_deduplication=True));print(json.dumps(dict(status='PREPARED_COMPLETE_FRESH328_NATIVE_INTAKE',nodes=len(nodes),edges=len(edges),parts=len(parts),files=len(files),raw_bytes=raw,backup_upper_each=backup,free_before=free)))
def audit():
    assert all(sha(Path(f))==h for f,h in rd('positive-source-hashes.json').items());packet=rd('positive-packet.json');c=sqlite3.connect('file:'+str(DB)+'?mode=ro',uri=True);c.row_factory=sqlite3.Row;c.execute('BEGIN');actual=[];nodes={}
    for table,key,item in [('weave_nodes','node_id',n)for n in packet['nodes']]+[('weave_edges','edge_id',n)for n in packet['edges']]:
        row=dict(c.execute('select * from '+table+' where '+key+'=?',(item[key],)).fetchone());assert all(row[k]==v for k,v in item.items());actual.append(dict(table=table,row=row))
        if table=='weave_nodes':nodes[row['node_id']]=row
    for s in rd('positive-parent-snapshot.json'):assert dig(c.execute('select body from weave_nodes where node_id=?',(s['node_id'],)).fetchone()[0])==s['sha256']
    c.rollback();c.close();save('positive-actual-readback.json',actual);header=json.loads(nodes[PRE+'proofsource:20261108']['body']);parts=[]
    for j,v in enumerate(header['parts'],1):
        body=nodes[v['node_id']]['body'];assert j==v['part']and len(body.encode())==v['bytes']and dig(body)==v['sha256'];parts.append(body)
    payload=''.join(parts);assert len(payload.encode())==header['payload_utf8_bytes']and dig(payload)==header['payload_sha256'];env=json.loads(payload)
    for f in env['files']:
        data=f['content'].encode();rel=Path(f['relative']);assert not rel.is_absolute()and'..'not in rel.parts;assert data==Path(f['path']).read_bytes()and len(data)==f['bytes']and hashlib.sha256(data).hexdigest()==f['sha256']
        for root in [P/'native-export',P/'native-replay']:
            dest=root/rel;dest.parent.mkdir(parents=True,exist_ok=True)
            if dest.exists():assert dest.read_bytes()==data
            else:dest.write_bytes(data)
    for label in ['positive-dryrun','positive-import']:assert rd(label+'.process.json')['exit_code']==0
    receipt=rd('positive-import.stdout.json');assert receipt['inserted']==dict(nodes=len(packet['nodes']),edges=len(packet['edges']),reviews=0);backup=Path(receipt['backup']);assert backup.is_file()and backup.stat().st_size<=rd('positive-write-plan.json')['backup_upper_each']
    summary=dict(status='PASS_NATIVE_FRESH328_COMPLETE_SOURCE_BYTE_IDENTITY',native_run_id=receipt['run_id'],nodes=len(packet['nodes']),edges=len(packet['edges']),files=len(env['files']),parts=len(parts),all_sources_byte_identical=True,parents_unchanged=True,backup=str(backup),original_full_computation='PASS all328 maxima and energy payments',fresh_native_math_replay='RUNNING separately from original acceptance',free_after=shutil.disk_usage(P).free,original_global='OPEN');save('positive-native-source-audit.json',summary);print(json.dumps(summary),flush=True)
    argv=[sys.executable,'-B','-X','utf8',str(P/'native-replay/read_positive_native.py')];start=time.monotonic()
    with(P/'native-positive-replay.stdout.txt').open('w')as out,(P/'native-positive-replay.stderr.txt').open('w')as err:
        proc=subprocess.Popen(argv,cwd=P/'native-replay',stdout=out,stderr=err);save('native-positive-replay-running.json',dict(pid=proc.pid,argv=argv,status='RUNNING'));code=proc.wait()
    save('native-positive-replay-process.json',dict(argv=argv,exit_code=code,wall_time_seconds=time.monotonic()-start,stdout_bytes=(P/'native-positive-replay.stdout.txt').stat().st_size,stderr_bytes=(P/'native-positive-replay.stderr.txt').stat().st_size));assert code==0,(P/'native-positive-replay.stderr.txt').read_text()
    result=json.loads((P/'native-replay/native-positive-replay-result.json').read_bytes());assert result['status']=='PASS_NATIVE_SOURCE_FRESH_ALL328_POSITIVE_MAXIMA_AND_ALL_EXACT_PAYMENTS'
    summary.update(status='PASS_NATIVE_FRESH328_COMPLETE_SOURCES_AND_FULL_EXACT_PORTABLE_REPLAY',fresh_native_math_replay=result,free_after=shutil.disk_usage(P).free);save('positive-native-audit.json',summary);print(json.dumps(summary))
if __name__=='__main__':prepare()if len(sys.argv)==1 or sys.argv[1]=='prepare'else audit()
