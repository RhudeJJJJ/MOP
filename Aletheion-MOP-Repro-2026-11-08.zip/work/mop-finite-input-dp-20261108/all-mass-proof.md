# Exact all-mass degree-state reconstruction for the remaining finite inputs

8 November 2026. ORIGINAL ALL UNIT MOP n>=8 GLOBAL OPEN; goal ACTIVE.
This is a finite-input computation method, not an original global theorem.

The actual new degree envelope removes old finite-cover obligations only
inside its exact degree/order table. The positive remaining Catalan inputs
are328 literal(n,d,k,l) rows,90(d,k) pairs and13 degrees d28..40. Each
such row asserts an upper maximum for M2(G-v), v an ACTUAL maximum-degree
vertex of degree d in a UNIT MOP. Its scalar payment has been checked
separately. Here the required new evidence is the full maximum computation.

For an interval polygon with p vertices and its ordered boundary edge,
T_p(r,s) is the maximum sum of squared INTERNAL vertex degrees among
triangulations with endpoint degrees r,s and internal degrees<=d.
Base T2(1,1)=0. Every larger triangulation has a unique triangle on the
boundary edge, splitting into polygons of sizes a and p-a+1. If their
endpoint states are(r,u),(w,s), the shared internal vertex has degree
u+w, the outer degrees become(r+1,s+1), and the score is
T_a(r,u)+T_(p-a+1)(w,s)+(u+w)^2. Reject u+w>d. Every child combination
is legal; every triangulation occurs. Taking the maximum is therefore
exact. Translation invariance allows storing only sizes, not all equal
interval-position copies. Endpoint degrees are retained jointly.

At a maximum-degree hub v, its d neighbors form an induced path. Each
of its d-1 edges bounds one independent polygon gap of mass m>=0.
Nonzero gap m uses a T_(m+2) state(r,s) and adds r-1,s-1 to the two
already present path-endpoint degrees, plus its internal square score.
Zero gap has(r,s,score)=(1,1,0). A neighbor has one further edge to v,
so its final residual degree must be<=d-1. Other gap-interior vertices
already have their full actual degree and are capped by d in T.

After a gap position, retain(used mass,nonempty gaps,pending increment
at the next path vertex) and the largest accumulated square score.
The next path vertex's base degree is1 at the first endpoint,2 in the
interior; the last endpoint has base1 and is scored only at the end.
All future choices and scores depend only on the retained state and
the current position. Smaller accumulated scores can safely be discarded.
This is an exact future-interface equivalence for this optimization;
it is not identification of different actual graphs or root contacts.

The older single-mass recurrence prescribes final mass k. Keeping all
used masses<=K and final gap counts<=L computes all(k,l) with k<=K,
l<=L at once. Mass and gap counts never decrease, so these caps cannot
remove a path to any retained final pair. No pruning to an assumed
terminal target or graph order is needed. End by adding the final
path endpoint square and taking the maximum over pending increments.
Every neighbor and every interior vertex is counted once. The zero-mass
case is the induced path on d neighbors, with square sum4d-6.

The small calibration independently enumerates ALL625 polygon
triangulations n3..9 and ALL maximum-degree root choices, computes
actual residual degrees, and compares every complete parameter maximum.
It calibrates this written all-size proof; it is not finite extrapolation.

The initial requested computation is d40,K30,L3, which includes the
remaining original row n71,d40,k30,l3 with stored maximum1388.
No full328-row claim follows from a pass on this one degree. A mismatch
would be an input/certificate discrepancy requiring source review, not
an original energy counterexample. Every next larger workload must keep
the exact target list, complete source versions and resource limits.
