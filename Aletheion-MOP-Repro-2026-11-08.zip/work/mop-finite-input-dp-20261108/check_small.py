from pathlib import Path
from functools import lru_cache
from math import comb
import json
import all_mass_dp as dp
P=Path(__file__).resolve().parent
@lru_cache(None)
def triangulations(a,b):
    if b==a+1:return(frozenset([(a,b)]),)
    return tuple(x|y|{(a,b)}for c in range(a+1,b)for x in triangulations(a,c)for y in triangulations(c,b))
def main():
    observed={};graphs=roots=0
    for n in range(3,10):
        family=triangulations(0,n-1);assert len(family)==len(set(family))==comb(2*(n-2),n-2)//(n-1)
        for edges in family:
            assert len(edges)==2*n-3
            N=[set()for _ in range(n)]
            for x,y in edges:N[x].add(y);N[y].add(x)
            maximum=max(map(len,N));graphs+=1
            for v in range(n):
                if len(N[v])!=maximum:continue
                d=maximum;k=n-d-1;neighbors=sorted(N[v],key=lambda x:(x-v)%n)
                masses=[(y-x)%n-1 for x,y in zip(neighbors,neighbors[1:])];assert sum(masses)==k
                l=sum(x>0 for x in masses);moment=sum((len(N[x])-int(x in N[v]))**2 for x in range(n)if x!=v)
                key=d,k,l;observed[key]=max(observed.get(key,-1),moment);roots+=1
    tested=0
    for d in range(2,9):
        K=8-d;T=dp.polygons(K+2,d)
        if K>=1:assert T[3]=={(2,2):4}
        result,layers=dp.chain(d,K,d-1,T)
        expected={(k,l):value for(dd,k,l),value in observed.items()if dd==d}
        assert result==expected,(d,result,expected);tested+=len(result)
    assert graphs==625
    out=dict(status='PASS_ALL_MASS_ALL_GAPS_EXACT_COMPLETE_POLYGON_CONTROLS_n3_TO9',graphs=graphs,maximum_degree_root_presentations=roots,distinct_parameter_maxima=tested,scope='Independent complete family calibration; all-order coverage follows the written Catalan/interface proof, not extrapolation',original_global='OPEN')
    (P/'small-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
