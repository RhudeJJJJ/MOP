"""Integer Catalan degree maxima, all masses and gap counts at one hub degree."""
def polygons(max_size,cap,progress=None):
    T={2:{(1,1):0}}
    for size in range(3,max_size+1):
        row={}
        for left in range(2,size):
            right=size-left+1
            for(a,b),x in T[left].items():
                for(c,d),y in T[right].items():
                    degree=b+c
                    if degree>cap:continue
                    key=(a+1,d+1);value=x+y+degree*degree
                    if value>row.get(key,-1):row[key]=value
        T[size]=row
        if progress:progress('polygon',size,len(row))
    return T
def chain(d,K,L,T,progress=None):
    """Maximize EVERY final(used,gaps), not only one prescribed K or L."""
    states={(0,0,0):0};choices={0:[(1,1,0)]}
    for m in range(1,K+1):choices[m]=[(r,s,x)for(r,s),x in T[m+2].items()]
    layers=[]
    for position in range(1,d):
        base=1 if position==1 else 2;out={}
        for(used,gaps,pending),score in states.items():
            for m in range(K-used+1):
                g=gaps+int(m>0)
                if g>L:continue
                for r,s,inside in choices[m]:
                    degree=base+pending+(r-1 if m else 0)
                    if degree>d-1:continue
                    key=(used+m,g,s-1 if m else 0);value=score+degree*degree+inside
                    if value>out.get(key,-1):out[key]=value
        states=out;layers.append(len(states))
        if progress:progress('chain',position,len(states))
    result={}
    for(used,gaps,pending),score in states.items():
        degree=1+pending
        if degree>d-1:continue
        key=(used,gaps);value=score+degree*degree
        if value>result.get(key,-1):result[key]=value
    assert result[0,0]==4*d-6
    return result,layers
