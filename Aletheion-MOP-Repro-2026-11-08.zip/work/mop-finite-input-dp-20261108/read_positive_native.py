from pathlib import Path
from fractions import Fraction as F
import hashlib,json,time
import all_mass_dp as dp
from run_all_positive import payment
P=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    start=time.monotonic();expected=json.loads((P/'full-positive-result.json').read_bytes());assert expected['status']=='PASS_FRESH_ALL328_REMAINING_POSITIVE_CATALAN_MAXIMA_AND_ACTUAL_ENERGY_PAYMENTS'
    assert all(sha(P/n)==h for n,h in expected['source_sha256'].items())
    index=json.loads((P/'inputs/order50-to71-index.json').read_bytes());caps={r['n']:r['D']for r in json.loads((P/'inputs/finite-degree-envelope-check.json').read_bytes())['rows']};targets=[]
    for item in index['orders']:
        path=P/'inputs'/item['rows'];assert sha(path)==item['rowfile_sha256']
        for r in json.loads(path.read_bytes())['rows']:
            if r['rule']=='exact_catalan_degree_dp'and r['maximum_degree']>caps[item['n']]:targets.append(dict(n=item['n'],d=r['maximum_degree'],k=r['nonneighbors'],l=r['nonempty_gaps'],M2_R=r['M2_R_exact_max'],shift=r['shift'],margin=r['positive_squared_margin'],source=item['rows']))
    assert targets==json.loads((P/'positive-targets.json').read_bytes())and len(targets)==328
    assert len({(r['d'],r['k'])for r in targets})==90
    checks=[]
    for d in sorted({r['d']for r in targets},reverse=True):
        selected=[r for r in targets if r['d']==d];K=max(r['k']for r in selected);L=max(r['l']for r in selected)
        T=dp.polygons(K+2,d);result,layers=dp.chain(d,K,L,T)
        saved=next(r for r in expected['results']if r['d']==d);original=json.loads((P/saved['result_file']).read_bytes());assert sha(P/saved['result_file'])==saved['result_sha256']
        actual=[dict(k=k,l=l,maximum=v)for(k,l),v in sorted(result.items())];assert actual==original['maxima']and layers==original['layer_state_counts']
        fresh=[]
        for r in selected:
            M=result[r['k'],r['l']];assert M==r['M2_R'];gain=payment(d,r['k'],r['l'],M,F(r['shift']));assert gain==F(r['margin'])>0
            fresh.append(dict(n=r['n'],d=d,k=r['k'],l=r['l'],M2_R=M,positive_squared_margin=str(gain)))
        assert fresh==saved['checks'];checks.extend(fresh);print(json.dumps(dict(status='NATIVE_POSITIVE_INPUT_REPLAY_PROGRESS',d=d,checked=len(checks),seconds=time.monotonic()-start)),flush=True)
    assert len(checks)==328 and all(sha(P/n)==h for n,h in expected['source_sha256'].items())
    out=dict(status='PASS_NATIVE_SOURCE_FRESH_ALL328_POSITIVE_MAXIMA_AND_ALL_EXACT_PAYMENTS',target_rows=328,groups=13,all_final_mass_gap_maxima_and_layer_counts_identical=True,every_rational_payment_identical=True,source_hashes_unchanged=True,seconds=time.monotonic()-start,original_global='OPEN')
    (P/'native-positive-replay-result.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
