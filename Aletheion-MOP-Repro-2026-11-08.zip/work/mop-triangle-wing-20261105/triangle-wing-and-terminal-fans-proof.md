# A private-triangle wing pays; every terminal unary path is a straight fan

5 November2026. Original EVERYfinite simple UNIT MOPn>=8,F>=2n remains
GLOBALOPEN/goalACTIVE. The inherited original finite cover puts a possible
minimal counter at n>=72; it is not independently replayed here.

The actual wing has external roots0,4, retains04, and outer0,1,2,3,4.
Its remaining edges are01,12,23,34,03,13. Private order is3,1,2, so
B=K3 and T=[[1,1,0],[1,0,0]]. No private outside contacts are allowed.
It adds3private vertices and6unit edges. At EVERYordered boundary of
EVERYold UNIT MOPn>=3, including coherent WHOLEreflection,

                   F(new)-F(old)>607/100=6.07.          (1)

There are no old degree/order/norm/spectrum bounds. The private positive
energy is4 exactly: eigenvalues2,-1,-1, retaining both negative modes.
The contact mass is3. Apply the proved full-cap SAMEparent homotopy and
complex matrix-ball support of full-cap-matrix-disk-proof.md with K=2I+J.
For the actual complete response Fcap, its support E(t)bounds the root
phase uniformly across the homotopy. Exact equal-trace integration gives

       DeltaF>=7-(2/pi)I, I=integral_0^infinity tE(t)dt.

The full rational certificate has2636directed cells and I<29/20. Private
B is invertible, so compact0..4is finite; the entire tail is represented
by z=1/t on0..1/4, with no cutoff omission. The retained exact Machin
bound pi>157/50 proves

       DeltaF>7-145/157=954/157
                         =607/100+101/15700>6.07.

A separate stdlib reader rebuilds actual B,T and the full polynomials
by contact moments, compares the adjugate route, recomputes EVERYcell,
checks complete disjoint domains, full inverse/nuclear invariants and
the actual complex homotopy floor/ball identities. Missing actual contact,
missing interval and corrupted tail data are rejected. Shared arithmetic
and topology helpers are declared; no external formal audit or exhaustive
firstpayment/priority comparison is claimed.

This is DIFFERENT from the unresolved balancedFork6: that has privateP3,
notK3, and4rather than3root contacts. Vertex/edge counts alone do not
identify them. No unrestrictedFork6 conclusion follows from(1).

Now classify ALLrooted triangulations on3,4,5vertices, with fixed outer
cyclic order and its closing rootedge. Roottriangle recursion agrees with
the exhaustive noncrossing diagonal route on1,2,5triangulations. A weak-dual
PATH rooted at anEND has1,2,4possibilities respectively. On3/4vertices
every such case is a fan with an externalapex. On5vertices exactly2of4
endpoint cases are externalapexfans; the other2are precisely the literal
wing above and its WHOLEreflection. The remaining fifth pentagon has an
internal rootface, the balancedfork, and is not ruled out here.

For a minimal original counter n>=72, each closed wing can be removed:
the actual old MOP has n-3>=69>=8 and is paid by minimality;(1)contradicts
the counter. Therefore every closed terminal unarypath of1,2or3faces
is an externalapexfan. The already proved all-length terminal-fan theorem
covers every q>=4. Together this proves the NECESSARYSTRUCTURE:

 EVERYactualCLOSEDterminal weakdualPATH ofANYq>=1faces, rootedatEND,
 in a minimal original counter n>=72 is a straightfan with one of the
 two external roots as apex.

At a deepest branching face in a rooted weak-dual tree, its two child
subtrees have no branches by deepest choice. They are precisely such
closed paths and therefore bothfans. In actual roottrianglea,b,c, the
left child onac has apex aorc; the right child oncb has apex corb.
This yields four POSSIBLEapex assignments to investigate. For a one-face
triangle either root can be an apex, so assignments are NOT disjoint
physical graph classes; no counting identity or unique orientation is
claimed. Distinct private vertices and actual rootroles remain fixed.

The original goal is stillGLOBALOPEN. Fans at branch ends do not themselves
pay all original graphs. In particular the unchanged C0onlywholepaidWfamily
refutes fixed cap-onlyE1and universal C0gain4. The four branch-apex regimes
still require actual joint energy payments or a whole-region argument;
balancedFork6and the globally sufficient extraction remainOPEN. No original
counterexample, allbranch closure or wholegraph coverage is asserted.
