from pathlib import Path
from fractions import Fraction as F
import hashlib,json,sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'mop-negative-modes-20261105'));import homotopy_interval as h
import certify_full_cap_phase as producer
def actual():
    e={(0,4),(0,3),(0,1),(3,4),(1,3),(2,3),(1,2)};h.rat.prior.outer_graph(5,e,list(range(5)))
    B=[[F(int(i!=j)) for j in range(3)] for i in range(3)];T=[[F(1),F(1),F(0)],[F(1),F(0),F(0)]]
    #Private order3,1,2; preserve actual ordered external roots0,4.
    return dict(n=5,roots=[0,4],private=[3,1,2],boundary=list(range(5)),edges=sorted(e)),B,T
def main():
    cap,B,T=actual();data=h.poly_data(B,T,'adjugate');assert data==h.poly_data(B,T,'moments')
    area=producer.integral(data);L,U=h.machin_pi();gain=7-2*F(area['upper'])/L
    assert F(area['upper'])<F(29,20) and gain>F(607,100)
    d=dict(format='triangle-wing-exact-full-integral-v1',cap=cap,polynomials=producer.serialize(data),integral=area,
       pi_lower=str(L),pi_upper=str(U),private_F='4',contact_mass='3',gain_lower=str(h.down(gain)),target='607/100',
       scope='EveryactualoldUNITMOPn>=3/everyorderedboundary: privateK3wing+3private gains>6.07. Sameparent fullcap ball, entire infinite tail, all private positive/negative directions. OriginalGLOBALOPEN.')
    p=HERE/'triangle-wing-certificates.json';p.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(status='PREPARED_EXACT_TRIANGLE_WING_UNIVERSAL_PAYMENT',cells=len(area['leaves']),gain_lower=str(h.down(gain)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())))
if __name__=='__main__':main()
