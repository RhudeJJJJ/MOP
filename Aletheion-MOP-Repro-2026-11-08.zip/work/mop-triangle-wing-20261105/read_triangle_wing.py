from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
import copy,hashlib,json,sys
import certify_triangle_wing as c
import read_full_cap_phase as integral_reader
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'mop-serial-turns-20261105'));import read_serial_turns as controls
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'mop-terminal-fan-20261105'));import read_small_cores_geometry as topology
P=Path(__file__).resolve().parent;h=c.h
def actual(cap):
    edges={(0,1),(1,2),(2,3),(3,4),(0,4),(0,3),(1,3)}
    assert cap==dict(n=5,roots=[0,4],private=[3,1,2],boundary=list(range(5)),edges=[list(e) for e in sorted(edges)])
    A=[[F(int(tuple(sorted((i,j))) in edges)) if i!=j else F(0) for j in range(5)] for i in range(5)]
    B=[[A[i][j] for j in cap['private']] for i in cap['private']];T=[[A[i][j] for j in cap['private']] for i in cap['roots']]
    assert B==[[int(i!=j) for j in range(3)] for i in range(3)] and h.rat.characteristic(B)==h.rat.mul([-2,1],h.rat.mul([1,1],[1,1]))
    return B,T
def main():
    path=P/'triangle-wing-certificates.json';d=json.loads(path.read_text());B,T=actual(d['cap']);data=h.poly_data(B,T,'moments')
    assert data==h.poly_data(B,T,'adjugate')=={r:[[F(v) for v in p] for p in z] for r,z in d['polynomials'].items()}
    lo,hi,n=integral_reader.verify_partition(d,data);L,U=h.machin_pi();assert L==F(d['pi_lower']) and U==F(d['pi_upper'])
    assert n==2636 and hi<F(29,20);gain=7-2*hi/L;assert gain>=F(d['gain_lower'])>F(607,100)
    matrices=controls.matrix_controls(B,T,F(0),data);floors=controls.homotopy_controls(B,T,F(0),F(1))
    bad=copy.deepcopy(d);bad['integral']['leaves'].pop();tail=copy.deepcopy(d);tail['polynomials']['tail'][1][0]=str(F(tail['polynomials']['tail'][1][0])+1)
    contact=copy.deepcopy(d['cap']);contact['edges'].remove([0,3])
    def checkpoly(z):assert z['polynomials']==d['polynomials']
    damages=dict(missing_interval=h.rat.rejection(lambda:integral_reader.verify_partition(bad,data,False)),wrong_tail=h.rat.rejection(lambda:checkpoly(tail)),missing_actual_contact=h.rat.rejection(lambda:actual(contact)))
    assert all(damages.values());classification=[]
    pos={v:i for i,v in enumerate(d['cap']['boundary'])};wing=frozenset(tuple(sorted((pos[a],pos[b]))) for a,b in d['cap']['edges']);reflected=frozenset(tuple(sorted((4-a,4-b))) for a,b in wing)
    for k in (3,4,5):
        recursive=set(topology.c.triangulations(tuple(range(k))));diagonal=topology.allsets(k);assert recursive==diagonal
        endpoints=paid=fans=0
        for edges in recursive:
            faces=[t for t in combinations(range(k),3) if all(tuple(sorted((a,b))) in edges for a,b in combinations(t,2))];root,=[i for i,t in enumerate(faces) if 0 in t and k-1 in t]
            degree=[sum(i!=j and len(set(t)&set(s))==2 for j,s in enumerate(faces)) for i,t in enumerate(faces)]
            if degree[root]>1:continue
            endpoints+=1;external_fan=any(sum(v in e for e in edges)==k-1 for v in (0,k-1))
            covered=k==5 and edges in (wing,reflected)
            assert external_fan or covered;assert not(external_fan and covered)
            fans+=external_fan;paid+=covered
        assert (len(recursive),endpoints,fans,paid)=={3:(1,1,1,0),4:(2,2,2,0),5:(5,4,2,2)}[k]
        classification.append(dict(vertices=k,all_rooted=len(recursive),endpoint_paths=endpoints,external_fans=fans,paid_wings=paid))
    out=dict(status='PASS_EXACT_UNIVERSAL_TRIANGLE_WING607_AND_ALL_SHORT_TERMINAL_PATH_CLASSIFICATION',gain_lower=str(h.down(gain)),gain_display_lower=str(h.rat.lower(gain)),cells=n,damaged_rejected=damages,matrix_checks=matrices,homotopy_checks=floors,classification=classification,
       certificate_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),proof_sha256=hashlib.sha256((P/'triangle-wing-and-terminal-fans-proof.md').read_bytes()).hexdigest(),
       effect='With retained allq>=4terminalfan theorem, ALLactualclosedterminalunarypaths q>=1in minimal original countern>=72are externalapexfans. Deepestbranch children arefans with4possibleapexassignments; assignmentsneednot be disjoint atlength1.',
       scope='OriginalGLOBALOPEN; privateK3wing differs from balancedFork6privateP3. No allbranchpayment or globalextractor; declared shared algebra/topology helpers, no externalformalreview or firstpriorityclaim.')
    (P/'triangle-wing-reader-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:out[k] for k in ('status','gain_display_lower','cells','classification','damaged_rejected','certificate_sha256')}))
if __name__=='__main__':main()
