from pathlib import Path
from fractions import Fraction as F
import copy,hashlib,json,math,sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'mop-h21-integrated-20261105'));import read_h21_filter_certificates as rat
sys.path.insert(0,str(HERE.parent/'mop-joint-switch-20261104'));import read_switch_controls as util
sys.path.insert(0,str(HERE));import read_outer_root_controls as outer
mm=rat.prior.mul;tr=rat.prior.transpose
def sqrt_lower(q):
    assert q>=0;s=10**20;n=math.isqrt(q.numerator*s*s//q.denominator);lo=F(n,s);assert lo*lo<=q<(lo+F(1,s))**2;return lo
def weighted_numerator(B,T,K,p):
    n=len(B);v=[list(map(F,r)) for r in T];mom=[]
    for j in range(n):
        M=mm(T,tr(v));mom.append(sum(K[i][j]*M[j][i] for i in range(2) for j in range(2)))
        v=mm(v,B)
    cc=list(reversed(p));return list(reversed([sum(cc[k]*mom[j-k] for k in range(j+1)) for j in range(n)]))
def actual(c):
    m=c['m'];assert c['label']=='C'+str(m) and 0<=m<=3;b=2*m+3;assert c['roots']==[0,b] and c['private']==list(range(1,b)) and c['n']==b+1
    es={(0,b),(0,1),(1,2),(2*m+2,b)};vv=[2*i+2 for i in range(m+1)];es|={(0,v) for v in vv}
    for i in range(m):
        x,y,z=vv[i],vv[i+1],2*i+3;es|={(x,y),(x,z),(z,y)}
    es={tuple(sorted(e)) for e in es};assert es=={tuple(e) for e in c['edges']};rat.prior.outer_graph(c['n'],es,c['boundary'])
    A=[[F(int(tuple(sorted((i,j))) in es)) if i!=j else F(0) for j in range(c['n'])] for i in range(c['n'])]
    B=[[A[i][j] for j in c['private']] for i in c['private']];T=[[A[i][j] for j in c['private']] for i in c['roots']]
    return A,B,T
def check(c):
    A,B,T=actual(c);n=len(B);p=rat.characteristic(B);assert p==list(reversed([F(x) for x in c['characteristic']]))
    der=rat.derivative(p);assert rat.gcd(p,der)==[1]
    roots=[];seq=rat.sturm(p)
    for z in c['intervals']:
        a,b=F(z['a']),F(z['b']);assert a<=b and z['multiplicity']==1
        if a==b:assert rat.ev(p,a)==0 and rat.ev(der,a)!=0
        else:assert rat.ev(p,a)!=0 and rat.ev(p,b)!=0 and rat.variations(seq,a)-rat.variations(seq,b)==1
        roots.append((a,b))
    roots.sort();assert len(roots)==n and all(roots[i][1]<roots[i+1][0] for i in range(n-1))
    metric=[[F(2,3),-F(1,3)],[-F(1,3),F(2,3)]];assert mm([[2,1],[1,2]],metric)==util.eye(2)
    gn=weighted_numerator(B,T,util.eye(2),p);qn=weighted_numerator(B,T,metric,p)
    assert weighted_numerator(B,list(reversed(T)),metric,p)==qn and weighted_numerator(B,list(reversed(T)),util.eye(2),p)==gn
    energy=reward=F(0);details=[];glo_sum=ghi_sum=qlo_sum=qhi_sum=F(0)
    for a,b in roots:
        gl,gu=rat.idiv(rat.iev(gn,(a,b)),rat.iev(der,(a,b)));ql,qu=rat.idiv(rat.iev(qn,(a,b)),rat.iev(der,(a,b)))
        assert gu>=0 and qu>=0;gl=max(F(0),gl);ql=max(F(0),ql)
        glo_sum+=gl;ghi_sum+=gu;qlo_sum+=ql;qhi_sum+=qu
        r=F(0);pen=F(0)
        if b<=0:pass
        elif a>=2:energy+=a*a;r=gl
        else:
            assert a>0 and b<2;energy+=a*a
            den=4*(sqrt_lower(2*a)+a);assert den>0
            pen=qu*(2-a)**2/den;r=max(F(0),gl-pen)
        reward+=r;details.append(dict(a=str(a),b=str(b),g_lower=str(gl),g_upper=str(gu),q_lower=str(ql),q_upper=str(qu),reward_lower=str(r),penalty_upper=str(pen)))
    gtotal=sum(x*x for row in T for x in row);qtotal=sum(metric[i][j]*mm(T,tr(T))[j][i] for i in range(2) for j in range(2))
    assert glo_sum<=gtotal<=ghi_sum and qlo_sum<=qtotal<=qhi_sum
    lo=rat.lower(energy+reward);return dict(label=c['label'],private=n,score_lower=str(lo),score_lower_fraction=lo,target_2k=2*n,
       pays_2k=lo>2*n,private_F_lower=str(rat.lower(energy)),contact_reward_lower=str(rat.lower(reward)),simple_roots=n,
       trace_contact=str(gtotal),trace_metric_contact=str(qtotal),spectral_details=details)
def phase_controls():
    A=[[F(int(i!=j)) for j in range(3)] for i in range(3)];roots=[0,1];controls=[]
    for b,l in [(F(-7),[F(1),F(0)]),(F(0),[F(0),F(1)]),(F(1),[F(1),F(1)]),(F(3,2),[F(1),-F(1)]),(F(4),[F(2),F(1)])]:
        sigma=max(F(2),b);K=[[sigma,F(1)],[F(1),sigma]];Ki=rat.prior.inverse(K);g=sum(x*x for x in l);q=sum(l[i]*Ki[i][j]*l[j] for i in range(2) for j in range(2))
        for t in (F(1,5),F(1),F(3)):
            R,I=outer.resolvent(A,t);r=[[R[x][y] for y in roots] for x in roots];im=[[I[x][y] for y in roots] for x in roots]
            # Preserve the complete anisotropic floor, not just its smallest eigenvalue.
            qr=mm(mm(tr(r),K),r);qi=mm(mm(tr(im),K),im)
            W=util.plus(util.plus(util.scale(r,sigma),util.scale(im,t),-1),util.scale(util.plus(qr,qi),t),-1);assert outer.psd(W)
            Wi=util.scale(util.plus(mm(mm(tr(r),K),im),mm(mm(tr(im),K),r),-1),-t)
            full=[W[i]+[-x for x in Wi[i]] for i in range(2)]+[Wi[i]+W[i] for i in range(2)];assert outer.psd(full)
            u=sum(l[i]*r[i][j]*l[j] for i in range(2) for j in range(2));v=sum(l[i]*im[i][j]*l[j] for i in range(2) for j in range(2))
            assert sigma*u-t*v>=t*(u*u+v*v)/q
            if b>0:
                P=t*v-b*u;Q=t*t+b*b+t*u+b*v
                if P>0:
                    assert b<sigma and Q>0;a=sigma-b
                    M=q*a*a*t/(4*(t*t+sigma*b)*(t*t+b*b));assert P/Q<=M
            controls.append(dict(old_order=len(A),private_mode=str(b),sigma=str(sigma),t=str(t),anisotropic_floor=True))
        n=len(A);C=[[F(0)]*(n+1) for _ in range(n+1)]
        for i in range(n):C[i][:n]=A[i]
        C[n][n]=b
        for i,v in enumerate(roots):C[v][n]=C[n][v]=l[i]
        A=C
    return controls
def main():
    p=HERE/'anisotropic-cap-certificates.json';d=json.loads(p.read_text());out=[check(c) for c in d['cases']]
    assert out[0]['score_lower_fraction']>F(3) and out[3]['score_lower_fraction']>F(d['C3_target'])
    assert [x['pays_2k'] for x in out]==[False,False,False,True]
    controls=phase_controls();bad=copy.deepcopy(d['cases'][3]);bad['edges'].pop();missing=copy.deepcopy(d['cases'][3]);missing['intervals'].pop()
    w=d['whole_triangle_parent'];es={tuple(e) for e in w['edges']};rat.prior.outer_graph(w['n'],es,w['boundary']);assert w['n']==11 and w['old_triangle']==[0,1,2]
    mapping={0:0,9:1,**{i:i+2 for i in range(1,9)}};expected={(0,1),(0,2),(1,2)}|{tuple(sorted((mapping[a],mapping[b]))) for a,b in d['cases'][3]['edges']};assert es==expected
    W=w['factor'];den=w['denominator'];assert len(W)==11 and all(type(v) is int for row in W for v in row)
    Z=mm(W,tr(W));traceA=2*sum(Z[a][b] for a,b in es);norm=sum(x*x for row in mm(tr(W),W) for x in row)
    whole_score=F(2*traceA,den**2)-F(norm,den**4);assert whole_score-4>F(d['C3_target'])
    neg=dict(lost_actual_C3_edge=rat.rejection(lambda:check(bad)),missing_private_eigenvalue=rat.rejection(lambda:check(missing)))
    for x in out:x.pop('score_lower_fraction')
    report=dict(status='PASS_EXACT_ANISOTROPIC_ONE_SIDED_FILTER_UNIVERSAL_C3_GAIN1607_OVER100',fixture_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),
       cap_scores=out,mode_controls=controls,damaged_rejected=neg,whole_triangle_parent=dict(n=11,whole_Gram_lower=str(whole_score),gain_from_exact_triangle_lower=str(whole_score-4),
          scope='ONEfull actual unitgraft direct integerPSD, all private vertices and entire squared norm retained; no finite all-parent enumeration or new whole-class payment credit'),
       universal_C3='EVERY old finite simple UNIT MOPn>=3,EVERY ordered actual boundaryedge, literal C3with8privatevertices gains>1607/100>16; no degree/order/norm/spectrum bound.',
       one_sided='Only upper-vrootsector used. ALLnegative private eigenmodes preserve the anisotropic floor; no lower bound on private lambda_min is needed.',
       global_effect='No actual closed C3can occur in a minimal original counter n>=72. Fixed cap-only E4/E3selectors remain REFUTED by earlier C0-only family; practical residual after all whole-paid exclusions remains OPEN.',
       original_status='GLOBAL_OPEN',original_counterexample=False,external_formal_audit=False)
    (HERE/'anisotropic-cap-reader-check.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(status=report['status'],scores=[dict(label=x['label'],lower=x['score_lower'],pays=x['pays_2k']) for x in out],
       mode_controls=len(controls),damaged=neg,fixture_sha256=report['fixture_sha256'],original_status='GLOBAL_OPEN')))
if __name__=='__main__':main()
