from pathlib import Path
from fractions import Fraction as F
import copy,hashlib,json,sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'mop-h21-integrated-20261105'));import read_h21_filter_certificates as rat
sys.path.insert(0,str(HERE.parent/'mop-joint-switch-20261104'));import read_switch_controls as util
mm=rat.prior.mul;tr=rat.prior.transpose;plus=util.plus;scale=util.scale
def psd(A):
    A=[list(map(F,r)) for r in A];assert A==tr(A)
    while A:
        a=A[0][0]
        if a<0:return False
        if not a:
            if any(A[0][1:]):return False
            A=[r[1:] for r in A[1:]];continue
        A=[[A[i][j]-A[i][0]*A[0][j]/a for j in range(1,len(A))] for i in range(1,len(A))]
    return True
def resolvent(A,t):
    n=len(A);B=mm(A,A);W=rat.prior.inverse([[B[i][j]+(t*t if i==j else 0) for j in range(n)] for i in range(n)])
    return scale(W,t),scale(mm(A,W),-1)
def paths(A,colors):
    n=len(A);adj=[{j for j in range(n) if A[i][j] and colors[i]==colors[j]} for i in range(n)];seen=set();sizes=[]
    assert all(len(a)<=2 for a in adj)
    for v in range(n):
        if v in seen:continue
        comp={v};todo=[v]
        while todo:
            x=todo.pop()
            for y in adj[x]-comp:comp.add(y);todo.append(y)
        assert sum(len(adj[x]) for x in comp)==2*(len(comp)-1);seen|=comp;sizes.append(len(comp))
    return sizes
def sector_kernel(A,D):
    B=[[A[i][j]*(1-D[i]-D[j]) for j in range(len(A))] for i in range(len(A))]
    return [plus(scale(util.eye(len(A)),2),scale(B,s)) for s in (-1,1)]
def check_congruence(A,D,E,R,I,t):
    n=len(A);q=len(E[0]);XR=mm(R,E);XI=mm(I,E);re=mm(mm(tr(E),R),E);im=mm(mm(tr(E),I),E)
    assert all(not D[i] or not any(E[i]) for i in range(n))
    for s,C in zip((-1,1),sector_kernel(A,D)):
        real=plus(mm(mm(tr(XR),C),XR),mm(mm(tr(XI),C),XI))
        imag=plus(mm(mm(tr(XR),C),XI),mm(mm(tr(XI),C),XR),-1)
        W=plus(scale(re,2),scale(im,-s*t))
        assert imag==util.zero(q) and scale(real,t)==W and psd(W)
    return re,im
def small(case):
    g=case['completion'];n=g['n'];es={tuple(e) for e in g['edges']};rat.prior.outer_graph(n,es,g['boundary'])
    A=util.zero(n);seen=set()
    for a,b,w in case['weighted_edges']:
        w=F(w);assert a<b and (a,b) in es and (a,b) not in seen and 0<abs(w)<=1;seen.add((a,b));A[a][b]=A[b][a]=w
    roots=case['roots'];col=case['colors'];assert len(set(roots))==len(roots) and len(roots) in (1,2) and len(col)==n
    assert set(col)<={0,1} and all(col[v]==0 for v in roots)
    if len(roots)==2:assert A[roots[0]][roots[1]]
    assert all(col[j]==1 for i in roots for j in range(n) if j not in roots and A[i][j])
    sizes=paths(A,col);floor=F(4,(max(sizes)+1)**2)
    for C in sector_kernel(A,col):assert psd(plus(C,scale(util.eye(n),floor),-1))
    E=[[F(int(i==v)) for v in roots] for i in range(n)];private=[i for i in range(n) if i not in roots]
    B=[[A[i][j] for j in private] for i in private];T=[[A[u][j] for j in private] for u in roots]
    DD=[1-col[i] for i in private];private_sizes=paths(B,DD);private_floor=F(4,(max(private_sizes)+1)**2)
    for C in sector_kernel(B,DD):assert psd(plus(C,scale(util.eye(len(B)),private_floor),-1))
    checks=[]
    for t in (F(1,3),F(1),F(3)):
        R,I=resolvent(A,t);hR,hI=check_congruence(A,col,E,R,I,t)
        bR,bI=resolvent(B,t);fR,fI=check_congruence(B,DD,tr(T),bR,bI,t)
        q=len(roots);zr=plus(scale(util.eye(q),t),fR);zi=plus([[A[x][y] for y in roots] for x in roots],fI)
        full=[zr[i]+[-x for x in zi[i]] for i in range(q)]+[zi[i]+zr[i] for i in range(q)];inv=rat.prior.inverse(full)
        assert [[inv[i][j] for j in range(q)] for i in range(q)]==hR and [[inv[i+q][j] for j in range(q)] for i in range(q)]==hI
        checks.append(dict(t=str(t),both_root_resolvent_sectors=True,both_private_response_sectors=True,
          full_anticommutator_identity=True,root_Schur_equals_full_inverse=True))
    return dict(label=case['label'],n=n,roots=roots,monochromatic_path_sizes=sizes,kernel_floor=str(floor),checks=checks)
def fan_column(d):
    DD=[1,1]
    for k in range(2,d+1):DD.append(DD[-1]+DD[-2])
    powers=[(1,0),(0,-1),(-1,0),(0,1)]
    x=[]
    for j in range(1,d+1):
        a,b=powers[(j-1)%4],powers[(d-j)%4]
        p=a[0]*DD[d-j]+b[0]*DD[j-1];q=a[1]*DD[d-j]+b[1]*DD[j-1]
        x.append((F(1,5)+F(2*p-q,5*DD[d]),-F(2,5)+F(p+2*q,5*DD[d])))
    return x
def fan_rows(g,x):
    d=g['n']-1;assert len(x)==d
    es={tuple(e) for e in g['edges']};rat.prior.outer_graph(g['n'],es,g['boundary'])
    assert es=={(0,v) for v in range(1,d+1)}|{(v,v+1) for v in range(1,d)}
    adj=[set() for _ in range(d)]
    for a,b in es:
        if a and b:adj[a-1].add(b-1);adj[b-1].add(a-1)
    for j,(r,i) in enumerate(x):assert r-sum(x[k][1] for k in adj[j])==1 and i+sum(x[k][0] for k in adj[j])==0
def sharp(case):
    g=case['graph'];d=g['n']-1;k=F(case['kappa']);assert case['root']==0 and case['frequency']=='1' and 0<=k<2
    x=fan_column(d);fan_rows(g,x);fr=sum(v[0] for v in x);fi=sum(v[1] for v in x)
    assert (fr-F(d,5))**2+(fi+F(2*d,5))**2<=F(16,25)
    upper=((k-2)*d+9*k+4)/5;numerator=k*(1+fr)+fi;assert numerator<=upper<0
    den=(1+fr)**2+fi**2;assert den>0;W=numerator/den
    return dict(n=d+1,private=d,kappa=str(k),t='1',all_actual_rows_verified=d,
       response_real=str(fr),response_imag=str(fi),root_W_kappa_minus=str(W),strict_numerator_upper=str(upper),
       exact_negative=True,two_boundary_root_sectors_also_fail_by_diagonal=True,
       whole_original_energy='PAID by inherited analytic fan theorem n>=21; not original counterexample')
def main():
    p=HERE/'outer-root-controls.json';data=json.loads(p.read_text());ss=[small(c) for c in data['small']];ff=[sharp(c) for c in data['fixed_frequency_sharpness']]
    cycle=data['small'][3];A=util.zero(5)
    for a,b,w in cycle['weighted_edges']:A[a][b]=A[b][a]=F(w)
    assert rat.characteristic(A)==rat.mul([-2,1],rat.mul([-1,1,1],[-1,1,1]))
    damaged=copy.deepcopy(data['small'][0]);damaged['colors']=[0]*damaged['completion']['n']
    overweight=copy.deepcopy(data['small'][-1]);overweight['weighted_edges'][0][2]='3/2'
    bad_column=fan_column(25);bad_column[0]=(bad_column[0][0]+1,bad_column[0][1])
    neg=dict(rooted_monochromatic_branch=rat.rejection(lambda:small(damaged)),weight_above_one=rat.rejection(lambda:small(overweight)),
      corrupted_actual_linear_system=rat.rejection(lambda:fan_rows(data['fixed_frequency_sharpness'][0]['graph'],bad_column)))
    assert all(neg.values())
    report=dict(status='PASS_EXACT_OUTER_ROOT_CARRIERS_AND_FIXED_T1_SHARP_CONSTANT2',fixture_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),
      small=ss,fixed_frequency_sharpness=ff,C5=dict(characteristic='(x-2)(x^2+x-1)^2',F='7-sqrt(5)',D='4-2sqrt(5)<0',
        scope='Actual UNIT outerplanar, nonchordal/non-MOP; sectors do not assert integrated sign'),damaged_rejected=neg,
      universal_claims='Weighted outerplanar support, real symmetric zero diagonal |weights|<=1, any single vertex or actual edge: BOTHroot resolvent and private response sectors at2. Existing220algebra plus explicit rooted completion coloring.',
      sharpness='For EVERY real0<=kappa<2 choose integerd>=20 with d>(9kappa+4)/(2-kappa); SAMEactualfanF_(d+1) at fixedt1 has scalarrootWkappa-minus<0. Hence no universal rootconstant below2, even singlevertex.',
      discovery_limit='Random852600two-root checks found no4/3counter, but explicit all-order fans refute4/3and everyconstantbelow2. Random finite sampling had no coverage authority.',
      original_status='GLOBAL_OPEN',original_counterexample=False,
      global_limit='No paying-core selector, arbitrary block energy balance or new original residual exclusion; scalar-sector sharpening route is closed, keep matrix/frequency/topology debt information.')
    (HERE/'outer-root-reader-check.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(dict(status=report['status'],small_cases=len(ss),root_frequency_checks=sum(len(x['checks']) for x in ss),
      fan_checks=[dict(n=x['n'],kappa=x['kappa'],all_rows=x['all_actual_rows_verified'],numerator_upper=x['strict_numerator_upper']) for x in ff],damaged=neg,
      fixture_sha256=report['fixture_sha256'],original_status='GLOBAL_OPEN')))
if __name__=='__main__':main()
