"""Portable mathematical replay; historical coverage annotations are separate."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json
import check_finite_degree_envelope as r
P=Path(__file__).resolve().parent
def main():
    expected=json.loads((P/'finite-degree-envelope-check.json').read_bytes())
    assert expected['status']=='PASS_ALL29_FINITE_DEGREE_ENVELOPES_FULL_HISTOGRAM_AND_KNAPSACK_READER'
    assert all(hashlib.sha256((P/n).read_bytes()).hexdigest()==h for n,h in expected['source_sha256'].items())
    got=[]
    for n in range(43,72):
        D=r.cap(n);value,count,states=r.literal(n,D);optimized,w=r.scout.bound(n,D);assert value==optimized
        margin=F(1359*n,32)-F(729,2)+F(441,n)-value;assert margin>0
        got.append(dict(n=n,D=D,M2_upper=value,margin=str(margin),direct_admitted_histograms=count,knapsack_high_states=states,relaxed_witness=w))
    assert got==expected['rows']
    out=dict(status='PASS_FRESH_PORTABLE_ALL29_FINITE_DEGREE_MATH_ROWS',rows_identical=True,rows=29,scope='Complete theorem arithmetic replay; original historical coverage annotations not recomputed by this portable core',original_global='OPEN')
    (P/'finite-degree-core-replay.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
