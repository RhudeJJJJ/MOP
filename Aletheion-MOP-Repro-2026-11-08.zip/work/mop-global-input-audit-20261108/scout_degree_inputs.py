"""Exact necessary-histogram discovery across the actual old finite stages.
Not yet a native theorem. Independent low-degree source files stay frozen.
"""
from pathlib import Path
from fractions import Fraction as F
import json,time
import audit_degree27 as a
P=Path(__file__).resolve().parent
def bound(n,D):
    assert 6<=D<=n-2
    cap=D-4;best=-1;witness=None
    for h in range((n-6)//2+1):
        for E in ([0]if h==0 else range(2*h,min(cap*h,n-6)+1)):
            if h==0:S=0
            elif cap==2:S=4*h
            else:
                full,rem=divmod(E-2*h,cap-2);S=4*h+(cap*cap-4)*full+((2+rem)**2-4 if rem else 0)
            lo=max(0,h+E+6-n);hi=min(n//2,(n-h+E+6)//3)
            intervals=[(lo,hi)]if h==0 else [(lo,min(hi,n-3-E))]if h==1 else [(lo,min(hi,n-2*h-1,n-6+2*h-E)),(max(lo,n-2*h),min(hi,(2*n-6-E)//2))]
            for aa,bb in intervals:
                if aa>bb:continue
                ears=bb;q=(n-h-E-6+ears)//2;b=E+q+6-2*ears;c=n-h-q-ears-b;assert min(ears,q,b,c)>=0
                value=16*n-48+S+4*ears+b+q
                if value>best:best=value;witness=dict(h=h,E=E,a=ears,q=q,b=b,c=c)
    return best,witness
def main():
    start=time.monotonic();rows=[]
    for n in range(43,72):
        good=[]
        for D in range(22,35):
            u,w=bound(n,D);margin=a.threshold(n)-u
            if margin>=0:good.append(dict(n=n,D=D,M2_upper=u,margin=str(margin),witness=w))
        rows.append(good[-1]if good else dict(n=n,D=None))
    out=dict(status='EXACT_NECESSARY_HISTOGRAM_SCOUT_NOT_YET_NEW_NATIVE_THEOREM',rows=rows,seconds=time.monotonic()-start,limit='Generalized proof and separate checks required before promoting a new degree/order range; existing direct input sources frozen',original_global='OPEN')
    (P/'degree-input-scout.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
