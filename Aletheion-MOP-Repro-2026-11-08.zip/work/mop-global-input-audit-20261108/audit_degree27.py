"""Independent small necessary-histogram optimizer, not the large historical module.

All inequalities come from degree27_all_orders_proof.txt. Earlier8..59
and the original PSD-moment/Jao-West inputs remain explicitly inherited.
"""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,time
P=Path(__file__).resolve().parent;ROOT=P.parent.parent
def threshold(n):return F(1359*n,32)-F(729,2)+F(441,n)
def highsq(h,E):
    if h==0:assert E==0;return 0
    assert 2*h<=E<=23*h
    full,rem=divmod(E-2*h,21)
    return 4*h+525*full+((2+rem)**2-4 if rem else 0)
def optimized(n,special=True):
    best=-1;witness=None;states=0
    for h in range((n-6)//2+1):
        for E in ([0]if h==0 else range(2*h,min(23*h,n-6)+1)):
            upper_a=min(n//2,(E+6)//2 if special and h==3 and E==n-6 else (n-h+E+6)//3)
            lower_a=max(0,h+E+6-n)
            intervals=[(lower_a,upper_a)]if h==0 else [(lower_a,min(upper_a,n-3-E))]if h==1 else [(lower_a,min(upper_a,n-2*h-1,n-6+2*h-E)),(max(lower_a,n-2*h),min(upper_a,(2*n-6-E)//2))]
            for lo,hi in intervals:
                if lo>hi:continue
                a=hi;q=0 if special and h==3 and E==n-6 else (n-h-E-6+a)//2
                b=E+q+6-2*a;c=n-h-q-a-b
                assert min(a,q,b,c)>=0 and h+q+a+b+c==n
                value=16*n-48+highsq(h,E)+4*a+b+q;states+=1
                if value>best:best=value;witness=dict(h=h,E=E,a=a,q=q,b=b,c=c)
    return best,witness,states
def direct(n):
    """Independent q/a loops with the piecewise original Jao-West inequality."""
    best=-1
    for h in range((n-6)//2+1):
        for E in ([0]if h==0 else range(2*h,min(23*h,n-6)+1)):
            for a in range(n//2+1):
                m=n-a
                if h:
                    degree_max=m-1 if h==1 else m-6+4*h if 2*h<m else 2*m-6+2*h
                    if E+4*h>degree_max+2*h:continue
                for q in ([0]if h==3 and E==n-6 else range(n-h+1)):
                    b=E+q+6-2*a;c=n-h-q-a-b
                    if b<0 or c<0:continue
                    best=max(best,16*n-48+highsq(h,E)+4*a+b+q)
    return best
def main():
    start=time.monotonic();old=json.loads((ROOT/'degree27-cover-verification.json').read_bytes());assert old['scope']=='MOP n>=8, Delta<=27'
    assert len(old['rows'])==315 and [r['n']for r in old['rows']]==list(range(60,375))
    rows=[]
    for n in range(60,375):
        value,witness,states=optimized(n);margin=threshold(n)-value;assert margin>0
        expected=old['rows'][n-60];assert value==expected['relaxed_max_M2']and str(margin)==expected['margin']and str(threshold(n))==expected['moment_threshold'],n
        if n in [60,75]:assert direct(n)==value
        rows.append(dict(n=n,M2_upper=value,margin=str(margin),maximizing_histogram=witness,admitted_extremal_a_states=states))
        if n%25==0:print(json.dumps(dict(status='EXACT_DEGREE27_HISTOGRAM_PROGRESS',n=n,seconds=time.monotonic()-start)),flush=True)
    assert min((F(r['margin']),r['n'])for r in rows)==(F(429,800),75)
    # For n>=375, written all-order inequality M2<=42n-188 and
    # B(n)-(42n-188)=(15n²-5648n+14112)/(32n). Positive increasing numerator.
    assert threshold(375)-(42*375-188)==F(1829,4000)
    assert 15*375**2-5648*375+14112==5487 and 30*375-5648>0
    without=optimized(75,False)[0];assert threshold(75)-without<0
    names=['degree27_all_orders_proof.txt','degree27-cover-verification.json','order59-complete-cover-verification.json','order59-audit.json']
    out=dict(status='PASS_INDEPENDENT_ALL315_DEGREE27_HISTOGRAM_ROWS_AND_ANALYTIC_BOUNDARY',finite_orders=[60,374],minimum_margin='429/800',minimum_order=75,direct_full_a_q_loop_orders=[60,75],all_original_moments_and_margins_identical=True,without_special_n75=dict(M2_upper=without,margin=str(threshold(75)-without),meaning='Necessary relaxation without the extremal-triangle exclusion fails; not an actual MOP counterexample'),analytic_from=375,analytic_margin_at375='1829/4000',rows=rows,seconds=time.monotonic()-start,source_sha256={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest()for n in names},scope='Fresh independent arithmetic for the actual degree27 histogram constraints plus exact analytic threshold. Necessary constraints use the read Jao-West statements and written equality case. Original PSD-moment criterion and all-order graph identities remain required; finite8..59 is inherited, not newly proved. Original unrestricted target stays OPEN.',original_global='OPEN')
    (P/'degree27-audit.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items()if k not in ['rows','source_sha256']},indent=2))
if __name__=='__main__':main()
