# A smaller source basis for the external/external counter front

8 November2026. ORIGINAL GLOBAL OPEN. This is a precise alternative
normalization proof for a SMALLEST original counter, not an all-parent
increment for every cap and not completion of the two parent payments.
The finite basis B71 and whole gamma<=4 theorem retain their separately
proved scopes and source boundaries. The latter is obtained by selected-hub
geometry/energy, not by the terminal-path normalization proved here.

1. Two proper induced MOP blocks suffice by minimality.

For a smallest original counter G, any partition V(G)=S union T into two
disjoint induced UNIT MOPs with |S|,|T|>=8 is impossible. Each smaller
MOP obeys F>=2order by minimality. The PSD variational formula, using a
block-diagonal witness, gives F(G)>=F(G[S])+F(G[T])>=2|G|. No positive
increment or energy edge-monotonicity is needed. In particular an actual
first-turn cap whose PRIVATE adjacency is fan_L with L>=8 is excluded
whenever its retained MOP has at least8vertices. Both blocks are proper.

This rule does not apply to c join(Pp union Pq): it has2N-4edges and an
articulation at c, so is not a maximal outerplanar graph. Nor does it
turn an old-apex fan's PRIVATE PATH into a maximal outerplanar graph.
The old-degree3 fan19 increment remains a separate needed theorem.

2. One common whole-small-old bridge.

Any old MOP H of order h2..7 with boundary ab has an anchored dominating
set {a,b,v}: a,b cover four consecutive cycle positions, and the remaining
at most three consecutive vertices are covered by their midpoint. Omit v
when unnecessary; K2 is explicit. If a closed cap's private vertices are
dominated by {a,b,u}, where at most one additional private u is used, the
WHOLE graft has gamma<=4. This applies to first-turn private fans, all four
two-fan apex assignments, and the three grouped parent forms. At original
n>=72 the already proved whole gamma<=4 theorem excludes it. This is not
an increment into unpaid K2..7. It avoids using the older small-core PSD
energies or disjoint-fan reserve inside this normalization step.

3. Every terminal path is an external-apex fan.

One/two endpoint-rooted triangles form an external-apex fan; choose the
apex of the two-triangle prefix to resolve a one-triangle ambiguity. While
the leaf prefix is u,v0,v1;...;u,v_(ell-1),v_ell, its closing edge is uv0.
The next face u,v0,x across that chord has a new third vertex on its other
side. Parent edge ux keeps external apexu; parent edge v0x makes u PRIVATE.
In the latter case the private adjacency is EXACTLY fan_L,L=ell+1, with
contacts au,av1,bu to a=v0,b=x. Closedness forbids other contacts.

The first possible turn has ell2,L3 and is the proved private-K3 wing
gain>6.07. At ell3,L4 it is literally operation D gain>8.3. At L5..7 use
only the three finite first-turn Perron-projector payments>2L. At L>=8,
use section1 if the retained order>=8, and section2 otherwise. Thus no
turn is possible for arbitrary path length. No old four-face catalogue,
unbounded first-turn spectral tail, or small-core energy lemma is needed
on this route. The existing broader theorems remain true. If the entire
weak dual has no branch, the resulting whole graph is a fan and is paid
by the already proved gamma<=4 class; it is not a smaller graph.

4. Both private fan apices: a uniform analytic large part.

At a deepest branch, its two children are straight fans. If both apices
are the private parent c, its private B is c join(Pp union Pq),d=p+q,
N=d+1. For a hub joined to two paths, put h=1-2/d. Interlacing on deletion
of the hub and the hub/uniform compression give

F(B)>2d+G(d), G(d)=2h²+2h sqrt(d+h²)-6.

Indeed F(Pp union Pq)=d-2, its top eigenvalue square<4, and the compressed
top eigenvalue is h+sqrt(d+h²). G strictly increases for d>2. At16,
G16=(7sqrt1073-143)/32>345/128, since(131/4)²<1073. Hence for EVERY
d>=16, F(B)>2N+89/128. Block pinching pays the whole increment for any
old H; in a counter use minimality when h>=8 and section2 when h<=7.
The old15 private d16 Gram witnesses are unnecessary for this input.

If d<=15 and max(p,q)>=3, remove the last two vertices next to c of a
long child. The whole root degrees are(d+2,3), retained(d,2), hence old
contactGram(d-1,1), with3<=d-1<=14. The fresh twelve-case C0 theorem
applies with gain>4.09. It leaves actual order n-2>=70. External root
degrees do not enter this calculation. The source is
../mop-c0-needed-input-20261108/needed-c0-proof.md.

For remaining p,q<=2, (1,2)/(2,1) are EXACT operation B and coherent
reflection, gaining>8.07 for four private vertices. For (1,1), choose
both child-triangle apices external; it remains for the external/external
front. No bare balanced-fork increment is asserted.

5. The private bowtie(2,2) has a short analytic replacement.

Its literal private order is c,x1,x2,y1,y2, with c adjacent to all leaves
and edges x1x2,y1y2. Contacts are e_c+e_x1 and e_c+e_y2. The eigenvalues
are lambda=(1+sqrt17)/2,1,-1,-1,(1-sqrt17)/2; all five are retained.
For the complete positive-mode filter at an actual old MOP boundary,

DeltaF>=F(B)+sum_(b>0)max(0,g_b-c(b)zeta_b),
c(b)=(2-b)²/[4(sqrt(2b)+b)] for b<2,and0otherwise,
g_b=Tr(T P_b T^t),zeta_b=Tr((2I+J)^-1 T P_b T^t).

This is the proved one-sided anisotropic mode lemma, sections2..4 of
../mop-root-sector-20261105/universal-C3-anisotropic-filter-proof.md.
It uses the physical original root sector, installs nonpositive modes
first and positives in ascending order, and imposes no old norm bound.

Here F(B)=(11+sqrt17)/2. The Perron vector is(lambda-1,1,1,1,1), with
norm-square9-lambda, so g_lambda=2lambda²/(9-lambda)
=(85+13sqrt17)/68. For eigenvalue1 the unit vector is
(0,1/2,1/2,-1/2,-1/2); its contact image is(1/2,-1/2), giving g1=zeta1=1/2.
Thus the exact filter score is

59/8+(47/68)sqrt17-sqrt2/8
 >59/8+(47/68)(4123/1000)-(1415/1000)/8>10+1/25.

The square comparisons4123²<17*1000² and1415²>2*1000² are exact.
This pays five private vertices for EVERY old unit MOP boundary, with
no1.5MB bowtie quadrature required by this alternative. The older stronger
gain>10.8 and its full certificate remain valid. This weaker but sufficient
analytic bound is not a claimed improvement of that numerical margin.

6. Mixed assignments and the exact remaining class.

After the whole-small-old stop, assume the bare branch's retained H>=8.
If a mixed branch has external apex a on p and private c on q, a p1
triangle may be reassigned to c and section4/5 applies. A q1 triangle
may be reassigned to b and becomes external/external. These are literal
same-edge descriptions, not separate credits. Otherwise p,q>=2.
At q2 use the accepted all-p mixed payment. At q3..14 use the fresh C0
Gram(q,1)tip. At q15..18 use only those instances of the existing q15..20
universal theorem. At q>=19 remove only that inward fan; retained c has
actual degree exactly3, independently of p, and the accepted fan19
increment applies. Its retained graph contains H and has order>=8.

Therefore every deepest branch in a smallest original counter admits
the EXTERNAL/EXTERNAL description E_(p,q). This establishes exactly the
structural premise used in parent-extraction-proof.md. It pays no arbitrary
bare E increment and does not assume a universal good ear or C0cap. The
only remaining energy work is the actual grouped parent payments already
specified in current-global-proof.md. Both sibling roles must still use
their own actual contacts; current private completion and pending double
selection are handled separately. Original global stays OPEN until that
last input and the final original-quantifier comparison are complete.
