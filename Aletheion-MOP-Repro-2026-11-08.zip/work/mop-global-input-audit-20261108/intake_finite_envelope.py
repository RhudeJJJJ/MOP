from pathlib import Path
import json,hashlib,sqlite3,shutil,subprocess,sys,time
P=Path(__file__).resolve().parent;DB=Path('C:/Users/jonas/Aletheion/aletheion/aletheion.db');PRE='math:mop:finite-degree-envelope:'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dig(s):return hashlib.sha256(s.encode()).hexdigest()
def rd(n):return json.loads((P/n).read_bytes())
def save(n,v):(P/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def prepare():
    v=rd('finite-degree-envelope-check.json');assert v['status']=='PASS_ALL29_FINITE_DEGREE_ENVELOPES_FULL_HISTOGRAM_AND_KNAPSACK_READER'
    assert all(sha(P/n)==h for n,h in v['source_sha256'].items())
    parent=['math:mop:direct-low-degree-inputs:use:20261108','legacy:essays:3023:r1:38807ebb1296ae02']
    c=sqlite3.connect('file:'+str(DB)+'?mode=ro',uri=True);c.execute('BEGIN');assert not c.execute('select node_id from weave_nodes where node_id like ?',(PRE+'%',)).fetchall();snap=[]
    for i in parent:
        body=c.execute('select body from weave_nodes where node_id=?',(i,)).fetchone()[0];snap.append(dict(node_id=i,body=body,sha256=dig(body)))
    c.rollback();c.close();save('finite-degree-parent-snapshot.json',snap)
    ids={k:PRE+k+':20261108'for k in ['payment','consequence','scope','proofsource','certificate']};nodes=[];edges=[]
    def node(k,kind,body,status):nodes.append(dict(node_id=ids[k],kind=kind,title='Finite degree-moment envelope: '+k,body=body,epistemic=status,provenance=json.dumps([dict(path=str(P/'finite-degree-envelope-proof.md'),sha256=sha(P/'finite-degree-envelope-proof.md'))])))
    def edge(a,b,rel,why):edges.append(dict(edge_id='edge:'+dig(a+'|'+rel+'|'+b),from_id=a,to_id=b,relation=rel,rationale=why,status='curated'))
    node('payment','claim','EVERY finite simple UNIT MOP has F=splus>2n in EACH complete domain: n43..46,Delta<=29; n47..48,Delta<=28; n49,Delta<=27; n50,Delta<=25; n51..54,Delta<=26; n55..58,Delta<=27; n59..64,Delta<=28; n65..71,Delta<=29. No smaller-order energy premise or Catalan/kernel maximum is assumed. The necessary degree-histogram superset uses Jao-West3.3/3.4, original ear deletion and actual degree sum, never equality lemma3.2. For ALL29 orders, an independent full a/q enumeration with integer-knapsack high squares reproduces each optimized maximum. All maxima are strictly below the PSD shift5/2 threshold1359n/32-729/2+441/n. Minimum exact margin1567/2080 at65. Not every degree or every original graph is covered.','PROVEN complete finite degree/order envelope, exact full literal histogram and knapsack checks')
    node('consequence','claim','At original order50, this new direct Delta<=25 input pays the old special profiles(d,l)=(23,2),(23,3),(24,3). The current finite-cover assembly may use it instead of the earlier two-gap reserve/full-kernel package and two three-gap Catalan maxima for those cases. It also covers the n50 single-gap low-degree case without smaller-order induction. Across other stated orders, only subcases with actual maximum degree at most the declared cap get this alternative proof. Old proofs and their original scopes remain true; overlaps give no additional energy credit. Higher-degree cover clauses and other smaller-order inductive inputs remain necessary.','PROVEN alternative finite-cover input; no old theorem refuted or whole B71 upgrade')
    node('scope','claim','ORIGINAL EVERY finite simple UNIT MOP n>=8 F=splus>=2n remains GLOBAL OPEN; goal ACTIVE. This finite degree envelope simplifies exact low-degree inputs to the old finite cover. It neither proves all high-degree Catalan/core geometry nor removes all earlier finite bases; gamma4 and the two running unbounded parent-family certificates retain their obligations. Portable same-reader reproduction is not an independent human/formal audit. No original counterexample, first discovery or causal LOTSE effect claimed.','PROVEN precise finite scope; global work remains')
    for k in ['payment','consequence','scope']:edge(ids[k],ids['proofsource'],'requires','Complete necessary histogram and PSD-moment argument, exact full literal checks and limits obligatory.')
    edge(ids['payment'],ids['certificate'],'requires','Full29 exact maxima and positive rational margins.')
    edge(ids['consequence'],ids['payment'],'requires','Only these declared degree/order domains justify replacing old proof obligations.')
    for i in parent:edge(ids['consequence'],i,'qualifies','Additional sufficient low-degree route; all older statements retained and other original input clauses unchanged.')
    names=list(v['source_sha256'])+['finite-degree-envelope-check.json','replay_finite_degree_core.py','intake_finite_envelope.py','run_guarded_native_low.py','finite-degree-parent-snapshot.json'];files=[P/n for n in dict.fromkeys(names)]
    env=dict(format='full-source-envelope-v2-relative-files',files=[dict(path=str(f),relative=f.name,bytes=f.stat().st_size,sha256=sha(f),content=f.read_bytes().decode())for f in files]);payload=json.dumps(env,ensure_ascii=True,separators=(',',':'));pieces=[payload[j:j+72000]for j in range(0,len(payload),72000)]
    header=dict(format='complete-source-envelope-chunks-v1',payload_utf8_bytes=len(payload.encode()),payload_sha256=dig(payload),parts=[dict(node_id=PRE+'sourcepart'+str(j)+':20261108',part=j+1,bytes=len(s.encode()),sha256=dig(s))for j,s in enumerate(pieces)])
    node('proofsource','source',json.dumps(header,separators=(',',':')),'FULL source header; every numbered body required')
    for j,(item,s)in enumerate(zip(header['parts'],pieces),1):
        nodes.append(dict(node_id=item['node_id'],kind='source',title='Finite degree envelope full source '+str(j),body=s,epistemic='FULL raw fragment incomplete alone',provenance=json.dumps([dict(payload_sha256=dig(payload),part=j)])));edge(ids['proofsource'],item['node_id'],'requires','Complete raw source part obligatory.')
    node('certificate','source',json.dumps(v,separators=(',',':')),'FULL original29 exact rows; historical coverage annotations distinct from portable mathematical replay')
    save('finite-degree-packet.json',dict(schema_version=1,nodes=nodes,edges=edges));save('finite-degree-source-hashes.json',{str(f):sha(f)for f in files})
    raw=sum(f.stat().st_size for f in files);backup=DB.stat().st_size+16*1024**2;free=shutil.disk_usage(P).free;assert raw<1024**2 and free-backup-3*raw>8*1024**3
    save('finite-degree-write-plan.json',dict(explicit_members=[str(f)for f in files],raw_bytes=raw,backup_count=1,backup_upper_each=backup,free_before=free,no_expected_deduplication=True));print(json.dumps(dict(status='PREPARED_FINITE_DEGREE_ENVELOPE',nodes=len(nodes),edges=len(edges),files=len(files),parts=len(pieces),raw_bytes=raw,backup_upper_each=backup,free_before=free)))
def audit():
    assert all(sha(Path(f))==h for f,h in rd('finite-degree-source-hashes.json').items());packet=rd('finite-degree-packet.json');c=sqlite3.connect('file:'+str(DB)+'?mode=ro',uri=True);c.row_factory=sqlite3.Row;c.execute('BEGIN');actual=[];nodes={}
    for table,key,item in [('weave_nodes','node_id',n)for n in packet['nodes']]+[('weave_edges','edge_id',n)for n in packet['edges']]:
        row=dict(c.execute('select * from '+table+' where '+key+'=?',(item[key],)).fetchone());assert all(row[k]==v for k,v in item.items());actual.append(dict(table=table,row=row))
        if table=='weave_nodes':nodes[row['node_id']]=row
    for s in rd('finite-degree-parent-snapshot.json'):assert dig(c.execute('select body from weave_nodes where node_id=?',(s['node_id'],)).fetchone()[0])==s['sha256']
    c.rollback();c.close();save('finite-degree-actual-readback.json',actual);header=json.loads(nodes[PRE+'proofsource:20261108']['body']);parts=[]
    for j,v in enumerate(header['parts'],1):
        body=nodes[v['node_id']]['body'];assert j==v['part']and len(body.encode())==v['bytes']and dig(body)==v['sha256'];parts.append(body)
    payload=''.join(parts);assert len(payload.encode())==header['payload_utf8_bytes']and dig(payload)==header['payload_sha256'];env=json.loads(payload);root=P/'finite-degree-native-replay'
    for f in env['files']:
        data=f['content'].encode();assert data==Path(f['path']).read_bytes()and len(data)==f['bytes']and hashlib.sha256(data).hexdigest()==f['sha256'];dest=root/f['relative'];assert dest.parent==root;root.mkdir(exist_ok=True)
        if dest.exists():assert dest.read_bytes()==data
        else:dest.write_bytes(data)
    argv=[sys.executable,'-B','-X','utf8',str(root/'replay_finite_degree_core.py')];start=time.monotonic();r=subprocess.run(argv,cwd=root,capture_output=True,text=True,encoding='utf8');save('finite-degree-replay-process.json',dict(argv=argv,exit_code=r.returncode,wall_time_seconds=time.monotonic()-start,stdout=r.stdout,stderr=r.stderr));assert r.returncode==0,r.stderr
    check=json.loads((root/'finite-degree-core-replay.json').read_bytes());assert check['status']=='PASS_FRESH_PORTABLE_ALL29_FINITE_DEGREE_MATH_ROWS'and check['rows_identical']
    for label in ['finite-degree-dryrun','finite-degree-import']:assert rd(label+'.process.json')['exit_code']==0
    receipt=rd('finite-degree-import.stdout.json');assert receipt['inserted']==dict(nodes=len(packet['nodes']),edges=len(packet['edges']),reviews=0);backup=Path(receipt['backup']);assert backup.is_file()and backup.stat().st_size<=rd('finite-degree-write-plan.json')['backup_upper_each']
    out=dict(status='PASS_NATIVE_ALL29_FINITE_DEGREE_ENVELOPES_AND_FULL_PORTABLE_MATH_REPLAY',native_run_id=receipt['run_id'],nodes=len(packet['nodes']),edges=len(packet['edges']),files=len(env['files']),parts=len(parts),all_sources_byte_identical=True,every_exact_mathematical_row_identical=True,parents_unchanged=True,backup=str(backup),free_after=shutil.disk_usage(P).free,original_global='OPEN',original_goal_complete=False,source_limit='Portable replay covers complete theorem mathematics; historical row-replacement annotations retained as separate original evidence')
    save('finite-degree-native-audit.json',out);print(json.dumps(out))
if __name__=='__main__':prepare()if len(sys.argv)==1 or sys.argv[1]=='prepare'else audit()
