# All-length contact identities and the signed infinite-tail formula

8 November 2026. A detailed derivation of the retained tail input, not a new
family payment or original global closure. The private sibling and middle
double compact certificates remain pending. No frozen computation source
is changed by this audit.

## 1. Actual double-parent coordinates, without a length cutoff

Use the literal private order L_1..L_p,d,Q_1..Q_q,c,R_1..R_r,e,S_1..S_s.
The whole list is a path, and c is additionally adjacent to d,e and every
Q and R vertex. Repeated edges are kept once. Let a indicate the prefix
L_1..L_p,d together with c, and b indicate c,e,S_1..S_s. These are the
two actual contact columns T^t. All four lengths are positive integers.
Write m=q+r and V=(B-2I)T^t, with columns v_a,v_b. Direct neighbor counts
at each named position give

v_a = -L_1 +2Q_1 +sum_(j=2..q) Q_j -c +sum_(j=1..r) R_j +e,
v_b = d +sum_(j=1..q) Q_j -c +sum_(j=1..r-1) R_j +2R_r -S_s.

Here a vertex symbol denotes its unit coordinate vector. Empty sums are
zero, and all separately named groups are disjoint even when a length is
one. Thus the formulas also cover p=q=r=s=1 without merging different
vertices. In particular,

TV=-2I,
T T^t=[[p+2,1],[1,s+2]],
V^t V=[[m+6,m+3],[m+3,m+6]].

For example ||v_a||^2=1+4+(q-1)+1+r+1=m+6; the cross product is
(q+1)+(r+1)+1=m+3. The outer lengths occur only in the locations of two
unit endpoint vectors, not in these Gram values. This is an all-length
coordinate proof, rather than an inference from finitely many inverses.

Deleting the star at c leaves a finite path forest. The star degree is
m+2, and its adjacency norm is sqrt(m+2); every finite path forest has
norm<2. The triangle inequality therefore gives ||B||<sqrt(m+2)+2,
uniformly in p,s. For m<=19 this is<7; for m<=41 it is<9.

For x=z^2>=0 put C=V^t(I+xB^2)^-1V and
D=V^t B(I+xB^2)^-1V. Spectral calculus gives 0<=(I+xB^2)^-1<=I and
||B(I+xB^2)^-1||<=||B||. Cauchy-Schwarz now proves
0<=C_ii<=m+6, |C_01|<=m+6, |D_ij|<=(m+6)||B||.
These inequalities hold on the closed z interval including zero and for
every finite p,s independently. No operator for an infinite graph is
introduced and no interchange of graph-size and frequency limits is used.

For the private-apex sibling the literal coordinate proof in
../mop-private-sibling-middle-20261108/private-model-proof.md section 6
similarly gives TV=-2I and, when ell>=2,
V^tV=[[S+5,S+1],[S+1,S+5]], S=q+ell. Its star degree S+1 gives
||B||<sqrt(S+1)+2. Thus the actual constants are C24,D156 on S4..19,
and C54,D540 on S20..49, uniformly in its infinite outer length p.
The ell=1 exception is not silently included in that Gram equality; it
has its separate external-role description in the original assembly.

## 2. The exact signed resolvent identity

Let w=t+2i and R=(tI+iB)^-1. Since B T^t=2T^t+V, multiplication by R
gives R T^t=(T^t-iRV)/w. Transposition is legitimate because B and R
are symmetric, not Hermitian. Applying this identity twice gives

T R T^t =T T^t/w-iTV/w^2-V^t R V/w^2
        =T T^t/w+2iI/w^2-V^t R V/w^2.

The double-parent lossless normalization subtracts (p-1)/w and (s-1)/w
from its respective diagonals, so T T^t is replaced by Q=[[3,1],[1,3]].
For the private sibling only the left ray is removed and Q=[[3,1],[1,2]].
This is the accepted phase-upper normalization; actual private energy and
contact mass are never replaced by energy of the normalized response.

With z=1/t, x=z^2, let f=1+4x. Since V^t R V=txC-ixD, the normalized
response is exactly F_n=zA-ixM, with REAL SYMMETRIC matrices

A=Q/f+8xI/f^2-x[(1-4x)C-4xD]/f^2,
M=2Q/f-2(1-4x)I/f^2-x[(1-4x)D+4C]/f^2.

For example 1/(1+2iz)^2=(1-4x-4iz)/f^2. This directly derives both
signed C/D terms in the running tail programs; neither is an unsigned
norm-remainder substitute. All actual finite private modes are retained.

## 3. Rationalization and every nonnegativity used by the programs

Fix K=[[2,1],[1,2]], K^-1=[[2,-1],[-1,2]]/3. At every tail point the
interval programs establish A positive definite, using A_00>0 and
det(A)>0. Put Ahat=K^-1/2 A K^-1/2, Mhat=K^-1/2 M K^-1/2 and define

q=Tr(Ahat), m=Tr(Mhat), u=det(Ahat), v=det(Mhat),
w=det(Ahat+Mhat)-u-v,
Z=sqrt((u-xv)^2+xw^2), Delta=w^2-4uv.

Thus q>0,u>0. If r1,r2 are the real eigenvalues of
Ahat^-1/2 Mhat Ahat^-1/2, then w=u(r1+r2),v=u*r1*r2 and
Delta=u^2(r1-r2)^2>=0. This proves the discriminant clamp used in the
interval code, even when Mhat is indefinite. No sign of v is assumed.

The denominator Z+u+xv is strictly positive for all x>=0. If v>=0 this
is immediate. If v<0, Z>=u-xv implies the denominator>=2u>0.
Define h=Delta/(Z+u+xv)>=0. Squaring gives the exact identity

Z-u-xv=xh,
||Ahat-izMhat||_*^2=q^2+x(m^2+2h).

The second identity uses the two-by-two singular-value formula
||Y||_*^2=Tr(Y*Y)+2|detY|, and retains BOTH singular directions.

The accepted old-root ball support bounds the phase after normalization:

t b(F_n,t)<=V_old
 =-xm-q/2+(1/2)sqrt((1+4x)[q^2+x(m^2+2h)]).

Let S denote the last square root without its factor1/2. Rationalizing
the difference gives the exact nonnegative density

V_old/x = [(2q-m)^2+2(1+4x)h] / [2(S+q+2xm)].                 (*)

For x>0 its denominator is strictly positive. Indeed
S^2-(q+2xm)^2=x[(2q-m)^2+2(1+4x)h]>=0. Equality can occur only when
m=2q,h=0, in which case q+2xm=q(1+4x)>0. Otherwise S>|q+2xm|.
At x=0 the denominator equals4q>0, giving a continuous finite formula.
The interval programs additionally CHECK a strictly positive lower bound
for each divisor over each full cell, rather than relying on pointwise
positivity to license interval division.

Formula (*) is exactly double_tail.py and the private small/large tail
formula. Their variables called q,m are these traces, not arm lengths.
Because dt=-dz/z^2, the complete required high-frequency integral obeys

integral_T^infinity t b(F_actual,t)dt
 <=integral_0^(1/T) [V_old(z)/z^2] dz.

The accepted lossless-ray lemma supplies b(F_actual)<=b(F_n); the
accepted root-ball support supplies the other inequality above. Entire
z cells, their square-root enclosures and their positive denominators
bound this density. There is no pointwise numerical quadrature and no
uncontrolled discarded upper tail.

## 4. What this audit changes

The current global proof may cite the displayed all-length coordinates,
Gram/norm proof, signed response identity and full rationalization rather
than treating the high-tail routine as an unexplained formula. Existing
physical controls remain useful calibration. They are not the proof of
unbounded arm coverage. The new algebra checker independently expands
the signed response and rationalization identities, including degenerate
endpoint lengths, and exposes any discrepancy without editing live inputs.
This detailed audit does not validate any missing compact slab, change a
family status, produce an original counterexample, or close the conjecture.
