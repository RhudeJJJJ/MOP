# Smaller sufficient degree inputs for the original finite cover

8 November 2026. Original ALL UNIT MOP n>=8 target GLOBAL OPEN; goal ACTIVE.
These are exact replacements of particular LOW-DEGREE INPUTS, not a
replacement of the target or closure of the other finite-cover cases.

Write F(G)=splus(G), M2(G)=sum_v degree(v)^2. All graphs here are finite,
simple, UNIT maximal outerplanar graphs of order n. They have2n-3 edges,
n-2 triangular faces and n-3 quadrilateral cycles. Every triangle is a
face: there are no polygon vertices inside it. Every quadrilateral cycle
has exactly one internal diagonal, whose two incident triangular faces
form it; conversely every internal diagonal produces one such cycle.
Thus the exact adjacency moments are

 mu2=4n-6, mu3=6n-12, mu4=2M2+4n-18.

For every real r>0 the PSD witness X=t(A+rI)^2, t>=0, gives

 F>= (mu3+2r mu2)^2/(mu4+4r mu3+6r^2 mu2+n r^4).

Indeed its objective is2t(mu3+2r mu2)-t^2 times the denominator;
maximize at t=(mu3+2r mu2)/denominator>0. This follows directly from
F=max_(X PSD)[2Tr(AX)-Tr(X^2)]. No connected n-1 or gluing theorem is
used in this moment test. Consequently M2<=T_r(n) suffices for F>=2n,
where

 T_r(n)=((6n-12+2r(4n-6))^2/(2n)
          -4n+18-4r(6n-12)-6r^2(4n-6)-n r^4)/2.

A strict moment inequality gives strict F>2n.

1. DEGREE8, EVERY n>=12, WITHOUT ANY SMALL-ORDER INPUT.

If Delta<=D and every degree>=2, then
(d-2)(d-D)<=0 for each degree, hence

                 M2<=(2D+8)n-6D-12.

At D8 this is24n-60. Take r2, for which T_2=39n-267+324/n.
Its difference from24n-60 is exactly

                    3(n-12)(5n-9)/n>=0.

Thus EVERY such graph n>=12,Delta<=8 has F>=2n, strictly for n>12.
Orders8..11 remain the separately inherited complete exact base. This
lemma has no outside paper input and no finite-histogram extrapolation.

2. DEGREE22, EVERY n>=36, WITHOUT A FINITE-ORDER BASE.

For n>=36 let H={v:degree(v)>=6}, h=|H|, E=sum_H(degree-4).
Let a,b,c,q count degree2,3,4,5 vertices respectively. Since total degree
is4n-6,

        2a+b=E+q+6,       E+3q+2h<=2n-6.

The read Jao-West Theorem3.4 at k6 gives h<=floor((n-6)/2)<n/2.
For h>=2, their Theorem3.3 gives sum_H degree<=n-6+4h, so E<=n-6.
For h1, E<=18<=n-6; for h0, E=0. Every high x=degree-4 lies in[2,18].
When h>=1,

 sum_v(degree-4)^2<=18E+4a+b+q
                    <=20E+3q+12
                    <=19E+2n+6-2h
                    <=21n-108-2h.

As sum_v(degree-4)=-6, M2=16n-48+sum_v(degree-4)^2. Hence
M2<=37n-158 for h>=1. For h0, the same low-degree identities give
M2<=18n-42<=37n-158 in the present domain.

For r5/2, T_r=B(n)=1359n/32-729/2+441/n. The numerator of
B(n)-(37n-158) is175n^2-6608n+14112 with denominator32n.
At n36 it is3024>0; its derivative350n-6608 is positive for n>=36.
Thus EVERY UNIT MOP n>=36,Delta<=22 has F>2n. In particular this
directly covers the degree22 input wherever used in the old n43..59
parameter stages. No n8..42 theorem is assumed by this new lemma.
It does not claim the degree22 subclass for smaller n.

3. DEGREE27, THE COMPLETE FINITE RANGE60..71, WITHOUT THE DEGREE75
EQUALITY CASE OR AN INHERITED SMALL-ORDER ENERGY THEOREM.

Use the same h,E,a,b,c,q. Now2h<=E<=min(23h,n-6), with h=E=0
allowed, and0<=a<=floor(n/2). The high-square maximum for fixed h,E is
obtained by packing x_i=degree-4 in[2,23] at its two endpoints. With
j,u=divmod(E-2h,21), it is

                 S(h,E)=4h+525j+((2+u)^2-4 if u>0 else0).

This is the elementary convex transfer: moving a unit from the smaller
of two nonsaturated interior entries to the larger increases the sum
of squares. It gives a global maximum after finitely many transfers.

Original ears are pairwise nonadjacent on the outer cycle for n>=4.
Deleting ALL a original ears therefore leaves a MOP on m=n-a vertices;
every surviving vertex loses at most its TWO original cycle neighbors.
For the surviving high set Jao-West gives the additional necessary bound

                   E+4h<=D(m,h)+2h,

where D(m,1)=m-1, D(m,h)=m-6+4h for2<=h<m/2, and
D(m,h)=2m-6+2h for h>=m/2. Here m>=30 and h<=m, so all uses are in
the stated domain. No equality characterization is used.

Enumerate ALL integer h,E,a,q satisfying these necessary inequalities,
b=E+q+6-2a>=0 and c=n-h-q-a-b>=0. Their moment upper is

                     16n-48+S(h,E)+4a+b+q.

This is a SUPerset of actual degree histograms. In particular the
relaxed h3,E=n-6 profiles with q1 are RETAINED; none is excluded by the
old extremal-triangle lemma. The exact twelve maxima for n60..71 are

  n: 60  61   62   63   64   65   66   67   68   69   70   71
  U:2108 2142 2178 2216 2256 2298 2342 2388 2436 2486 2538 2592.

Every U<B(n). The least exact margin in this finite range is
147663/2272 at n71. The supplied exact reader checks all twelve using
both the optimizer and a fresh literal full a/q loop against the
piecewise Jao-West constraint; it stores all rational margins and
maximizing relaxed histograms. No actual realization of those maxima
is needed. These finite positive inequalities plus the written necessary
constraints prove F>2n for EVERY graph in this finite low-degree range.

4. Consequence and limits.

The n12+ degree8, n36+ degree22, and n60..71 degree27 LOW-DEGREE cases
of the finite original cover can now use these direct inputs. The last
does not need the old degree27 theorem's n8..59 energy premise or its
equality-only special treatment at n75. This does NOT remove the n8..59
premise from other original-cover cases, such as a single-gap inductive
partition. Nor does it establish the missing high-degree Catalan/core
geometric inputs, gamma4 whole bridge, or the running unbounded parent
payments. The old all-order degree27 theorem and its genuine n75 special
case remain valid at their original scope.

Primary degree source: Kyle F. Jao and Douglas B. West, Vertex Degrees in
Outerplanar Graphs (2010), https://dwest.web.illinois.edu/pubs/outerpl.pdf,
Theorems3.3/3.4. The actual statements were read in this continuation's
input audit. No external theorem is claimed as an original discovery.
This input simplification changes the justified next work: the B71 audit
need not audit the stronger all-order degree27 equality case to justify
its n60..71 low-degree subcases. All other named obligations remain.
