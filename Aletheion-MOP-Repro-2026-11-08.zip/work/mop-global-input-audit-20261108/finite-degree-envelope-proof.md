# A direct degree-moment envelope for the actual finite original-cover stages

8 November 2026. ORIGINAL ALL UNIT MOP n>=8 target GLOBAL OPEN; goal ACTIVE.
This proves the exact finite degree/order domains below, not every degree.

THEOREM. EVERY finite simple UNIT maximal outerplanar graph G in ANY of
these domains has F(G)=splus(G)>2|G|:

    order n       upper bound on maximum degree
    43..46                    29
    47..48                    28
       49                     27
       50                     25
    51..54                    26
    55..58                    27
    59..64                    28
    65..71                    29.

There is no assumed smaller-order energy inequality. This proof uses
only exact necessary degree constraints, the PSD-moment witness and the
read Jao-West degree theorems3.3/3.4. Their equality lemma3.2 is NOT used.
It does not assume the older Catalan moment maxima or exact hub kernels.

1. Necessary integer histogram set, arbitrary declared cap D.

Let H contain the h vertices of degree>=6 and put E=sum_H(degree-4).
Let a,b,c,q count degrees2,3,4,5. Every graph in the theorem satisfies
6<=D<=n-2. The necessary constraints are

 h<=floor((n-6)/2), 2h<=E<=min((D-4)h,n-6),
 h=E=0 allowed, 0<=a<=floor(n/2),
 b=E+q+6-2a>=0, c=n-h-q-a-b>=0, q>=0.

The first bound is Jao-West3.4 at degree6. For h>=2, h<n/2 and
Jao-West3.3 gives E<=n-6. At h1, E<=D-4<=n-6. The degree-sum
identity gives the formulas for b,c. Ears are pairwise nonadjacent on
the outer cycle. Removing ALL a original ears leaves a MOP on m=n-a
vertices, every surviving high vertex losing at most TWO neighbors.
Therefore also require

 E+4h<=Dsum(m,h)+2h when h>=1,

 Dsum(m,1)=m-1;
 Dsum(m,h)=m-6+4h for2<=h<m/2;
 Dsum(m,h)=2m-6+2h for h>=m/2.

These are exactly the read Jao-West3.3 cases. Here m>=22, h<=m,
so the original hypotheses hold. No necessary-condition set is claimed
to consist only of realizable graphs.

Put C=D-4. The high x=degree-4 are integers in[2,C] with sum E.
Their square sum is at most S_C(h,E): S(0,0)=0, S_2(h,2h)=4h, and
for C>2, writing j,u=divmod(E-2h,C-2),

    S_C=4h+(C^2-4)j+((2+u)^2-4 if u>0 else0).

Moving a unit from a smaller nonsaturated entry to a larger one raises
the square sum, proving this convex maximum. The independent exact
reader ALSO reconstructs it by an integer knapsack over ALL h,E and
every x in2..C, without using this packing formula.

Since sum_v(degree-4)=-6, every actual graph satisfies

                 M2<=16n-48+S_C(h,E)+4a+b+q.              (1)

The literal checker maximizes(1) over ALL integers h,E,a,q in the
necessary set. For every n43..71 it enumerates a from0..floor(n/2)
and q from0..n-h, tests b,c and the original piecewise ear-deletion
constraint, and reads S from its independently reconstructed knapsack.
No relaxation state is silently removed on a presumed energy theorem.

2. Optimizer and independent literal coverage.

For efficiency an additional optimizer eliminates q and a. At fixed
h,E, the maximal q is floor((n-h-E-6+a)/2). Feasibility gives

 max(0,h+E+6-n)<=a<=min(floor(n/2),floor((n-h+E+6)/3)).

For h1 also a<=n-3-E. For h>=2 the ear condition partitions a into
TWO intervals: a<=n-2h-1 with a<=n-6+2h-E, or a>=n-2h with
2a<=2n-6-E. The objective(1) increases with a and its maximal q,
so the largest a in EACH nonempty interval suffices. This argument
justifies the optimizer; the literal checker does not use it.

Every one of the29 order-specific maxima computed in the two ways
agrees. The complete record retains each exact maximum, rational
margin and relaxed maximizing histogram, plus admitted direct counts.
It also requires the continuous order index to be exactly43..71 and
the declared degree cap to match the theorem table. The old exploratory
scout is not itself accepted as this independent check.

3. Original quantitative energy payment.

The exact MOP moments and PSD variational argument are written in
low-degree-inputs-proof.md: mu2=4n-6, mu3=6n-12,
mu4=2M2+4n-18, X=t(A+(5/2)I)^2. They imply F>2n whenever

                 M2<B(n)=1359n/32-729/2+441/n.

All29 maxima in(1) are STRICTLY smaller than B(n). The minimum
exact margin is1567/2080 at n65,Delta29. Hence the necessary
histogram superset pays every actual graph in the theorem table.
The displayed upper degree is a permitted cap, not an assertion that
every actual graph attains that degree or the relaxed moment maximum.

4. Actual change in the global input route, and preserved obligations.

At n50 the new direct input pays ALL graphs with Delta<=25, including
the old(d,l)=(23,2),(23,3),(24,3) special cases. The n50 finite-cover
assembly can therefore avoid its old two-gap reserve/kernels and
three-gap exact Catalan maxima for those cases. Higher-degree cases
still need their proper original payment. At other stated orders the
new cap similarly replaces only the low-degree subcases it covers.
Overlap is alternative proof coverage, not extra independent credit.

This does not refute any older reserve or Catalan theorem. It does not
remove other smaller-order inductive inputs, establish all of B71,
or close the two running unbounded parent families or the original
global target. No assertion for any larger degree follows from an
unpaid histogram relaxation. Full original completion remains subject
to its exact all-order assembly and source checks.

Primary degree source: Jao-West, Vertex Degrees in Outerplanar Graphs,
https://dwest.web.illinois.edu/pubs/outerpl.pdf, Theorems3.3/3.4.
The source statements and applicability were checked in the current
input audit. Independent software reconstruction is not an independent
human or formal proof-assistant audit; external novelty is not claimed.
