"""Second route: full a/q enumeration and knapsack high squares for all29 orders."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,time
import scout_degree_inputs as scout
P=Path(__file__).resolve().parent
def cap(n):
    if n<=46:return 29
    if n<=48:return 28
    if n==49:return 27
    if n==50:return 25
    if n<=54:return 26
    if n<=58:return 27
    if n<=64:return 28
    return 29
def high_table(n,C):
    table={(0,0):0}
    for h in range(1,(n-6)//2+1):
        for E in range(2*h,min(C*h,n-6)+1):
            scores=[table[h-1,E-x]+x*x for x in range(2,C+1)if(h-1,E-x)in table]
            if scores:table[h,E]=max(scores)
    return table
def literal(n,D):
    T=high_table(n,D-4);best=-1;seen=0
    for(h,E),S in T.items():
        for ears in range(n//2+1):
            m=n-ears
            if h:
                limit=m-1 if h==1 else m-6+4*h if 2*h<m else 2*m-6+2*h
                if E+4*h>limit+2*h:continue
            for q in range(n-h+1):
                b=E+q+6-2*ears;c=n-h-q-ears-b
                if min(b,c)<0:continue
                value=16*n-48+S+4*ears+b+q;seen+=1;best=max(best,value)
    return best,seen,len(T)
def main():
    start=time.monotonic();rows=[]
    for n in range(43,72):
        D=cap(n);assert 6<=D<=n-2
        direct,seen,highstates=literal(n,D);optimized,w=scout.bound(n,D);assert direct==optimized
        margin=F(1359*n,32)-F(729,2)+F(441,n)-direct;assert margin>0
        rows.append(dict(n=n,D=D,M2_upper=direct,margin=str(margin),direct_admitted_histograms=seen,knapsack_high_states=highstates,relaxed_witness=w))
        print(json.dumps(dict(status='EXACT_FINITE_DEGREE_ENVELOPE_PROGRESS',n=n,D=D,seconds=time.monotonic()-start)),flush=True)
    assert min((F(r['margin']),r['n'])for r in rows)==(F(1567,2080),65)
    assert [r['n']for r in rows]==list(range(43,72))and rows[7]['n']==50 and rows[7]['D']==25
    previous=json.loads((P/'order50-to71-index.json').read_bytes());replacement={};special=[]
    for item in previous['orders']:
        n=item['n'];D=cap(n);counts={}
        for r in json.loads((P.parent.parent/item['rows']).read_bytes())['rows']:
            if r['maximum_degree']>D:continue
            counts[r['rule']]=counts.get(r['rule'],0)+1
            if r['rule']in ['two_gap_partition_and_gluing','three_gap_degree_dp','shared_fan_dominating_triangle_or_restricted_dp','hub_triangle_or_restricted_exact_dp']:special.append(dict(n=n,d=r['maximum_degree'],l=r['nonempty_gaps'],rule=r['rule']))
        replacement[str(n)]=counts
    names=['finite-degree-envelope-proof.md','check_finite_degree_envelope.py','scout_degree_inputs.py','audit_degree27.py','low-degree-inputs-proof.md']
    out=dict(status='PASS_ALL29_FINITE_DEGREE_ENVELOPES_FULL_HISTOGRAM_AND_KNAPSACK_READER',rows=rows,minimum_margin='1567/2080',minimum_order=65,old_payment_rows_with_alternative_coverage=replacement,old_special_rows_now_alternatively_paid=special,seconds=time.monotonic()-start,source_sha256={n:hashlib.sha256((P/n).read_bytes()).hexdigest()for n in names},scope='Complete stated degree/order table only; necessary histogram superset and PSD moment proof, no smaller-order energy or Catalan input. Old proof results retained; high-degree and global obligations still OPEN.',original_global='OPEN',native_intake='PENDING')
    (P/'finite-degree-envelope-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in ['rows','source_sha256','old_payment_rows_with_alternative_coverage']},indent=2))
if __name__=='__main__':main()
