from pathlib import Path
from functools import lru_cache
from itertools import combinations
import copy,json,sys
import singular_metric_interval as m
HERE=Path(__file__).resolve().parent
def key(a,b):return tuple(sorted((a,b)))
@lru_cache(None)
def triangulations(verts):
    if len(verts)==2:return (frozenset({key(*verts)}),)
    result=set()
    for split in range(1,len(verts)-1):
        tri={key(verts[0],verts[split]),key(verts[split],verts[-1]),key(verts[0],verts[-1])}
        for left in triangulations(verts[:split+1]):
            for right in triangulations(verts[split:]):result.add(frozenset(tri|set(left)|set(right)))
    return tuple(sorted(result,key=lambda x:sorted(x)))
def independent_diagonal_route():
    boundary={key(i,(i+1)%6) for i in range(6)}
    diagonals=[e for e in combinations(range(6),2) if e not in boundary]
    valid=set()
    for chosen in combinations(diagonals,3):
        if any(a<c<b<d or c<a<d<b for (a,b),(c,d) in combinations(chosen,2)):continue
        valid.add(frozenset(boundary|set(chosen)))
    return valid
def catalogue():
    old=json.loads((HERE.parent/'mop-root-sector-20261105/anisotropic-cap-certificates.json').read_text())['cases'][1]
    templates={'C1':old}
    for typ in ('A','B'):templates[typ]=m.previous.actual(typ)[0]
    for typ in ('C','D'):templates[typ]=m.actual(typ)[0]
    catalogue={}
    for typ,cap in templates.items():
        pos={v:i for i,v in enumerate(cap['boundary'])};normal=frozenset(key(pos[a],pos[b]) for a,b in cap['edges'])
        for reflected,e in ((False,normal),(True,frozenset(key(5-a,5-b) for a,b in normal))):
            catalogue.setdefault(e,[]).append(dict(type=typ,whole_reflection=reflected))
    return catalogue
def describe(e,cat):
    faces=[t for t in combinations(range(6),3) if all(key(a,b) in e for a,b in combinations(t,2))];assert len(faces)==4
    adj=[[] for _ in faces]
    for i,j in combinations(range(4),2):
        if len(set(faces[i])&set(faces[j]))==2:adj[i].append(j);adj[j].append(i)
    assert sum(map(len,adj))==6
    root,=[i for i,t in enumerate(faces) if 0 in t and 5 in t]
    deg=[sum(v in edge for edge in e) for v in range(6)]
    path=sorted(map(len,adj))==[1,1,2,2];endpoint=path and len(adj[root])==1
    paid=cat.get(e,[]);external_apex=[v for v in (0,5) if deg[v]==5]
    return dict(edges=[list(x) for x in sorted(e)],faces=[list(t) for t in faces],root_face=list(faces[root]),dual_degrees=list(map(len,adj)),root_dual_degree=len(adj[root]),
      dual_is_path=path,root_at_path_endpoint=endpoint,external_root_degrees=[deg[0],deg[5]],all_vertex_degrees=deg,paid_by_literal_operations=paid,external_fan_apex=external_apex)
def main():
    first=set(triangulations(tuple(range(6))));second=independent_diagonal_route();assert first==second and len(first)==14
    cat=catalogue();assert set(cat)<=first
    rows=[describe(e,cat) for e in sorted(first,key=lambda e:sorted(e))]
    endpoints=[r for r in rows if r['root_at_path_endpoint']];unpaid=[r for r in rows if not r['paid_by_literal_operations']]
    assert len(endpoints)==8 and len([r for r in endpoints if not r['paid_by_literal_operations']])==2
    assert all(bool(r['paid_by_literal_operations'])==(not bool(r['external_fan_apex'])) for r in endpoints)
    assert len(unpaid)==4 and len([r for r in unpaid if r['root_at_path_endpoint']])==2
    assert all(r['external_fan_apex'] for r in unpaid if r['root_at_path_endpoint'])
    assert all(r['dual_is_path'] and r['root_dual_degree']==2 for r in unpaid if not r['root_at_path_endpoint'])
    # All3 chosen crossing diagonals cannot be a triangulation.
    crossing={(0,2),(1,3),(2,4)};assert any(a<c<b<d or c<a<d<b for (a,b),(c,d) in combinations(sorted(crossing),2))
    damaged=set(first);damaged.pop();assert damaged!=second
    out=dict(status='PASS_TWO_EXACT_ENUMERATION_ROUTES_ALL14_ROOTED_HEXAGONS_AND8_TERMINAL_PATHS',cases=rows,total_rooted_triangulations=14,
      path_endpoint_cases=8,path_endpoint_paid=6,path_endpoint_unpaid=2,total_paid=10,total_unpaid=4,
      analytic_consequence='After universalA/B/C/DandC1payments, a minimal original counter n>=12 has no closed terminal FOUR-face weak-dual path except a fan whose apex is one of the two external roots. Such purefan caps are NOT thereby paid. Internal root-dual-degree2zigzag cases remain outside this conclusion.',
      unit='Rooted hexagon triangulations on fixed cyclic order and rootedge05; exact edgeidentity under whole coherent reflection, NOT unrooted graph isomorphism. Different physicalC/D kept distinct despite equal support algebra.',
      damaged_rejected=dict(crossing_diagonals=True,missing_member=True),
      limit='Finite exhaustive classification proves only its declared four-face pattern coverage; global residual extraction/whole-region compensation remainsOPEN. UseC/Dpayment only AFTERfull exact singular certificate reader passes.',original_status='GLOBAL_OPEN')
    (HERE/'four-face-classification.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:out[k] for k in ('status','total_rooted_triangulations','path_endpoint_cases','path_endpoint_paid','total_paid','total_unpaid','original_status')}))
if __name__=='__main__':main()
