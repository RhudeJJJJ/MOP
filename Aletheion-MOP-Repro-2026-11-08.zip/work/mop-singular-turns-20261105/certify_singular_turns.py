from pathlib import Path
from fractions import Fraction as F
import hashlib,json
import singular_metric_interval as m
HERE=Path(__file__).resolve().parent
def main():
    L,U=m.h.machin_pi();actuals=[];allpolys=[]
    for typ in ('C','D'):
        cap,B,T=m.actual(typ);data=[m.polys(B,T,s,'adjugate') for s in (F(0),F(1,2))]
        assert all(d==m.polys(B,T,s,'moments') for s,d in zip((F(0),F(1,2)),data))
        cp=m.rat.characteristic(B);assert cp==m.rat.mul([0,1],m.rat.mul([1,1],[-4,-1,1]))
        actuals.append(dict(cap=cap,private_characteristic=[str(x) for x in cp],support_parameters=['0','1/2']))
        allpolys.append(data)
    assert allpolys[0]==allpolys[1] # Compare EVERYcoefficient, both metrics/domains.
    components=[]
    for s,data in zip((F(0),F(1,2)),allpolys[0]):
        area=m.integral(data);components.append(dict(s=str(s),polynomials=m.serialize(data),integral=area))
        print(json.dumps(dict(completed_support=str(s),cells=len(area['leaves']),upper=str(m.h.up(F(area['upper']))))),flush=True)
    mean=sum(F(c['integral']['upper']) for c in components)/2
    low_energy=4*m.EPS*m.EPS;energy=F(6561552,1000000);gain=energy+3-low_energy-2*mean/L
    assert gain>F(83,10) and mean+2*U*m.EPS*m.EPS<F(39,20)
    out=dict(format='singular-turn-shared-support-exact-v1',epsilon=str(m.EPS),pi_lower=str(L),pi_upper=str(U),physical_cases=actuals,
      shared_support_components=components,coefficientwise_invariant_identity='ALLsix polynomials of BOTHcompact/tail regions agree exactly for C/Dat BOTHs0and1/2; actual graphs and rootroles remain distinct.',
      low_interval=dict(added_private_vertices=4,root_phase_upper_multiple_pi=4,energy_penalty=str(low_energy),contract='Principal interlacing gives|theta_new-theta_old|<2pi;|theta_B|<2pi, so rootphase<4pi on0..epsilon. No privatezero mode dropped.'),
      support_integral_mean_upper=str(mean),whole_root_integral_upper=str(mean+2*U*m.EPS*m.EPS),private_F_lower=str(energy),contact_mass='3',gain_lower=str(m.h.down(gain)),target='83/10',
      scope='Two distinct physical unitMOPgrafts, same exact scalar support family. ALLpositive-tcompact cells, normalized entiretail and analytic low-t interval obligatory. OriginalGLOBALOPEN.')
    p=HERE/'singular-turn-certificates.json';p.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(status='PREPARED_EXACT_SHARED_SINGULAR_TURN_CERTIFICATE',gain_lower=str(m.h.down(gain)),cells=sum(len(c['integral']['leaves']) for c in components),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())))
if __name__=='__main__':main()
