# Singular diamond turns pay universally; only external-apex fans survive terminal four-face paths

5 November2026. Original fixed target: EVERY finite simple UNIT maximal
outerplanar G,n>=8,F=splus>=2n, equivalently D>=6. GLOBAL OPEN / goal ACTIVE.
This note closes two further all-parent four-private operations and an
exhaustive LOCAL structural classification. No global extraction/whole-region
coverage, original counterexample, exhaustive priority or external formal
audit is claimed.

## 1. Two distinct actual operations and their all-parent statements

Ordered external roots are0,3. Keep03 exactly once. Base serial cap has
edges01,02,03,12,23. Add two more vertices4,5:

 C: add14,15,25,45; outer arc0,1,4,5,2,3.
 D: add15,24,25,45; outer arc0,1,5,4,2,3.

The private set is {1,2,4,5}, with NOoutside contacts. Each complete cap
is an actual triangulated hexagon. C attaches a second C0on12with serial
apex1; D attaches it on12with serial apex2. Whole coherent reflection
and its actual old parent are allowed. Both add4vertices and8unit edges.

THEOREM. At EVERY ordered actual boundary of EVERY old finite simple
UNIT MOP H,order>=3, each SAME actual graft satisfies

                     F(new)-F(H)>83/10=8.3.             (1)

There are no old order/degree/norm/spectrum bounds. A closed occurrence
of either operation is impossible in a minimal original counter n>=12,
as deleting its4private vertices leaves a paid old MOP n>=8. The inherited
n>=72minimal-counter domain is covered; no fresh audit of its finite
base dependencies is implied.

Their private adjacency matrices are diamonds with characteristic

               x(x+1)(x^2-x-4).

Every private eigenvalue is retained: zero,minus1 and(1+-sqrt17)/2.
There is exactly one positive eigenvalue, and
F(B)=(9+sqrt17)/2>6561552/1000000>164/25.
The first strict comparison is checked by squaring its positive rational
square-root endpoint. Contact mass TrTT^t=3 in both cases.

The zero modes genuinely contact the roots. In private order1,2,4,5,
kernel vectors are z_C=(0,1,-1,0)and z_D=(1,0,-1,0), each norm-square2.
Their actual root images are Tz_C=(1,1),Tz_D=(1,0). Deleting these modes
would change the actual response. The singularity is not a numerical
conditioning artifact or permission to omit a coordinate.

## 2. Reuse the proved same-parent nested private-metric theorem

Let Fcap=T(tI+iB)^(-1)T^t=R+iS. Both the complete actual cap and the actual
old parent satisfy201Wplus2 at every t>0. Thus P(t)=2R/t+S>=0. As proved
in serial-turn-payments-proof.md, set J=[[0,1],[1,0]], K=2I+J,
K_u=K+uP(t),u0..1. With the SAME old parent throughout the homotopy,

 delta_root(t)=ImTrLogZ1-ImTrLogZ0
       <=.5[E_K0(t)+E_K(1/2)(t)],                     (2)

where E_M is the exact support of the enlarged complex matrix ball,

 E_M=ImTr(M^-1Fcap)/t-ReTr(M^-1Fcap)/2
                +sqrt(t^2+4)/(2t)||M^-1/2FcapM^-1/2||_*.

Nested balls make supports nonincreasing in u, so this FINITE LEFT sum
upperbounds the whole homotopy integral. These are not samples of the
actual phase derivative. Both private signs AND the coupled zero mode
remain in Fcap. Strict accretivity fixes the continuous trace-log branch
anchored at infinity. No principal product-argument reset or weighted
original-energy premise occurs.

For t>0 the theorem is unchanged by singular B. But E_K0 has a1/t^2
contribution near0 from its coupled zero mode, so tE_K0 is not integrable
there. Applying(2) down to0 would not prove(1). A finite numerical cutoff
cannot remove this obligation.

## 3. Pay the ENTIRE low interval by principal interlacing

Fix epsilon=1/100. Let theta_A(t)=sum arctan(lambda_j(A)/t)using the
continuous unwrapped eigenvalue-sum phase. Since the actual old matrix
is a principal submatrix of the new one with4added vertices, interlacing
gives |theta_new-theta_old|<2pi for every t>0. Independently
|theta_B|<2pi, counting all4private eigenvalues including zero. Therefore

 delta_root=theta_new-theta_old-theta_B<4pi,
 integral_0^epsilon t delta_root(t)dt<=2pi epsilon^2.    (3)

No desired global energy inequality or phase SIGN is assumed. This bound
is crude but finite and independent of the old graph. The exact energy
identity with contact mass3 then gives

 Delta F>=F(B)+3-4epsilon^2-(2/pi)I,
 I=.5sum_(u=0,1/2) integral_epsilon^infinity t E_Ku(t)dt. (4)

The pi factor in(3) cancels algebraically in the energy penalty:
4epsilon^2=1/2500 exactly. Thus neither a zero mode nor the low interval
is discarded.

## 4. Exact rational representation on the positive compact domain

Use the full private p(x)=det(xI+B^2), x=t^2. Here p(0)=0 and degree4.
Adjugate and direct contact-moment routes both reconstruct ALL entries of
Q=T(xI+B^2)^(-1)T^t=Qn/p and M=TB(xI+B^2)^(-1)T^t=Mn/p.
The private zero-pole residue is independently checked:

          Qn(0)/p'(0)=Tzz^tT^t/(z^tz).

At a fixed u the metric is K_u=K+u(2Q-M). Put D=pK+u(2Qn-Mn),d=detD.
The five invariants q,m,v1,v2,w used by the previous support formula have
numerators Tr(adjD Qn),Tr(adjD Mn),detQn,detMn,cross(Qn,Mn)over d.
The last three numerators are multiplied by d for the shared squared-
denominator representation. Exact common polynomial factors are canceled
ONLY after exact divisibility and cross-multiplication identities. This
changes a rational representation, not the physical matrix or zero mode.
In particular the u0compact denominator retains its zero constant term.

The compact domain is STRICTLY[epsilon,4], never[0,4]. All denominator
coefficients are nonnegative and the enclosure must have a strictly
positive lower endpoint before division. The usual support integrand
formula therefore has a valid directed-rational evaluation on every cell.

For the ENTIRE tail t>=4, set z=1/t,y=z^2. The hatted response uses
(I+yB^2)^(-1), which is nonsingular even at y0. Its metric is

               Khat_u=K+uy(2Qhat-Mhat).

The previous exact rationalization V(t)=yW(y) gives
integral_4^infinity Vdt=integral_0^(1/4)W(z^2)dz. Full degree4reversal
retains the actual zero coefficients before any polynomial cancellation.
The low compact cutoff does not truncate the infinite tail. Generalized
eigenvalues of Mhat relative to Qhat remain in[-4,4], independent of the
SPD metric, giving the already proved radical/denominator sign bounds.

## 5. Equal scalar support algebra, DIFFERENT physical operations

The exact SIX coefficient arrays for BOTHcompact and tail regions agree
for C and D at BOTHu0and1/2. The reader rebuilds them from BOTH actual
private matrices/contact maps and checks EVERY coefficient. Consequently
their enlarged support functions and the two integrals in(4) agree.
The two support integrals are certified once and reused with this exact
identity. No scalar-invariant equality is promoted to graph identity,
actual increment equality or action permission. Their unequal kernel root
images above retain a concrete physical distinction. The whole triangle-
parent Gram controls likewise use two separately reconstructed graphs.

Thus10139cells means10139distinct rational integral cells for TWO support
functions, not20278cells or an enumeration of old parent graphs. Both
actual graph models remain mandatory. This exact reduction avoids repeated
proof arithmetic; a missing identity would require separate integrals.

## 6. Separate full reader and simple constants

singular-turn-certificates.json contains all10139directed-rational cells:
6764foru0and3375foru1/2. The stdlib reader rebuilds polynomials by the
contact-moment route, checks adjugate equality, both physical graphs,
private characteristic, nonzero kernel contacts, the exact low-interval
contract and complete disjoint coverage[epsilon,4]and[0,1/4]. It recomputes
EVERYcell with outward72bit dyadic operations and integer radical bounds.
The normalization is checked against exact physical matrix inverses.

The resulting support integral upper plus2*pi_upper*epsilon^2 is<39/20.
With F(B)>164/25, TrTT^t=3 and pi>157/50 from the exact Machin bounds,
equation(4), or equivalently the full root-integral bound, gives

 Delta F>239/25-195/157=32648/3925
                         =83/10+141/7850>83/10.        (5)

The stronger retained rational private energy and actual interval area
endpoints give the reader's separate lower score;(5)already proves(1).
No floating value accepts it. Separate actual whole triangle-parent integer
PSD Gram controls retain all original vertices and ENTIRE squared norms.
They are finite controls, not the all-parent quantifier or fresh original
finite-base coverage.

The reader rejects missing low-interval payment, private-zero deletion,
fake positive raw p(0), stale variable metric/tail, missing actual contacts,
missing cells and broken C/Dcoefficient identity. Shared scalar/characteristic/
topology utilities are declared; no external formal-assistant audit or
exhaustive first-payment comparison with all older cuts is claimed.

## 7. Exhaustive rooted four-face classification and its exact consequence

A rooted triangulated hexagon has14possible triangulations of its fixed
outer cyclic order. One route enumerates by the unique root triangle and
its two polygon sides. A second route checks ALL84choices of3diagonals
among9 and keeps exactly the noncrossing sets. Both cover the entire
declared finite population by construction and agree on all14edge sets.
This is not an unrooted-isomorphism count.

Among these14, exactly8have a four-node PATH as weak dual with the root
face at a path END. Exact edge matching to the literal A,B,C,Dand prior
C1operations, allowing only WHOLEcoherent reflection, pays6of these8.
The other2are pure fans whose apex is one of the two external roots.
Across all14the same catalogue pays10and leaves4: those2fans and2cases
with an internal path root. No payment is inferred for the latter2.

It follows that in a minimal original counter n>=12, ANY actual CLOSED
four-face terminal path with root face at an endpoint must be a fan with
an EXTERNAL apex. This is a necessary local structure, not global graph
coverage. A terminal unary run shorter than4faces is not covered; a long
fan run is not paid merely by knowing its shape. A nonterminal window can
have outside contacts and cannot be removed under this theorem.

The original all-MOP2n goal remains OPEN. The old C0only infinite family
continues to refute fixed cap-only E1while its WHOLE graphs are paidW.
Universal C0gain4remainsFALSE. Global extraction with a nonnegative exact
sequence ledger OR whole-region compensation on the ACTUALremaining domain,
after ALLwholepaid exclusions and other valid cuts, remains the obligation.
The new local classification justifies attacking external-apex fan regions
and short branching ends; it does not establish that every graph has a
paying finite cap or that all terminal runs have length>=4.
