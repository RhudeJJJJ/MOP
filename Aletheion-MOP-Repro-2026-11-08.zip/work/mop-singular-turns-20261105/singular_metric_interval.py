"""Singular PRIVATE graphs: strict compact cutoff, complete original matrices."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,heapq,json,sys,time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'mop-serial-turns-20261105'))
import turn_metric_interval as previous
h=previous.h;rat=h.rat;mm=h.mm;tr=h.tr
EPS=F(1,100)
def actual(typ):
    assert typ in ('C','D');base={(0,1),(0,2),(0,3),(1,2),(2,3)}
    e=base|({(1,4),(1,5),(2,5),(4,5)} if typ=='C' else {(1,5),(2,4),(2,5),(4,5)})
    boundary=[0,1,4,5,2,3] if typ=='C' else [0,1,5,4,2,3]
    rat.prior.outer_graph(6,e,boundary)
    A=[[F(int(tuple(sorted((i,j))) in e)) if i!=j else F(0) for j in range(6)] for i in range(6)];private=[1,2,4,5]
    B=[[A[i][j] for j in private] for i in private];T=[[A[i][j] for j in private] for i in (0,3)]
    return dict(label=typ,n=6,edges=sorted(e),boundary=boundary,private=private,roots=[0,3]),B,T
def raw(B,T,route):
    n=len(B);B2=mm(B,B);cp=rat.characteristic(B2);p=[v*(-1)**(n+i) for i,v in enumerate(cp)]
    assert len(B)==4 and p[0]==0 and all(v>=0 for v in p) and p[-1]==1
    Q=[[[F(0)]*n for _ in range(2)] for _ in range(2)];M=[[[F(0)]*n for _ in range(2)] for _ in range(2)];cc=list(reversed(p))
    if route=='adjugate':
        C=[[F(int(i==j)) for j in range(n)] for i in range(n)]
        for j in range(n):
            q=mm(mm(T,C),tr(T));m=mm(mm(mm(T,B),C),tr(T))
            for a in range(2):
                for b in range(2):Q[a][b][n-1-j]=q[a][b];M[a][b][n-1-j]=m[a][b]
            AC=mm(B2,C);C=[[cc[j+1]*int(a==b)-AC[a][b] for b in range(n)] for a in range(n)]
        assert all(not x for row in C for x in row)
    else:
        assert route=='moments';v=tr(T);mom=[];bmom=[]
        for j in range(n):mom.append(mm(T,v));bmom.append(mm(mm(T,B),v));v=mm([[-z for z in row] for row in B2],v)
        for j in range(n):
            for a in range(2):
                for b in range(2):Q[a][b][n-1-j]=sum(cc[k]*mom[j-k][a][b] for k in range(j+1));M[a][b][n-1-j]=sum(cc[k]*bmom[j-k][a][b] for k in range(j+1))
    return p,Q,M
def polys(B,T,s,route):
    p,Q,M=raw(B,T,route);n=len(B);pa=h.pa;ps=h.ps;mul=rat.mul
    def pack(p,Q,M,tail):
        D=[[pa(ps(p,2 if i==j else 1),ps(mul([0,1] if tail else [1],pa(ps(Q[i][j],2),M[i][j],-1)),s)) for j in range(2)] for i in range(2)]
        d=pa(mul(D[0][0],D[1][1]),mul(D[0][1],D[1][0]),-1)
        assert all(v>=0 for v in d) and any(v>0 for v in d)
        assert d[0]>0 if tail else d[0]==0
        def trace(X):return pa(pa(mul(D[1][1],X[0][0]),mul(D[0][0],X[1][1])),mul(D[0][1],X[0][1]),-2)
        def det(X):return pa(mul(X[0][0],X[1][1]),mul(X[0][1],X[0][1]),-1)
        w=pa(pa(mul(Q[0][0],M[1][1]),mul(Q[1][1],M[0][0])),mul(Q[0][1],M[0][1]),-2)
        raw=[d,trace(Q),trace(M),mul(d,det(Q)),mul(d,det(M)),mul(d,w)]
        # Cancel only an EXACT common polynomial factor. This is rational
        # identity on x>0 (compact) / y>=0 (tail), not zero-mode deletion.
        reduced=[]
        for j,z in enumerate(raw):
            factor=p if j<3 else mul(p,p)
            quotient,remainder=rat.divrem(z,factor);assert remainder==[0] and mul(quotient,rat.trim(factor[:]))==rat.trim(z[:])
            reduced.append(quotient)
        assert all(v>=0 for v in reduced[0])
        return reduced
    return dict(compact=pack(p,Q,M,False),tail=pack(h.reverse(p,n+1),[[h.reverse(z,n) for z in row] for row in Q],[[h.reverse(z,n) for z in row] for row in M],True))
def integral(data,tol=F(1,25),limit=50000):
    heap=[];lo=hi=F(0);counter=0
    def put(region,a,b,depth=0):
        nonlocal lo,hi,counter
        assert a>=EPS if region=='compact' else a>=0
        try:v=h.enclosure(data,region,a,b)
        except ArithmeticError:
            assert depth<30;mid=(a+b)/2;put(region,a,mid,depth+1);put(region,mid,b,depth+1);return
        low=(b-a)*v[0];high=(b-a)*v[1];lo+=low;hi+=high;counter+=1
        heapq.heappush(heap,(-(high-low),counter,region,a,b,v))
    put('compact',EPS,F(4));put('tail',F(0),F(1,4));start=time.monotonic();splits=0
    while hi-lo>tol:
        assert len(heap)<limit;_,_,region,a,b,v=heapq.heappop(heap);lo-=(b-a)*v[0];hi-=(b-a)*v[1];mid=(a+b)/2;put(region,a,mid);put(region,mid,b);splits+=1
        if splits%2000==0:print(json.dumps(dict(progress='exact_singular_cutoff_support',leaves=len(heap),width=str(h.up(hi-lo)),elapsed=time.monotonic()-start)),flush=True)
    cells=[dict(region=r,a=str(a),b=str(b),lower=str(v[0]),upper=str(v[1])) for _,_,r,a,b,v in heap]
    cells.sort(key=lambda c:(c['region'],F(c['a'])))
    return dict(lower=str(lo),upper=str(hi),width=str(hi-lo),leaves=cells)
def serialize(data):return {r:[[str(v) for v in p] for p in z] for r,z in data.items()}
