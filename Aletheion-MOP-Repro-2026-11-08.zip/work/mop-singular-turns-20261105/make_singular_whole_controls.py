from pathlib import Path
import json
import numpy as np
import singular_metric_interval as m
HERE=Path(__file__).resolve().parent
def main():
    rows=[]
    for typ in ('C','D'):
        cap,B,T=m.actual(typ);edges={tuple(e) for e in cap['edges']}|{(0,6),(3,6)};A=np.zeros((7,7))
        for a,b in edges:A[a,b]=A[b,a]=1
        b,V=np.linalg.eigh(A);W=np.rint((V*np.sqrt(np.maximum(b,0)))@V.T*1000000).astype(int)
        rows.append(dict(label=typ,n=7,edges=sorted(edges),boundary=cap['boundary']+[6],old_triangle=[0,3,6],factor=W.tolist(),denominator=1000000))
    (HERE/'singular-whole-controls.json').write_text(json.dumps(dict(cases=rows,scope='Numeric proposes integer PSD factors; only exact full norm scoring accepts whole controls.'),indent=2)+'\n')
    print(json.dumps(dict(status='PROPOSED_TWO_DISTINCT_SINGULAR_WHOLE_GRAMS')))
if __name__=='__main__':main()
