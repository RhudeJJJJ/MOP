from pathlib import Path
from fractions import Fraction as F
import copy,hashlib,json,time
import singular_metric_interval as m
import read_serial_turns as oldread
import classify_four_face_caps as classification
HERE=Path(__file__).resolve().parent
mm=m.mm;tr=m.tr;rat=m.rat
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def actual(cap):
    typ=cap['label'];assert typ in ('C','D')
    boundary=[0,1,4,5,2,3] if typ=='C' else [0,1,5,4,2,3]
    diagonals=[(0,2),(1,2),(1,5)] if typ=='C' else [(0,2),(1,2),(2,5)]
    edges={tuple(sorted((boundary[j],boundary[(j+1)%6]))) for j in range(6)}|set(diagonals)
    assert cap['n']==6 and cap['roots']==[0,3] and cap['private']==[1,2,4,5] and cap['boundary']==boundary and edges=={tuple(e) for e in cap['edges']}
    rat.prior.outer_graph(6,edges,boundary)
    A=[[F(int(tuple(sorted((i,j))) in edges)) if i!=j else F(0) for j in range(6)] for i in range(6)]
    B=[[A[i][j] for j in cap['private']] for i in cap['private']];T=[[A[i][j] for j in cap['private']] for i in cap['roots']]
    assert sum(v*v for row in T for v in row)==3 and max(sum(abs(v) for v in row) for row in B)<=4
    return B,T
def partition(component,data,recompute):
    lower=upper=F(0);count=0
    for region,start,end in [('compact',m.EPS,F(4)),('tail',F(0),F(1,4))]:
        cells=sorted((z for z in component['integral']['leaves'] if z['region']==region),key=lambda z:F(z['a']));cursor=start
        for z in cells:
            a,b=F(z['a']),F(z['b']);assert a==cursor and a<b<=end;cursor=b
            stored=(F(z['lower']),F(z['upper']));assert 0<=stored[0]<=stored[1]
            if recompute:assert m.h.enclosure(data,region,a,b)==stored
            lower+=(b-a)*stored[0];upper+=(b-a)*stored[1];count+=1
        assert cursor==end
    assert count==len(component['integral']['leaves']) and lower==F(component['integral']['lower']) and upper==F(component['integral']['upper'])
    assert upper-lower==F(component['integral']['width'])<=F(1,25)
    return lower,upper,count
def verify(d,recompute=True):
    assert d['format']=='singular-turn-shared-support-exact-v1' and F(d['epsilon'])==m.EPS==F(1,100)
    low=d['low_interval'];assert low['added_private_vertices']==4 and low['root_phase_upper_multiple_pi']==4 and F(low['energy_penalty'])==4*m.EPS*m.EPS==F(1,2500)
    L,U=m.h.machin_pi();assert F(d['pi_lower'])==L and F(d['pi_upper'])==U
    assert F(d['private_F_lower'])==F(6561552,1000000) and F(d['contact_mass'])==3
    rootlo=2*F(d['private_F_lower'])-9;assert rootlo>0 and rootlo*rootlo<17
    ss=[F(0),F(1,2)];assert [F(c['s']) for c in d['shared_support_components']]==ss
    assert [c['cap']['label'] for c in d['physical_cases']]==['C','D']
    allpolys=[];physical=[]
    for physical_case in d['physical_cases']:
        cap=physical_case['cap'];B,T=actual(cap);cp=rat.characteristic(B);expected=rat.mul([0,1],rat.mul([1,1],[-4,-1,1]))
        assert cp==expected==[F(v) for v in physical_case['private_characteristic']] and physical_case['support_parameters']==['0','1/2']
        z=[F(0),F(1),F(-1),F(0)] if cap['label']=='C' else [F(1),F(0),F(-1),F(0)]
        assert mm(B,[[v] for v in z])==[[0]]*4 and sum(v*v for v in z)==2
        Tz=mm(T,[[v] for v in z]);assert Tz==([[1],[1]] if cap['label']=='C' else [[1],[0]])
        p,Qn,Mn=m.raw(B,T,'moments');assert p[0]==0 and p[1]>0
        residue=[[Qn[a][b][0]/p[1] for b in range(2)] for a in range(2)]
        assert residue==[[Tz[a][0]*Tz[b][0]/2 for b in range(2)] for a in range(2)]
        assert any(v for row in residue for v in row)
        polys=[];matrices=[];floors=[]
        for s in ss:
            data=m.polys(B,T,s,'moments');assert data==m.polys(B,T,s,'adjugate');polys.append(data)
            if recompute:
                matrices+=oldread.matrix_controls(B,T,s,data);floors+=oldread.homotopy_controls(B,T,s,s+F(1,2))
                # A point at the actual cutoff must retain the kernel pole.
                q=oldread.previous.exact_invariants(data['compact'],m.EPS*m.EPS);assert q[0]>0 and q[2]>0
        allpolys.append(polys);physical.append(dict(label=cap['label'],private_characteristic=[str(v) for v in cp],inertia=[1,2,1],kernel_root_image=[str(v[0]) for v in Tz],
            zero_pole_residue=[[str(v) for v in row] for row in residue],matrix_checks=matrices,homotopy_checks=floors))
    assert allpolys[0]==allpolys[1]
    areas=[];count=0
    for component,data in zip(d['shared_support_components'],allpolys[0]):
        assert data=={r:[[F(v) for v in p] for p in z] for r,z in component['polynomials'].items()}
        lo,hi,n=partition(component,data,recompute);areas.append(hi);count+=n
    mean=sum(areas)/2;assert mean==F(d['support_integral_mean_upper'])
    full_upper=mean+2*U*m.EPS*m.EPS;assert full_upper==F(d['whole_root_integral_upper'])<F(39,20)
    gain=F(d['private_F_lower'])+3-4*m.EPS*m.EPS-2*mean/L
    assert gain>=F(d['gain_lower'])>F(d['target'])==F(83,10)
    assert F(239,25)-F(195,157)==F(83,10)+F(141,7850)>F(83,10)
    return dict(physical_cases=physical,distinct_support_integrals=2,distinct_cells=count,shared_support_identity=True,gain_lower=str(m.h.down(gain)),gain_display_lower=str(rat.lower(gain)),
      target='83/10',support_integral_mean_upper=str(mean),full_root_integral_upper=str(full_upper),low_energy_penalty='1/2500')
def main():
    path=HERE/'singular-turn-certificates.json';d=json.loads(path.read_text());start=time.monotonic();result=verify(d)
    print(json.dumps(dict(accepted='C_and_D',gain=result['gain_display_lower'],cells=result['distinct_cells'],elapsed=time.monotonic()-start)),flush=True)
    whole=[]
    for w in json.loads((HERE/'singular-whole-controls.json').read_text())['cases']:
        cap=next(c['cap'] for c in d['physical_cases'] if c['cap']['label']==w['label']);edges={tuple(e) for e in cap['edges']}|{(0,6),(3,6)}
        assert edges=={tuple(e) for e in w['edges']} and w['old_triangle']==[0,3,6] and w['n']==7
        rat.prior.outer_graph(7,edges,w['boundary']);W=w['factor'];D=w['denominator'];assert len(W)==7 and all(type(v) is int for row in W for v in row)
        Z=mm(W,tr(W));G=mm(tr(W),W);score=F(4*sum(Z[a][b] for a,b in edges),D**2)-F(sum(v*v for row in G for v in row),D**4)
        assert score-4>F(83,10);whole.append(dict(label=w['label'],whole_F_Gram_lower=str(score),gain_from_exact_triangle_lower=str(score-4)))
    bads={}
    c=copy.deepcopy(d);c.pop('low_interval');bads['missing_low_interval']=c
    c=copy.deepcopy(d);c['low_interval']['energy_penalty']='0';bads['unpaid_low_interval']=c
    c=copy.deepcopy(d);c['physical_cases'][0]['cap']['private'].pop();bads['private_zero_mode_deleted']=c
    c=copy.deepcopy(d);c['physical_cases'][0]['private_characteristic'][0]='1';bads['fake_nonsingular_private_constant']=c
    c=copy.deepcopy(d);c['shared_support_components'][0]['integral']['leaves'].pop();bads['missing_interval']=c
    c=copy.deepcopy(d);c['shared_support_components'][1]['polynomials']=c['shared_support_components'][0]['polynomials'];bads['stale_constant_metric']=c
    c=copy.deepcopy(d);c['shared_support_components'][1]['polynomials']['tail'][1][0]=str(F(c['shared_support_components'][1]['polynomials']['tail'][1][0])+1);bads['wrong_tail_normalization']=c
    c=copy.deepcopy(d);c['physical_cases'][0]['cap']['edges'].remove([1,5]);bads['missing_actual_contact']=c
    c=copy.deepcopy(d);c['physical_cases'][1]['cap']['edges'].remove([2,4]);bads['broken_second_physical_identity']=c
    def rejected(z):
        try:verify(z,False)
        except (AssertionError,KeyError):return True
        return False
    damages={name:rejected(c) for name,c in bads.items()};assert all(damages.values())
    first=set(classification.triangulations(tuple(range(6))));second=classification.independent_diagonal_route();assert first==second and len(first)==14
    expected=[classification.describe(e,classification.catalogue()) for e in sorted(first,key=lambda e:sorted(e))]
    cls=json.loads((HERE/'four-face-classification.json').read_text());assert cls['cases']==expected and cls['path_endpoint_paid']==6 and cls['path_endpoint_unpaid']==2 and cls['total_paid']==10
    result.update(status='PASS_EXACT_UNIVERSAL_SINGULAR_C_D_GAIN83_AND_ALL_TERMINAL_FOUR_FACE_PATH_CLASSIFICATION',whole_controls=whole,damaged_rejected=damages,
      certificate_sha256=sha(path),proof_sha256=sha(HERE/'singular-turn-proof.md'),classification_sha256=sha(HERE/'four-face-classification.json'),whole_fixture_sha256=sha(HERE/'singular-whole-controls.json'),
      local_structural_effect='Minimal original counter n>=12: every CLOSEDfour-face terminal weak-dual PATH rooted at endpoint is a fan with EXTERNALapex. Exactly6of8paid; other2are not assertedpaid. Short unary runs and whole global residual remainOPEN.',
      identity_rule='Two DIFFERENTphysical capoperations, one coefficientwiseidentical scalar support family with2integrals/10139distinctcells. Root images and whole controls remainseparate; no actualenergy/graphidentity inferred.',
      source_scope='Shared exact scalar/characteristic/topology helpers; separate adjugate/contactmoment polynomial routes, direct matrix inverse/floors and exhaustive roottriangle/84diagonal routes. No external formal audit or firstpayment/priority comparison.',
      original_status='GLOBAL_OPEN',global_extraction='OPEN',original_counterexample=False)
    assert result['distinct_cells']==10139
    (HERE/'singular-turn-reader-check.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:result[k] for k in ('status','gain_display_lower','distinct_cells','damaged_rejected','certificate_sha256','original_status')}))
if __name__=='__main__':main()
