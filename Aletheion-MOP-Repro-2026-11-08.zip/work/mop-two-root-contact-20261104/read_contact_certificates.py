"""Separate stdlib/Fraction reader of the contact proof's finite calibrations.

The all-order proof is in the accompanying note; finite tests do not replace it.
"""
import copy
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent

def transpose(a):
    return [list(x) for x in zip(*a)]

def mul(a, b):
    return [[sum(x*y for x,y in zip(row,col)) for col in zip(*b)] for row in a]

def add(a,b,scale=1):
    return [[x+scale*y for x,y in zip(u,v)] for u,v in zip(a,b)]

def inverse(a):
    n = len(a)
    z = [[F(x) for x in row]+[F(i==j) for j in range(n)]
         for i,row in enumerate(a)]
    for i in range(n):
        pivot = next(j for j in range(i,n) if z[j][i])
        z[i],z[pivot] = z[pivot],z[i]
        divisor = z[i][i]
        z[i] = [x/divisor for x in z[i]]
        for j in range(n):
            if j!=i and z[j][i]:
                v=z[j][i]
                z[j]=[x-v*y for x,y in zip(z[j],z[i])]
    return [row[n:] for row in z]

def psd(a):
    assert len(a) in (1,2)
    assert a==transpose(a)
    if len(a)==1:
        return a[0][0]>=0
    return a[0][0]>=0 and a[1][1]>=0 and a[0][0]*a[1][1]>=a[0][1]**2

def triangulations(vertices):
    if len(vertices)==2:
        yield {tuple(sorted(vertices))}
        return
    a,b=vertices[0],vertices[-1]
    for i in range(1,len(vertices)-1):
        v=vertices[i]
        for left in triangulations(vertices[:i+1]):
            for right in triangulations(vertices[i:]):
                yield left|right|{tuple(sorted((a,b))),tuple(sorted((a,v))),
                                  tuple(sorted((v,b)))}

def boundary_calibration():
    graphs=roots=inequalities=0
    least=None
    for n in range(3,8):
        for edges in triangulations(tuple(range(n))):
            graphs+=1
            a=[[F(tuple(sorted((i,j))) in edges) if i!=j else F(0)
                for j in range(n)] for i in range(n)]
            a2=mul(a,a)
            for t in (F(1,3),F(1),F(7,2)):
                k=inverse([[a2[i][j]+(t*t if i==j else 0)
                            for j in range(n)] for i in range(n)])
                ak=mul(a,k)
                for v in range(n):
                    inds=(v,(v+1)%n)
                    if t==F(1,3):
                        roots+=1
                    r=[[t*k[i][j] for j in inds] for i in inds]
                    s=[[-ak[i][j] for j in inds] for i in inds]
                    r2=mul(r,r)
                    for sign in (-1,1):
                        m=add(add(r,r),r2,-t)
                        m=add(m,s,sign*t)
                        assert psd(m),(n,inds,t,sign,m)
                        inequalities+=1
                        det=m[0][0]*m[1][1]-m[0][1]**2
                        least=det if least is None else min(det,least)
                    for l in ([[F(1)],[F(2)]],
                              [[F(1),F(2)],[F(3),F(-1)]]):
                        lt=transpose(l)
                        g=mul(lt,l)
                        rr=mul(mul(lt,r),l)
                        ss=mul(mul(lt,s),l)
                        square=mul(mul(rr,inverse(g)),rr)
                        gap=add(mul(mul(lt,r2),l),square,-1)
                        assert psd(gap)
                        for sign in (-1,1):
                            assert psd(add(add(add(rr,rr),square,-t),ss,sign*t))
                            inequalities+=1
    assert (graphs,roots)==(64,414)
    return dict(graphs=graphs,ordered_boundary_roots=roots,
                rational_frequencies=3,psd_inequalities=inequalities,
                least_base_determinant=str(least))

def outer_graph(n, edges, boundary):
    assert len(boundary)==n and set(boundary)==set(range(n))
    assert len(edges)==2*n-3
    assert all(type(u) is int and type(v) is int and 0<=u<v<n for u,v in edges)
    assert len(edges)==len(set(edges))
    es=set(edges)
    for i,v in enumerate(boundary):
        assert tuple(sorted((v,boundary[(i+1)%n]))) in es
    loc={v:i for i,v in enumerate(boundary)}
    intervals=sorted((tuple(sorted((loc[u],loc[v]))) for u,v in es),
                     key=lambda e:(e[0],-e[1]))
    stack=[]
    for left,right in intervals:
        while stack and stack[-1]<=left:
            stack.pop()
        assert not stack or right<=stack[-1],(left,right,stack[-1])
        stack.append(right)
    return es

def one_carrier(c):
    n,p,r=c['n'],c['parent_n'],c['r']
    a,b=c['roots']
    x,y=c['x'],c['y']
    assert len(x)==2*r and len(y)==r and n==p+3*r
    assert set(x+y)==set(range(p,n))
    es=outer_graph(n,[tuple(e) for e in c['edges']],c['boundary'])
    parent={e for e in es if e[1]<p}
    outer_graph(p,list(parent),list(range(p)))
    adj=[set() for _ in range(n)]
    for u,v in es:
        adj[u].add(v);adj[v].add(u)
    priv=set(x+y)
    assert all(adj[v]-priv<={a,b} for v in priv)
    assert len(es)-len(parent)==6*r
    groups=[{x[2*j],x[2*j+1],y[j]} for j in range(r)]
    owner={v:j for j,z in enumerate(groups) for v in z}
    # This reconstructs the entire private graph; no omitted private edges.
    private_edges={e for e in es if e[0] in priv and e[1] in priv}
    expected=set()
    for group in groups:
        expected|={tuple(sorted((v,w))) for v in group for w in group if v<w}
    expected|={tuple(sorted((x[2*j+1],x[2*j+2]))) for j in range(r-1)}
    assert private_edges==expected
    assert max(len(adj[v]&priv) for v in priv)<=3
    # K=Z^T B Z, with literal triangle indicator columns.
    diag=[0]*r;off={}
    for u,v in private_edges:
        i,j=owner[u],owner[v]
        if i==j:diag[i]+=2
        else:off[tuple(sorted((i,j)))]=off.get(tuple(sorted((i,j))),0)+1
    assert diag==[6]*r
    assert off=={(j,j+1):1 for j in range(r-1)}
    assert all(6>int(i>0)+int(i+1<r) for i in range(r))
    witness=F(sum(z*z for z in diag)+2*sum(z*z for z in off.values()),9)
    assert witness==4*r+F(2*(r-1),9)
    contacts=[adj[a]&priv,adj[b]&priv]
    g=[[len(u&v) for v in contacts] for u in contacts]
    m=[[sum(1 for u in contacts[i] for v in adj[u]&contacts[j])
        for j in range(2)] for i in range(2)]
    assert g==[[2*r,1],[1,1]]
    assert m==[[4*r-2,1],[1,0]]
    scale=F(1,2*r-1)
    assert psd(add(m,g,scale))
    assert F((m[0][0]+scale*g[0][0])*(m[1][1]+scale*g[1][1])
             -(m[0][1]+scale*g[0][1])**2)==F(2*r-2,2*r-1)
    # Reconstruct every bounded face from the actual cap's triangles.
    cap_vertices=priv|{a,b}
    cap_adj={v:adj[v]&cap_vertices for v in cap_vertices}
    faces=[]
    for u in sorted(cap_vertices):
        for v in sorted(w for w in cap_adj[u] if w>u):
            for w in sorted(z for z in cap_adj[u]&cap_adj[v] if z>v):
                faces.append(frozenset((u,v,w)))
    assert len(faces)==3*r
    incident={}
    for i,face in enumerate(faces):
        for u in face:
            for v in face:
                if u<v:incident.setdefault((u,v),[]).append(i)
    dual=[set() for _ in faces]
    for ids in incident.values():
        assert len(ids)<=2
        if len(ids)==2:
            i,j=ids;dual[i].add(j);dual[j].add(i)
    root=incident[tuple(sorted((a,b)))]
    assert len(root)==1
    root=root[0]
    order=[root];parent_face={root:None}
    for u in order:
        for v in dual[u]:
            if v==parent_face[u]:continue
            assert v not in parent_face
            parent_face[v]=u;order.append(v)
    assert len(order)==len(faces)
    kids={u:dual[u]-({parent_face[u]} if parent_face[u] is not None else set())
          for u in order}
    sizes={};full={};max_full=0;max_double_unary=0
    for u in reversed(order):
        sizes[u]=1+sum(sizes[v] for v in kids[u])
        full[u]=len(kids[u]) in (0,2) and all(full[v] for v in kids[u])
        if full[u]:max_full=max(max_full,sizes[u])
        if len(kids[u])==1 and len(kids[next(iter(kids[u]))])==1:
            max_double_unary=max(max_double_unary,sizes[u])
    assert max_full==1 and max_double_unary==3
    assert not any(len(adj[v])==4 and
                   sum(len(adj[w])==2 for w in adj[v]&priv)>=2 for v in priv)
    return dict(n=n,parent_n=p,r=r,root_order=[a,b],private_edges=len(private_edges),
                triangle_compression_lower=str(witness),root_G=g,root_M=m,
                largest_terminal_full_binary_faces=max_full,
                largest_two_unary_stem_subtree_faces=max_double_unary,
                unconditional_incremental_payment=r>=200)

def exact_threshold():
    endpoint=F(245,9)-F(105,4)-F(7,133)
    derivative=F(2,9)-(F(5,4)+F(1,399))/20
    assert endpoint==F(4403,4788)>0 and derivative>0
    # c<5/4 follows from pi>31/10 and sqrt(2)<10/7.
    assert F(10,7)**2>2 and F(8)*F(10,7)/(3*F(31,10))<F(5,4)
    return dict(endpoint=str(endpoint),all_order_derivative_floor=str(derivative),
                r_min=200,private_vertices_min=600,
                comparison_constant='8sqrt(2)/(3pi)<5/4')

def main():
    path=HERE/'contact-whole-carriers.json'
    data=json.loads(path.read_text(encoding='utf-8'))
    checked=[one_carrier(c) for c in data['cases']]
    damage=[]
    bad=copy.deepcopy(data['cases'][1]);bad['roots'].reverse()
    try:one_carrier(bad)
    except AssertionError:damage.append('swapped_asymmetric_root_roles')
    else:raise AssertionError('swapped roots wrongly accepted')
    bad=copy.deepcopy(data['cases'][1]);bad['edges'].remove([bad['roots'][0],bad['x'][0]])
    try:one_carrier(bad)
    except AssertionError:damage.append('missing_actual_root_contact')
    else:raise AssertionError('missing contact wrongly accepted')
    bad=copy.deepcopy(data['cases'][1]);bad['boundary'][0],bad['boundary'][2]=bad['boundary'][2],bad['boundary'][0]
    try:one_carrier(bad)
    except AssertionError:damage.append('damaged_outer_boundary')
    else:raise AssertionError('damaged boundary wrongly accepted')
    out=dict(status='PASS',scope='exact finite calibration of analytic all-order proof',
             carrier_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
             boundary=boundary_calibration(),threshold=exact_threshold(),
             carriers=checked,damaged_controls_rejected=damage,
             original_conjecture='OPEN',external_formal_audit=False)
    outpath=HERE/'contact-reader-check.json'
    outpath.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(out))

if __name__=='__main__':
    main()
