# Two actual serial-turn payments and monotone private-metric support

5 November 2026. Original target EVERY finite simple UNIT maximal outerplanar
G,n>=8,F=splus>=2n remains GLOBAL OPEN / goal ACTIVE. The statements below
pay two literal four-private-vertex operations for ALL old parents. They
do not close the original global conjecture or all serial-chain types.

## 1. Exact physical operations, with roots retained

External ordered roots are a=0,b=3. Keep the boundary edge03 exactly once.
Begin with the serialC0cap edges01,02,03,12,23 on0,1,2,3. Add vertices4,5.

  Type A: add05,14,15,45; outer arc0,5,4,1,2,3.
  Type B: add24,25,35,45; outer arc0,1,2,4,5,3.

The private set is {1,2,4,5}; no private vertex has any additional outside
contact. Each graph is an actual triangulated hexagon. A can be constructed
by a C0on boundary01with new serial apex1; B by a C0on boundary23with
new serial apex2. In each case an old serial apex changes. They are not
identified merely because both have4private vertices. Their root degree
pairs within the cap are(4,2)and(3,3), respectively. Coherent reflection
of the WHOLE operation and old parent is allowed.

THEOREM. For EVERY old finite simple UNIT MOP H,order>=3, at EVERY ordered
actual boundary edge, the SAME graft satisfies

  Delta F(A)>413/50=8.26;    Delta F(B)>807/100=8.07.     (1)

There is NO old degree/order/norm/spectrum bound. Thus no closed occurrence
of either operation occurs in a minimal original counter of order>=12,
since removing its4private vertices then leaves an original MOP n>=8.
The inherited n>=72 residual is covered by this new necessary restriction.
No first-payment claim relative to every older cut is made.

## 2. Preserve the full positive AND negative private response

Use the already proved full-cap homotopy of full-cap-matrix-disk-proof.md.
For t>0 write J=[[0,1],[1,0]],K=2I+J and the old actual root response F0.
The actual private B,T of either operation give

 F=T(tI+iB)^(-1)T^t=R+iS,
 Z_u=tI+iJ+F0+uF, H_u=Z_u^(-1), 0<=u<=1.

Both the actual old parent AND complete actual cap satisfy201Wplus2:
2ReF0+tImF0>=0 and2R+tS>=0. Put P(t)=2R/t+S>=0 and

                    K_u(t)=K+uP(t)>=K>0.

Strict accretivity and inverse congruence give

             2ReH_u-tImH_u>=t H_u^* K_u H_u.          (2)

For any POSITIVE DEFINITE metric M, completing the exact complex matrix
square, with c=1/t+i/2, yields a matrix ball:

 2ReH-tImH>=tH^*MH
 iff (M^1/2 H M^1/2-conj(c)I)^*
     (M^1/2 H M^1/2-conj(c)I)<=|c|^2I.

The EXACT support of that enlarged ball for ImTr(HF) is

 E_M(t)=ImTr(M^-1F)/t-ReTr(M^-1F)/2
              +sqrt(t^2+4)/(2t)||M^-1/2 F M^-1/2||_* . (3)

The trace norm is the sum of singular values, with complex adjoints.
No commutation, entrywise positivity or common pointwise maximizer is
asserted. All balls contain0, so their support is nonnegative.

## 3. Nested balls license FINITE left sums in the homotopy parameter

For v>=u, K_v>=K_u. The set defined by the inequality(2) with K_v is
a subset of the set with K_u: subtract tH^*(K_v-K_u)H>=0. Therefore the
exact supports E_{K_u}(t) are NONINCREASING in u. For ANY integer N>=1,

 ImTrLog Z1-ImTrLog Z0
 =integral_0^1 ImTr(H_uF)du
 <= (1/N)sum_(j=0)^(N-1) E_{K_(j/N)}(t).               (4)

The trace-log is the continuous accretive branch anchored at infinity,
not a reset principal determinant argument. Each actual H_u lies in its
own ball and hence in the ball at the left endpoint of its subinterval.
This proves(4) without any derivative bound or numerical integration in u.
These are upper supports, not phase derivatives sampled at left endpoints.
The SAME old physical parent F0 persists at every t,u. A weighted original
energy conjecture is not applied to the algebraic intermediate matrices.

By the equal-trace spectral-phase identity, the original actual graft has

 Delta F >= F(B)+TrTT^t-(2/pi)I_N,
 I_N=(1/N)sum_j integral_0^infinity t E_{K_(j/N)}(t)dt.  (5)

For A choose N1; for B choose N2. The second operation is certified by
the supports at u0and1/2, not by assuming its old constant-metric bound
already exceeds8. The N1numerical scout for B was7.98055<8 and did not
prove underpayment of an actual graft. The new K_u changes that bound.

## 4. Entire rational integral, with the variable metric retained

Set x=t^2,Q=T(xI+B^2)^(-1)T^t,M=TB(xI+B^2)^(-1)T^t, so F=tQ-iM.
At a fixed rational u the metric is K_u=K+u(2Q-M), a rational matrix in x.
Let q=Tr(K_u^-1Q),m=Tr(K_u^-1M),u0=detQ/detK_u,v=detM/detK_u,
w=(Q11M22+Q22M11-2Q12M12)/detK_u. The support integrand is exactly

 V(t)=-m-xq/2+.5sqrt((x+4)[x(q^2-2u0)+(m^2-2v)
                               +2sqrt((xu0-v)^2+xw^2)]). (6)

This uses arbitrary SPD K_u, not a fixed determinant3. Both private B
are invertible and T has full row rank. Thus the compact endpoint t0
is finite for these operations. Singular private responses are NOT
covered by this endpoint assertion or these finite-left-sum certificates.

For t>=4 put y=1/t^2,z=1/t and Qhat=T(I+yB^2)^(-1)T^t,
Mhat=TB(I+yB^2)^(-1)T^t. The metric now reads

                   Khat_u=K+uy(2Qhat-Mhat).

Use the same five hatted invariants with THIS metric. With
h=(w^2-4u0v)/(sqrt((u0-yv)^2+yw^2)+u0+yv),
the identical exact rationalization gives V(t)=yW(y), where

 W=[(2q-m)^2+2(1+4y)h]/
          [2(sqrt((1+4y)[q^2+y(m^2+2h)])+q+2ym)].       (7)

Hence integral_4^infinity Vdt=integral_0^(1/4)W(z^2)dz, including the
ENTIRE infinite tail. The generalized eigenvalues of Mhat relative to
Qhat lie in[-4,4] since maxprivate degree<=4. This is independent of
the SPD metric used for the trace invariants. It implies the same
nonnegative radicands and strictly positive denominators as the previous
full-cap proof. The variable metric does not change the tail identity.

Producer and reader build exact polynomials from respectively adjugate
recurrences and direct contact moments. For p=det(xI+B^2), write Q=Qn/p,
M=Mn/p, D=pK+u(2Qn-Mn),d=detD. Then q,m have numerator
Tr(adj(D)Qn),Tr(adj(D)Mn) over d; the other invariants have numerators
detQn,detMn,cross(Qn,Mn) over d. For the shared interval representation
with squared denominator these last numerators are multiplied by d.
Tail polynomials instead use Dhat=phat K+uy(2Qhat_n-Mhat_n).
The reader checks these formulas against direct exact matrix inverses
and the full compact/tail normalization. Replacing detK_u by3 or omitting
the tail factor y in Khat_u is rejected.

## 5. Complete acceptance and simple rational constants

serial-turn-certificates.json contains EVERY directed rational interval
cell of ALL3support integrals. The stdlib reader rebuilds polynomials by
the moment route and recomputes every cell, both disjoint gap-free domains
[0,4]and[0,1/4], all outward72bit dyadic operations and integer square
roots, and exact upper area sums. No floating value accepts a theorem.
The accepted area bounds imply

                    I_A<17/20;  I_B<23/20.             (8)

Both private matrices are the previously isolated C1paw graph, with an
explicit vertex permutation checked, so the already accepted full-root
Sturm energy bound gives F(B)>2403/500. The actual contact mass is4 in
both cases. The exact alternating-Machin certificate gives pi>157/50.
Thus(5) gives the human-readable implications

 A gain>4403/500-85/157=648771/78500
                      =413/50+361/78500>8.26;
 B gain>4403/500-115/157=633771/78500
                      =807/100+69/19625>8.07.           (9)

The universal old-parent quantifier comes from sections2-3, not a finite
enumeration of old MOPs. Actual whole triangle-parent integer PSD Gram
controls, scored with ENTIRE squared norms and all actual edges, supplement
the proof. Missing interval coverage, stale actual contacts and the wrong
variable-metric normalization are rejected. Producer and reader share the
declared scalar interval/topology utilities; this is a written
computer-assisted proof, not an external formal-assistant audit.

## 6. The exact global residue stays explicit

These are two new uniformly paying literal operations, not all possible
serial turns. Straight fan runs remain outside this conclusion, and the
existing infinite C0only family still refutes the fixed cap-only E1selector
while its WHOLE graphs are already paidW. Universal C0gain4 remainsFALSE.
Some other four-private serial constructions have singular private B;
their naive constant-metric support is not integrable at0. No bound is
claimed for them from a finite numerical cutoff.

The next structural work can exclude closed AandB as well as C1/C2/C3
and use the already proved exact sequence ledger. It still must prove
an actual nonnegative-ledger extraction OR whole-region compensation
on the ACTUAL remaining domain after ALLwholepaid exclusions and other
valid cuts. No such all-graph extraction, original counterexample or global
closure is established here. The earlier fixed-core236obstruction,
sector2sharpness and true conditional statements retain their scopes.
