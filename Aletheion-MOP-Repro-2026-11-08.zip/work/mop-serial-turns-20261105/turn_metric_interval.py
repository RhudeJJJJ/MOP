"""Exact private-response metric; reuse directed interval scalar algebra."""
from pathlib import Path
from fractions import Fraction as F
import sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'mop-negative-modes-20261105'))
import homotopy_interval as h
import certify_full_cap_phase as producer
mm=h.mm;tr=h.tr;rat=h.rat
def raw(B,T,route):
    n=len(B);B2=mm(B,B);cp=rat.characteristic(B2);p=[v*(-1)**(n+i) for i,v in enumerate(cp)]
    assert p[0]>0 and all(v>=0 for v in p)
    Q=[[[F(0)]*n for _ in range(2)] for _ in range(2)];M=[[[F(0)]*n for _ in range(2)] for _ in range(2)];cc=list(reversed(p))
    if route=='adjugate':
        C=[[F(int(i==j)) for j in range(n)] for i in range(n)]
        for j in range(n):
            q=mm(mm(T,C),tr(T));m=mm(mm(mm(T,B),C),tr(T))
            for a in range(2):
                for b in range(2):Q[a][b][n-1-j]=q[a][b];M[a][b][n-1-j]=m[a][b]
            AC=mm(B2,C);C=[[cc[j+1]*int(a==b)-AC[a][b] for b in range(n)] for a in range(n)]
        assert all(not x for row in C for x in row)
    else:
        assert route=='moments';v=tr(T);mom=[];bmom=[]
        for j in range(n):mom.append(mm(T,v));bmom.append(mm(mm(T,B),v));v=mm([[-z for z in row] for row in B2],v)
        for j in range(n):
            for a in range(2):
                for b in range(2):Q[a][b][n-1-j]=sum(cc[k]*mom[j-k][a][b] for k in range(j+1));M[a][b][n-1-j]=sum(cc[k]*bmom[j-k][a][b] for k in range(j+1))
    return p,Q,M
def polys(B,T,s,route):
    p,Q,M=raw(B,T,route);n=len(B)
    pa=h.pa;ps=h.ps;mul=rat.mul
    def pack(p,Q,M,tail):
        D=[[pa(ps(p,2 if i==j else 1),ps(mul([0,1] if tail else [1],pa(ps(Q[i][j],2),M[i][j],-1)),s)) for j in range(2)] for i in range(2)]
        d=pa(mul(D[0][0],D[1][1]),mul(D[0][1],D[1][0]),-1)
        assert d[0]>0 and all(v>=0 for v in d)
        def trace(X):return pa(pa(mul(D[1][1],X[0][0]),mul(D[0][0],X[1][1])),mul(D[0][1],X[0][1]),-2)
        def det(X):return pa(mul(X[0][0],X[1][1]),mul(X[0][1],X[0][1]),-1)
        w=pa(pa(mul(Q[0][0],M[1][1]),mul(Q[1][1],M[0][0])),mul(Q[0][1],M[0][1]),-2)
        return [d,trace(Q),trace(M),mul(d,det(Q)),mul(d,det(M)),mul(d,w)]
    compact=pack(p,Q,M,False)
    tail=pack(h.reverse(p,n+1),[[h.reverse(z,n) for z in row] for row in Q],[[h.reverse(z,n) for z in row] for row in M],True)
    return dict(compact=compact,tail=tail)
def actual(typ):
    assert typ in ('A','B')
    old={(0,1),(0,2),(0,3),(1,2),(2,3)}
    e=old|({(0,5),(1,4),(1,5),(4,5)} if typ=='A' else {(2,4),(2,5),(3,5),(4,5)})
    outer=[0,5,4,1,2,3] if typ=='A' else [0,1,2,4,5,3]
    rat.prior.outer_graph(6,e,outer)
    A=[[F(int(tuple(sorted((i,j))) in e)) if i!=j else F(0) for j in range(6)] for i in range(6)]
    private=[1,2,4,5];B=[[A[i][j] for j in private] for i in private];T=[[A[i][j] for j in private] for i in (0,3)]
    return dict(label=typ,n=6,edges=sorted(e),boundary=outer,private=private,roots=[0,3]),B,T
