from pathlib import Path
from fractions import Fraction as F
import hashlib,json,time
import turn_metric_interval as m
HERE=Path(__file__).resolve().parent
def main():
    piL,piU=m.h.machin_pi();cases=[]
    for typ,ss,target in [('A',[F(0)],F(413,50)),('B',[F(0),F(1,2)],F(807,100))]:
        cap,B,T=m.actual(typ);components=[]
        for s in ss:
            data=m.polys(B,T,s,'adjugate');assert data==m.polys(B,T,s,'moments')
            res=m.producer.integral(data,F(1,25));components.append(dict(s=str(s),polynomials=m.producer.serialize(data),integral=res))
            print(json.dumps(dict(completed_support=typ,s=str(s),cells=len(res['leaves']),upper=str(m.h.up(F(res['upper']))))),flush=True)
        mean=sum(F(c['integral']['upper']) for c in components)/len(ss)
        gain=F(2403,500)+sum(x*x for row in T for x in row)-2*mean/piL;assert gain>target
        cases.append(dict(label=typ,cap=cap,components=components,integral_mean_upper=str(mean),private_F_lower='2403/500',gain_lower=str(m.h.down(gain)),target=str(target)))
        print(json.dumps(dict(accepted_proposal=typ,gain=str(m.h.down(gain)),target=str(target))),flush=True)
    result=dict(format='serial-turn-monotone-private-metric-exact-v1',pi_lower=str(piL),pi_upper=str(piU),cases=cases,
      scope='Full rational intervals and entire normalized tail. All-parent proof requires same-parent homotopy and nested PRIVATE-metric balls; finite left sums upperbound the true s integral. OriginalGLOBALOPEN.')
    p=HERE/'serial-turn-certificates.json';p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status='PREPARED_EXACT_SERIAL_TURN_CERTIFICATES',bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())))
if __name__=='__main__':main()
