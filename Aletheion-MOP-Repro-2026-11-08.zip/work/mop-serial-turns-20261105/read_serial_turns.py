from pathlib import Path
from fractions import Fraction as F
import copy,hashlib,json,time
import turn_metric_interval as m
import read_full_cap_phase as previous
HERE=Path(__file__).resolve().parent
u=m.h.old.util;outer=m.h.old.outer;mm=m.mm;tr=m.tr
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def actual(cap):
    typ=cap['label'];assert typ in ('A','B')
    boundary=[0,5,4,1,2,3] if typ=='A' else [0,1,2,4,5,3]
    diagonals=[(0,1),(0,2),(1,5)] if typ=='A' else [(0,2),(2,3),(2,5)]
    e={tuple(sorted((boundary[j],boundary[(j+1)%6]))) for j in range(6)}|set(diagonals)
    assert cap['n']==6 and cap['roots']==[0,3] and cap['private']==[1,2,4,5] and cap['boundary']==boundary and e=={tuple(x) for x in cap['edges']}
    m.rat.prior.outer_graph(6,e,boundary)
    A=[[F(int(tuple(sorted((i,j))) in e)) if i!=j else F(0) for j in range(6)] for i in range(6)]
    B=[[A[i][j] for j in cap['private']] for i in cap['private']];T=[[A[i][j] for j in cap['private']] for i in cap['roots']]
    assert max(sum(abs(x) for x in row) for row in B)<=4
    return B,T
def matrix_controls(B,T,s,data):
    result=[];det=lambda X:X[0][0]*X[1][1]-X[0][1]*X[1][0];trace=lambda X:sum(X[i][i] for i in range(2))
    for t in (F(1,2),F(1),F(4)):
        r,im=outer.resolvent(B,t);r=mm(mm(T,r),tr(T));im=mm(mm(T,im),tr(T));Q=u.scale(r,1/t);M=u.scale(im,-1)
        K=u.plus([[2,1],[1,2]],u.scale(u.plus(u.scale(Q,2),M,-1),s));assert outer.psd(K)
        Ki=m.rat.prior.inverse(K);C=mm(Ki,Q);N=mm(Ki,M)
        vals=[trace(C),trace(N),det(C),det(N),trace(C)*trace(N)-trace(mm(C,N))]
        assert vals==previous.exact_invariants(data['compact'],t*t)
        dr=det(r)-det(im);di=r[0][0]*im[1][1]+im[0][0]*r[1][1]-2*r[0][1]*im[0][1]
        q,ma,ua,va,w=vals;assert (dr*dr+di*di)/(det(K)**2)==(t*t*ua-va)**2+t*t*w*w
        assert trace(mm(mm(mm(Ki,r),Ki),r))+trace(mm(mm(mm(Ki,im),Ki),im))==t*t*(q*q-2*ua)+(ma*ma-2*va)
        result.append(dict(t=str(t),s=str(s),direct_actual_matrix_inverse_and_variable_metric_invariants=True))
    for t in (F(4),F(8),F(16)):
        y=1/(t*t);a=previous.exact_invariants(data['compact'],t*t);b=previous.exact_invariants(data['tail'],y)
        assert a==[y*b[0],y*b[1],y*y*b[2],y*y*b[3],y*y*b[4]]
        e1=m.h.enclosure(data,'compact',t,t);e2=m.h.times(m.h.enclosure(data,'tail',1/t,1/t),y)
        assert max(e1[0],e2[0])<=min(e1[1],e2[1]);result.append(dict(t=str(t),s=str(s),complete_variable_metric_tail_normalization=True))
    return result
def homotopy_controls(B,T,a,right):
    result=[]
    for t in (F(1,3),F(1),F(3)):
        r,im=outer.resolvent(B,t);r=mm(mm(T,r),tr(T));im=mm(mm(T,im),tr(T));P=u.plus(u.scale(r,2/t),im)
        assert outer.psd(P);K=u.plus([[2,1],[1,2]],u.scale(P,a));Ki=m.rat.prior.inverse(K)
        for v in (a,(a+right)/2,right):
            ZR=u.plus(u.plus(u.scale(u.eye(2),t),[[1/t]*2 for _ in range(2)]),u.scale(r,v));ZI=u.plus([[0,1],[1,0]],u.scale(im,v))
            lower=u.plus(u.plus(u.scale(ZR,2),u.scale(ZI,t)),u.scale(K,t),-1)
            assert lower==u.plus([[2/t]*2 for _ in range(2)],u.scale(P,t*(v-a))) and outer.psd(lower)
            block=[ZR[i]+[-x for x in ZI[i]] for i in range(2)]+[ZI[i]+ZR[i] for i in range(2)];inv=m.rat.prior.inverse(block)
            R=[row[:2] for row in inv[:2]];I=[row[:2] for row in inv[2:]]
            HR=u.plus(mm(mm(tr(R),K),R),mm(mm(tr(I),K),I));HI=u.plus(mm(mm(tr(R),K),I),mm(mm(tr(I),K),R),-1)
            W=u.plus(u.plus(u.scale(R,2),u.scale(I,t),-1),u.scale(HR,t),-1);Wi=u.scale(HI,-t)
            assert outer.psd([W[i]+[-x for x in Wi[i]] for i in range(2)]+[Wi[i]+W[i] for i in range(2)])
            MR=u.plus(R,u.scale(Ki,1/t),-1);MI=u.plus(I,u.scale(Ki,F(1,2)))
            DR=u.plus(u.scale(Ki,1/(t*t)+F(1,4)),u.plus(mm(mm(tr(MR),K),MR),mm(mm(tr(MI),K),MI)),-1)
            DI=u.scale(u.plus(mm(mm(tr(MR),K),MI),mm(mm(tr(MI),K),MR),-1),-1)
            assert DR==u.scale(W,1/t) and DI==u.scale(Wi,1/t)
            result.append(dict(t=str(t),left=str(a),actual_homotopy=str(v),nested_metric_floor_and_complex_ball_identity=True))
    return result
def verify_case(item,recompute=True):
    typ=item['label'];B,T=actual(item['cap']);assert typ==item['cap']['label']
    ss=[F(0)] if typ=='A' else [F(0),F(1,2)]
    assert [F(c['s']) for c in item['components']]==ss
    areas=[];count=0;controls=[];floors=[]
    for j,component in enumerate(item['components']):
        s=F(component['s']);data=m.polys(B,T,s,'moments')
        assert data=={r:[[F(v) for v in p] for p in z] for r,z in component['polynomials'].items()}
        assert data==m.polys(B,T,s,'adjugate')
        lo,hi,n=previous.verify_partition(component,data,recompute);areas.append(hi);count+=n
        if recompute:controls+=matrix_controls(B,T,s,data);floors+=homotopy_controls(B,T,s,ss[j+1] if j+1<len(ss) else F(1))
    mean=sum(areas)/len(ss);assert mean==F(item['integral_mean_upper'])
    assert mean<(F(17,20) if typ=='A' else F(23,20))
    energy=F(2403,500);assert item['private_F_lower']==str(energy)
    oldsrc=HERE.parent/'mop-root-sector-20261105/anisotropic-cap-certificates.json';c1=json.loads(oldsrc.read_text())['cases'][1]
    _,oldB,_=m.h.old.actual(c1);perm=[1,0,2,3] if typ=='A' else [0,1,2,3]
    assert [[B[perm[i]][perm[j]] for j in range(4)] for i in range(4)]==oldB
    assert F(m.h.old.check(c1)['private_F_lower'])>energy
    pL,pU=m.h.machin_pi();gain=energy+sum(x*x for row in T for x in row)-2*mean/pL
    target=F(413,50) if typ=='A' else F(807,100)
    assert F(item['target'])==target and gain>=F(item['gain_lower'])>target
    return dict(label=typ,gain_lower=str(m.h.down(gain)),gain_display_lower=str(m.rat.lower(gain)),target=str(target),leaves=count,integral_mean_upper=str(mean),matrix_checks=controls,homotopy_checks=floors)
def main():
    path=HERE/'serial-turn-certificates.json';d=json.loads(path.read_text());assert d['format']=='serial-turn-monotone-private-metric-exact-v1'
    pL,pU=m.h.machin_pi();assert F(d['pi_lower'])==pL and F(d['pi_upper'])==pU
    results=[];start=time.monotonic()
    for item in d['cases']:
        result=verify_case(item);results.append(result);print(json.dumps(dict(accepted=result['label'],gain=result['gain_display_lower'],cells=result['leaves'],elapsed=time.monotonic()-start)),flush=True)
    assert [r['label'] for r in results]==['A','B']
    whole=[]
    for w in json.loads((HERE/'turn-whole-controls.json').read_text())['cases']:
        cap=next(c['cap'] for c in d['cases'] if c['label']==w['label']);edges={tuple(e) for e in cap['edges']}|{(0,6),(3,6)}
        assert edges=={tuple(e) for e in w['edges']} and w['old_triangle']==[0,3,6]
        m.rat.prior.outer_graph(w['n'],edges,w['boundary']);W=w['factor'];den=w['denominator'];assert len(W)==7 and all(type(z) is int for row in W for z in row)
        Z=mm(W,tr(W));G=mm(tr(W),W);score=F(4*sum(Z[a][b] for a,b in edges),den**2)-F(sum(x*x for row in G for x in row),den**4)
        assert score-4>next(F(c['target']) for c in results if c['label']==w['label'])
        whole.append(dict(label=w['label'],whole_F_Gram_lower=str(score),gain_from_exact_triangle_lower=str(score-4)))
    bad=copy.deepcopy(d['cases'][0]);bad['components'][0]['integral']['leaves'].pop()
    missing=copy.deepcopy(d['cases'][1]);missing['components'].pop()
    stale=copy.deepcopy(d['cases'][1]);stale['components'][1]['polynomials']=stale['components'][0]['polynomials']
    tail=copy.deepcopy(d['cases'][1]);tail['components'][1]['polynomials']['tail'][1][0]=str(F(tail['components'][1]['polynomials']['tail'][1][0])+1)
    contact=copy.deepcopy(d['cases'][0]);contact['cap']['edges'].remove([0,5])
    damaged={name:m.rat.rejection(lambda c=c:verify_case(c,False)) for name,c in [('missing_interval',bad),('missing_left_support_component',missing),('stale_constant_metric',stale),('wrong_tail_normalization',tail),('missing_actual_contact',contact)]}
    assert all(damaged.values())
    result=dict(status='PASS_EXACT_ALL_PARENT_SERIAL_TURN_A826_B807_AND_NESTED_PRIVATE_METRIC_SUPPORT',cases=results,whole_controls=whole,
      damaged_rejected=damaged,total_cells=sum(r['leaves'] for r in results),certificate_sha256=sha(path),proof_sha256=sha(HERE/'serial-turn-payments-proof.md'),
      whole_fixture_sha256=sha(HERE/'turn-whole-controls.json'),
      universal='EVERYoldactualUNITMOPn>=3/EVERYorderedboundary: literalA+4private gain>8.26;literalB+4private gain>8.07. Sameparent homotopy, all negative and positive private directions retained, no old degree/order/normbound.',
      evidence='Every directed rational cell recomputed for all3support integrals; entire normalized infinite tail and full compact/tail variable metric verified. Analytic nested-ball theorem, not samples, covers all homotopy parameters.',
      shared='Producer/reader share scalar interval primitives and original characteristic/topology helpers; exact polynomials have separate adjugate/contactmoment routes and direct matrix checks. No external formal audit.',
      original_status='GLOBAL_OPEN',global_extraction='OPEN',original_counterexample=False)
    (HERE/'serial-turn-reader-check.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ('status','total_cells','damaged_rejected','certificate_sha256','original_status')}))
if __name__=='__main__':main()
