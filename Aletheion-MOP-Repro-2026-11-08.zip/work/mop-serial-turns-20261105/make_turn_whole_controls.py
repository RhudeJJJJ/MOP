from pathlib import Path
import json
import numpy as np
import turn_metric_interval as m
HERE=Path(__file__).resolve().parent
def main():
    out=[]
    for typ in ('A','B'):
        cap,B,T=m.actual(typ);edges={tuple(e) for e in cap['edges']}|{(0,6),(3,6)}
        A=np.zeros((7,7))
        for a,b in edges:A[a,b]=A[b,a]=1
        b,U=np.linalg.eigh(A);W=np.rint((U*np.sqrt(np.maximum(b,0)))@U.T*1000000).astype(int)
        outer=cap['boundary']+[6];m.rat.prior.outer_graph(7,edges,outer)
        out.append(dict(label=typ,n=7,edges=sorted(edges),boundary=outer,old_triangle=[0,3,6],factor=W.tolist(),denominator=1000000))
    (HERE/'turn-whole-controls.json').write_text(json.dumps(dict(cases=out,scope='Numeric proposes integer PSD factors; exact full Gram scoring is required, no floating acceptance.'),indent=2)+'\n')
    print(json.dumps(dict(status='PROPOSED_TWO_WHOLE_INTEGER_GRAMS')))
if __name__=='__main__':main()
