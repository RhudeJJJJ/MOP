# Degree-three retirement pays EVERY boundary fan of length at least19

8 November2026. LOCAL EXACT GRAM ACCEPTANCE PASSED. Original every
finite simple UNIT MOP G,n>=8 satisfies F=splus>=2n remains GLOBAL OPEN.

THEOREM. For every old UNIT MOP A, every actual boundary uv with OLD
degree_A(u)<=3, and every r>=19, append a standard unit boundary fan
of r private vertices with apex u. Then

                         DeltaF>2r+1/20.                    (1)

There is no old order/other-root-degree/norm upper bound. All original
edges are retained once. This is a one-fan increment and not a payment
for an entire differently rooted mixed branch at the original H.

The accepted exact all-degree retirement theorem for chordal outerplanar
graphs states that deleting actual degree D costs less than R(D), where
R>D is the unique root R(R-D)^2=4D^2, and R is increasing. At D3,
U=111/20 gives U(U-3)^2-36=711/8000>0, hence R(3)<111/20.
Pinch the NEW graph into the retained A-u and actual Fan_(r+1) block.
The blocks are disjoint, with u counted ONCE in its fan block. The PSD
variational principle therefore gives

 DeltaF>=F(Fan_(r+1))-[F(A)-F(A-u)]
        >F(Fan_(r+1))-111/20.                            (2)

Complete integer PSD witnesses prove F(Fan_(r+1))>2r+28/5 for r19,20,
and >2r+6 for EVERY r21..27. Each witness X=ZZt/q^2 is positive
semidefinite and is accepted by the exact bound

 F(A)>=2Tr(AX)-Tr(X^2)
      =[2q^2 Tr(A ZZt)-Tr((ZZt)^2)]/q^4.

The independent stdlib reader reconstructs every actual unit fan edge,
reads ALL integer columns, computes the entire Frobenius square, checks
all nine lengths and the exact thresholds. Floats propose Z only.
The variational formula follows by diagonalizing A and completing the
square on the PSD cone, whose maximizer is Aplus. It does not require
that the integer witness exactly equals the floating spectral optimum.

For ALL r>=28, the prior elementary Rayleigh/path-interlacing proof gives
F(Fan_(r+1))>2r+f(r),
f(r)=2sqrt(r)-2/sqrt(r)-4-2/r+1/r^2.
Its derivative is positive for r>=1. Using sqrt28>21/4 gives
f28>21/2-8/21-4-1/14+1/784>6. Thus the ENTIRE infinite r tail is
covered analytically, without assuming monotonicity of actual fan energy.
Since 28/5-111/20=1/20, equations(2) and these bounds prove(1).

Qualified original consequence. In the existing mixed deepest-branch
description on original ab, child apex c is private and its inward fan
has r vertices; the other fan has external apex a and length p.
Remove ONLY the inward fan: actual retained c has degree EXACTLY3,
independently of p. If the retained order is>=8, minimality plus(1)
excludes ALL r>=19. If that retained order h<=7 and original n>=72,
r=n-h>=65; the retained old small-core/whole-fan argument already pays
the WHOLE graph. This keeps, rather than extends, those original scopes.

Intersecting with the prior necessary inward set{2,15,16,17,18,19,20}
leaves{2,15,16,17,18}; outward p>=2 remains unbounded, with coherent
whole reflection. This is a genuine stricter necessary representation,
not a proof of existence or compensation of any remaining graph. The
two descriptions of a one-face fan can still coincide; no independent
overlapping energy credits may be added. Global completion, all-small-old
arbitrary whole payment and the unrestricted bare external branch remain
unproved. Native source intake/replay of this new improvement is PENDING.
