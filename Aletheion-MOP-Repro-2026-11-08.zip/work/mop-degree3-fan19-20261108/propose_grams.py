"""FLOAT discovery ONLY: complete integer Gram columns are the output."""
from pathlib import Path
import json,numpy as np
P=Path(__file__).resolve().parent
def main():
    rows=[];scale=10**6
    for r in range(19,28):
        A=np.zeros((r+1,r+1));A[0,1:]=1;A[1:,0]=1
        for j in range(1,r):A[j,j+1]=A[j+1,j]=1
        vals,vec=np.linalg.eigh(A);keep=vals>1e-8;Z=np.rint(vec[:,keep]*np.sqrt(vals[keep])*scale).astype(np.int64).tolist()
        rows.append(dict(path_vertices=r,scale=scale,columns=int(sum(keep)),Z=Z))
    (P/'fan-grams.json').write_text(json.dumps(dict(format='complete-integer-psd-gram-v1',rows=rows),separators=(',',':'))+'\n')
    print(json.dumps(dict(status='HEURISTIC_INTEGER_GRAMS_READY_REQUIRES_EXACT_READER',rows=len(rows))))
if __name__=='__main__':main()
