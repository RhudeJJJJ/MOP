"""Normal existing native import; full source readback and isolated exact replay."""
from pathlib import Path
import hashlib,json,sqlite3,shutil,subprocess,sys,time
P=Path(__file__).resolve().parent;DB=Path('C:/Users/jonas/Aletheion/aletheion/aletheion.db');PREFIX='math:mop:degree3-fan19:'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dig(s):return hashlib.sha256(s.encode()).hexdigest()
def rd(n):return json.loads((P/n).read_bytes())
def save(n,v):(P/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def prepare():
    r=rd('fan19-check.json');assert r['status']=='PASS_ALL_DEGREE_AT_MOST3_FAN_LENGTH_AT_LEAST19_PAYMENT'
    parents=['math:mop:exact-retirement:retirement:20261108','math:mop:exact-retirement:proofsource:20261108','math:mop:mixed-seven-inward-lengths:lowapex:20261105','math:mop:mixed-seven-inward-lengths:regime:20261105','math:mop:mixed-seven-inward-lengths:sources:20261105']
    known={n['node_id']:n for folder in ['mop-exact-retirement-20261108','mop-mixed-branch-20261105']for n in json.loads((P.parent/folder/'packet.json').read_bytes())['nodes']}
    c=sqlite3.connect('file:'+str(DB)+'?mode=ro',uri=True);c.execute('BEGIN');snap=[]
    assert not c.execute('select node_id from weave_nodes where node_id like ?',(PREFIX+'%',)).fetchall(),'existing packet must be inspected'
    for node_id in parents:
        row=c.execute('select body,provenance from weave_nodes where node_id=?',(node_id,)).fetchone();assert row and row[0]==known[node_id]['body'],'parent changed'
        incoming=c.execute('select from_id from weave_edges where to_id=? and relation=?',(node_id,'revises')).fetchall();assert not incoming,'new revision requires targeted review'
        snap.append(dict(node_id=node_id,sha256=dig(row[0]),body=row[0]if known[node_id]['kind']!='source'else'Full source retained canonically; relevant complete original proof included here. No entry-delivery claim.',provenance=row[1]))
    c.rollback();c.close();save('parent-snapshot.json',snap);save('parent-bindings.json',{x['node_id']:x['sha256']for x in snap})
    (P/'inherited').mkdir(exist_ok=True)
    for folder,name in [('mop-exact-retirement-20261108','exact-retirement-proof.md'),('mop-mixed-branch-20261105','mixed-reduction-proof.md')]:
        source=P.parent/folder/name;dest=P/'inherited'/name
        if dest.exists():assert dest.read_bytes()==source.read_bytes()
        else:shutil.copyfile(source,dest)
    source=P.parent/'mop-joint-region-20261108/run_guarded_native.py';dest=P/'run_guarded_native.py'
    if dest.exists():assert dest.read_bytes()==source.read_bytes()
    else:shutil.copyfile(source,dest)
    names=['fan19-proof.md','propose_grams.py','read_grams.py','fan-grams.json','fan19-check.json','intake_fan19.py','run_guarded_native.py','parent-snapshot.json','parent-bindings.json','inherited/exact-retirement-proof.md','inherited/mixed-reduction-proof.md']
    files=[P/n for n in names];env=dict(format='full-source-envelope-v2-relative-files',files=[dict(path=str(p),relative=p.relative_to(P).as_posix(),bytes=p.stat().st_size,sha256=sha(p),content=p.read_bytes().decode())for p in files]);payload=json.dumps(env,ensure_ascii=True,separators=(',',':'));pieces=[payload[j:j+72000]for j in range(0,len(payload),72000)]
    keys=['payment','mixed-front','scope','proofsource','certificate'];ids={k:PREFIX+k+':20261108'for k in keys};parts=[PREFIX+'sourcepart'+str(j)+':20261108'for j in range(len(pieces))];nodes=[];edges=[]
    def node(k,kind,body,status):nodes.append(dict(node_id=ids[k],kind=kind,title='Degree-three fan threshold19: '+k,body=body,epistemic=status,provenance=json.dumps([dict(path=str(P/'fan19-proof.md'),sha256=sha(P/'fan19-proof.md'))])))
    node('payment','claim','For EVERY old finite simple UNIT MOP A and actual ordered boundary uv with degree_A(u)<=3, EVERY standard unit boundary fan of r>=19 private vertices at old apex u has DeltaF>2r+1/20. No old upper order, other degree, norm or spectrum bound. Exact all-degree retirement gives R3<111/20 from polynomial excess711/8000. Disjoint actual partition A-u and Fan_(r+1) counts u ONCE. Complete integer PSD witnesses give fan excess>28/5 for r19,20 and>6 for r21..27; complete monotone analytic f tail gives>6 for ALLr>=28. The entire integer factors and full Frobenius squares are stored, not just hashes or eigenvalue samples.','PROVEN universal unit-MOP old-degree-at-most3 fan increment')
    node('mixed-front','claim','In the inherited minimal original UNIT-MOP counter n>=72, EVERY deepest branch admits external/external fan apices OR a mixed description with inward q in{2,15,16,17,18}, outward p>=2, including coherent whole reflection. Remove ONLY the inward fan: the actual retained private apex has degree EXACTLY3 independent of p. If retained order>=8, minimality and the new allr>=19 payment exclude q19,20. If retained order<=7, original n>=72 forces q>=65 and the previously proved small-old WHOLE argument applies. Intersect the prior true necessary set{2,15,16,17,18,19,20}, preserving its other premises/assignment ambiguities. This is a strictly sharper NECESSARY representation, not existence or a complete graph cover; external/external remains open.','PROVEN refined necessary mixed-front; original global OPEN')
    node('scope','claim','ORIGINAL EVERY finite simple UNIT MOP n>=8 has F=splus>=2n remains GLOBAL OPEN; goal ACTIVE. The new old-MOP-degree<=3 premise is narrower than the prior arbitrary real symmetric squared-row-norm<=3 theorem, which remains true for r>=21 and is NOT revised to arbitrary matrices at r19. Only chordal outerplanar R3 retirement licenses the stronger MOP threshold. Prior true seven-length necessary set remains valid but weaker; no false historical theorem alleged. Not a fresh B71 proof, whole all-small-old payment, bare-branch compensation or all-method optimum. Native full source replay and entry delivery remain distinct.','PROVEN scope and limits')
    header=dict(format='complete-source-envelope-chunks-v1',payload_utf8_bytes=len(payload.encode()),payload_sha256=dig(payload),parts=[dict(node_id=i,part=j+1,bytes=len(s.encode()),sha256=dig(s))for j,(i,s)in enumerate(zip(parts,pieces))],scope='ALL numbered raw source bodies and full Gram factors required; header alone incomplete')
    node('proofsource','source',json.dumps(header,separators=(',',':')),'FULL source header, all parts obligatory')
    for j,(i,s)in enumerate(zip(parts,pieces),1):nodes.append(dict(node_id=i,kind='source',title='Degree3 fan19 full source '+str(j),body=s,epistemic='EXACT full source fragment; incomplete alone',provenance=json.dumps([dict(payload_sha256=dig(payload),part=j)])))
    node('certificate','source',json.dumps(r,separators=(',',':')),'COMPLETE exact Gram lower bounds and analytic bridge checks')
    def edge(a,b,rel,why):edges.append(dict(edge_id='edge:'+dig(a+'|'+rel+'|'+b),from_id=a,to_id=b,relation=rel,rationale=why,status='curated'))
    for k in keys[:3]:edge(ids[k],ids['proofsource'],'requires','Complete literal unit proof, all Gram factors, all-length analytic tail and scope required.')
    for i in parts:edge(ids['proofsource'],i,'requires','Every numbered full source body obligatory.')
    edge(ids['payment'],ids['certificate'],'requires','Exact entire Gram calculation and rational retirement/tail inequalities.')
    edge(ids['payment'],parents[0],'derived_from','R3<111/20 improves only actual chordal outerplanar retirement.')
    edge(ids['payment'],parents[2],'qualifies','Old arbitrary-matrix r>=21 theorem remains true; new r>=19 result requires actual old MOP.')
    edge(ids['mixed-front'],parents[3],'qualifies','Intersect previous true necessary seven-length representation with the new MOP-only exclusion q>=19; preserve all other scope.')
    edge(ids['mixed-front'],ids['payment'],'requires','Actual retained private apex degree3, not original outside degree.')
    for i in [parents[1],parents[4]]:edge(ids['proofsource'],i,'requires','Full canonical accepted ancestor source retained; complete relevant original proof also included.')
    assert max(len(n['body'].encode())for n in nodes)<95000
    save('packet.json',dict(schema_version=1,nodes=nodes,edges=edges));save('source-hashes.json',{str(p):sha(p)for p in files})
    raw=sum(p.stat().st_size for p in files);backup=DB.stat().st_size+16*1024**2;free=shutil.disk_usage(P).free;assert raw<1024**2 and free-backup-raw>8*1024**3
    save('write-plan.json',dict(explicit_members=[str(p)for p in files],raw_bytes=raw,backup_upper=backup,free_before=free,backup_count=1,no_expected_deduplication=True,storage_status='Current free checked. Earlier detailed archive manager lock respected; no second manager or maintenance.'))
    print(json.dumps(dict(status='PREPARED_FAN19_FULL_SOURCE_NATIVE_PACKET',nodes=len(nodes),edges=len(edges),parts=len(parts),files=len(files),raw_bytes=raw,backup_upper=backup,free_before=free)))
def audit():
    assert all(sha(Path(p))==h for p,h in rd('source-hashes.json').items())
    packet=rd('packet.json');c=sqlite3.connect('file:'+str(DB)+'?mode=ro',uri=True);c.row_factory=sqlite3.Row;c.execute('BEGIN');actual=[];nodes={}
    for table,key,item in [('weave_nodes','node_id',n)for n in packet['nodes']]+[('weave_edges','edge_id',n)for n in packet['edges']]:
        row=dict(c.execute('select * from '+table+' where '+key+'=?',(item[key],)).fetchone());assert all(row[k]==v for k,v in item.items());actual.append(dict(table=table,row=row))
        if table=='weave_nodes':nodes[row['node_id']]=row
    for i,h in rd('parent-bindings.json').items():assert dig(c.execute('select body from weave_nodes where node_id=?',(i,)).fetchone()[0])==h
    c.rollback();c.close();save('actual-readback.json',actual)
    header=json.loads(nodes[PREFIX+'proofsource:20261108']['body']);pieces=[]
    for j,item in enumerate(header['parts'],1):
        body=nodes[item['node_id']]['body'];assert item['part']==j and len(body.encode())==item['bytes']and dig(body)==item['sha256'];pieces.append(body)
    payload=''.join(pieces);assert len(payload.encode())==header['payload_utf8_bytes']and dig(payload)==header['payload_sha256'];env=json.loads(payload)
    for folder in ['native-export','native-replay']:
        for f in env['files']:
            rel=Path(f['relative']);assert not rel.is_absolute()and'..'not in rel.parts;data=f['content'].encode();assert len(data)==f['bytes']and hashlib.sha256(data).hexdigest()==f['sha256']and data==Path(f['path']).read_bytes()
            path=P/folder/rel;path.parent.mkdir(parents=True,exist_ok=True)
            if path.exists():assert path.read_bytes()==data
            else:path.write_bytes(data)
    start=time.monotonic();argv=[sys.executable,'-B','-X','utf8',str(P/'native-replay/read_grams.py')];r=subprocess.run(argv,capture_output=True,text=True,encoding='utf8');save('replay-process.json',dict(argv=argv,exit_code=r.returncode,wall_time_seconds=time.monotonic()-start,stdout_bytes=len(r.stdout.encode()),stderr_bytes=len(r.stderr.encode())));(P/'replay.stdout.txt').write_text(r.stdout);(P/'replay.stderr.txt').write_text(r.stderr);assert r.returncode==0,r.stderr;assert json.loads((P/'native-replay/fan19-check.json').read_bytes())==rd('fan19-check.json')
    for label in ['fan19-dryrun','fan19-import']:assert rd(label+'.process.json')['exit_code']==0
    receipt=rd('fan19-import.stdout.json');assert receipt['inserted']==dict(nodes=len(packet['nodes']),edges=len(packet['edges']),reviews=0);backup=Path(receipt['backup']);assert backup.is_file()and backup.stat().st_size<=rd('write-plan.json')['backup_upper']
    out=dict(status='PASS_NATIVE_ALL_LENGTH_FAN19_AND_FIVE_INWARD_LENGTH_FRONT',native_run_id=receipt['run_id'],nodes=len(packet['nodes']),edges=len(packet['edges']),files=len(env['files']),parts=len(pieces),proof_sha256=sha(P/'fan19-proof.md'),gram_sha256=sha(P/'fan-grams.json'),all_sources_byte_identical=True,independent_native_export_replay=rd('replay-process.json'),parents_unchanged=True,backup=str(backup),free_after=shutil.disk_usage(P).free,original_global='OPEN',original_goal_complete=False,mixed_remaining_necessary_inward_lengths=[2,15,16,17,18],entry_delivery='No automatic delivery inferred from native replay; earlier entry gaps retained')
    save('native-audit.json',out);print(json.dumps(out))
if __name__=='__main__':prepare()if len(sys.argv)==1 or sys.argv[1]=='prepare'else audit()
