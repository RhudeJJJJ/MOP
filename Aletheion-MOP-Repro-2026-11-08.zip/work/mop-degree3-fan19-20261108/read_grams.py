"""Independent stdlib all-integer PSD variational witness check."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,copy
P=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check(row):
    r=row['path_vertices'];n=r+1;q=row['scale'];Z=row['Z'];k=row['columns']
    assert type(r)is int and 19<=r<=27 and q==10**6 and 0<k<=n
    assert len(Z)==n and all(len(a)==k and all(type(v)is int for v in a)for a in Z)
    W=[[sum(a*b for a,b in zip(Z[i],Z[j]))for j in range(n)]for i in range(n)]
    # Actual fan hub0 over the path1..r, every unit edge ONCE.
    edges=[(0,j)for j in range(1,n)]+[(j,j+1)for j in range(1,r)]
    assert len(set(edges))==2*r-1
    trace=2*sum(W[i][j]for i,j in edges)
    norm=sum(v*v for row in W for v in row)
    lower=F(2*q*q*trace-norm,q**4)
    target=2*r+(F(28,5)if r<=20 else F(6))
    assert lower>target,'integer Gram misses required actual energy bound'
    return dict(path_vertices=r,positive_energy_lower=str(lower),excess_lower=str(lower-2*r),required_excess=str(target-2*r),columns=k)
def reject(fn):
    try:fn()
    except(AssertionError,KeyError,TypeError):return 1
    raise AssertionError('damaged Gram accepted')
def main():
    artifact=json.loads((P/'fan-grams.json').read_bytes());assert artifact['format']=='complete-integer-psd-gram-v1'
    assert [row['path_vertices']for row in artifact['rows']]==list(range(19,28))
    rows=[check(row)for row in artifact['rows']]
    a=copy.deepcopy(artifact['rows'][0]);a['Z']=a['Z'][:-1]
    b=copy.deepcopy(artifact['rows'][0]);b['scale']=1
    c=copy.deepcopy(artifact['rows'][0]);c['Z']=[[0]*c['columns']for _ in c['Z']]
    damage=sum(reject(lambda row=row:check(row))for row in[a,b,c])
    R=F(111,20);poly=R*(R-3)**2-36;assert poly==F(711,8000)>0
    assert R>3 and F(28,5)-R==F(1,20)
    # f increasing for r>=1, and sqrt28>21/4.
    f28=F(21,2)-F(8,21)-4-F(1,14)+F(1,784);assert f28>6 and F(21,4)**2<28
    out=dict(status='PASS_ALL_DEGREE_AT_MOST3_FAN_LENGTH_AT_LEAST19_PAYMENT',rows=rows,retirement_upper=str(R),retirement_polynomial_excess=str(poly),analytic_tail_from=28,analytic_f28_lower=str(f28),proved_increment='DeltaF>2r+1/20 for ALL r>=19, actual OLD apex degree<=3',damaged_cases_rejected=damage,gram_sha256=sha(P/'fan-grams.json'),reader_sha256=sha(Path(__file__)),original_global='OPEN',mixed_branch_necessary_inward_lengths=[2,15,16,17,18],scope='Qualified minimal-counter consequence uses exact retained old degree3 and original n>=72/small-old whole proof; no complete cover inferred')
    (P/'fan19-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
