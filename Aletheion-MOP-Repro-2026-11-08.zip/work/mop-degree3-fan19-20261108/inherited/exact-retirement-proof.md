# Exact scalar-integral retirement bound for every degree

8 November 2026. ORIGINAL every finite simple UNIT maximal outerplanar
graph G,n>=8 has F(G)=splus(G)>=2n remains GLOBAL OPEN. This is a stronger
universal vertex-deletion bound and justified joint-retirement tool. The
word exact describes the scalar integral, NOT a proved extremal actual
graph or a best possible all-degree deletion bound.

THEOREM A. Let X be ANY finite simple chordal outerplanar graph, allowing
disconnected graphs, bridges and isolated vertices. If v has actual degree
D>=1, let alpha be the UNIQUE real root greater than sqrt(D) of

               alpha^3-D alpha-2D=0,
               R(D)=alpha^2.

Then, for the SAME actual induced deletion,

 0<=F(X)-F(X-v)<=2D,
 F(X)-F(X-v)<R(D),
 R(D)(R(D)-D)^2=4D^2, R(D)>D.                            (1)

For D=0 the difference is0. Put Unew(0)=0 and
Unew(D)=min(2D,R(D)) for real D>0. This Unew is increasing and concave
on[0,infinity); it equals2D through D2 and R(D) for D>=2. For EVERY
D>0, R(D)<D+2sqrt(D). The earlier valid cost Uold=min(2D,D+2sqrt(D))
and its asymptotically sharp coefficient2 remain true, weaker bounds.

1. Actual hereditary sector and complete scalar phase. Use the accepted
hereditary-retirement-proof.md, Theorem A and section3. With actual
C=A[X-v], contact row a, ||a||^2=D, and f=a(tI+iC)^-1 at, all t>0 obey

 0<Re f<=D/t, |Im f|<2Re f/t,
 delta(t)=arg(t+f(t)),
 F(X)-F(X-v)=D-(2/pi)integral_0^infinity t delta(t)dt.        (2)

The two one-root sector signs are strict for a nonisolated root. The
scalar Schur determinant t+f is accretive, so its phase has no winding.
The function r/(t+r) increases for r>=0. Consequently

 |delta(t)|<atan(2D/[t(t^2+D)]).

All frequencies and all private/old zero modes are retained. Define
I(D)=integral_0^infinity t atan(2D/[t(t^2+D)])dt. Integration by parts,
whose boundary terms vanish at0 and infinity, gives the EXACT identity

 I(D)=integral_0^infinity
      D t^2(3t^2+D)/[(t^3+Dt)^2+4D^2] dt.                 (3)

2. Evaluate the entire integral algebraically. Define polynomials
qplus(z)=z^3+Dz+2Di, qminus(z)=z^3+Dz-2Di. There is a unique alpha>
sqrt(D) with alpha^3-D alpha-2D=0, since the left polynomial is negative
at sqrt(D), increasing thereafter, and tends to infinity. Put r=alpha^2.

Factor

 qplus(z)=(z-i alpha)[z^2+i alpha z+(D-r)].

It has exactly ONE root in the upper half-plane, i alpha. Both roots
of the quadratic lie strictly in the lower half-plane. Indeed they are
-i alpha/2 plus/minus sqrt(3r-4D)/2. If 3r>=4D their real parts split
and their imaginary parts are -alpha/2. If 3r<4D, their imaginary parts
are[-alpha plus/minus sqrt(4D-3r)]/2, both negative because r>D.
The roots of qminus are the complex conjugates, so it has TWO upper
roots counting multiplicity and lower root -i alpha. No pole is real.

Let the rational integrand in(3) be W(z). The exact identity

 W(z)=(i/4)z^2[qplus'(z)/qplus(z)-qminus'(z)/qminus(z)]      (4)

shows its residue at a qplus root z0 of multiplicity m is i m z0^2/4;
at a qminus root it is -i m z0^2/4. This remains valid at repeated roots,
because a logarithmic derivative has a simple pole of residue m.

The three squared roots of qminus sum to -2D by Vieta. Its lower
root has square -r, so the two upper squared roots sum to r-2D.
The COMPLETE upper-half-plane residue sum of W is therefore

 (i/4)(-r)-(i/4)(r-2D)=-i(r-D)/2.

W(z)=O(|z|^-2) on a large semicircle, so that arc contributes0. The
residue theorem and the even real integrand give

                2I(D)=pi(r-D),
                D+2I(D)/pi=r=R(D).                       (5)

Thus (2),(3),(5) prove the strict second inequality in(1); the first
follows from principal interlacing of both square energies as before.
No computer quadrature, eigenvalue sampling, discarded high tail or
weighted graph-energy premise enters this all-D proof. A few numerical
integrals suggested the identity but are not used as evidence for(5).

3. Monotonicity, concavity and order of retirement. From the defining
equation, D=alpha^3/(alpha+2), which increases for alpha>0, and

 R'(D)=(alpha+2)^2/[alpha(alpha+3)]>0,
 d/dalpha log R'(D)=-(alpha+6)/[alpha(alpha+2)(alpha+3)]<0.

Therefore R is strictly increasing and strictly concave. Also
R(D)<=2D exactly when alpha>=2, equivalently D>=2. At D2 the left
slope of Unew=2D is2, while the right slope of R is8/5. This downward
join proves concavity of the full Unew, including its linear part at0.
Finally R-D=2D/alpha<2sqrt(D), proving the stronger cost comparison.
The asymptotically sharp leading coefficient2 from actual fans is not
retracted; this bound refines lower-order terms rather than proving a
smaller leading coefficient possible.

For ANY old unit MOP H with actual boundary ab and old degrees da,db,
retire the larger old degree first and count edgeab ONCE. Heredity of
the class permits the second actual deletion. The justified new upper
cost is

 F(H)-F(H-{a,b})<=
 Cnew_ab=Unew(max(da,db))+Unew(min(da,db)-1).               (6)

The opposite order is also a valid upper. Concavity makes integer
increments decrease, proving that (6) is the better of the two bounds.
This is ONE actual deletion chain, not a sum of independently optimized
overlapping graph witnesses. The accepted joint fan partitions can now
use Cnew instead of Cold, with their literal vertex ownership unchanged.

4. Clean degree4 and existing cap consequences. At D4, the increasing
polynomial r(r-4)^2 has value64 at R(4). Its value at351/50=7.02 exceeds
64 by3151/125000. Hence EVERY actual degree4 retirement costs<351/50.
This strengthens the already accepted<141/20 theorem and supplies a
complete analytic proof independent of its4096-cell calibration.

Use the SAME distinct graph partitions and old h>=3 domains in
retirement4-proof.md. For the external-b sibling cap, all p,ell>=1,
q>=40, the exact increment is>2N+9/100, since its q40 rational lower
is179500493/1985736000>9/100. For the PRIVATE-c sibling cap, all p>=1,
q+ell>=50, the increment is>2N+3/20, since its r49 rational lower is
2952143/18847850>3/20. All old weaker positive constants remain true.
These stronger margins do not further lower the integer thresholds40
and50 in this proof, nor pay the remaining small internal lengths.

5. Effect on the current original attack. Formula(6) strictly improves
the actual root-pair retirement bound whenever a used degree>=3. This
allows the established SAME-partition sufficient joint-fan region to be
recomputed with lower costs; no universal UB or compensation theorem is
claimed. The external q3..45 exact certificate continues unchanged. Its
acceptance remains a separate pending requirement, not a consequence of
an exact scalar integral. Private sibling role still has ordered
q+ell<=49 and unbounded p open on the general all-parent increment route.

Positive cap increments exclude minimal original counter occurrences
only WHERE deletion leaves h>=8; no unrestricted small-old whole
payment or auxiliary-K2 extension follows from the branch h>=3 source.
The original global target, bareFork6, other original hypotheses and
source/entry-delivery gaps remain explicit. No external audit, priority,
actual optimality of R(D), or LOTSE causal method_effect is claimed.
Native intake is a separate auditable step.
