# Low-old-degree fan payment and seven remaining inward lengths

5 November2026. Original EVERYfinite simple UNIT MOPn>=8,F=splus>=2n
remainsGLOBALOPEN/goalACTIVE. This is an auxiliary universal payment and
a further necessary branch structure, not global graph coverage.

1. A vertex can be retired at a controlled exact cost. For ANYreal
symmetric matrix A with A_uu=0 and squared offdiagonal row normd, let C
delete coordinateu. Principal interlacing makes BOTHFplus andFminus
nondecreasing under this extension. Since TrA^2-TrC^2=2d,

                      F(A)-F(C)<=2d.                 (1)

Append qnew vertices that together with u induce the UNITfan(q+1),
retaining all old coordinates/entries. Additional contacts to the rest
do not affect the following block-pinching lower bound:

 F(new)>=F(C)+F(fan(q+1)),
 F(new)-F(A)>=F(fan(q+1))-2d.                         (2)

The OLD u is counted ONCE in the fan block; q,notq+1,is the new vertex
count. For a standard unit boundaryfan cap, appendpathy1..yq, allseen
by apexu and onlyy1alsoseenby otherrootv, keepinguv. It addsqvertices/
2qunit edges. If the actual OLDapexdegree<=3, then forEVERYq>=21,

                         DeltaF>2q.                 (3)

There is no oldotherrootdegree/order/norm/spectrum bound. In fact (2)
needs only the displayed actual row norm, not an old MOP energy theorem.
This does NOT restore the alreadyfalse unrestricted externalfan cap
payment: the OLDdegree<=3premise is essential to this particular proof.

2. Complete evidence for (3). For q21..27, seven complete integerPSD
Grams prove F(fan(q+1))>2q+6 with their ENTIREsquared norms. ForALLq>=28,
interlace the privatefan against its qvertex path. The Rayleigh vector
with hubcoordinate sqrtqand pathcoordinates1 gives

 F(fan(q+1))>2q+f(q),
 f(q)=2sqrtq-2/sqrtq-4-2/q+1/q^2.

The derivative f'=q^(-1/2)+q^(-3/2)+2q^(-2)-2q^(-3)ispositiveforq>=1.
At28use sqrt28>21/4 to get
f(28)>21/2-8/21-4-1/14+1/784>6.
The path's largest eigenvalue is STRICTLYbelow2, so the interlacing
bound is strict. This is an analytic unbounded tail, not extrapolation
from the seven Grams. It proves(3)by(2).

3. Apply to the ACTUALmixed branch. At closingrootab, triangleabc has
cPRIVATE. Leftchildonacis a pfacefan with EXTERNALapexa. Rightchildoncb
is a qfacefan with INTERNALapexc. All child/private interiors are closed.
Remove the qrightprivate vertices. The actual oldMOP H0hascdegreeEXACTLY3:
its neighbors area,b,and the lastleftpathvertex. In particular this
degree does NOT grow with p. Thus(3)excludesq>=21from a minimal original
counter whenever H0hasorder>=8.

If h=|H0|<=7, originaln>=72impliesq=n-h>=65. The retained exact small-
core bound F(H0)>=2h-3, and(1)give F(H0-c)>=2h-9. For q>=64,
f(q)>16-1/4-4-1/32=375/32>11. Equation(2)then pays the WHOLEgraph:

                  F(G)>2q+11+2h-9=2n+2.

This does not assume the original2hbound for smallH0. K2andoldsmallcore
sources retain their existing scope; the actual mixed H0hasorder>=4.

4. For3<=q<=14, take the lasttwovertices in the rightfan. They form an
actual closed C0with rootsc and the preceding PRIVATErightpathvertex.
Their WHOLEdegrees areq+3and3, summingq+6<=20. Source256's proved
bounded-root serial payment excludes this C0in a minimal countern>=72.
This uses no degree bound on the external rootsa,b. The reflection of
the WHOLErooted operation covers the opposite mixed assignment.

Hence a mixed assignment has inwardlength qin{1,2,15,16,17,18,19,20}.
If q1, that child is one triangle and may instead choose its outerroot
as apex: it admits an external/external assignment. If outwardp1and
q>=2, the lefttriangle also admitsapexc; bothchildren then admitCOMMON
PRIVATEapexc, excluded by the previous allp,qregime theorem except(1,1).

Combining with the proved common-private-apex regime and allterminal-
path fan necessity, EVERYdeepestbranch in a minimal original countern>=72
admits at leastONEof the following descriptions:

 (a)Bothfanapicesare the EXTERNALrootsa,b;
 (b)Onefan has the PRIVATEapexc and length
       qin{2,15,16,17,18,19,20}; the outwardfan lengthp>=2;
       include coherent WHOLEreflection.

These are possible REPRESENTATIONS, not disjoint physical graph classes.
One-face triangles can admit several apices. BalancedFork6is included
in(a),withp=q1, and its unrestricted payment remainsOPEN. The all-length
outerfan variable remains unbounded. No energy conclusion follows from
choosing a name or assignment. The new finite inward-length list is
necessary structure only, NOT a globally sufficient selector.

5. Evidence and remaining work. Exact topology controls reconstruct
mixed polygons, the olddegree3after deleting the inwardfan, the serial
tip's WHOLErootdegrees/closedness and the assignment ambiguity. Integer
Grams are checked on actual matrices and full norms; broken factors,
missing members and dropping the low-old-degree premise are rejected.
Known independent enumeration/smallcore sources are retained; shared
topology/algebra helpers are declared. No external formal review,
exhaustive firstpayment/priority claim or repaired automatic entry.

The q2numerical support scout suggests a further all-outward-length
payment, but is NOT an exact certificate or allpstatement. Fixedcap-only
E1and unrestrictedbarefan payments remainREFUTED by unchangedwholepaidW
families. The seven inward lengths, external/external regime, arbitrary
fan assemblies and original global extraction still require proof.
