"""Stdlib Fraction/Newton/Sturm reader; no SymPy or NumPy acceptance."""
from pathlib import Path
from fractions import Fraction as F
from functools import reduce
import copy,hashlib,json,math,sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'mop-two-root-contact-20261104'))
import read_contact_certificates as prior
def trim(a):
    while len(a)>1 and a[-1]==0:a.pop()
    return a
def mul(a,b):
    c=[F(0)]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):c[i+j]+=x*y
    return trim(c)
def divrem(a,b):
    a=trim(a[:]);b=trim(b[:]);assert b!=[0];q=[F(0)]*max(1,len(a)-len(b)+1)
    while a!=[0] and len(a)>=len(b):
        k=len(a)-len(b);c=a[-1]/b[-1];q[k]+=c
        for j,x in enumerate(b):a[j+k]-=c*x
        trim(a)
    return trim(q),a
def derivative(a):return trim([i*a[i] for i in range(1,len(a))] or [F(0)])
def gcd(a,b):
    while b!=[0]:a,b=b,divrem(a,b)[1]
    return [x/a[-1] for x in a]
def ev(a,x):
    v=F(0)
    for c in reversed(a):v=v*x+c
    return v
def primitive(a):
    den=math.lcm(*(x.denominator for x in a));z=[int(x*den) for x in a]
    g=reduce(math.gcd,map(abs,z)) or 1
    return [F(x//g) for x in z]
def sturm(a):
    seq=[primitive(a),primitive(derivative(a))]
    while seq[-1]!=[0]:
        r=divrem(seq[-2],seq[-1])[1]
        if r==[0]:break
        seq.append(primitive([-x for x in r]))
    return seq
def variations(seq,x):
    v=[ev(p,x) for p in seq];v=[x for x in v if x]
    return sum((x<0)!=(y<0) for x,y in zip(v,v[1:]))
def iadd(a,b):return a[0]+b[0],a[1]+b[1]
def imul(a,b):
    v=[x*y for x in a for y in b];return min(v),max(v)
def iev(a,interval):
    v=(F(0),F(0))
    for c in reversed(a):v=iadd(imul(v,interval),(c,c))
    return v
def idiv(a,b):
    assert b[1]<0 or b[0]>0
    return imul(a,(min(1/b[0],1/b[1]),max(1/b[0],1/b[1])))
def characteristic(B):
    n=len(B);P=[[F(i==j) for j in range(n)] for i in range(n)];tr=[F(0)]
    sparse=[[(j,x) for j,x in enumerate(row) if x] for row in B]
    for k in range(1,n+1):
        P=[[sum(x*P[j][v] for j,x in sparse[i]) for v in range(n)] for i in range(n)]
        tr.append(sum(P[i][i] for i in range(n)))
    c=[F(1)]
    for k in range(1,n+1):c.append(-sum(c[k-j]*tr[j] for j in range(1,k+1))/k)
    return list(reversed(c))
def phi(x,k=F(3)):
    return F(0) if x<=k/2 else 2-k/x if x<k else F(1)
def lower(x):return F(x.numerator*10**6//x.denominator,10**6)
def upper(x):return -lower(-x)

def accept_case(c,B,T,kappa=F(3)):
    n=len(B);assert all(len(row)==n for row in B) and B==prior.transpose(B)
    p=characteristic(B);assert p==list(reversed([F(x) for x in c['characteristic']]))
    fac=[];prod=[F(1)];sf=[F(1)]
    for f in c['squarefree_factors']:
        a=list(reversed([F(x) for x in f['coefficients']]));m=f['multiplicity']
        assert a[-1]==1 and type(m) is int and m>=1 and gcd(a,derivative(a))==[1]
        assert all(gcd(a,b)==[1] for b,mm in fac)
        fac.append((a,m));sf=mul(sf,a)
        for _ in range(m):prod=mul(prod,a)
    assert prod==p
    roots=[];counts=[0]*len(fac);sequences=[sturm(a) for a,m in fac]
    for z in c['intervals']:
        j=z['factor'];a,b=F(z['a']),F(z['b']);f,m=fac[j];assert a<=b
        if a==b:assert ev(f,a)==0 and ev(derivative(f),a)!=0
        else:
            assert ev(f,a)!=0 and ev(f,b)!=0
            assert variations(sequences[j],a)-variations(sequences[j],b)==1
        counts[j]+=1;roots.append((a,b,m))
    assert counts==[len(a)-1 for a,m in fac]
    roots.sort();assert all(roots[i][1]<roots[i+1][0] for i in range(len(roots)-1))
    assert sum(m for a,b,m in roots)==n and roots[0][0]>=-kappa
    # Complete projectors: one pole per DISTINCT eigenvalue, energy multiplicity retained separately.
    degree=len(sf)-1;vectors=[list(map(F,row)) for row in T];mom=[]
    for j in range(degree):
        mom.append(sum(sum(F(x)*y for x,y in zip(row,v)) for row,v in zip(T,vectors)))
        vectors=[[sum(B[i][j]*v[j] for j in range(n)) for i in range(n)] for v in vectors]
    cc=list(reversed(sf));num=list(reversed([sum(cc[k]*mom[j-k] for k in range(j+1)) for j in range(degree)]))
    der=derivative(sf);private_lo=private_hi=contact_lo=F(0);wsum_lo=wsum_hi=F(0);details=[]
    for a,b,m in roots:
        wlo,whi=idiv(iev(num,(a,b)),iev(der,(a,b)))
        assert whi>=0;wlo=max(F(0),wlo);whi=min(mom[0],whi);assert wlo<=whi
        private_lo+=m*max(a,F(0))**2;private_hi+=m*max(b,F(0))**2
        contact_lo+=wlo*phi(a,kappa);wsum_lo+=wlo;wsum_hi+=whi
        details.append(dict(a=str(a),b=str(b),multiplicity=m,weight_lower=str(lower(wlo)),weight_upper=str(upper(whi))))
    assert wsum_lo<=mom[0]<=wsum_hi
    # Root reflection is a row permutation and must preserve ALL contact moments.
    reverse=[list(map(F,row)) for row in reversed(T)];v=[r[:] for r in reverse]
    for j in range(degree):
        assert sum(sum(x*y for x,y in zip(row,col)) for row,col in zip(reverse,v))==mom[j]
        v=[[sum(B[i][j]*u[j] for j in range(n)) for i in range(n)] for u in v]
    return dict(label=c['label'],roots=c['roots'],n_private=n,private_lower=str(lower(private_lo)),private_upper=str(upper(private_hi)),
      contact_filter_lower=str(lower(contact_lo)),total_lower=str(lower(private_lo+contact_lo)),
      total_lower_fraction=lower(private_lo+contact_lo),root_intervals=len(roots),multiplicity_total=n,
      min_eigenvalue_lower=str(roots[0][0]),contact_weight_sum=str(mom[0]),spectral_weights=details)

def rejection(f):
    try:f()
    except (AssertionError,IndexError,ValueError,ZeroDivisionError):return True
    raise AssertionError('Corrupt certificate accepted')
def main():
    path=HERE/'h21-filter-certificates.json';d=json.loads(path.read_text());g=d['graph'];n=g['n'];es={tuple(e) for e in g['edges']}
    assert n==21;prior.outer_graph(n,es,g['boundary']);A=[[F(0)]*n for _ in range(n)]
    for u,v in es:A[u][v]=A[v][u]=F(1)
    assert {tuple(c['roots']) for c in d['cases']}=={(u,(u+1)%n) for u in range(n)}
    original=Path(g['original_source']);assert hashlib.sha256(original.read_bytes()).hexdigest()==g['original_sha256']
    old=json.loads(original.read_text());assert es=={tuple(e) for e in old['edges']}
    Blist=[];checked=[]
    for c in d['cases']:
        u,v=c['roots'];private=[i for i in range(n) if i not in (u,v)]
        B=[[A[i][j] for j in private] for i in private];T=[[A[r][j] for j in private] for r in (u,v)]
        Blist.append((B,T));out=accept_case(c,B,T);assert out['total_lower_fraction']>F(d['strict_uniform_score']);checked.append(out)
    control=d['arithmetic_controls'][0];aux=accept_case(control,control['calibration_matrix'],control['calibration_contacts'])
    assert aux['total_lower_fraction']==F(21,2) and aux['contact_filter_lower']=='5/2'
    assert phi(F(3,2))==0 and phi(F(3))==1 and phi(F(0))==0
    damaged=copy.deepcopy(d['cases'][0]);damaged['intervals'].pop()
    mult=copy.deepcopy(d['cases'][0]);mult['squarefree_factors'][0]['multiplicity']+=1
    wrong=copy.deepcopy(d['cases'][0]);wrong['intervals'][0]['a']='-1000';wrong['intervals'][0]['b']='-999'
    negatives=dict(missing_root=rejection(lambda:accept_case(damaged,*Blist[0])),wrong_multiplicity=rejection(lambda:accept_case(mult,*Blist[0])),
      false_root_interval=rejection(lambda:accept_case(wrong,*Blist[0])),wrong_actual_roots=rejection(lambda:accept_case(d['cases'][0],*Blist[3])),
      inflated_score=rejection(lambda:(_ for _ in ()).throw(AssertionError()) if min(x['total_lower_fraction'] for x in checked)<=100 else None))
    minimum=min(x['total_lower_fraction'] for x in checked);under=[x['roots'] for x in checked if F(x['private_upper'])<38]
    for out in checked:out.pop('total_lower_fraction')
    aux.pop('total_lower_fraction')
    report=dict(status='PASS_EXACT_H21_ALL_ROOTS_UNIVERSAL_FILTER_SCORE',cases=21,ordered_orientations=42,kappa='3',private_vertices=19,
      strict_uniform_gain='>40',minimum_certified_score=str(minimum),private_only_underpay_roots=under,all_cases=checked,
      repeated_positive_zero_control=aux,damaged_rejected=negatives,
      fixture_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
      theorem='For EVERY old unitMOP boundaryroot and EVERY one of21H21boundary choices/coherent reflection, actual19vertexgraft gains>40; no fullQphase assumption',
      original_global_status='OPEN; no allMOP selector/coverage',external_formal_audit=False)
    (HERE/'h21-filter-reader-check.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k not in ('all_cases','repeated_positive_zero_control')}))
if __name__=='__main__':main()
