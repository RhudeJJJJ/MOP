from pathlib import Path
import hashlib,json,time,shutil
from fractions import Fraction as F
import all_mass_dp as polygons
import masked_dp
from run_preflight import payment
P=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def atomic(p,v):
    t=p.with_suffix('.tmp');t.write_text(json.dumps(v,separators=(',',':'))+'\n');t.replace(p)
def main():
    start=time.monotonic();targets=json.loads((P/'targets.json').read_bytes());rows=targets['rows'];assert len(rows)==130
    assert len({(r['n'],r['d'],r['C'],r['k'],r['l'])for r in rows})==130
    groups=sorted({(r['d'],r['C'])for r in rows},reverse=True);assert len(groups)==29
    groups.remove((31,31));groups.insert(0,(31,31))
    assert json.loads((P/'mask-small-check.json').read_bytes())['distinct_parameter_mask_maxima']==144
    for name,h in targets['source_sha256'].items():assert sha(P/'inputs'/name)==h
    names=['all_mass_dp.py','masked_dp.py','check_mask_small.py','mask-small-check.json','masked-proof.md','prepare_targets.py','run_preflight.py','targets.json','kernel-lineage.json','preflight-inputs.json','preflight-result.json','full-masked-proof.md','run_all_masked.py']+['inputs/'+name for name in targets['source_sha256']]
    hashes={n:sha(P/n)for n in names};frozen=P/'full-inputs.json'
    if frozen.exists():assert json.loads(frozen.read_bytes())==hashes
    else:atomic(frozen,hashes)
    free=shutil.disk_usage(P).free;assert free-16*1024**2>8*1024**3;atomic(P/'full-write-plan.json',dict(explicit_sources=names,input_raw_bytes=sum((P/n).stat().st_size for n in names),maximum_additional_result_raw_bytes=16*1024**2,free_before=free,reserve_bytes=8*1024**3,no_archive_or_database_write=True))
    completed=[]
    for d,C in groups:
        selected=[r for r in rows if r['d']==d and r['C']==C];K=max(r['k']for r in selected);L=max(r['l']for r in selected);path=P/f'full-d{d}-C{C}.json'
        if path.exists():
            saved=json.loads(path.read_bytes());assert saved['targets']==selected and saved['source_sha256']==hashes
        elif(d,C)==(31,31):
            pre=json.loads((P/'preflight-result.json').read_bytes());assert pre['status']=='PASS_EXACT_MASKED_ALL_MASS_D31_C31_TWO_REQUIRED_DOMAINS'
            assert [r['target']for r in pre['checks']]==selected and all(sha(P/n)==h for n,h in pre['source_sha256'].items())
            saved=dict(d=d,C=C,K=K,L=L,targets=selected,checks=pre['checks'],source_sha256=hashes,origin='REUSED_ACTUAL_SOURCE_BOUND_PREFLIGHT_NO_RECOMPUTATION');atomic(path,saved)
        else:
            t=time.monotonic()
            def progress(i,count):
                if i%10==0:print(json.dumps(dict(status='EXACT_FULL_MASKED_PROGRESS',d=d,C=C,index=i,states=count,group_seconds=time.monotonic()-t,total_seconds=time.monotonic()-start)),flush=True)
            print(json.dumps(dict(status='EXACT_FULL_MASKED_GROUP_STARTED',d=d,C=C,K=K,L=L,targets=len(selected))),flush=True)
            T=polygons.polygons(K+2,C);result,layers=masked_dp.chain(d,C,K,L,T,progress);checks=[]
            for r in selected:
                M=result.get((r['k'],r['l'],0))
                if r['M2_R']is None:
                    assert M is None,(r,M);checks.append(dict(target=r,actual_mask0_maximum=None,payment='VACUOUS_NO_ADMITTED_MASK0_GRAPH'));continue
                assert M is not None
                if r['comparison']=='EXACT_SAME_MASK0_DOMAIN':assert M==r['M2_R'],(r,M)
                else:assert M<=r['M2_R'],(r,M)
                gain,required=payment(r,M);assert gain>0
                if r['comparison']=='EXACT_SAME_MASK0_DOMAIN':assert gain==F(r['margin'])
                else:assert required<=0 or gain>=F(r['margin'])
                checks.append(dict(target=r,actual_mask0_maximum=M,required=str(required),positive_payment_indicator=str(gain)))
            saved=dict(d=d,C=C,K=K,L=L,targets=selected,checks=checks,source_sha256=hashes,origin='FRESH_INTEGER_ALL_MASS_FULL_MASK_COMPUTATION',layer_state_counts=layers,terminal_parameter_masks=len(result),seconds=time.monotonic()-t);atomic(path,saved)
        assert all(sha(P/n)==h for n,h in hashes.items())
        completed.append(dict(d=d,C=C,result_file=path.name,result_sha256=sha(path),checks=saved['checks'],origin=saved['origin']))
        print(json.dumps(dict(status='PASS_EXACT_MASKED_NEEDED_GROUP',d=d,C=C,rows=len(selected),total_checked=sum(len(r['checks'])for r in completed),seconds=time.monotonic()-start)),flush=True)
    assert len(completed)==29 and sum(len(r['checks'])for r in completed)==130
    out=dict(status='PASS_FRESH_ALL130_CAPPED_AND_RESTRICTED_MASK0_MAXIMA_AND_ACTUAL_PAYMENTS',target_rows=130,capped_rows=125,restricted_rows=5,groups=29,results=completed,source_sha256=hashes,seconds=time.monotonic()-start,scope='Every actual UNIT graph in these capped/restricted parameter domains with no dominating triangle through its hub has F>2n, or its exact domain is empty. Dominating-triangle and high-second-hub complements, other finite stages and original unbounded work remain separate.',original_global='OPEN',native_intake='PENDING')
    atomic(P/'full-masked-result.json',out);print(json.dumps({k:v for k,v in out.items()if k not in ['source_sha256','results']},indent=2))
if __name__=='__main__':main()
