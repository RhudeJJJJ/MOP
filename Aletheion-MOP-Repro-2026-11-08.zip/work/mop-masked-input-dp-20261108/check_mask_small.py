from pathlib import Path
from functools import lru_cache
from math import comb
import json
import all_mass_dp as polygons
import masked_dp as dp
P=Path(__file__).resolve().parent
@lru_cache(None)
def family(a,b):
    if b==a+1:return(frozenset([(a,b)]),)
    return tuple(left|right|{(a,b)}for c in range(a+1,b)for left in family(a,c)for right in family(c,b))
def main():
    observed={};graphs=roots=presentations=0
    for n in range(3,10):
        cases=family(0,n-1);assert len(cases)==len(set(cases))==comb(2*(n-2),n-2)//(n-1)
        for edges in cases:
            assert len(edges)==2*n-3;N=[set()for _ in range(n)]
            for x,y in edges:N[x].add(y);N[y].add(x)
            graphs+=1;maximum=max(map(len,N))
            for v in range(n):
                d=len(N[v])
                if d!=maximum:continue
                roots+=1;minimum_cap=max(len(N[w])for w in range(n)if w!=v)
                neighbors=sorted(N[v],key=lambda w:(w-v)%n);masses=[(y-x)%n-1 for x,y in zip(neighbors,neighbors[1:])];k=n-d-1;l=sum(m>0 for m in masses);assert sum(masses)==k
                mask=0
                for j,(x,y)in enumerate(zip(neighbors,neighbors[1:])):
                    covered={v,x,y}|N[v]|N[x]|N[y]
                    if len(covered)==n:mask|=1<<j
                moment=sum((len(N[w])-int(w in N[v]))**2 for w in range(n)if w!=v)
                for C in range(minimum_cap,d+1):
                    key=d,C,k,l,mask;observed[key]=max(observed.get(key,-1),moment);presentations+=1
    checked=0;empty=0
    for d in range(2,9):
        for C in range(2,d+1):
            K=8-d;T=polygons.polygons(K+2,C);actual,layers=dp.chain(d,C,K,d-1,T)
            expected={(k,l,mask):value for(dd,cc,k,l,mask),value in observed.items()if dd==d and cc==C}
            assert actual==expected,(d,C,actual,expected)
            checked+=len(actual);empty+=not actual
    assert graphs==625 and roots==896
    out=dict(status='PASS_MASKED_ALL_MASS_ALL_CAPS_FULL_CANDIDATE_MASKS_COMPLETE_POLYGONS_n3_TO9',graphs=graphs,max_degree_root_choices=roots,root_cap_presentations=presentations,distinct_parameter_mask_maxima=checked,empty_degree_cap_domains=empty,scope='Actual full graph domination masks and residual degrees compared for every capped root; all-order interface proof remains required',original_global='OPEN')
    (P/'mask-small-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
