"""Full candidate-triangle masks and an actual nonhub degree cap."""
def chain(d,C,K,L,T,progress=None):
    assert 2<=C<=d
    all_pairs=(1<<(d-1))-1;states={(0,0,0,all_pairs):0};choices={0:[(1,1,0)]};layers=[]
    for m in range(1,K+1):choices[m]=[(r,s,x)for(r,s),x in T[m+2].items()]
    for position in range(1,d):
        base=1 if position==1 else 2;out={}
        for(used,gaps,pending,mask),score in states.items():
            for m in range(K-used+1):
                g=gaps+int(m>0)
                if g>L:continue
                for r,s,inside in choices[m]:
                    degree=base+pending+(r-1 if m else 0)
                    if degree>C-1:continue
                    next_mask=mask
                    if m:
                        allowed=0
                        if position>1 and r==m+1:allowed|=1<<(position-2)
                        if r+s==m+3:allowed|=1<<(position-1)
                        if position<d-1 and s==m+1:allowed|=1<<position
                        next_mask&=allowed
                    key=(used+m,g,s-1 if m else 0,next_mask);value=score+degree*degree+inside
                    if value>out.get(key,-1):out[key]=value
        states=out;layers.append(len(states))
        if progress:progress(position,len(states))
    result={}
    for(used,gaps,pending,mask),score in states.items():
        degree=1+pending
        if degree>C-1:continue
        key=(used,gaps,mask);value=score+degree*degree
        if value>result.get(key,-1):result[key]=value
    return result,layers
