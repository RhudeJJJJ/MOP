# Complete actual capped and restricted finite-input reconstruction

8 November2026. ORIGINAL GLOBAL OPEN; goal ACTIVE. Complete acceptance
requires all130 targets, not a preflight or partially completed groups.

The exact geometric candidate-mask and nonhub-cap proof is masked-proof.md.
All625 polygon triangulations n3..9,896 maximum-root choices and1627
root/cap presentations have passed full actual-mask comparison, including
144 distinct parameter/mask maxima and6 empty degree/cap domains.
The d31,C31 preflight has separately reconstructed the required n60 and
n61 cases with maxima1216 and1280 and exact positive energy payments.
Reuse only those actual source-bound results; do not recompute them merely
because the full target set is now being processed.

1. The exact original target set.

targets.json is reconstructed from the COMPLETE13 actual original input
files, with their full raw snapshots and hashes. It contains125 capped
profiles n63..71 and five restricted profiles n60..63. Every tuple
(n,d,C,k,l) is distinct, n=d+k+1, and2<=C<=d. The capped set uses the
actual second-hub degree cap C<d. The restricted set uses C=d. There
are29 distinct(d,C) groups. The full source/hash set is frozen before
any group runs. This is neither all possible graphs nor all original
finite-cover inputs; it is exactly these still-needed conditional classes.

At fixed(d,C), choose K=max target k and L=max target l. The all-mass,
all-gap dynamic program retains the exact candidate-triangle mask and
pending residual endpoint increment. Polygon interiors are capped by C;
completed hub-neighbor residual degrees are capped by C-1. Its final
mask0 maximum therefore bounds EVERY original graph in that target
class with NO dominating triangle through its actual hub v.

2. Exact maximum and actual energy, including the different n60 domain.

For every target require the fresh mask0 maximum to equal the old
recorded maximum. If there is no admitted mask0 state, require that
the old recorded maximum is also absent; this is a vacuous conditional
class, not a graph counterexample.

ONLY the n60 target permits a smaller maximum: its older bound1216
covered a BROADER class with no adjacent shared-fan pair. Any graph
without a dominating triangle through v belongs to that broader class,
so the exact mask0 maximum<=1216 suffices. The preflight actually found
equality1216. Do not interpret a stricter-domain improvement as a
refutation of the broader-domain old maximum.

For each nonvacuous target recompute the rational PSD residual moment
and hub-compression payment from the FRESH M2(R) maximum. The formulas
are the same actual graph identities and elementary PSD/compression
argument written in full-positive-proof.md of the unmasked package:
mu2(R)=2(d-1+2k), mu3=6k, mu4<=2M2(R)-2(d-1+2k)+8(k-l),
S<=k+3l and h=(d-1)/d. A positive squared hub margin, or a
nonpositive required term, proves the ORIGINAL F(G)>2n on that actual
conditional graph class. Every stored positive rational margin must
match exactly, except that the smaller allowed n60 bound may improve it.

3. What this completes and what it does not.

After terminal acceptance, all125 capped and5 restricted mask0 finite
inputs are reconstructed with their original quantitative payment.
The separate classes with a dominating triangle through v are paid by
the existing n>=60 dominating-triangle theorem; its source and exact
allocation remain separate obligations. For C<d, graphs escaping the
nonhub cap need their existing high-second-hub pair/core payment.
Neither of those complements is inferred merely from mask0 acceptance.

The original unbounded parent-family calculations and other original
finite stages also remain distinct. No arbitrary weighted extension,
global conclusion, first-priority or independent human/formal audit is
claimed. Native intake, complete source export and a portable mathematical
replay are separate from the original terminal integer computation.
