from pathlib import Path
from fractions import Fraction as F
import hashlib,json,time
import all_mass_dp as polygons
import masked_dp
P=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def payment(r,M):
    d,k,l=r['d'],r['k'],r['l'];x=F(r['shift']);m=d-1+2*k
    mu2=2*m;mu3=6*k;mu4=2*M-2*m+8*(k-l)
    den=mu4+4*x*mu3+6*x*x*mu2+(d+k)*x**4;assert den>0
    q=(mu3+2*x*mu2)**2/den-(d+k-1);h=F(d-1,d);required=k+5+F(2*(k+3*l),d)-F(6,d*d)-q
    margin=F(1)if required<=0 else 4*h*h*(d+h*h)-required*required
    return margin,required
def main():
    start=time.monotonic();v=json.loads((P/'targets.json').read_bytes());assert len(v['rows'])==130
    assert json.loads((P/'mask-small-check.json').read_bytes())['status']=='PASS_MASKED_ALL_MASS_ALL_CAPS_FULL_CANDIDATE_MASKS_COMPLETE_POLYGONS_n3_TO9'
    selected=[r for r in v['rows']if r['d']==r['C']==31];assert [(r['n'],r['k'],r['l'])for r in selected]==[(60,28,2),(61,29,3)]
    names=['all_mass_dp.py','masked_dp.py','check_mask_small.py','mask-small-check.json','masked-proof.md','prepare_targets.py','run_preflight.py','targets.json','kernel-lineage.json']+['inputs/'+n for n in v['source_sha256']]
    hashes={n:sha(P/n)for n in names};frozen=P/'preflight-inputs.json'
    if frozen.exists():assert json.loads(frozen.read_bytes())==hashes
    else:frozen.write_text(json.dumps(hashes,indent=2)+'\n')
    def progress(i,count):
        if i%5==0:print(json.dumps(dict(status='EXACT_MASKED_PREFLIGHT_PROGRESS',d=31,C=31,index=i,states=count,seconds=time.monotonic()-start)),flush=True)
    T=polygons.polygons(31,31);result,layers=masked_dp.chain(31,31,29,3,T,progress);checks=[]
    for r in selected:
        M=result.get((r['k'],r['l'],0));assert M is not None
        if r['comparison']=='EXACT_SAME_MASK0_DOMAIN':assert M==r['M2_R']
        else:assert M<=r['M2_R']
        gain,required=payment(r,M);assert gain>0
        if r['comparison']=='EXACT_SAME_MASK0_DOMAIN':assert gain==F(r['margin'])
        else:assert required<=0 or gain>=F(r['margin'])
        checks.append(dict(target=r,actual_mask0_maximum=M,required=str(required),positive_payment_indicator=str(gain)))
    assert all(sha(P/n)==h for n,h in hashes.items())
    out=dict(status='PASS_EXACT_MASKED_ALL_MASS_D31_C31_TWO_REQUIRED_DOMAINS',checks=checks,source_sha256=hashes,layer_state_counts=layers,terminal_parameter_masks=len(result),seconds=time.monotonic()-start,original_global='OPEN',full130_inputs='NOT_COMPLETED_BY_THIS_PREFLIGHT')
    (P/'preflight-result.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in ['source_sha256','layer_state_counts']},indent=2))
if __name__=='__main__':main()
