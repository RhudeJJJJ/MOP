# Exact nonhub caps and the complete candidate-triangle mask

8 November2026. ORIGINAL GLOBAL OPEN; goal ACTIVE. Method only until
the actual targeted maxima and energy payments pass in full.

Let v be an actual maximum-degree hub of degree d. Its d neighbors
x1,..,xd form a path, and gaps are numbered i1..d-1. Every triangle
through v uses exactly the consecutive pair xj,x(j+1). The candidate
mask has one bit for each j; initially all bits are present.

For a NONEMPTY gap i of mass m and its ordered boundary degrees r,s,
interior vertices can see no hub neighbor except the two gap roots.
A candidate triangle can dominate that gap only in three cases:

* j=i-1: all gap vertices must see the left root, exactly r=m+1;
* j=i: all must see at least one root, exactly r+s=m+3;
* j=i+1: all must see the right root, exactly s=m+1.

The outside-index cases are omitted. The middle equality follows because
there is exactly ONE vertex adjacent to both ends of the boundary edge
in the gap: it is the third vertex of its incident face. Thus endpoint
degree sum minus2 counts gap-root incidences, at most m+1; equality
m+1 holds iff every gap vertex is seen. No gap-internal triangulation
detail beyond(r,s) changes these predicates.

Intersect the old candidate mask with these permitted bits on every
nonempty gap. An empty gap imposes no restriction. All neighbors of v
are already dominated by v. Hence the FINAL mask is EXACTLY the set of
triangles through v dominating the whole graph. Mask0 is precisely the
absence of such a triangle, not the absence of every dominating set or
of a dominating triangle elsewhere.

If every original nonhub vertex has degree<=C<=d, use internal cap C
in the Catalan polygon table and require each completed hub-neighbor
RESIDUAL degree<=C-1, since it also has its edge to v. Keep the full
state(used mass,gap count,pending endpoint increment,exact mask).
For the same state/layer all future choices and degree/mask effects
coincide. Retaining the largest score is exact; combining different
masks or checking only whether the mask is currently empty is not used.
All masses and gap counts up to the declared K,L can be computed at
once because both counts are nondecreasing. The final endpoint square
is scored once. The all-size Catalan decomposition proof is the same
one preserved in the unmasked source; the cap and mask refinements
retain all information relevant to future feasibility.

The independent small controller enumerates every625 triangulations
n3..9 and every maximum-degree hub, constructs actual vertex neighborhoods
and every candidate triangle's domination set, and tests ALL nonhub caps
from2 to d. It compares complete degree/mass/gap/MASK maxima, including
empty cap domains. This calibrates the written exact proof, not an
all-order inference from samples.

The original finite inputs to be reconstructed are125 capped profiles
n63..71 plus five restricted profiles at n60..63. A nonzero final mask
is handled ONLY by the already written dominating-triangle theorem for
ALL n>=60; its large-order proof does not need the older8..59 energy
base. That original proof and its exact split-fan allocation still need
their proper source checks. A capped mask0 case also needs its separate
high-second-hub complement; this method alone does not pay that complement.

The n60 old bound1216 used the broader class with no adjacent shared-fan
pair. Mask0 is a SUBCLASS, so a fresh maximum<=1216 suffices there; a
strictly smaller value would not refute the old broader-class maximum.
For the other recorded mask0 inputs the actual domains coincide and
exact maximum identity is required. No energy counterexample follows
merely from an optimizer discrepancy. Full original closure, all finite
cover stages, high-second-hub kernels and unbounded parent payments are
not claimed by this method note.
