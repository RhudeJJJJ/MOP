from pathlib import Path
import hashlib,json,shutil
P=Path(__file__).resolve().parent;ROOT=P.parent.parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    sources={};rows=[]
    def read(name):
        data=(ROOT/name).read_bytes();sources[name]=data;return json.loads(data)
    for n in range(63,72):
        name=f'order{n}-'+('second-hub-cap30-verification.json'if n<=65 else'adaptive-second-hub-caps-verification.json'if n<=68 else'adaptive-second-hub-caps-probe.json');v=read(name)
        for key,r in v['profiles'].items():
            d,k,l=r['d'],r['k'],r['l'];assert d+k+1==n and key==f'{d},{k},{l}'and r['positive_payment']
            C=r.get('second_hub_cap',v.get('second_highest_degree_cap'));assert 2<=C<d
            M=r.get('capped_M2_R',r.get('maximum_M2_R'))
            shift=v['shift']if n==63 else r.get('best_shift')
            margin=r['hub_squared_margin']if n==63 else r.get('squared_margin')
            assert M is None or shift is not None and margin is not None
            rows.append(dict(n=n,d=d,C=C,k=k,l=l,M2_R=M,shift=shift,margin=margin,comparison='EXACT_SAME_MASK0_DOMAIN',kind='capped',source=name))
    assert len(rows)==125
    for n in [60,61,62]:
        name=f'order{n}-repaired-cover-verification.json';v=read(name)
        for r in v['rows']:
            if r['rule']not in ['hub_triangle_or_restricted_exact_dp','shared_fan_dominating_triangle_or_restricted_dp']:continue
            d,k,l=r['maximum_degree'],r['nonneighbors'],r['nonempty_gaps'];assert n==d+k+1
            rows.append(dict(n=n,d=d,C=d,k=k,l=l,M2_R=r['restricted_M2_R_exact_max'],shift=r['shift'],margin=r['restricted_squared_margin'],comparison='UPPER_BOUND_BROADER_OLD_NO_SHARED_FAN_DOMAIN'if n==60 else'EXACT_SAME_MASK0_DOMAIN',kind='restricted',source=name))
    name='order63-partial-repair-verification.json';r=read(name)['newly_paid_profile'];d,k,l=r['d'],r['k'],r['l'];assert d+k+1==63
    rows.append(dict(n=63,d=d,C=d,k=k,l=l,M2_R=r['non_dominating_M2_R_upper'],shift=r['shift'],margin=r['positive_squared_margin'],comparison='EXACT_SAME_MASK0_DOMAIN',kind='restricted',source=name))
    assert len(rows)==len({(r['n'],r['d'],r['C'],r['k'],r['l'])for r in rows})==130
    raw=sum(map(len,sources.values()));free=shutil.disk_usage(P).free;assert raw<8*1024**2 and free-raw-16*1024**2>8*1024**3
    for name,data in sources.items():
        assert sha(ROOT/name)==hashlib.sha256(data).hexdigest();dst=P/'inputs'/name;dst.parent.mkdir(exist_ok=True)
        if dst.exists():assert dst.read_bytes()==data
        else:dst.write_bytes(data)
    out=dict(format='masked-finite-input-targets-v1',rows=rows,source_sha256={name:hashlib.sha256(data).hexdigest()for name,data in sources.items()},original_global='OPEN',scope='125 capped mask0 domains and5 restricted domains. Nonzero masks and high-second-hub complements remain separate; n60 permits a smaller bound because the new domain is a subclass.')
    dest=P/'targets.json'
    if dest.exists():assert json.loads(dest.read_bytes())==out
    else:dest.write_text(json.dumps(out,indent=2)+'\n')
    (P/'target-write-plan.json').write_text(json.dumps(dict(explicit_original_sources=list(sources),input_raw_bytes=raw,free_before=free,max_additional_proof_raw_bytes=16*1024**2),indent=2)+'\n')
    print(json.dumps(dict(status='PREPARED_ALL130_ACTUAL_MASKED_ORIGINAL_INPUT_TARGETS',targets=130,groups=len({(r['d'],r['C'])for r in rows}),source_files=len(sources),raw_bytes=raw)))
if __name__=='__main__':main()
