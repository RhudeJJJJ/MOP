# The universal path trace weight is a single ray

5 November2026. ORIGINAL EVERY finite simple UNIT maximal outerplanar
G,n>=8,F(G)=splus(G)>=2n remains GLOBAL OPEN / goal ACTIVE. This note
closes a precise auxiliary characterization in the current branch attack;
it does not prove universal Fork6 or the original global conjecture.
No external formal audit, worldwide priority or full-corpus claim.

## 1. Keep the exact physical cap and its state

Use the SAME external/external twofan cap p,q>=1, private path B=P_k,
k=p+q+1, contact rows T=prefix0..p and suffixp..k-1. It attaches at an
actual ordered old MOP boundary ab, retaining ab, and has NO other
private contacts. The fixed auxiliary matrix C has orderk+1, unit
path offdiagonal, endpoint diagonal1, and all other diagonal entries0.
Set

 W=(e_(p+1)-e0,e_k-e_p), V=W/sqrt2,
 S_(p,q)(t)=V^t(tI+iC)^-1V,
 K=2I+J=[[2,1],[1,2]], Ki=K^-1=(1/3)[[2,-1],[-1,2]].

The completed normalization proves V^tV=I and
Fcap=T(tI+iB)^-1T^t=(TT^t+2iS)/(t+2i). The recently completed
weighted-trace theorem proves, for ALL p,q>=1 and ALL t>0,

                    -Im Tr(Ki S_(p,q)(t))>=0.          (1)

Every actual private coordinate and zero mode is retained. C and S are
auxiliaries of the SAME physical cap, never a substitute graph energy.

## 2. Exact target, including the constant-metric quantifier

Fix ONE constant REAL SYMMETRIC2by2 matrix M, independent of p,q,t
and the old parent. No positivity assumption on M is needed initially.

THEOREM. The following are equivalent:

 (A) -ImTr(M S_(p,q)(t))>=0 for EVERY p,q>=1 and EVERY t>0;
 (B) M=r Ki for some real r>=0.                        (2)

Thus the cone of universal CONSTANT real symmetric trace weights is
exactly ONE ray. This is more precise than saying that a particular
choice I or one contrast direction fails. It does not restrict a metric
depending on lengths, frequency or the actual old parent. Such choices
still need their own valid sign and support arguments. No uniqueness
of graph, response, PSD completion or energy proof is claimed.

## 3. Four actual states force the ray

For (p,q)=(4,3),(3,4),(1,4),(4,1), respectively, C is invertible.
The exact determinants are2,2,-2,-2. Therefore its resolvent and S
are continuous down to t0, and

 lim_(t down0)(-ImS)=V^t C^-1 V=Wt C^-1 W/2.

Complete exact solves C X=W give the four limit matrices

 Q43=[[-1/2,-1/2],[-1/2,0]],
 Q34=[[0,-1/2],[-1/2,-1/2]],
 Q14=[[1,1/2],[1/2,-1/2]],
 Q41=[[-1/2,1/2],[1/2,1]].                            (3)

These are four genuine length states of the literal unit cap. Taking
limits of (A) is licensed by the verified invertibility. It does NOT
silently extend a hypothesis to a singular endpoint or discard a pole.

Write M=[[a,c],[c,b]]. The four inequalities Tr(MQ)>=0 are

  -a/2-c>=0, -b/2-c>=0,
   a-b/2+c>=0, -a/2+b+c>=0.                           (4)

Adding the first and fourth gives b-a>=0. Adding the second and third
gives a-b>=0. Thus a=b. Equations (4) now force c=-a/2, so M=(3a/2)Ki.

It remains to determine the sign of a; the limit matrices alone permit
either sign. Use the actual Fork state p=q1 at t1, where a separate
complete rational solve gives

                 -ImS_(1,1)(1)=[[1,1],[1,1]]/6.

Then (A) reads a/6>=0. Hence a>=0 and r=3a/2>=0. Conversely (1)
immediately proves (A) for every such r. This proves the ENTIRE
equivalence, including the zero metric and possible indefinite starting
metrics. The all-length sufficiency uses the completed GF/cone theorem;
five finite states supply all the necessary restrictions.

## 4. Positive-frequency counters prevent stronger sign claims

The new scalar trace sign must not be promoted to ImS<=0. At the actual
state p4,q3 and rational t1/10, full required resolvent columns give
Q=-ImS with TrQ<0 and detQ<0. Thus even the identity trace weight fails,
and the full matrix Q is indefinite. At the state p1,q4,t1/10, with
Pminus=[[1,-1],[-1,1]]/2, the exact value Tr(Pminus Q)<0. Therefore a
universal sign on the contrast direction fails as well. Both SAME states
still satisfy Tr(Ki Q)>0, as (1) requires.

An earlier contrast-polynomial proposal found two negative initial jets.
That arithmetic alone would not refute a positive function on x>0.
Here the rational positive-frequency column solve independently proves
the actual negative contrast. For reference its numerator from the
cofactor route is -1+5x+2x^2, which is negative at x1/100; this observation
is not used instead of the direct complete solve.

No accepted earlier theorem asserted either stronger matrix sign. No
existing true result or stored source is revoked. The new counters qualify
how (1) may be used. They are not original graph-energy counterexamples.

## 5. Full state and whole-graph evidence

The producer gives rational columns C^-1W for all four nonsingular limit
states, and (tI+iC)^-1W for the two positive-frequency counters and the
Fork calibration. The separate stdlib reader rebuilds every actual C,W,
computes detC by exact Bareiss elimination, and verifies EVERY row of
EVERY required column. This certifies the needed complete matrix solves;
it does not claim that unlisted inverse columns were delivered.

The reader also reconstructs the private unit path B, actual prefix/suffix
T and incidence D. It checks D^tD=2I-B, 2I-DD^t=C, DB=CD, DT^t=W and
W^tW=2I entrywise. Thus (3) is tied to the actual cap state, not to an
unrealizable free2by2 example. All five caps are grafted literally onto
the SAME old8vertex fan at ordered boundary0,1; the resulting original
unit MOP orders are16,16,14,14,11. The reader checks the entire outer
polygons, actual private closedness and every edge. Complete integer PSD
Gram witnesses on all rows prove F(old)>16 and F(new)>2n in every case,
with the ENTIRE squared Frobenius norm. No projected or quotient energy
is transferred to these graphs. The two reversed length states are kept
as distinct ordered grafts; no equality of actual gains is inferred.

A corrupted limit column, wrong actual contact and omitted state are
rejected. Numerical scouts are discovery only. The initial contrast
producer failed on representing a zero polynomial and was corrected to
retain [0]; no false all-length contrast proof was accepted. Independent
readers and native readback are not external human/formal verification.

## 6. Exact effect on the unchanged global attack

The original all-MOP2n target, universal integrated Fork6, full external-
branch nonnegative UB and whole-sequence debt compensation remain OPEN.
The previously proved universal branch debt194/157 and long-arm1156,
including their conditional global ledger/front boundary, remain valid.

This theorem removes one concrete proposed freedom: another CONSTANT
real symmetric trace weight cannot replace Ki while retaining its sign
for ALL new twofan lengths and frequencies. The root metric used by the
current support estimate is forced by actual small-cap geometry.
Frequency/parent-sensitive information and actual noncrossing old pockets
remain available. The next global work should use that additional physical
old-parent structure or integrated compensation, rather than infer a
matrix/contrast sign or optimize an invalid fixed trace metric.

The retained205/206 exact NONMOP Fork counters already satisfy strict
all-frequency root sectors and several original local root data. Those
sources were reread in this attack. Merely combining the new path trace
sign with those old sectors therefore still lacks the full original
noncrossing-pocket contract; no claim that all such enlarged models meet
Fork6 is restored. Their known energy counterexamples are ONLY to helpers,
and do not decide the original UNIT MOP conjecture.

A bounded fresh online check reread the original arXiv v1 target and
found no usable resolving primary theorem in its returned results. It
is not an exhaustive proof of literature absence or priority. The local
mathematical status remains GLOBAL OPEN; no goal completion, automatic
entry-size repair, complete Drive/corpus delivery, background or subagent
work is claimed.
