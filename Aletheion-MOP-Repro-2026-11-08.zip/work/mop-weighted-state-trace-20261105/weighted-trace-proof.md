# A weighted state trace improves the universal branch debt

5 November2026. ORIGINAL unchanged: every finite simple UNIT maximal
outerplanar graph G,n>=8 has F(G)=splus(G)>=2n. GLOBAL OPEN / goal ACTIVE.
This is an all-length trace theorem and a sharper universal increment,
with a conditional global ledger consequence at the named B71 boundary.
It does not prove universal nonnegative Fork6, UB or global compensation.
No external formal audit, literature priority or full-corpus claim.

## 1. The actual cap and the fixed auxiliary state

At ANY ordered actual boundary ab of ANY old UNIT MOP H,order>=3,
retain ab and graft the external/external twofan branch with p,q>=1.
In long-arc private order0,...,k-1,k=p+q+1, B is the UNIT path,
and the contact rows of T are prefix0..p and suffixp..k-1. The shared
vertex at indexp is the branch center. All private outside contacts are
absent. There are k new vertices and2k new unit edges. Let

 J=[[0,1],[1,0]], K=2I+J, Ki=K^-1=(1/3)[[2,-1],[-1,2]],
 G=TT^t=[[p+1,1],[1,q+1]], E=diag(p-1,q-1)>=0.

The completed two-dipole normalization theorem gives ONE fixed
Neumann-path matrix C of orderk+1, with offdiagonal1 and endpoint
diagonal1, and columns

 W=(e_(p+1)-e0, e_k-e_p), V=W/sqrt2, V^tV=I,
 S=V^t(tI+iC)^-1V, Fcap=T(tI+iB)^-1T^t,
 Fcap=(G+2iS)/(t+2i), Fstar=(K+2iS)/(t+2i).

C,V are unchanged at all t>0; spectrumC is in(-2,2]. Fstar is a SIGNED
algebraic normalization, not an actual graph or assigned an energy.
The original H and actual new G remain the physical energy objects.
Zero eigenvalues are retained in the complete matrices.

THEOREM A, new weighted trace sign, for ALL p,q>=1 and ALL t>0:

                  Im Tr(Ki S(t)) <=0.                 (1)

This differs from the already proved ImFstar<=0. Neither sign is
asserted for a generic OLD normalized MOP response or arbitrary isometry.

THEOREM B, new universal increment for the SAME actual cap:

               F(new)-F(H)>2k-194/157>2k-31/25.       (2)

There is NO old order, degree or norm upper bound. In particular actual
old reserve F(H)-2|H|>=194/157 pays the WHOLE new graph. This is still
a possibly negative increment surplus; it is not universal UB.

## 2. Exact finite numerator with an all-index generating function

Let D0=1,D1=t,D_n=tD_(n-1)+D_(n-2), D_-1=0. These are the positive
real determinants det(tI+iP_n). Set U_-1=0 and

 U_p=sum_(r=0)^p (-i)^r D_(p-r),
 sum_(p>=0)U_p z^p =1/[(1+iz)(1-tz-z^2)].             (3)

The actual private cofactor formula, for i<=j, is

 [(tI+iB)^-1]_ij=(-i)^(j-i)D_i D_(k-j-1)/D_k.

Let u_a,u_b be the two actual contact indicator columns. For allp,q>=1,

 (2I-B)u_a=e0+e_p-e_(p+1),
 (2I-B)u_b=e_(k-1)+e_p-e_(p-1).

Since (t+2i)(tI+iB)^-1=I+i(2I-B)(tI+iB)^-1,

 S=(1/2)T(tI+iB)^-1(2I-B)T^t.                       (4)

All factors commute where claimed because they are functions of B.
The right side is exactly the isometric state above, not another state.
Write its entries as S_aa=Naa/(2D_k), S_bb=Nbb/(2D_k),
S_ab=Nab/(2D_k). Summing the displayed cofactors gives

 Naa=2D_q U_p+D_(q-1)(U_(p-1)+iU_p),
 Nbb=2D_p U_q+D_(p-1)(U_(q-1)+iU_q),
 Nab=[(-i)^q+D_q]U_p-D_(q+1)U_(p-1)+iD_(p-1)D_q.    (5)

For example, the first term in Naa comes from
sum_(j=0)^p(-i)^j D_(p+q-j)
=D_qU_p+D_(q-1)U_(p-1), together with the other two dipole coordinates.
For Nab split the sum at p-1 before adding the p-coordinate. These
identities keep every contact and both directions of the cross term.
Symmetry of (4) proves the reflected form of Nab as well.

Define the REAL integer polynomial

 n_(p,q)(t)=-Im(Naa+Nbb-Nab), nu=k mod2,
 R_(p,q)(x)=n_(p,q)(t)/t^nu, x=t^2,
 d_k(x)=D_k(t)/t^nu.

Parity of the actual path cofactors shows this is a polynomial in x.
The exact trace formula is

              -ImTr(Ki S)=R_(p,q)(x)/(3d_k(x)).       (6)

The denominator is positive at EVERY t>0. At p=q1, R=1 and
the formula gives -ImTr(KiS)=1/[3(t^2+2)], a useful exact calibration.

For fixed q, each term in (5) is a linear combination of U_p,U_(p-1),
D_p,D_(p-1), with coefficients depending only on q,t. Its p-generating
function is PROPER with denominator (1+iz)(1-tz-z^2): multiplying the
D terms by1+iz still gives numerator degree at most2. Taking imaginary
parts introduces the conjugate pole+i as well. The four poles are the
two path roots lambda+/-, solving lambda^2=t lambda+1, and +/-i.
There are NO doubled poles and no residual p*lambda^p terms.
By reflection the same assertion holds in q. For t>0 all needed poles
are distinct. Their fourth powers are1 and lambda+^4,lambda-^4, with
product1 and sum a(x)=x^2+4x+2. Thus, along EACH residue class modulo4,
R satisfies the exact characteristic

                       (mu-1)(mu^2-a mu+1).           (7)

Division by t^nu leaves (7) unchanged since nu is constant on these
subsequences. The resulting equalities at every positive t are polynomial
identities in x. This supplies the ALL-index quantifier, independently
of the finite recurrence controls or numerical scout.

## 3. A complete144-jet scalar cone certificate

Use the cone of real polynomials with nonnegative coefficients. It is
closed under addition and multiplication by b=a-2=x^2+4x. For a sequence
Z_m with Z_(m+2)-aZ_(m+1)+Z_m=L constant in m, put

 Delta0=Z1-Z0, K0=bZ0+L=Z2-aZ1+(a-1)Z0.

If Z0,Delta0,K0 are in the cone, every Z_m and every successive
difference is in the cone. Indeed

 Delta_(m+1)=Delta_m+K0+b(Z_(m+1)-Z0),

so induction proves both claims. L alone need not be nonnegative.

On R define I_p, Delta_p with shift4, and
K_pR=R(p+8,q)-aR(p+4,q)+(a-1)R(p,q); similarly in q.
The complete certificate checks EVERY polynomial

 O_q O_p R(r,s), r,s in{1,2,3,4}, O_p,O_q in{I,Delta,K}. (8)

There are144 jets. All their coefficients are nonnegative. First apply
the cone lemma in q to each of the three p-initial objects, and then
in p. The operators commute and (7) supplies their recurrences. It
follows that R_(p,q) has nonnegative coefficients for EVERY p,q>=1.
Together with (6) this proves (1). All16 base polynomials are nonzero,
so the trace is in fact strictly negative at positive t, but the weak
sign suffices and is the only sign used below.

The producer computes (5) with integer continuants. The separate stdlib
reader instead reconstructs the ACTUAL private B,T, all Newton traces
and characteristic coefficients, and the weighted contact moments of
T(2I-B)B^jT^t. Multiplying their expansion at infinity by det(tI+iB)
independently reconstructs EVERY polynomial R for1<=p,q<=12. It then
recomputes every jet in (8). Shared polynomial helpers are not imported.
This is an analytic recurrence proof with a complete finite arithmetic
certificate, not extrapolation from144 lengths or the numerical sample.

## 4. A nonlinear support bound retains this new sign

For the same old parent, the completed root-ball argument gives

 t delta_star <= V(t)=ImTrL-1+||I+2iL||_*/2,
 L=Ki^(1/2)S Ki^(1/2), 0<=V<=||L||_F^2<=10/(9t^2).

The last norm bound is retained from the exact isometry theorem; it
uses Ki eigenvalues1,1/3 and row AND column bounds ||S||<=1/t.
Put a0=ImTrL<=0 by (1) and b0=||L||_F^2. Cauchy-Schwarz on the TWO
singular values of I+2iL, with the full complex adjoint, gives

 ||I+2iL||_* <=2sqrt(1-2a0+2b0).

The function a0-1+sqrt(1-2a0+2b0) is nondecreasing on a0<=0:
its derivative is1-1/sqrt(1-2a0+2b0)>=0. Therefore

 t delta_star <=V<=sqrt(1+2b0)-1
                         <=sqrt(1+20/(9t^2))-1.       (9)

This improves the previous b0 bound at every positive frequency.
It uses an actual new weighted trace sign, not an unproved matrix sign
ImS<=0 or an old-parent norm hypothesis. The same old graph persists
at every t; no pointwise optimizer is asserted physically realizable.

## 5. Pay the whole positive frequency line

The preceding normalized-imaginary-sign theorem gives the continuously
anchored SAME-parent phase bound delta_star<2atan(2/t). Its actual
nonnegative shaving still yields I_full<=Jstar and retains reserve Rlen.
For epsilon=5/8 use the phase bound on ENTIRE0..epsilon. Its exact integral is

 Jlow=pi*epsilon^2/2+2epsilon-(epsilon^2+4)atan(epsilon/2).

On the ENTIRE remaining axis use (9). With z=1/t and a=20/9,

 Jtail<=integral_0^(1/epsilon) a/[sqrt(1+a z^2)+1] dz.  (10)

The integrand is positive, continuous at0 and nonincreasing. The
certificate covers0..8/5 with128 equal intervals. At each LEFT endpoint
it gives an EXACT rational lower/upper bracket on sqrt(1+a z^2), checked
by squaring positive endpoints. Using its lower bracket in the positive
denominator gives an upper integrand value throughout that interval.
All widths and all upper areas are summed exactly. Thus this is a
directed full-tail bound, including infinity, with NO cutoff omission.

For the low interval use pi<22/7 and the8-term alternating LOWER sum
for atan(5/16). Together with all128 upper areas the reader proves

                       Jstar<97/50.                  (11)

The existing exact Machin bound pi>157/50 and physical graph identity
DeltaF=2k-(2/pi)I_full then give

 DeltaF>2k-(2/pi)(97/50)>2k-194/157>2k-31/25,

proving (2). The inequality directions do not replace a positive phase
integral by an absolute value, and no signed Fstar is assigned energy.
Every private eigenvalue, including a real zero-mode pole, remains counted.

## 6. A stronger long-arm cut and the global conditional ledger

Retain the positive shaving reserve Rlen from the exact normalization
proof. Put alpha=max(p-1,q-1),D0=max OLD rootdegrees in H. If

                       alpha>=max(D0,1156),           (12)

then l=sqrt(alpha)>=34. On t in[l,2l] the old norm estimate gives
||Z_s||<=4l+1+4/l<=(41/10)l for all0<=s<=1, since
1+4/34<=34/10. Also l^2/(l^2+4)>=99/100. Consequently

 Rlen>=99l/1681>=3366/1681.

Use (11), the exact comparison
(7/11)(3366/1681-97/50)>1/50, and2/pi>7/11. The SAME physical branch
therefore has DeltaF>2k+1/50 under (12). The other arm and the far graph
are unrestricted. This strengthens the previous sufficient1521 threshold.

The already completed actual dual-removal grammar may now use c=194/157
for each potentially negative external/external branch step. It deletes
one distinct actual unrooted degree3 dual face, so B<=initial b(T).
On ONE actual chain the final reserve plus justified positive credits
minus cB still bounds e(G)=F(G)-2|G|. With EXACT named inherited B71
(every original MOP8<=n<=71 paid), the resulting all-graph bound is

                    F(G)>=2n-(194/157)b(T).           (13)

The first inequality is strict when n>=72 or b(T)>0, with precisely
the old grammar's argument. This does NOT establish F>=2n for b>0.
Complete geometric coverage and the original nonnegative compensation
obligation remain separate. B71 and the other inherited universal
payments retain their existing audit boundaries; none is freshly proved
or upgraded by this new arithmetic.

Under the SAME existing B71/gamma<=4/small-parent-cover boundary,
every deepest branch of a minimal original counter n>=72 has an
external/external representation whose actual deleted parent satisfies

 h>=14, 0<=F(H)-2h<194/157,
 max(p,q)<=max(D0,1156).

Retain own-root retirement, joint payment and root-pair-plus-two domination
exclusions. No all-order existence or impossibility of these parents is
shown. The old false norm M1/M2 on larger domains remains false.

## 7. Evidence limits and changed next work

The full reader checks all144 Newton/moment polynomials, all144 jets,
EVERY directed tail cell and the exact constants, plus direct rational
full-column Neumann-path solves at18 declared length/frequency cases.
Those actual auxiliary matrices include zero eigenvalues; every row of
each required solve is verified. A corrupt numerator, omitted jet and
tail gap are rejected. These controls support, not replace, the written
all-index GF and cone proof. The raw10240-case trace scout is discovery
only. An initial producer syntax error ended before any certificate;
only the corrected producer and separate reader are accepted.

This strengthens the actual global branch-debt coefficient from below
1.42 to194/157<1.24, while retaining the same original target. It is not
the global closure or a counterexample. Fork6 and full nonnegative UB
remain OPEN. Prior C0/barefan/genericgluing/pointwiseFork/near-norm
counterexamples remain valid. No automatic entry-gap repair, exhaustive
Drive/corpus delivery, external audit, background or subagent work claimed.

The next required work is the actual large, near-reserve, nondominated
old parent, using either a sharper integrated Fork/branch payment or
whole-sequence compensation. The new trace sign changes the support
function quantitatively; finite no-counter searches do not close that
remaining obligation.
