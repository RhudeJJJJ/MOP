"""Explicit complete-source intake; native guard unchanged, source replay separate."""
from pathlib import Path
import hashlib,json,sqlite3,shutil,sys
P=Path(__file__).resolve().parent
DB=Path('C:/Users/jonas/Aletheion/aletheion/aletheion.db')
PRE='math:mop:grouped-parent-payments:'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dig(s):return hashlib.sha256(s.encode()).hexdigest()
def rd(p):return json.loads(p.read_bytes())
def save(n,v):(P/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def prepare():
    middle=P.parent/'mop-finite-middle-20261108';small=P.parent/'mop-double-child-20261108'
    mv=rd(middle/'middle-verification.json');sv=rd(small/'small-double-verification.json')
    assert mv['status']=='PASS_ALL_FINITE_MIDDLE_q3_TO45_AND_TWO_INFINITE_OUTER_ARMS'
    assert sv['status']=='PASS_ALL_p_s_FOUR_SMALL_DOUBLE_CHILD_INCREMENT_PAYMENTS'
    files=[]
    for folder,v,extra in [(middle,mv,['middle-verification.json']),(small,sv,['small-double-verification.json','double-analytic-proof.md','check_double_analytic.py','double-analytic-check.json'])]:
        assert all(sha(folder/n)==h for n,h in v['source_sha256'].items())
        files.extend(folder/n for n in dict.fromkeys(list(v['source_sha256'])+extra))
    keys=['external-middle','external-allq','double-small','double-tail','double-floors','scope','proofsource','certificate']
    ids={k:PRE+k+':20261108'for k in keys};nodes=[];edges=[]
    def node(k,kind,body,status):nodes.append(dict(node_id=ids[k],kind=kind,title='Grouped-parent payment: '+k,body=body,epistemic=status,provenance=json.dumps([dict(path=str(middle/'middle-payment-proof.md'),sha256=sha(middle/'middle-payment-proof.md')),dict(path=str(small/'small-double-payment-proof.md'),sha256=sha(small/'small-double-payment-proof.md'))])))
    def edge(a,b,rel,why):
        eid='edge:'+dig(a+'|'+rel+'|'+b);edges.append(dict(edge_id=eid,from_id=a,to_id=b,relation=rel,rationale=why,status='curated'));return eid
    node('external-middle','claim','For EVERY old UNIT MOP H,h>=3 and ordered boundary ab, EVERY p,ell>=1 and EVERY q3..45, the external-b sibling parent B(E_(p,q),Pell) with its exact external-root contacts has DeltaF>2N+1/10, N=p+q+ell+2. Full original exact reader terminal PASS covers512 frequency leaves and547916 length leaves, both outer lengths UNBOUNDED, maximum anchor10 an infinite-tail start. Actual certified surplus>.148744. Certificate d87b69d0539b0d033cf4d982eb603623e4b96119dae4b464b4cbfb6235f74eee. Frozen13 producer inputs and full47-file verification envelope retained. This is not the private-c sibling role and not a global theorem.','PROVEN local complete exact original reader; source-export replay separate')
    effect='The EXTERNAL-b sibling family B(E_(p,q),Pell) now pays DeltaF>2N+1/50 for EVERY p,q,ell>=1 and EVERY old UNIT MOP H,h>=3, with the actual ordered old roots. The previous remaining-q3..39 work obligation for this family is closed by the full q3..45 certificate; the prior q1,q2 and q>=40 theorems remain true and supply the other ranges.'
    node('external-allq','claim',effect+' No energy credit is added twice on overlapping q40..45. The distinct private-c sibling role and original global conjecture retain their actual remaining obligations. Whole old H2..7 use only the separate parent-extraction domination<=4 bridge at its inherited gamma4/finite-base input boundary; this statement does not extend the increment toK2.','PROVEN composed all-q external sibling payment')
    node('double-small','claim','For EVERY old finite simple UNIT MOP H,h>=3 and ordered boundary ab, add parent abc, E_(p,q) on ac (apices a,c), and E_(r,s) on cb (apices c,b). For ALL independent p,s>=1 and EACH ORDERED(q,r) in{1,2}², N=p+q+r+s+3 and DeltaF>2N+3/20. Exact full phase reader terminal PASS on all sixteen infinite outer residues for every pair; actual surplus lower fractions>.176285,.387271,.377281,.484712 respectively. Complete frequency and64-cell infinite-frequency-tail bounds; no old upper order/degree/norm/spectrum assumption. Certificate45b0f890541e41a79ebd9c38829d08fcc104b826f7a20051d6de2cbcf9a7f21b. No general B(E,E) closure inferred.','PROVEN four small ordered double-child families, both outer lengths infinite')
    node('double-tail','claim','For the SAME literal double-child geometry, ALL p,q,r,s>=1 with m=q+r>=42 and ALL old UNIT MOP H,h>=3 have DeltaF>2N+9/100. Keep d,e, delete ONLY both internal paths: induced Hbar is bare E_(p+1,s+1) relative to the SAME H. Its c has actual degreeEXACT4(a,b,d,e). Retire c ONCE at cost<351/50, use accepted bare deficit184/157, then pinch final G into Hbar-c and c join(Pq disjoint Pr). Exact two-dimensional compression gives private J energy>2m+G(m), h0=1-2/m, G=2h0²+2h0 sqrt(m+h0²)-6 increasing. At42, G>3656/441 and final gain>2N+340213/3461850>2N+9/100. This is all lengths, not a sampled tail, and no K2 increment is inferred.','PROVEN all-length analytic double-child large tail')
    node('double-floors','claim','Literal double private B has edges=p+s+2m+2, contact mass=p+s+4,total2N. For ALL p,s, m>=14 its private excess above edges is>269/100; for m>=20 it is>43/10. Pinch into two pendant paths and c join(P(q+1) disjoint P(r+1)); exact compression atR16 gives G>345/128>269/100, atR22 gives G>525/121>43/10. For(q,r)in{1,2}² the FULL determinant normalized by DpDs is C(x,y)-iM(x,y) with nonnegative bilinear coefficients and both monotonicity cross polynomials nonnegative for all nonnegative other endpoint. Actual x,y<=1/t imply integrated D>=p=s1. Full base integer Grams give the stronger reserves33/25,187/100,187/100,239/100 used in double-small. No false pointwise one-arm helper is revived.','PROVEN actual private reserves, distinct from full old-root payments')
    node('scope','claim','ORIGINAL EVERY finite simple UNIT MOP n>=8 F=splus>=2n remains GLOBAL OPEN; goal ACTIVE. All-q external-b sibling payment, four small double-child pairs and analytic double-child m>=42 are now locally proved. Private-c sibling q+ell<=49 and general double-child14<=q+r<=41 still require terminal full exact acceptance; their running calculations are not completed theorems. The parent extraction, whole-small-old bridge, unary-parent counter exclusion, original finite8..71 cover, gamma4 and other named inherited inputs keep their precise scopes. Current source audit has read the order71 conditional proof and identified its actual finite/spectral/Catalan dependencies, but has not freshly replayed all of them. Native byte identity, original complete mathematical reader, fresh source-export replay, automatic entry delivery and proof truth are distinct. No global completion, original-target counterexample, external priority, independent human/formal audit or causal LOTSE effect.','PROVEN scope and retained original obligations')
    parents=['math:mop:retirement4:external:20261108','math:mop:two-tail-payment:payment:20261106','math:mop:q2-root:payment:20261108','math:mop:exact-retirement:retirement:20261108','math:mop:quantitative-path-state:increment:20261105','math:mop:parent-extraction:small-old:20261108','math:mop:parent-extraction:three-forms:20261108','math:mop:unary-parent:counter-exclusion:20261108']
    c=sqlite3.connect('file:'+str(DB)+'?mode=ro',uri=True);c.execute('BEGIN');snap=[]
    assert not c.execute('select node_id from weave_nodes where node_id like ?',(PRE+'%',)).fetchall(),'inspect existing intake before retry'
    for i in parents:
        row=c.execute('select body,provenance from weave_nodes where node_id=?',(i,)).fetchone();assert row
        snap.append(dict(node_id=i,body=row[0],sha256=dig(row[0]),provenance=row[1]))
    assert not c.execute('select edge_id from weave_edges where to_id=? and relation=?',(parents[0],'revises')).fetchall(),'review new external front revision before proceeding'
    c.rollback();c.close();save('parent-snapshot.json',snap);save('parent-bindings.json',{v['node_id']:v['sha256']for v in snap})
    old='Together with accepted q1,q2 payments, only q3..39 remain for this external family, both outer lengths unbounded.'
    scope='For EVERY old UNIT MOP H,h>=3 and ordered boundary ab, EVERY integers p,ell>=1,q>=40, the external-b sibling cap with external E_(p,q) child has DeltaF>2N+1/20, N=p+q+ell+2.'
    assert old in snap[0]['body'] and scope in snap[0]['body']
    eid=edge(ids['external-allq'],parents[0],'revises','Close ONLY the external remaining-q3..39 work clause; preserve prior q>=40 increment and all original inputs.')
    save('revision.json',dict(version=1,reviewer='Codex terminal complete external-middle exact-reader and range-composition review20261108',affected_prior_claim=dict(node_id=parents[0],field='body',quote=old),prior_scope=dict(node_id=parents[0],field='body',quote=scope),successor_effect=dict(node_id=ids['external-allq'],field='body',quote=effect)))
    save('revision-edge.json',dict(edge_id=eid,prior=parents[0],successor=ids['external-allq']))
    for k in keys[:6]:edge(ids[k],ids['proofsource'],'requires','Complete mathematical proof, full exact certificates, source controls and limits mandatory.')
    for k in ['external-middle','double-small','double-floors']:edge(ids[k],ids['certificate'],'requires','Full exact rational output plus complete certificate in source envelope.')
    edge(ids['external-allq'],ids['external-middle'],'requires','The complete uniform middle theorem closes the previous exact remaining range.')
    for i in parents[:3]:edge(ids['external-allq'],i,'requires','Preserved precise other-range payment and exact prior scope.')
    for i in parents[3:5]:edge(ids['double-tail'],i,'requires','Exact degree4 retirement and quantitative bare increment, each applied once.')
    for i in parents[5:]:edge(ids['scope'],i,'requires','Whole-small-old, extraction and unary boundaries remain explicit.')
    shutil.copyfile(P.parent/'mop-unary-parent-20261108/run_guarded_native.py',P/'run_guarded_native.py')
    files.extend(P/n for n in ['intake.py','run_guarded_native.py','parent-snapshot.json','parent-bindings.json','revision.json','revision-edge.json'])
    envelope=dict(format='full-source-envelope-v2-relative-files',files=[dict(path=str(f),relative=f.relative_to(P.parent).as_posix(),bytes=f.stat().st_size,sha256=sha(f),content=f.read_bytes().decode())for f in files])
    payload=json.dumps(envelope,ensure_ascii=True,separators=(',',':'));pieces=[payload[j:j+72000]for j in range(0,len(payload),72000)];parts=[PRE+'sourcepart'+str(j)+':20261108'for j in range(len(pieces))]
    header=dict(format='complete-source-envelope-chunks-v1',payload_utf8_bytes=len(payload.encode()),payload_sha256=dig(payload),parts=[dict(node_id=i,part=j+1,bytes=len(s.encode()),sha256=dig(s))for j,(i,s)in enumerate(zip(parts,pieces))])
    node('proofsource','source',json.dumps(header,separators=(',',':')),'FULL source header; every raw numbered fragment required')
    for j,(i,s)in enumerate(zip(parts,pieces),1):
        nodes.append(dict(node_id=i,kind='source',title='Grouped-parent complete source '+str(j),body=s,epistemic='FULL raw source fragment; incomplete alone',provenance=json.dumps([dict(payload_sha256=dig(payload),part=j)])));edge(ids['proofsource'],i,'requires','All numbered full original source fragments obligatory.')
    node('certificate','source',json.dumps(dict(middle=rd(middle/'middle-reader-result.json'),small=rd(small/'small-v2-reader-result.json'),analytic=rd(small/'double-analytic-check.json')),separators=(',',':')),'FULL exact original reader results; complete cells and sources in envelope')
    assert max(len(n['body'].encode())for n in nodes)<95000
    save('packet.json',dict(schema_version=1,nodes=nodes,edges=edges));save('source-hashes.json',{str(f):sha(f)for f in files})
    raw=sum(f.stat().st_size for f in files);backup=DB.stat().st_size+16*1024**2;free=shutil.disk_usage(P).free;assert raw<4*1024**2 and free-2*backup-3*raw>8*1024**3
    save('write-plan.json',dict(explicit_members=[str(f)for f in files],raw_bytes=raw,backup_count=2,backup_upper_each=backup,free_before=free,no_expected_deduplication=True))
    print(json.dumps(dict(status='PREPARED_FULL_EXTERNAL_MIDDLE_SMALL_DOUBLE_AND_ANALYTIC_TAIL_NATIVE_INTAKE',nodes=len(nodes),edges=len(edges),parts=len(parts),files=len(files),raw_bytes=raw,backup_upper_each=backup,free_before=free)))
def audit():
    assert all(sha(Path(f))==h for f,h in rd(P/'source-hashes.json').items())
    packet=rd(P/'packet.json');c=sqlite3.connect('file:'+str(DB)+'?mode=ro',uri=True);c.row_factory=sqlite3.Row;c.execute('BEGIN');actual=[];nodes={}
    for table,key,item in [('weave_nodes','node_id',n)for n in packet['nodes']]+[('weave_edges','edge_id',n)for n in packet['edges']]:
        row=dict(c.execute('select * from '+table+' where '+key+'=?',(item[key],)).fetchone());assert all(row[k]==v for k,v in item.items());actual.append(dict(table=table,row=row))
        if table=='weave_nodes':nodes[row['node_id']]=row
    for i,h in rd(P/'parent-bindings.json').items():assert dig(c.execute('select body from weave_nodes where node_id=?',(i,)).fetchone()[0])==h
    bindings=[dict(r)for r in c.execute('select * from weave_revision_bindings where edge_id=?',(rd(P/'revision-edge.json')['edge_id'],)).fetchall()];assert len(bindings)==1;c.rollback();c.close()
    save('actual-readback.json',actual);save('revision-readback.json',bindings)
    header=json.loads(nodes[PRE+'proofsource:20261108']['body']);pieces=[]
    for j,v in enumerate(header['parts'],1):
        s=nodes[v['node_id']]['body'];assert v['part']==j and len(s.encode())==v['bytes']and dig(s)==v['sha256'];pieces.append(s)
    payload=''.join(pieces);assert dig(payload)==header['payload_sha256']and len(payload.encode())==header['payload_utf8_bytes'];env=json.loads(payload)
    for f in env['files']:
        rel=Path(f['relative']);assert not rel.is_absolute()and'..'not in rel.parts;data=f['content'].encode();assert data==Path(f['path']).read_bytes()and len(data)==f['bytes']and hashlib.sha256(data).hexdigest()==f['sha256']
        for root in [P/'native-export',P/'native-replay']:
            dest=root/rel;dest.parent.mkdir(parents=True,exist_ok=True)
            if dest.exists():assert dest.read_bytes()==data
            else:dest.write_bytes(data)
    for label in ['payments-dryrun','payments-import','payments-revision-dryrun','payments-revision-bind']:assert rd(P/(label+'.process.json'))['exit_code']==0
    receipt=rd(P/'payments-import.stdout.json');assert receipt['inserted']==dict(nodes=len(packet['nodes']),edges=len(packet['edges']),reviews=0)
    backups=[]
    for label in ['payments-import','payments-revision-bind']:
        b=Path(rd(P/(label+'.stdout.json'))['backup']);assert b.is_file()and b.stat().st_size<=rd(P/'write-plan.json')['backup_upper_each'];backups.append(str(b))
    out=dict(status='PASS_NATIVE_COMPLETE_SOURCE_BYTE_IDENTITY_AND_EXACT_EXTERNAL_FRONT_REVISION',native_run_id=receipt['run_id'],nodes=len(packet['nodes']),edges=len(packet['edges']),files=len(env['files']),parts=len(pieces),all_sources_byte_identical=True,parents_unchanged=True,exact_revision_binding=True,backups=backups,free_after=shutil.disk_usage(P).free,original_full_exact_readers='PASSED middle and small four; terminal exact margins retained',fresh_source_export_math_replay='PENDING; byte identity alone is not fresh recomputation',original_global='OPEN',original_goal_complete=False,entry_delivery='PENDING actual old-external-ID dependency check')
    save('native-audit.json',out);print(json.dumps(out))
if __name__=='__main__':prepare()if len(sys.argv)==1 or sys.argv[1]=='prepare'else audit()
