# Fresh all-order class inputs and actual finite complements

8 November 2026. Original UNIT-MOP conjecture GLOBAL OPEN. These are
class theorems used in a finite cover, not a proof of every original graph.
The existing written arguments are explicitly preserved in inputs/ and
class-inputs/. This document states their exact use and the new full checks.

For a real symmetric adjacency matrix A,
F(A)=max over X>=0 of 2Tr(AX)-Tr(X^2). Completing the square at A_+
proves this identity. A block-supported test proves superadditivity over
disjoint induced vertex sets; zero extension proves principal-submatrix
monotonicity. Edge deletion is not substituted for either operation.

1. Split-fan reserve six and full-fan reserve eight.

For L consisting of one or two paths on q vertices and m edges, F(L)=m,
rho(L)<2. Interlacing gives F(K1 join L)>=rho(K1 join L)^2+m-rho(L)^2.
The hub/uniform-leaf compression has top root of t^2-c t-q=0, c=2m/q.
For q>=30, c>=2-4/q and c^2(q+12)>144, strictly at30 and increasing.
Thus rho^2>q+12, giving F>2q+6. At29 the 30 ordered splits are checked
with the actual degree-weighted integer Rayleigh vector hub107,
leaf20+2deg_L; their minimum N^2-41D^2 is14659079>0. At28 use all15
unordered full integer Gram factors, with minimum objective gap above62
123655042413/1099511627776>0. Exchanging the two entire paths gives all
ordered splits. Consequently SF6 holds for every q>=28.

For a single path on q>=33 vertices, c=2(q-1)/q and
c^2(q+13)>169, since its positive numerator at33 is4375. Both factors
increase, so F(K1 join P_q)>2q+8. At32 the vector hub99, endpoints18,
interior21 has N158958,D23679 and N^2-45D^2=36368919>0. This proves F8
for every q>=32. Strict path-radius interlacing supplies strictness.

In a MOP, neighbors in their cyclic order induce a path: consecutive
neighbors form faces, and a further chord crosses an intervening spoke.
For adjacent hubs of degrees d,e and h common neighbors (h1 boundary,
h2 internal), allocate a of the shared neighbors to the first hub.
The disjoint induced pieces have q1=d-1-h+a, q2=e-1-a leaves, each
forming at most two paths. With h2, removing the other hub and zero,
one, or two immediately neighboring common vertices removes a contiguous
segment; with h1 that segment is at an end. SF6 pays whenever both leaf
counts>=28 and d+e>=n-4+h. The two common neighbors are distinguishable;
no identification by their totals or by private spectra is made.

For nonadjacent hubs there are at most two common neighbors, lying at
the endpoints of the unique first-hub gap containing the second hub.
If two, they are consecutive in the first hub's neighbor path. Assign
the second hub its entire fan, and remove the h common neighbors from
the first hub's path. The disjoint pieces have e and d-h leaves.
SF6 pays when these counts>=28 and d+e>=n-6+h. If the full fan has
at least32 leaves, F8 improves the sum requirement to n-7+h. The roles
of the hubs may be exchanged as a whole.

2. Actual induced cores and exterior ears.

For an adjacent pair, its two stars and two neighbor paths force exactly
2(d+e-h)-3 edges on N[u] union N[v]. Outerplanarity permits no more.
For h2 the common neighbors cannot be adjacent, since that would give K4.
Thus this is exactly the induced MOP core. Each private segment attaches
to its own hub and a common-neighbor end; its far endpoint is an ear.
Deleting far endpoints independently reduces either hub to any required
degree>=h+1 while preserving the common neighbors and induced core.

The complete canonical profiles and exact Gram objectives freshly checked
by read_high_pairs.py are:

* internal(32,32):900 cases, F>138;
* internal(33,32):930 cases, F>140;
* boundary(32,32):one case, F>140;
* boundary(33,32):one case, F>142;
* internal(33,33) and(34,32):961+960 cases, F>142;
* nonadjacent(33,32),two common neighbors:992 cases, F>142.

In the last class, the four-cycle through the two common neighbors has
the common-neighbor diagonal: the other diagonal is the absent hub edge.
MOPs are chordal. Their two neighbor paths therefore share exactly this
edge. The forced edge count is2(d+e)-3 on d+e vertices. Oppositely
oriented private path segments yield all32*31 profiles. The fresh reader
reconstructs those labels, not merely an isomorphic unmatched factor.

Every core in the reader also has the full polygon domain checked:
2n-3 distinct edges, one or two common neighbors per edge, boundary edges
forming one cycle through all vertices, and no crossing diagonals in
that cycle order. All expected parameter grids are exact and duplicate
free. Full B factors give X=BB^t/1024^2. All bounded int64 products have
an explicit prior absolute-value bound; squaring and final sums use
unbounded Python integers. No floating spectral value is a certificate.

For an actual internal(33,32) pair at n71 the induced63-vertex core is
proper. Consecutive vertices on the smaller polygon enclosing outside
vertices define a boundary edge whose outside face gives a new vertex w.
It has exactly two neighbors in the core: three would exceed the
outerplanar edge bound. The induced extension is an ear on that boundary
edge. A hub-incident ear is paid by(34,32)/(33,33) above. The fresh reader
checks all59 nonhub edges of every930 core, hence54870 extensions. Appending
c=floor((k(B_x+B_y)+8)/16), k1..12, to the full factor B gives a positive
objective above142 in every case; k<=3 suffices. Its smallest exact gap
is5428137/549755813888>0. Here w need only be an ear in the induced
extension, not in the entire original G. Zero extension pays G.

The independent reader's first version attached a right segment at its
far end when the left segment was empty. Its failed assertion and exact
source are preserved. Explicit orientation corrected that labeling;
the full corrected run passed. That reader failure was no graph
counterexample and did not alter any stored original claim.

3. Every needed high-second-degree complement.

There are46 actual(n,d,C) capped domains among the125 finite targets.
read_class_payments.py enumerates EVERY e=C+1..d, adjacent h1/2 and
nonadjacent h0/1/2:1150 cases. Each has an explicit sufficient SF6/NP7
inequality or one of the preceding induced core/ear payments, at its
actual order. In particular no F>138 kernel is used above order69,
no F>140 kernel above70, and the last exceptional nonadjacent pair
(33,32,h2) at71 uses the992 F>142 kernels. Every original graph outside
its cap belongs to one of these cases. The five unrestricted targets
have C=d, so there is no second-degree complement to them.

4. Dominating triangles for all n>=60, with no small-order energy input.

Let sigma(S)=F(S)-2|S| for a split fan on k leaves. Use the monotone
rational q0=q1=q2=-4. For each k3..13, the fresh reader checks all52
unordered split types with full integer Gram factors at scale16384 and
the stated rational lower q_k. The k0/1/2 values follow from the isolated
hub, K2, triangle and P3. For k14..54 put r=(k-2)/k. Interlacing and
hub compression give sigma>g(k)=2r^2+2r sqrt(k+r^2)-8. Every rational
q_k is checked by T=k+8+q_k>0,8+q_k>0,4r^2T>(8+q_k)^2.
All q0..q54 are nondecreasing, q54=203/25>8, and g increases for k>=2;
therefore q54 remains a lower bound at every larger k.

A dominating triangle separates the outer polygon into three gaps.
In a nonempty gap every vertex sees one of its endpoints and none sees
the third hub. There is exactly one pivot adjacent to both endpoints;
the remaining hub neighbors form a prefix and suffix, since crossings
are impossible. These forced spokes and path edges triangulate that
gap completely. Assign the pivot to either endpoint, and all other
vertices to their unique endpoint. Each hub with its assigned vertices
induces a split fan with at most two paths. The three sets partition G.

For r1/2/3 nonempty gaps, let b_i count nonpivots assigned to hub i.
At n60, sum b_i=57-r. Up to relabeling triangle vertices, pivot edges
form one edge, two consecutive edges, or the full triangle. All1653,
1596,1540 ordered triples and all2^r pivot assignments are freshly
enumerated. In each case some assignment has sum q_min(k_i,54)>=3/25.
For n>60 select b'_i<=b_i with sum57-r and keep that assignment. The
actual k_i increase coordinatewise, so monotonic q preserves the bound;
if a count exceeds54 its q54>8 pays the other two lower bounds -4.
PSD superadditivity yields F(G)>2n for every such actual graph.
This proof imports no assertion for orders8..59.

These class payments close exactly the complements to the selected
finite mask0 domains. The complete mask0 maxima, the other finite
payments and both remaining unbounded parent families stay separate.
No external novelty, independent human review or formal-assistant proof
is asserted.
