"""Exact all-order class constants and every actual finite-cap complement."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
import json,hashlib,shutil,time
from read_high_pairs import gram,sha
P=Path(__file__).resolve().parent;ROOT=P.parent.parent
def main():
    start=time.monotonic();sources={n:ROOT/n for n in ['split-fan-small-certificate.json','three-hub-partition-certificate.json','dominating_triangle_class_proof.txt']};sources['masked-targets.json']=P.parent/'mop-masked-input-dp-20261108/targets.json'
    raw=sum(p.stat().st_size for p in sources.values());free=shutil.disk_usage(P).free;assert raw<1024**2 and free-raw>8*1024**3
    (P/'class-inputs').mkdir(exist_ok=True);hashes={n:sha(p)for n,p in sources.items()}
    for n,p in sources.items():
        dest=P/'class-inputs'/n
        if dest.exists():assert sha(dest)==hashes[n]
        else:shutil.copyfile(p,dest)
    plan=P/'class-source-plan.json';obj=dict(source_sha256=hashes,explicit_original_paths={n:str(p)for n,p in sources.items()},raw_bytes=raw,free_before=free,reserve_bytes=8*1024**3)
    if plan.exists():assert json.loads(plan.read_bytes())['source_sha256']==hashes
    else:plan.write_text(json.dumps(obj,indent=2)+'\n')
    kernel=json.loads((P/'high-pair-result.json').read_bytes());assert kernel['status']=='PASS_FRESH_ALL_HIGH_PAIR_EXACT_KERNELS_AND_54870_EARS'and sha(P/'read_high_pairs.py')==kernel['reader_sha256']
    assert all(sha(P/'inputs'/n)==h for n,h in kernel['source_sha256'].items())
    # SF6 q29: all ordered splits, not a sample of four degree types.
    ray=[]
    for a in range(30):
        deg=[];edges=[];off=0
        for size in(a,29-a):
            deg.extend(int(i>0)+int(i<size-1)for i in range(size));edges.extend((off+i,off+i+1)for i in range(size-1));off+=size
        x=[20+2*z for z in deg];N=214*sum(x)+2*sum(x[i]*x[j]for i,j in edges);D=107**2+sum(z*z for z in x);margin=N*N-41*D*D;assert margin>0;ray.append(margin)
    assert min(ray)==14659079 and 28**2*42>144*15**2
    # F8 q32 and q>=33 monotone analytic base.
    x=[99,18]+[21]*30+[18];E={(0,i)for i in range(1,33)}|{(i,i+1)for i in range(1,32)};N=2*sum(x[i]*x[j]for i,j in E);D=sum(z*z for z in x)
    assert(N,D,N*N-45*D*D)==(158958,23679,36368919)and 64**2*46-169*33**2==4375>0
    # Full independent dominating-triangle rational allocation.
    small=json.loads((P/'class-inputs/split-fan-small-certificate.json').read_bytes());q={0:F(-4),1:F(-4),2:F(-4)};seen=set();slacks=[];scale=small['factor_denominator'];assert scale==16384
    q.update({k:F(small['lower_surplus_by_k'][str(k)])for k in range(2,14)});assert q[2]==-4
    for rec in small['rows']:
        k,a,b=rec['k'],rec['a'],rec['b'];assert 3<=k<=13 and 0<=a<=b and a+b==k and(k,a)not in seen;seen.add((k,a));E={(0,i)for i in range(1,k+1)}
        E|={(i,i+1)for i in range(1,a)}|{(i,i+1)for i in range(a+1,k)}
        num,_,_=gram(rec['factor'],E,0,scale);slack=F(num,scale**4)-2*(k+1)-q[k];assert slack>=0;slacks.append(slack)
    assert seen=={(k,a)for k in range(3,14)for a in range(k//2+1)}
    large=json.loads((P/'class-inputs/three-hub-partition-certificate.json').read_bytes());assert large['scope']=='k=14..54'
    for k in range(14,55):
        v=F(large['large_surplus_by_k'][str(k)]);r=F(k-2,k);T=k+8+v;assert T>0 and 8+v>0 and 4*r*r*T>(8+v)**2;q[k]=v
    assert all(q[k]<=q[k+1]for k in range(54))and q[54]==F(203,25)>8
    alloc=[]
    for r in range(1,4):
        edges=[(0,1),(1,2),(2,0)][:r];B=57-r;count=0;minimum=None
        for a in range(B+1):
            for b in range(B-a+1):
                base=[a,b,B-a-b];scores=[]
                for bits in product([0,1],repeat=r):
                    ks=base.copy()
                    for edge,bit in zip(edges,bits):ks[edge[bit]]+=1
                    scores.append(sum(q[min(k,54)]for k in ks))
                best=max(scores);assert best>0;count+=1;minimum=best if minimum is None else min(minimum,best)
        assert count=={1:1653,2:1596,3:1540}[r];alloc.append(dict(nonempty_gaps=r,triples=count,minimum_surplus=str(minimum)))
    assert min(F(x['minimum_surplus'])for x in alloc)==F(3,25)
    # Every actually used capped-domain complement, all second degrees.
    targets=json.loads((P/'class-inputs/masked-targets.json').read_bytes())['rows'];domains=sorted({(r['n'],r['d'],r['C'])for r in targets if r['C']<r['d']});thresholds=[]
    for n,d,C in domains:
        for e in range(C+1,d+1):
            for adjacent,hs in[(True,[1,2]),(False,[0,1,2])]:
                for h in hs:
                    rule=None
                    if adjacent:
                        if d+e>=n-4+h and any(min(d-1-h+a,e-1-a)>=28 for a in range(h+1)):rule='SF6_adjacent'
                        elif h==1 and min(d,e)>=32 and n<=70:rule='boundary32_32_core'
                        elif h==2 and min(d,e)>=32 and n<=69:rule='internal32_32_core'
                        elif h==2 and d>=33 and e>=32 and n<=70:rule='internal33_32_core'
                        elif n==71 and h==1 and d>=33 and e>=32:rule='boundary33_32_core'
                        elif n==71 and h==2 and((d>=34 and e>=32)or(d>=33 and e>=33)):rule='internal34_32_or33_33_core'
                        elif n==71 and h==2 and(d,e)==(33,32):rule='internal33_32_proper_core_exterior_ear'
                    else:
                        if min(d-h,e)>=28 and d+e>=n-6+h:rule='SF6_nonadjacent'
                        elif d+e>=n-7+h and((d>=32 and e-h>=28)or(e>=32 and d-h>=28)):rule='F8_SF6_NP7'
                        elif n==71 and(d,e,h)==(33,32,2):rule='nonadjacent33_32_h2_core'
                    assert rule is not None,(n,d,C,e,adjacent,h)
                    thresholds.append(dict(n=n,d=d,cap=C,e=e,adjacent=adjacent,common=h,rule=rule))
    assert all(sha(P/'class-inputs'/n)==h==sha(sources[n])for n,h in hashes.items())
    out=dict(status='PASS_FRESH_DOMINATING_TRIANGLE_N60_PLUS_AND_ALL_ACTUAL_CAP_COMPLEMENTS',q29_ordered_splits=30,small_splitfan_gram_types=len(seen),small_minimum_slack=str(min(slacks)),all_pivot_allocations=alloc,actual_cap_domains=len(domains),complete_second_degree_common_neighbor_cases=len(thresholds),complement_cases=thresholds,source_sha256=hashes,proof_sha256=sha(P/'class-payment-proof.md'),high_pair_result_sha256=sha(P/'high-pair-result.json'),reader_sha256=sha(Path(__file__)),seconds=time.monotonic()-start,scope='All UNIT MOP with a dominating triangle and n>=60, and every actual high-second-degree complement to the125 capped finite targets. Hand structural/analytic proof is class-payment-proof.md plus explicit original proof snapshots. Does not itself pay mask0 or prove B71/global.',original_global='OPEN')
    (P/'class-result.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in ['complement_cases','source_sha256']},indent=2))
if __name__=='__main__':main()
