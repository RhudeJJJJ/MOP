from pathlib import Path
import json,hashlib,sqlite3,shutil,sys,subprocess,time,base64
P=Path(__file__).resolve().parent;DB=Path('C:/Users/jonas/Aletheion/aletheion/aletheion.db');PRE='math:mop:fresh-finite-complements:'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dig(s):return hashlib.sha256(s.encode()).hexdigest()
def rd(n):return json.loads((P/n).read_bytes())
def save(n,v):(P/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def prepare():
    h=rd('high-pair-result.json');r=rd('class-result.json');assert h['status']=='PASS_FRESH_ALL_HIGH_PAIR_EXACT_KERNELS_AND_54870_EARS'and r['status']=='PASS_FRESH_DOMINATING_TRIANGLE_N60_PLUS_AND_ALL_ACTUAL_CAP_COMPLEMENTS'
    assert sha(P/'read_high_pairs.py')==h['reader_sha256']and sha(P/'read_class_payments.py')==r['reader_sha256']and sha(P/'class-payment-proof.md')==r['proof_sha256']and sha(P/'high-pair-result.json')==r['high_pair_result_sha256']
    assert all(sha(P/'inputs'/n)==v for n,v in h['source_sha256'].items())and all(sha(P/'class-inputs'/n)==v for n,v in r['source_sha256'].items())
    parents=['legacy:essays:3023:r1:38807ebb1296ae02','math:mop:fresh-positive-catalan:scope:20261108','math:mop:fresh-early-cover:scope:20261108'];con=sqlite3.connect('file:'+str(DB)+'?mode=ro',uri=True);con.execute('BEGIN');assert not con.execute('select node_id from weave_nodes where node_id like ?',(PRE+'%',)).fetchall();snap=[]
    for i in parents:
        body=con.execute('select body from weave_nodes where node_id=?',(i,)).fetchone()[0];snap.append(dict(node_id=i,body=body,sha256=dig(body)))
    con.rollback();con.close();save('class-parent-snapshot.json',snap)
    ids={k:PRE+k+':20261108'for k in ['kernels','dominating-triangle','cap-complements','scope','proofsource','certificate']};nodes=[];edges=[]
    def node(k,kind,body,ep):nodes.append(dict(node_id=ids[k],kind=kind,title='Fresh finite MOP complementary classes: '+k,body=body,epistemic=ep,provenance=json.dumps([dict(path=str(P/'class-payment-proof.md'),sha256=sha(P/'class-payment-proof.md'))])))
    def edge(a,b,rel,why):edges.append(dict(edge_id='edge:'+dig(a+'|'+rel+'|'+b),from_id=a,to_id=b,relation=rel,rationale=why,status='curated'))
    node('kernels','claim','Full fresh exact integer Gram reader pays4760 finite kernel/splitfan cases and54870 nonhub exterior-ear extensions. Complete actual polygon domains and literal label grids checked; every int64 matrix product has an explicit no-overflow bound and every final square/sum is an unbounded Python integer. Kernels: SF6q28 all15 types; internal32/32 all900 F>138; internal33/32 all930 F>140; boundary32/32 F>140; boundary33/32 F>142; internal33/33 and34/32 all1921 F>142; nonadjacent33/32,h2 all992 F>142. Every930 internal33/32 core has all59 nonhub boundary-ear extensions paid above142, minimum5428137/549755813888. Full universal induced-core/pruning/exterior-ear proof preserved. First new reader wrong segment-end labeling was corrected and complete run repeated; no original graph counterexample.','PROVEN exact finite spectral kernels with written universal embeddings')
    node('dominating-triangle','claim','EVERY finite simple UNIT maximal outerplanar graph with a dominating triangle and n>=60 has F=splus>2n, without any smaller-order energy premise. Full proof derives splitfan rational q0..54 monotone and q54=203/25>8; all52 small Gram types and every exact large analytic inequality rechecked. All4789 ordered base triples across r1/2/3 nonempty triangle gaps and all pivot assignments checked, least best surplus3/25. Larger n follows by coordinatewise reduction and monotonic q, not an extrapolation of graph enumeration. Complete all-order gap/pivot/induced partition argument preserved.','PROVEN all-order class theorem n>=60; no n8..59 premise')
    node('cap-complements','claim','Every actual high-second-degree complement to the125 capped finite mask0 targets is paid. Full reader enumerates all46(n,d,C) domains, every e=C+1..d and all1150 adjacent/nonadjacent common-neighbor cases, each mapped to exact SF6/NP7 or a complete induced-core/ear theorem at its actual order. No F>138 kernel above69, F>140 kernel above70, or equality-as-positive substitution. The5 unrestricted targets have C=d and no second-degree complement. This theorem does not establish their separate mask0 maxima.','PROVEN complete actual finite cap complements')
    node('scope','claim','ORIGINAL EVERY finite simple UNIT MOP n>=8 F>=2n remains GLOBAL OPEN and goal ACTIVE. This package freshly discharges the dominating-triangle n>=60 and high-second-hub complements of130 capped/restricted finite targets, not their mask0 maxima, not complete B71 and not either remaining unbounded parent family. Complete sources include compressed original binary certificates losslessly in base64, not only manifests or summary counts. Byte identity, replay, context delivery and truth remain separate; no human/formal audit, literature first priority or LOTSE causal effect asserted.','PROVEN scope; original global OPEN')
    for k in ['kernels','dominating-triangle','cap-complements','scope']:edge(ids[k],ids['proofsource'],'requires','Complete exact source and universal written proof required.')
    edge(ids['cap-complements'],ids['kernels'],'requires','Actual finite core/ear cases at their exact orders.');edge(ids['cap-complements'],ids['dominating-triangle'],'qualifies','Dominating-triangle branch is separately paid before applying mask0 domain.')
    for i in parents:edge(ids['scope'],i,'qualifies','Fresh complementary class inputs; original finite and unbounded obligations retain their exact scope.')
    shutil.copyfile(P.parent/'mop-finite-input-dp-20261108/run_guarded_native.py',P/'run_guarded_native.py')
    local=['read_high_pairs.py','read_class_payments.py','class-payment-proof.md','portable_replay.py','intake_classes.py','run_guarded_native.py','high-pair-result.json','class-result.json','source-plan.json','class-source-plan.json','class-parent-snapshot.json','v1-reader-failure.json','read_high_pairs_v1_wrong_endpoint.py']+['inputs/'+n for n in h['source_sha256']]+['class-inputs/'+n for n in r['source_sha256']]
    files=[]
    for n in local:
        f=P/n;b=f.read_bytes();binary=n.endswith('.gz');files.append(dict(path=str(f),relative='high/'+n,bytes=len(b),sha256=sha(f),encoding='base64'if binary else'utf8',content=base64.b64encode(b).decode('ascii')if binary else b.decode('utf8')))
    f=P/'class-inputs/masked-targets.json';b=f.read_bytes();files.append(dict(path=str(f),relative='mop-masked-input-dp-20261108/targets.json',bytes=len(b),sha256=sha(f),encoding='utf8',content=b.decode('utf8')))
    env=dict(format='full-source-envelope-v3-explicit-binary-encoding',files=files);payload=json.dumps(env,ensure_ascii=True,separators=(',',':'));pieces=[payload[i:i+72000]for i in range(0,len(payload),72000)]
    header=dict(format='complete-source-envelope-chunks-v1',payload_utf8_bytes=len(payload.encode()),payload_sha256=dig(payload),parts=[dict(node_id=PRE+'sourcepart'+str(j)+':20261108',part=j+1,bytes=len(s.encode()),sha256=dig(s))for j,s in enumerate(pieces)])
    node('proofsource','source',json.dumps(header,separators=(',',':')),'FULL source header; all raw numbered fragments required')
    for j,(v,s)in enumerate(zip(header['parts'],pieces),1):
        nodes.append(dict(node_id=v['node_id'],kind='source',title='Complete finite complement source '+str(j),body=s,epistemic='FULL raw fragment incomplete alone',provenance=json.dumps([dict(payload_sha256=dig(payload),part=j)])));edge(ids['proofsource'],v['node_id'],'requires','Complete lossless source fragment required.')
    node('certificate','source',json.dumps(dict(high_pair=h,class_payment={k:v for k,v in r.items()if k!='complement_cases'}),separators=(',',':')),'Terminal result summary; full witnesses and all1150 cases in required source')
    raw=sum(f['bytes']for f in files);backup=DB.stat().st_size+16*1024**2;free=shutil.disk_usage(P).free;assert raw<32*1024**2 and free-backup-5*raw>8*1024**3
    save('class-write-plan.json',dict(explicit_files=[dict(path=f['path'],relative=f['relative'],bytes=f['bytes'])for f in files],raw_bytes=raw,backup_count=1,backup_upper_each=backup,free_before=free,reserve_bytes=8*1024**3,no_expected_deduplication=True))
    save('class-source-hashes.json',{f['path']:f['sha256']for f in files});save('class-packet.json',dict(schema_version=1,nodes=nodes,edges=edges));print(json.dumps(dict(status='PREPARED_COMPLETE_FINITE_COMPLEMENT_NATIVE_INTAKE',nodes=len(nodes),edges=len(edges),files=len(files),parts=len(pieces),raw_bytes=raw,backup_upper_each=backup,free_before=free)))
def audit():
    assert all(sha(Path(n))==h for n,h in rd('class-source-hashes.json').items());packet=rd('class-packet.json');con=sqlite3.connect('file:'+str(DB)+'?mode=ro',uri=True);con.row_factory=sqlite3.Row;con.execute('BEGIN');actual=[];nodes={}
    for table,key,item in [('weave_nodes','node_id',n)for n in packet['nodes']]+[('weave_edges','edge_id',n)for n in packet['edges']]:
        row=dict(con.execute('select * from '+table+' where '+key+'=?',(item[key],)).fetchone());assert all(row[k]==v for k,v in item.items());actual.append(dict(table=table,row=row))
        if table=='weave_nodes':nodes[row['node_id']]=row
    for v in rd('class-parent-snapshot.json'):assert dig(con.execute('select body from weave_nodes where node_id=?',(v['node_id'],)).fetchone()[0])==v['sha256']
    con.rollback();con.close();save('class-actual-readback.json',actual);header=json.loads(nodes[PRE+'proofsource:20261108']['body']);parts=[]
    for j,v in enumerate(header['parts'],1):
        s=nodes[v['node_id']]['body'];assert j==v['part']and len(s.encode())==v['bytes']and dig(s)==v['sha256'];parts.append(s)
    payload=''.join(parts);assert len(payload.encode())==header['payload_utf8_bytes']and dig(payload)==header['payload_sha256'];env=json.loads(payload);root=P/'native-replay'
    for f in env['files']:
        b=base64.b64decode(f['content'],validate=True)if f['encoding']=='base64'else f['content'].encode('utf8');rel=Path(f['relative']);assert not rel.is_absolute()and'..'not in rel.parts;assert b==Path(f['path']).read_bytes()and len(b)==f['bytes']and hashlib.sha256(b).hexdigest()==f['sha256'];dest=root/rel;dest.parent.mkdir(parents=True,exist_ok=True)
        if dest.exists():assert dest.read_bytes()==b
        else:dest.write_bytes(b)
    argv=[sys.executable,'-B','-X','utf8',str(root/'high/portable_replay.py')];t=time.monotonic();r=subprocess.run(argv,cwd=root,capture_output=True,text=True,encoding='utf8');save('class-replay-process.json',dict(argv=argv,exit_code=r.returncode,wall_time_seconds=time.monotonic()-t,stdout=r.stdout,stderr=r.stderr));assert r.returncode==0,r.stderr
    assert 'PASS_FRESH_PORTABLE_ALL_KERNELS_EARS_DOMINATING_TRIANGLES_AND_CAP_COMPLEMENTS'in r.stdout
    for label in ['class-dryrun','class-import']:assert rd(label+'.process.json')['exit_code']==0
    receipt=rd('class-import.stdout.json');assert receipt['inserted']==dict(nodes=len(packet['nodes']),edges=len(packet['edges']),reviews=0);backup=Path(receipt['backup']);assert backup.is_file()and backup.stat().st_size<=rd('class-write-plan.json')['backup_upper_each']
    out=dict(status='PASS_NATIVE_COMPLETE_FINITE_COMPLEMENTS_AND_FULL_EXACT_PORTABLE_REPLAY',native_run_id=receipt['run_id'],nodes=len(packet['nodes']),edges=len(packet['edges']),files=len(env['files']),parts=len(parts),all_source_bytes_identical=True,all_binary_gzip_sources_lossless=True,all4760_kernels_54870_ears_4789_allocations_1150_complements_identical=True,parents_unchanged=True,backup=str(backup),fresh_exact_replay_seconds=time.monotonic()-t,free_after=shutil.disk_usage(P).free,original_global='OPEN',original_goal_complete=False);save('class-native-audit.json',out);print(json.dumps(out))
if __name__=='__main__':prepare()if len(sys.argv)==1 or sys.argv[1]=='prepare'else audit()
