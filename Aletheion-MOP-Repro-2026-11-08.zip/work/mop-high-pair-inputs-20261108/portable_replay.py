"""Source-preserving path adapter; all mathematical readers remain unchanged."""
from pathlib import Path
import json,sys
P=Path(__file__).resolve().parent
import read_high_pairs as h
import read_class_payments as c
def read(n):return json.loads((P/n).read_bytes())
oldh=read('high-pair-result.json');oldc=read('class-result.json')
assert h.sha(P/'high-pair-result.json')==oldc['high_pair_result_sha256']
h.ROOT=P/'inputs';h.main()
newh=read('high-pair-result.json')
for x in(oldh,newh):x.pop('seconds',None)
assert oldh==newh
c.ROOT=P/'class-inputs';c.main()
newc=read('class-result.json');assert newc['high_pair_result_sha256']==h.sha(P/'high-pair-result.json')
for x in(oldc,newc):x.pop('seconds',None);x.pop('high_pair_result_sha256',None)
assert oldc==newc
print(json.dumps(dict(status='PASS_FRESH_PORTABLE_ALL_KERNELS_EARS_DOMINATING_TRIANGLES_AND_CAP_COMPLEMENTS',only_path_adapter=True,every_mathematical_field_identical=True)))
