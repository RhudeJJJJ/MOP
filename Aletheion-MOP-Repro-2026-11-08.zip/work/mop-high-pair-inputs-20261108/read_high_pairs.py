"""Fresh exact full kernel reader. Numpy only for overflow-bounded integer products."""
from pathlib import Path
from fractions import Fraction as F
import json,gzip,hashlib,time,shutil
import numpy as np
P=Path(__file__).resolve().parent
ROOT=P.parent.parent
CERTS=['splitfan-q28-certificates.json','adjacent-32-32-core-certificates.json','adjacent-33-32-h2-core-certificates.json','adjacent-32-32-boundary-core-certificate.json','order71-adjacent-core-certificates.jsonl.gz','order71-boundary-pair-certificate.json','order71-nonadjacent-33-32-h2-core-certificates.jsonl.gz']
PROOFS=['split_fan_reserve_six_proof.txt','split_fan_reserve_six_q28_extension.txt','fan_reserve_eight_proof.txt','split_fan_pair_payment_proof.txt','edge_neighborhood_core_lemma.txt','monotone_edge_core_inheritance_proof.txt','induced_mop_core_exterior_ear_lemma.txt','nonadjacent_h2_edge_neighborhood_core_lemma.txt','order71_internal_33_32_one_ear_proof.txt','order71_adjacent_high_pair_core_proof.txt','order71_degree32_second_hub_proof.txt']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(n):return json.loads((P/'inputs'/n).read_bytes())
def prepare():
    names=CERTS+PROOFS;raw=sum((ROOT/n).stat().st_size for n in names);free=shutil.disk_usage(P).free
    assert raw<32*1024**2 and free-raw-8*1024**2>8*1024**3
    hashes={n:sha(ROOT/n)for n in names}
    plan=dict(explicit_members=names,source_sha256=hashes,raw_bytes=raw,maximum_additional_raw_bytes=raw+8*1024**2,free_before=free,reserve_bytes=8*1024**3,no_recursive_archive=True)
    dest=P/'source-plan.json'
    if dest.exists():assert read_plan()['source_sha256']==hashes
    else:dest.write_text(json.dumps(plan,indent=2)+'\n')
    (P/'inputs').mkdir(exist_ok=True)
    for n in names:
        dest=P/'inputs'/n
        if dest.exists():assert sha(dest)==hashes[n]
        else:shutil.copyfile(ROOT/n,dest)
    return hashes
def read_plan():return json.loads((P/'source-plan.json').read_bytes())
def internal(d,e,a,b):
    p,q=d-3,e-1;assert 0<=a<=p and 1<=b<q
    v,f=p+1,p+2;E=set()
    def add(i,j):assert i!=j;E.add(tuple(sorted((i,j))))
    for i in range(1,p+1):add(0,i)
    for start,length in [(1,a),(a+1,p-a),(f,b),(f+b,q-b)]:
        for i in range(start,start+length-1):add(i,i+1)
    for i in range(f,f+q):add(v,i)
    for edge in [(0,v),(0,f),(0,f+b)]:add(*edge)
    if a:add(1,f)
    if p>a:add(a+1,f+b)
    domain(d+e-2,E,{0:d,v:e})
    return E,v
def boundary(d,e):
    p,q=d-2,e-1;v,c=p+1,p+2;E={(0,i)for i in range(1,p+1)}|{(i,i+1)for i in range(1,p)}
    E|={(v,i)for i in range(c,c+q)}|{(i,i+1)for i in range(c,c+q-1)}|{(0,v),(0,c),(p,c)}
    domain(d+e-1,E,{0:d,v:e});return E
def nonadj(a,b):
    assert 0<=a<=31 and 0<=b<=30
    E={(0,j)for j in range(1,34)}|{(34,j)for j in range(35,65)}|{(32,34),(33,34),(32,33)}
    for first,size,common,at_end in [(1,a,32,True),(a+1,31-a,33,False),(35,b,33,True),(35+b,30-b,32,False)]:
        E|={(i,i+1)for i in range(first,first+size-1)}
        if size:
            endpoint=first+size-1 if at_end else first
            E.add(tuple(sorted((endpoint,common))))
    domain(65,E,{0:33,34:32});assert(0,34)not in E;return E
def domain(n,E,degrees=None):
    assert len(E)==2*n-3 and all(0<=i<j<n for i,j in E)
    adj=[set()for _ in range(n)]
    for i,j in E:adj[i].add(j);adj[j].add(i)
    if degrees:assert all(len(adj[v])==d for v,d in degrees.items())
    bd=[[]for _ in range(n)]
    for i,j in E:
        common=len(adj[i]&adj[j]);assert common in (1,2)
        if common==1:bd[i].append(j);bd[j].append(i)
    assert all(len(r)==2 for r in bd)
    order=[0];prev=-1;v=0
    while True:
        w=next(x for x in bd[v]if x!=prev)
        if w==0:break
        assert w not in order;order.append(w);prev,v=v,w
    assert len(order)==n
    ix={v:i for i,v in enumerate(order)};diags=[]
    for x,y in E:
        a,b=sorted((ix[x],ix[y]))
        if b-a not in (1,n-1):diags.append((a,b))
    assert all(not(a<c<b<d or c<a<d<b)for a,b in diags for c,d in diags)
    return adj,[(i,j)for i,j in E if len(adj[i]&adj[j])==1]
def gram(B,E,target,q=1024):
    n=len(B);r=len(B[0]);assert 1<=r<=n and all(len(row)==r and all(type(x)is int for x in row)for row in B)
    z=max(abs(x)for row in B for x in row);assert max(n,r)*z*z<2**63
    M=np.array(B,dtype=np.int64);C=M.T@M;W=M@M.T
    value=4*q*q*sum(int(W[i,j])for i,j in E)-sum(int(x)**2 for x in C.flat)-target*q**4
    assert value>0,(target,value)
    return value,M,C
def main():
    start=time.monotonic();hashes=prepare();out=[];ear_count=0;ear_min=None;ear_worst=None;max_k=0
    obj=read(CERTS[0]);assert obj['q_leaves']==28 and obj['denominator']==1024 and len(obj['cases'])==15
    values=[]
    for a,rec in enumerate(obj['cases']):
        assert rec['path_sizes']==[a,28-a];E={(0,j)for j in range(1,29)};offset=1
        for length in [a,28-a]:E|={(i,i+1)for i in range(offset,offset+length-1)};offset+=length
        num,_,_=gram(rec['positive_factor'],E,62);values.append(num)
    out.append(dict(class_name='splitfan28',cases=15,target=62,minimum_margin=str(F(min(values),1024**4))))
    for d,e,name,target in [(32,32,CERTS[1],138),(33,32,CERTS[2],140)]:
        obj=read(name);assert obj['denominator']==1024;seen=set();values=[]
        for rec in obj['records']:
            a,b=rec['a'],rec['b'];assert(a,b)not in seen;seen.add((a,b));E,v=internal(d,e,a,b)
            num,M,C=gram(rec['factor'],E,target);values.append(num)
            if d==33:
                base=num-2*1024**4
                _,edges=domain(63,E)
                eligible=[(i,j)for i,j in edges if i not in (0,v)and j not in(0,v)];assert len(eligible)==59
                for i,j in eligible:
                    s=M[i]+M[j]
                    for k in range(1,13):
                        c=(k*s+8)//16
                        assert M.shape[1]*int(np.max(np.abs(M)))*int(np.max(np.abs(c)))<2**63
                        y=M@c
                        margin=base+4*1024**2*sum(int(x)*int(z)for x,z in zip(s,c))-2*sum(int(x)**2 for x in y)-sum(int(x)**2 for x in c)**2
                        if margin>0:break
                    else:raise AssertionError(('one-ear',a,b,i,j))
                    ear_count+=1;max_k=max(max_k,k)
                    if ear_min is None or margin<ear_min:ear_min=margin;ear_worst=[a,b,i,j,k]
            if len(seen)%150==0:print(json.dumps(dict(status='EXACT_KERNEL_PROGRESS',degrees=[d,e],cores=len(seen),ear_cases=ear_count,seconds=time.monotonic()-start)),flush=True)
        assert seen=={(a,b)for a in range(d-2)for b in range(1,e-1)}
        out.append(dict(class_name=f'internal{d}_{e}',cases=len(seen),target=target,minimum_margin=str(F(min(values),1024**4))))
    assert ear_count==54870
    out.append(dict(class_name='internal33_32_nonhub_one_ear',cases=ear_count,target=142,minimum_margin=str(F(ear_min,1024**4)),worst=ear_worst,max_k=max_k))
    for d,e,name,target in [(32,32,CERTS[3],140),(33,32,CERTS[5],142)]:
        obj=read(name);assert obj['denominator']==1024;num,_,_=gram(obj['factor'],boundary(d,e),target)
        out.append(dict(class_name=f'boundary{d}_{e}',cases=1,target=target,minimum_margin=str(F(num,1024**4))))
    for name,mode in [(CERTS[4],'adjacent'),(CERTS[6],'nonadjacent')]:
        seen=set();values=[]
        with gzip.open(P/'inputs'/name,'rt',encoding='utf8')as stream:
            header=json.loads(next(stream));assert header['denominator']==1024 and header['status']=='CANDIDATES_VERIFY_SEPARATELY'
            for line in stream:
                rec=json.loads(line);a,b=rec['a'],rec['b']
                if mode=='adjacent':
                    d,e=rec['degrees'];assert(d,e)in[(33,33),(34,32)];key=(d,e,a,b);E,_=internal(d,e,a,b)
                else:key=(a,b);E=nonadj(a,b)
                assert key not in seen;seen.add(key);num,_,_=gram(rec['factor'],E,142);values.append(num)
        expected={(d,e,a,b)for d,e in[(33,33),(34,32)]for a in range(d-2)for b in range(1,e-1)}if mode=='adjacent'else{(a,b)for a in range(32)for b in range(31)}
        assert seen==expected;out.append(dict(class_name=mode+'71',cases=len(seen),target=142,minimum_margin=str(F(min(values),1024**4))))
        print(json.dumps(out[-1]),flush=True)
    assert all(sha(P/'inputs'/n)==h==sha(ROOT/n)for n,h in hashes.items())
    final=dict(status='PASS_FRESH_ALL_HIGH_PAIR_EXACT_KERNELS_AND_54870_EARS',classes=out,source_sha256=hashes,reader_sha256=sha(Path(__file__)),seconds=time.monotonic()-start,integer_arithmetic='Every numpy matrix product has an explicit conservative int64 no-overflow bound; every square and final sum uses unbounded Python integers.',scope='Exact finite spectral witnesses and actual polygon domains only. Universal embedding, pruning, exterior-ear and split-fan proofs are separate written inputs. This is not B71 or the global theorem.',original_global='OPEN')
    (P/'high-pair-result.json').write_text(json.dumps(final,indent=2)+'\n');print(json.dumps({k:v for k,v in final.items()if k!='source_sha256'},indent=2),flush=True)
if __name__=='__main__':main()
