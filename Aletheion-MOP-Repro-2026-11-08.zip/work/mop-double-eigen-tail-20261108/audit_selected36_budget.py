"""Portable full78-source and ALL28 complete-tail budget check, no compact replay."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,sys,time
P=Path(__file__).resolve().parent;W=P.parent;H=W/'mop-double-fixed-middle-20261108';BASE=W/'mop-double-reciprocal-20261108';sys.path.insert(0,str(BASE));sys.path.insert(0,str(P));import eigen_tail_v3 as tail
import net_interval as net
def rd(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    start=time.monotonic();hashes=rd(P/'selected36-inputs.json');assert len(hashes)==78 and all(sha(W/n)==h for n,h in hashes.items());s=rd(P/'selection36.json');assert s['cutoff']=='5'and s['compact_slabs']==36 and s['actual_total']==[14,41]
    grid=rd(H/'fixed-budget.json')['frequency_grid'][:36];assert grid==s['frequency_grid'];end=F(1,2);compact=F(0)
    for j,v in enumerate(grid):
        a,b=F(v['a']),F(v['b']);assert a==end;end=b;compact+=(b-a)*(F(5,2)if j<16 else F(14,5))/(1+((a+b)/2)**2)
    assert end==5 and compact==F(s['target_compact_upper']);rows=[];step=F(1,640)
    for m in range(14,42):
        value=sum((tail.tail(j*step,(j+1)*step,m)[1]*step for j in range(128)),F(0));reserve=tail.reserve(m);gain=reserve-F(1,2)-2*(compact+value)/net.PI[0];r=next(v for v in s['conditional_cases']if v['total']==m);assert str(value)==r['tail_integral_upper']and str(reserve)==r['reserve_lower']and str(gain)==r['surplus_lower']and gain>F(1,20);rows.append(dict(total=m,surplus_lower=str(gain)))
    controls=rd(P/'physical-controls.json');assert controls['status']=='PASS_ROOT_EIGENDIRECTION_FULL_PRIVATE_INVERSE_AND_SPECTRAL_ENCLOSURE_CONTROLS'and controls['full_private_inverse_cases']==16;assert all(sha(P/n)==h for n,h in controls['source_sha256'].items())and all(sha(BASE/n)==h for n,h in controls['inherited_source_sha256'].items());assert all(sha(W/n)==h for n,h in hashes.items())
    out=dict(status='PASS_PORTABLE_ALL78_SOURCES_AND_ALL28_SELECTED36_FULL_SIGNED_BUDGETS',source_files=78,actual_totals=28,whole_tail_cells=3584,compact_slabs_required=36,cutoff='5',minimum_margin=str(min(F(v['surplus_lower'])for v in rows)),minimum_float=float(min(F(v['surplus_lower'])for v in rows)),seconds=time.monotonic()-start,scope='Exact conditional budget/source replay. Original16 full-private controls source-bound and preserved, not numerically repeated here. No numerical compact leaf or whole family accepted. Original global OPEN.');(P/'portable-budget-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
