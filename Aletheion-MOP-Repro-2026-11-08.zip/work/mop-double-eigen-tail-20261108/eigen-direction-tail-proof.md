# Retaining the two root directions shortens the double-parent high tail

8 November2026. ORIGINAL EVERY finite simple UNIT MOP n>=8,F>=2n GLOBAL
OPEN. This develops an alternative complete-tail input for the SAME actual
double-parent family, not a completed compact phase certificate. No source
or data of the running hybrid56 computation is edited.

1. Actual geometry and exact congruence.

For ALL independent p,q,r,s>=1, put m=q+r, V=(B-2I)T^t for the literal
double cap. The complete all-length coordinate argument is retained in
../mop-global-input-audit-20261108/signed-tail-all-length-proof.md:
TV=-2I,V^tV=[[m+6,m+3],[m+3,m+6]],||B||<sqrt(m+2)+2.
The normalized Q=[[3,1],[1,3]] subtracts only the two positive outer rays;
its effect on phase, not graph energy, is the accepted lossless-ray lemma.

Let U=2^(-1/2)[[1,1],[1,-1]], K=[[2,1],[1,2]]. Then
U^tKU=diag(3,1), U^tQU=diag(4,2),
U^t(V^tV)U=diag(2m+9,3).
Put R=VU diag(1/sqrt3,1). Thus R^tR=diag(g1,g2),
g1=(2m+9)/3,g2=3: the two columns of R are orthogonal.
This congruence is exactly the K^-1/2 normalization followed by an
orthogonal change of coordinates. Both traces, determinants, mixed
determinants and singular-value norms in the root support are preserved.
It does not equate the two directions or graphs with the same total.

For x=z², use C=R^t(I+xB²)^-1R and D=R^tB(I+xB²)^-1R. In these
coordinates Q becomes diag(4/3,2), and the identity term becomes
diag(1/3,1). Consequently the EXACT formulas are

A=Q/(1+4x)+8xI/(1+4x)^2
  -x[(1-4x)C-4xD]/(1+4x)^2,
M=2Q/(1+4x)-2(1-4x)I/(1+4x)^2
  -x[(1-4x)D+4C]/(1+4x)^2.

Here Fhat=zA-ixM is already the K-normalized actual response in the
orthogonal U coordinates. Its invariants are therefore q=TrA,mtrace=TrM,
u=detA,v=detM,w=A11M22+A22M11-2A12M12; no extra K^-1/3 factors
remain. The arm total m is distinct from the trace variable mtrace.

2. Whole-interval spectral bounds, without any infinite-graph norm.

For a WHOLE inverse-frequency cell 0<=a<=z<=b choose the rational upper
L>=sqrt(m+2)+2. Spectral calculus gives

l I <=(I+z²B²)^-1<=I, l=1/(1+b²L²).

Hence l*g_i<=Cii<=g_i. Since the columns of R are orthogonal,
subtracting ((1+l)/2)I before taking the off-diagonal gives

|C12|<=(1-l)*sqrt(g1*g2)/2.

This uses the operator norm bound(1-l)/2 for the centered selfadjoint
resolvent, not merely independent entrywise Cauchy-Schwarz. The earlier
v1 code uses the weaker valid |C12|<=sqrt(g1*g2); its retained result is
a distinct conditional budget, not falsely called the newer version.

The real spectral function lambda/(1+z²lambda²) is bounded in modulus
by H(a,L), where

H=L/(1+a²L²) when aL<=1; H=1/(2a) when aL>1.

This follows by maximizing over |lambda|<=L at the minimum z=a; its
maximum occurs at |lambda|=L or1/a respectively. It includes a0 with
H=L. Therefore |Dij|<=H*sqrt(g_i*g_j). Directed square-root upper
enclosures give rational L and sqrt(g1*g2)=sqrt(2m+9), preserving all
these bounds over the entire cell and every finite outer length p,s.

3. The same signed complete-tail density, with proved divisor floors.

The written signed-tail audit already derives, for A positive definite,
Delta=w²-4uv>=0,Z=sqrt((u-xv)²+xw²),h=Delta/(Z+u+xv)>=0,
S=sqrt((1+4x)[q²+x(mtrace²+2h)]), and exact support density

J=[(2q-mtrace)²+2(1+4x)h]/[2(S+q+2x*mtrace)].

It bounds the full integral from T to infinity after z=1/t. Every actual
point has A>0 only where the whole-cell interval checks establish it;
no indefinite real response is accepted using this rationalization.

There are stronger exact denominator lower bounds than naive independent
interval evaluation shows. Since Z>=|u-xv|,

Z+u+xv>=2max(u,xv)>=2u.

Also S²-(q-2x*mtrace)²=x[(2q+mtrace)²+2(1+4x)h]>=0, so

2(S+q+2x*mtrace)>=4max(q,2x*mtrace)>=4q.

Thus v3 may intersect each computed denominator interval with the
PROVED lower floor2u_lower or4q_lower, respectively. It asserts the
intersection nonempty and retains its original upper endpoint. These
are inequalities valid for every point of the actual domain, not a
replacement of a negative interval denominator by an arbitrary epsilon.
The positive u_lower/q_lower and every other divisor remain checked.

4. Each actual middle total keeps its own private floor and entire tail.

The retained disjoint private partition gives, for every actual m>=14,
F(B)+TrTT^t>2N+G(m+2), with
G(R)=2h²+2h sqrt(R+h²)-6,h=1-2/R.
Use a directed lower enclosure separately for each integer m14..41.
This is the SAME actual graph's private floor throughout its integral.
No reserve or finite norm is moved to an artificially enlarged compact
state. It is stronger than using one reserve for all m20..41, while
retaining both inner arm positions in the compact response.

For any chosen cutoff T at a boundary of the existing grid, let C_T be
the complete exact compact upper on[1/2,T]. The low interval costs1/2
energy. If the entire128-cell signed tail upper J_m on[0,1/T] obeys

G_lower(m+2)-1/2-2(C_T+J_m)/pi_lower>1/20

for EVERY m14..41, the SAME all-old double-parent family has
DeltaF>2N+1/20. A uniform selected target upper for C_T can license a
cutoff before the actual compact slabs finish; it does not prove them.

5. Reuse and noncompletion boundary.

The existing hybrid reader atomically writes a complete exact per-slab
result ONLY after full rational reading, with data hash, full67-source
snapshot, exact area and leaf count. Such completed individual bounds
may be reused at their exact original sources and domains. A new complete
composition must validate every required compact subresult, every raw
data hash and source snapshot, the contiguous frequency endpoints and
ALL28 signed final inequalities; it must retain actual execution evidence
for the original completed subresults. It must not infer an area from
a running progress count or invent a terminal exit for the full56 job.

The old hybrid56 producer/reader may continue while a shorter exact
composition is prepared. No alternate cutoff is accepted merely because
its selection budget or finite physical controls pass. Any intentional
later termination of an own redundant attempt needs its actual identity,
preserved data, explicit reason and confirmed terminal receipt. Foreign
processes and immutable existing source inputs remain untouched.

The v1,v2,v3 source variants and their actual budgets are kept distinct.
Failed interval budgets are method limitations, not original graph
counterexamples. No external priority, independent human/formal audit,
causal LOTSE effect or original global closure is claimed.
