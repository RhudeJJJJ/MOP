from pathlib import Path
from fractions import Fraction as F
import json,hashlib,shutil,sys
P=Path(__file__).resolve().parent;W=P.parent;H=W/'mop-double-fixed-middle-20261108';BASE=W/'mop-double-reciprocal-20261108'
def rd(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,v):(P/n).write_text(json.dumps(v,indent=2)+'\n')
def main():
    old=rd(H/'full-inputs.json');assert len(old)==67 and all(sha(W/n)==h for n,h in old.items())
    scout=rd(P/'cut-scout-v3.json');assert scout['status']=='EXACT_ROOT_EIGENDIRECTION_POSITIVE_FLOOR_TAIL_CUT_SCOUT_ONLY'and all(sha(P/n)==h for n,h in scout['source_sha256'].items());row=next(v for v in scout['rows']if v['cutoff']=='5');assert row['all_targets_suffice']and not row['failed']and row['compact_slabs']==36 and[c['total']for c in row['cases']]==list(range(14,42))and all(F(c['surplus_lower'])>F(1,20)for c in row['cases'])
    physical=rd(P/'physical-controls.json');assert physical['status']=='PASS_ROOT_EIGENDIRECTION_FULL_PRIVATE_INVERSE_AND_SPECTRAL_ENCLOSURE_CONTROLS'and physical['full_private_inverse_cases']==16 and all(sha(P/n)==h for n,h in physical['source_sha256'].items())and all(sha(BASE/n)==h for n,h in physical['inherited_source_sha256'].items())
    grid=rd(H/'fixed-budget.json')['frequency_grid'][:36];assert F(grid[0]['a'])==F(1,2)and F(grid[-1]['b'])==5
    selection=dict(format='actual-double-selected36-root-direction-tail-v1',cutoff='5',actual_total=[14,41],compact_slabs=36,frequency_grid=grid,target_compact_upper=row['compact_target_upper'],conditional_cases=row['cases'],required_surplus='1/20',original_source_manifest_sha256=sha(H/'full-inputs.json'),scope='Same actual all-old ordered-boundary double-parent family. Reuse complete exact individual hybrid subresults0..35 with full data/source binding and genuine observed source-reader execution. Recompute all28 complete signed tails. Never infer numerical areas from progress counts alone.',original_global='OPEN')
    save('selection36.json',selection)
    new=['eigen_tail_v2.py','eigen_tail_v3.py','eigen-direction-tail-proof.md','scout_cuts_v3.py','cut-scout-v3.json','check_eigen_physical.py','physical-controls.json','prepare_selected36.py','read_selected36.py','selection36.json'];hashes=dict(old);hashes[H.relative_to(W).as_posix()+'/full-inputs.json']=sha(H/'full-inputs.json')
    for n in new:hashes[P.relative_to(W).as_posix()+'/'+n]=sha(P/n)
    raw=sum((W/n).stat().st_size for n in hashes);free=shutil.disk_usage(P).free;planned_additional=8*1024**2;assert raw<4*1024**2 and free-raw-planned_additional>8*1024**3
    save('selected36-inputs.json',hashes);save('selected36-write-plan.json',dict(explicit_input_members=list(hashes),input_raw_bytes=raw,planned_additional_data_and_results_upper=planned_additional,free_before=free,reserve_bytes=8*1024**3,native_backup='Not part of this foreground composition launch; separately checked before any later intake'))
    for name in['selected-data','selected-exact']:(P/name).mkdir(exist_ok=True)
    print(json.dumps(dict(status='PREPARED_SAME_PHYSICAL_DOUBLE_FAMILY_SELECTED36',input_files=len(hashes),raw_bytes=raw,planned_additional_bytes=planned_additional,cutoff='5',all28_conditional_margins_strictly_gt='1/20',minimum_conditional_margin=float(min(F(v['surplus_lower'])for v in row['cases'])),scope='Full36 compact not yet complete; original global OPEN')))
if __name__=='__main__':main()
