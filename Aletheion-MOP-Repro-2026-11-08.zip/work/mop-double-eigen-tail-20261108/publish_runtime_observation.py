"""Publish ONLY an actual verbatim tool result previously saved by the agent.

This validates its content/identity; authenticity of the saved tool response
remains the agent's responsibility, not something this script can infer.
"""
from pathlib import Path
import json,hashlib,sys,datetime
P=Path(__file__).resolve().parent;W=P.parent;H=W/'mop-double-fixed-middle-20261108'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rd(p):return json.loads(p.read_bytes())
def main():
    assert len(sys.argv)==2,'Pass path containing the ACTUAL tools.write_stdin(44532) result object, without rewriting its output.'
    path=Path(sys.argv[1]).resolve();event=rd(path);assert event.get('session_id')==44532 or event.get('exit_code')==0
    indices=[]
    for line in event['output'].splitlines():
        try:v=json.loads(line)
        except ValueError:continue
        if v.get('status')=='EXACT_FULL_HYBRID56_SLAB_PASSED':indices.append(v['index'])
    assert indices and max(indices)>=35,'Actual execution result has not yet reported complete36 prefix'
    hashes=rd(P/'selected36-inputs.json');assert all(sha(W/n)==h for n,h in hashes.items())
    out=dict(format='actual-source-execution-observation-v1',original_exact_session_id=44532,observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_manifest_sha256=sha(H/'full-inputs.json'),reader_sha256=sha(H/'read_full.py'),full_tool_result=event,verbatim_event_source=str(path),event_file_sha256=sha(path),authenticity_boundary='Agent-saved actual tool response; validator checks shape, source identity and completed prefix index, not the origin of arbitrary JSON.')
    dest=P/'runtime-prefix-observation.json';assert not dest.exists(),'Existing observation is preserved; do not overwrite'
    dest.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(status='PUBLISHED_ACTUAL_ORIGINAL_READER_PREFIX36_EXECUTION_OBSERVATION',last_completed=max(indices),path=str(dest))))
if __name__=='__main__':main()
