"""Compose actual source-bound exact subproofs with ALL28 complete new tails.

Does NOT rerun the expensive leaf arithmetic and never calls a progress count
an area. Completed individual source-bound exact area records are obligatory;
a genuine observed original-reader prefix execution is also obligatory.
"""
from pathlib import Path
from fractions import Fraction as F
import sys,json,hashlib,time,types
P=Path(__file__).resolve().parent;W=P.parent;H=W/'mop-double-fixed-middle-20261108';BASE=W/'mop-double-reciprocal-20261108';sys.path.insert(0,str(BASE));sys.path.insert(0,str(H))
import reciprocal_cover as old,fixed_cover
sys.path.insert(0,str(P));import eigen_tail_v3 as tail
import net_interval as net
def rd(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def atomic(p,v):t=p.with_suffix('.tmp');t.write_text(json.dumps(v,separators=(',',':'))+'\n');t.replace(p)
def waitfile(p):
    deadline=time.monotonic()+7200
    while not p.exists():assert time.monotonic()<deadline,'bounded selected36 input wait expired: '+p.name;time.sleep(.25)
    return rd(p)
def copy_same(src,dest):
    b=src.read_bytes()
    if dest.exists():assert dest.read_bytes()==b,'Selected snapshot changed'
    else:dest.write_bytes(b)
def check_observation(v):
    assert v['format']=='actual-source-execution-observation-v1'and v['original_exact_session_id']==44532 and v['source_manifest_sha256']==sha(H/'full-inputs.json')and v['reader_sha256']==sha(H/'read_full.py')
    tool=v['full_tool_result'];assert tool.get('session_id')==44532 or tool.get('exit_code')==0
    found=[]
    for line in tool['output'].splitlines():
        try:r=json.loads(line)
        except ValueError:continue
        if r.get('status')=='EXACT_FULL_HYBRID56_SLAB_PASSED':found.append(r['index'])
    assert found and max(found)>=35,'No actual full prefix36 execution event';return max(found)
def main():
    start=time.monotonic();hashes=rd(P/'selected36-inputs.json');assert all(sha(W/n)==h for n,h in hashes.items());selection=rd(P/'selection36.json');oldhashes=rd(H/'full-inputs.json');assert selection['format']=='actual-double-selected36-root-direction-tail-v1'and selection['compact_slabs']==36 and selection['cutoff']=='5'and selection['original_source_manifest_sha256']==sha(H/'full-inputs.json');records=[];compact=F(0);end=F(1,2);zero=lambda*args:dict(upper=F(0));dummy=types.SimpleNamespace(bound=zero)
    for i,row in enumerate(selection['frequency_grid']):
        source=H/f'exact-slabs/{i:04}.json';r=waitfile(source);raw=H/f'full-checkpoints/{i:04}.json';data=waitfile(raw);a,b=F(row['a']),F(row['b']);assert a==end;end=b;target=(F(5,2)if i<16 else F(14,5))/(1+((a+b)/2)**2)
        assert r['index']==i and(r['a'],r['b'])==(str(a),str(b))and r['source_sha256']==oldhashes and r['data_sha256']==sha(raw)and F(0)<=F(r['area'])<=(b-a)*target
        # Supplementary grammar/domain replay with ZERO callback; numerical
        # enclosure/area comes ONLY from the retained completed exact subproof.
        if i<16:
            assert r['method']=='FULL_EXACT_OLD_FOUR_INFINITE_COVER_LOW_SLAB'and data['index']==i and F(data['target'])==target
            _,count,anchor,xd,fc=old.frequency(data['partition'],a,b,target,dummy,dummy);assert count==r['leaves']and anchor==r['max_anchor']and fc==r['frequency_cells']
        else:
            assert r['method']==('REUSED_COMPLETE_EXACT_PREFLIGHT_IDENTICAL_DOMAIN_AND_TARGET'if i==23 else'FULL_EXACT_ACTUAL378_MIDDLE_PAIRS_TWO_INFINITE_OUTER_ARMS')
            assert data['index']==i and(data['a'],data['b'])==(str(a),str(b));_,count,anchor,depth=fixed_cover.read_cell(data,zero);assert count==r['leaves']and anchor==r['max_anchor']and depth==r['frequency_depth']
            if i==23:
                pre=rd(H/'preflight-result.json');assert pre['status']=='PASS_EXACT_COMPLETE_FIXED_MIDDLE_ONE_FREQUENCY_PREFLIGHT'and pre['certificate_sha256']==sha(raw)and pre['whole_slab_integral_upper']==r['area']and pre['reader_sha256']==sha(H/'read_preflight.py')
                assert all(sha(H/n)==h for n,h in pre['source_sha256'].items())and all(sha(BASE/n)==h for n,h in pre['inherited_source_sha256'].items())
            else:assert data['source_sha256']==oldhashes
        sr=P/f'selected-exact/{i:04}.json';dr=P/f'selected-data/{i:04}.json';copy_same(source,sr);copy_same(raw,dr);assert sha(sr)==sha(source)and sha(dr)==r['data_sha256'];compact+=F(r['area']);records.append(dict(index=i,area=r['area'],leaves=r['leaves'],exact_record=sr.relative_to(P).as_posix(),exact_sha256=sha(sr),data=dr.relative_to(P).as_posix(),data_sha256=sha(dr),numerical_proof_origin=r['method']));assert all(sha(W/n)==h for n,h in hashes.items());print(json.dumps(dict(status='SELECTED36_COMPLETED_EXACT_SUBPROOF_BOUND_AND_GRAMMAR_AUDITED',index=i,total=36,numerical_leaf_arithmetic='REUSED_PREVIOUS_COMPLETE_SOURCE_BOUND_EXACT_SUBRESULT',leaves=sum(v['leaves']for v in records),seconds=time.monotonic()-start)),flush=True)
    assert end==5 and compact<=F(selection['target_compact_upper']);runtime=waitfile(P/'runtime-prefix-observation.json');last=check_observation(runtime);cases=[];step=F(1,640)
    for m in range(14,42):
        cells=[];value=F(0)
        for j in range(128):
            a,b=j*step,(j+1)*step;upper=tail.tail(a,b,m)[1];value+=upper*step;cells.append(dict(a=str(a),b=str(b),density_upper=str(upper)))
        reserve=tail.reserve(m);gain=reserve-F(1,2)-2*(compact+value)/net.PI[0];assert gain>F(1,20);proposal=next(v for v in selection['conditional_cases']if v['total']==m);assert str(reserve)==proposal['reserve_lower']and str(value)==proposal['tail_integral_upper'];cases.append(dict(actual_total=m,reserve_lower=str(reserve),tail_integral_upper=str(value),surplus_lower=str(gain),cells=cells));print(json.dumps(dict(status='SELECTED36_COMPLETE_SIGNED_TOTAL_PASSED',actual_total=m,surplus_lower=float(gain))),flush=True)
    assert all(sha(W/n)==h for n,h in hashes.items());out=dict(status='PASS_COMPLETE_DOUBLE_PARENT_M14_TO41_SELECTED36_ROOT_DIRECTION_TAIL',actual_domain='Every old UNIT MOP H>=3,ordered boundary,independent p,s>=1,q,r>=1,14<=q+r<=41; coherent whole reflection q>=r',proved_increment='DeltaF>2N+1/20,N=p+q+r+s+3',cutoff='5',compact_integral_upper=str(compact),compact_records=records,cases=cases,source_sha256=hashes,original_exact_source_snapshot=oldhashes,runtime_prefix_observation_sha256=sha(P/'runtime-prefix-observation.json'),observed_original_prefix_index=last,replay_scope='All36 saved exact area subproofs reused with full data/source binding; complete grammar/domain audited with zero callback, NOT claimed a new numerical leaf replay. All3584 exact tail intervals and ALL28 actual final inequalities recomputed here. Genuine original execution event retained. Original56 job need not have completed.',seconds=time.monotonic()-start,original_global='OPEN; private sibling and final mathematical assembly remain separate');atomic(P/'selected36-result.json',out);print(json.dumps({k:v for k,v in out.items()if k not in['compact_records','cases','source_sha256','original_exact_source_snapshot']},indent=2),flush=True)
if __name__=='__main__':main()
