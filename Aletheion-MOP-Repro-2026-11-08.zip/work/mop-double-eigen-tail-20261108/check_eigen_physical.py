from pathlib import Path
from fractions import Fraction as F
import sys,json,time,hashlib
P=Path(__file__).resolve().parent;BASE=P.parent/'mop-double-reciprocal-20261108';sys.path.insert(0,str(BASE))
import exact as e,double_geometry as g,double_physical as phys
sys.path.insert(0,str(P));import eigen_tail_v3 as tail
def enclosed(x,a):return a[0]<=x<=a[1]
def transformed(A):return((A[0][0]+2*A[0][1]+A[1][1])/6,(A[0][0]-2*A[0][1]+A[1][1])/2,(A[0][0]-A[1][1])/2)
def main():
    start=time.monotonic();count=0;states=[(1,7,7,1),(2,13,1,3),(3,1,18,2),(1,10,10,1),(2,1,19,2),(1,20,21,1),(2,40,1,3),(4,19,19,2)];rows=[]
    for p,q,r,s in states:
        B,T=g.cap(p,q,r,s);n=len(B);m=q+r;V=e.mm(B,e.tr(T));V=[[a-2*b for a,b in zip(row,tt)]for row,tt in zip(V,e.tr(T))];W=[[v[0]+v[1],v[0]-v[1]]for v in V];assert e.mm(e.tr(W),W)==[[2*(2*m+9),0],[0,6]]
        for t in[F(5),F(7)]:
            z=1/t;x=z*z;BB=e.mm(B,B);R=e.inverse([[F(int(i==j))+x*BB[i][j]for j in range(n)]for i in range(n)]);CW=e.mm(e.mm(e.tr(W),R),W);DW=e.mm(e.mm(e.mm(e.tr(W),B),R),W)
            C=(CW[0][0]/6,CW[1][1]/2,CW[0][1]/2);D=(DW[0][0]/6,DW[1][1]/2,DW[0][1]/2);ci,di=tail.constants(z-F(1,1280),z+F(1,1280),m)
            assert enclosed(C[0],ci[0][0])and enclosed(C[1],ci[1][1])and C[2]**2/3<=ci[0][1][1]**2
            assert enclosed(D[0],di[0][0])and enclosed(D[1],di[1][1])and D[2]**2/3<=di[0][1][1]**2
            f=1+4*x;Q=(F(4,3),F(2),F(0));I=(F(1,3),F(1),F(0));A=tuple(Q[i]/f+8*x*I[i]/f**2-x*((1-4*x)*C[i]-4*x*D[i])/f**2 for i in range(3));M=tuple(2*Q[i]/f-2*(1-4*x)*I[i]/f**2-x*((1-4*x)*D[i]+4*C[i])/f**2 for i in range(3));actual=phys.response(p,q,r,s,t);AR=[[t*v[0]for v in row]for row in actual];MR=[[-t*t*v[1]for v in row]for row in actual];assert A==transformed(AR)and M==transformed(MR)
            # Root/K invariants independently agree, without numerical square roots.
            assert A[0]+A[1]==F(2,3)*(AR[0][0]+AR[1][1]-AR[0][1]);assert A[0]*A[1]-A[2]**2/3==(AR[0][0]*AR[1][1]-AR[0][1]**2)/3
            assert M[0]*M[1]-M[2]**2/3==(MR[0][0]*MR[1][1]-MR[0][1]**2)/3
            density=tail.tail(z-F(1,1280),z+F(1,1280),m);assert density[0]>=0;count+=1
        rows.append(dict(p=p,q=q,r=r,s=s,private_order=n,total=m,cases=2));print(json.dumps(dict(status='EIGEN_TAIL_FULL_PRIVATE_CONTROL_PROGRESS',states=len(rows),full_inverse_cases=count,total_states=len(states))),flush=True)
    out=dict(status='PASS_ROOT_EIGENDIRECTION_FULL_PRIVATE_INVERSE_AND_SPECTRAL_ENCLOSURE_CONTROLS',full_private_states=len(states),full_private_inverse_cases=count,rows=rows,source_sha256={n:hashlib.sha256((P/n).read_bytes()).hexdigest()for n in['eigen_tail_v2.py','eigen_tail_v3.py','eigen-direction-tail-proof.md','check_eigen_physical.py']},inherited_source_sha256={n:hashlib.sha256((BASE/n).read_bytes()).hexdigest()for n in['exact.py','complex_exact.py','double_geometry.py','double_physical.py','disk_interval.py','net_interval.py']},seconds=time.monotonic()-start,scope='Full exact physical calibration of the new congruence and signed matrices; written all-length spectral argument supplies universal coverage. Conditional cutoff budget is separate and compact full family remains pending. Original global OPEN.');(P/'physical-controls.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in['source_sha256','inherited_source_sha256','rows']},indent=2))
if __name__=='__main__':main()
