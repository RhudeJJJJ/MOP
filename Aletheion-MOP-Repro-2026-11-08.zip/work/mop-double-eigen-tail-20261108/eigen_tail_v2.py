"""K root directions with spectral lower/upper resolvent bounds, exact192bit."""
from pathlib import Path
from fractions import Fraction as F
import sys
BASE=Path(__file__).resolve().parent.parent/'mop-double-reciprocal-20261108';sys.path.insert(0,str(BASE))
import disk_interval as h
def con(x):return h.con(x)
def add(A,B):return[[h.add(a,b)for a,b in zip(x,y)]for x,y in zip(A,B)]
def scale(A,c):return[[h.mul(a,c)for a in row]for row in A]
def det(A):return h.sub(h.mul(A[0][0],A[1][1]),h.square(A[0][1]))
def constants(a,b,m):
    gp=F(2*m+9,3);gm=F(3);cross=h.sqrt(con(2*m+9))[1];norm=h.add(h.sqrt(con(m+2)),con(2))[1]
    lo=1/(1+b*b*norm*norm)
    ccross=(1-lo)*cross/2
    dbound=norm/(1+a*a*norm*norm)if a*norm<=1 else 1/(2*a)
    C=[[(lo*gp,gp),(-ccross,ccross)],[(-ccross,ccross),(lo*gm,gm)]]
    D=[[(-dbound*gp,dbound*gp),(-dbound*cross,dbound*cross)],[(-dbound*cross,dbound*cross),(-dbound*gm,dbound*gm)]]
    return C,D
def tail(a,b,m):
    assert 14<=m<=41 and 0<=a<=b
    x=(a*a,b*b);one=con(1);I=[[con(F(1,3)),con(0)],[con(0),one]];Q=[[con(F(4,3)),con(0)],[con(0),con(2)]];C,D=constants(a,b,m)
    fac=h.add(one,h.times(x,4));fac2=h.square(fac);factor=h.sub(one,h.times(x,4));inv=h.div(one,fac);inv2=h.div(one,fac2)
    A=add(add(scale(Q,inv),scale(I,h.times(h.mul(x,inv2),8))),scale(add(scale(C,factor),scale(D,h.times(x,-4))),h.neg(h.mul(x,inv2))))
    M=add(add(scale(Q,h.times(inv,2)),scale(I,h.times(h.mul(factor,inv2),-2))),scale(add(scale(D,factor),scale(C,con(4))),h.neg(h.mul(x,inv2))))
    q=h.add(A[0][0],A[1][1]);mtr=h.add(M[0][0],M[1][1]);u=det(A);v=det(M)
    assert A[0][0][0]>0 and u[0]>0 and q[0]>0,'positive real matrix not enclosed'
    w=h.sub(h.add(h.mul(A[0][0],M[1][1]),h.mul(A[1][1],M[0][0])),h.times(h.mul(A[0][1],M[0][1]),2))
    disc=h.positive(h.sub(h.square(w),h.times(h.mul(u,v),4)));Z=h.sqrt(h.add(h.square(h.sub(u,h.mul(x,v))),h.mul(x,h.square(w))))
    H=h.div(disc,h.add(h.add(Z,u),h.mul(x,v)));num=h.add(h.square(h.sub(h.times(q,2),mtr)),h.times(h.mul(fac,H),2))
    den=h.times(h.add(h.add(h.sqrt(h.mul(fac,h.positive(h.add(h.square(q),h.mul(x,h.add(h.square(mtr),h.times(H,2))))))),q),h.times(h.mul(x,mtr),2)),2)
    return h.positive(h.div(num,den))
def reserve(m):
    R=F(m+2);a=1-2/R;return h.sub(h.add(con(2*a*a),h.times(h.sqrt(con(R+a*a)),2*a)),con(6))[0]
