"""Same spectral-direction enclosure, with PROVED positive denominator floors."""
from eigen_tail_v2 import F,h,con,add,scale,det,constants,reserve
def tail(a,b,m):
    assert 14<=m<=41 and 0<=a<=b
    x=(a*a,b*b);one=con(1);I=[[con(F(1,3)),con(0)],[con(0),one]];Q=[[con(F(4,3)),con(0)],[con(0),con(2)]];C,D=constants(a,b,m)
    fac=h.add(one,h.times(x,4));fac2=h.square(fac);factor=h.sub(one,h.times(x,4));inv=h.div(one,fac);inv2=h.div(one,fac2)
    A=add(add(scale(Q,inv),scale(I,h.times(h.mul(x,inv2),8))),scale(add(scale(C,factor),scale(D,h.times(x,-4))),h.neg(h.mul(x,inv2))))
    M=add(add(scale(Q,h.times(inv,2)),scale(I,h.times(h.mul(factor,inv2),-2))),scale(add(scale(D,factor),scale(C,con(4))),h.neg(h.mul(x,inv2))))
    q=h.add(A[0][0],A[1][1]);mtr=h.add(M[0][0],M[1][1]);u=det(A);v=det(M)
    assert A[0][0][0]>0 and u[0]>0 and q[0]>0,'positive real matrix not enclosed'
    w=h.sub(h.add(h.mul(A[0][0],M[1][1]),h.mul(A[1][1],M[0][0])),h.times(h.mul(A[0][1],M[0][1]),2))
    disc=h.positive(h.sub(h.square(w),h.times(h.mul(u,v),4)));Z=h.sqrt(h.add(h.square(h.sub(u,h.mul(x,v))),h.mul(x,h.square(w))))
    # Z>=|u-xv|, so Z+u+xv>=2u, for EVERY real v.
    hd=h.add(h.add(Z,u),h.mul(x,v));hd=max(hd[0],2*u[0]),hd[1];assert hd[0]<=hd[1]
    H=h.div(disc,hd);num=h.add(h.square(h.sub(h.times(q,2),mtr)),h.times(h.mul(fac,H),2))
    den=h.times(h.add(h.add(h.sqrt(h.mul(fac,h.positive(h.add(h.square(q),h.mul(x,h.add(h.square(mtr),h.times(H,2))))))),q),h.times(h.mul(x,mtr),2)),2)
    # S²-(q-2xm)²=x[(2q+m)²+2(1+4x)H]>=0 =>2(S+q+2xm)>=4q.
    den=max(den[0],4*q[0]),den[1];assert den[0]<=den[1]
    return h.positive(h.div(num,den))
