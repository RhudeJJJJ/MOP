from pathlib import Path
from fractions import Fraction as F
import sys,json,time,hashlib
P=Path(__file__).resolve().parent;W=P.parent
import eigen_tail_v3 as e
sys.path.insert(0,str(W/'mop-double-reciprocal-20261108'))
import net_interval as net
def main():
    start=time.monotonic();grid=json.loads((W/'mop-double-fixed-middle-20261108/fixed-budget.json').read_bytes())['frequency_grid'];rows=[]
    for T in[F(9,2),F(5)]:
        selected=[(j,v)for j,v in enumerate(grid)if F(v['b'])<=T];assert selected and F(selected[-1][1]['b'])==T
        compact=sum(((F(v['b'])-F(v['a']))*(F(5,2)if j<16 else F(14,5))/(1+((F(v['a'])+F(v['b']))/2)**2)for j,v in selected),F(0));cases=[];failed=[]
        for m in range(14,42):
            try:
                step=F(1,128)/T;tail=sum((e.tail(j*step,(j+1)*step,m)[1]*step for j in range(128)),F(0));r=e.reserve(m);gain=r-F(1,2)-2*(compact+tail)/net.PI[0];cases.append(dict(total=m,reserve_lower=str(r),tail_integral_upper=str(tail),surplus_lower=str(gain),surplus_float=float(gain)))
            except(AssertionError,ArithmeticError)as exc:failed.append(dict(total=m,error=str(exc)))
        row=dict(cutoff=str(T),compact_slabs=len(selected),compact_target_upper=str(compact),cases=cases,failed=failed,all_targets_suffice=not failed and all(F(c['surplus_lower'])>F(1,20)for c in cases),minimum=min(cases,key=lambda v:F(v['surplus_lower']))if cases else None);rows.append(row)
        print(json.dumps(dict(cutoff=str(T),compact_slabs=len(selected),all_targets_suffice=row['all_targets_suffice'],minimum_total=row['minimum']['total']if row['minimum']else None,minimum_surplus=row['minimum']['surplus_float']if row['minimum']else None,failed_totals=[v['total']for v in failed])),flush=True)
    out=dict(status='EXACT_ROOT_EIGENDIRECTION_POSITIVE_FLOOR_TAIL_CUT_SCOUT_ONLY',rows=rows,source_sha256={n:hashlib.sha256((P/n).read_bytes()).hexdigest()for n in['eigen_tail_v2.py','eigen_tail_v3.py','scout_cuts_v3.py']},seconds=time.monotonic()-start,scope='Exact conditional target budgets, not completed compact or family proof. New all-length congruence/spectral/denominator proof and full physical controls still required. Original global OPEN.');(P/'cut-scout-v3.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(status=out['status'],seconds=out['seconds'])))
if __name__=='__main__':main()
