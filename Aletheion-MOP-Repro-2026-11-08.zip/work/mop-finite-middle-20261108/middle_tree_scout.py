"""HEURISTIC ONLY. Group finite middle lengths; retain both infinite outer tails."""
import float_discovery
float_discovery.install()
import middle_ad5 as direct,middle_common_ad5 as common
import json,time,sys
def solve(ta,tb,target,limit=30000):
    stats=dict(calls=0,leaves=0,max_outer_anchor=4,middle_splits=0,common_leaves=0,direct_leaves=0);cache={};maximum=0.;trees=[]
    def evaluate(n,left,m,right,q,hi):
        key=(n,left,m,right,q,hi)
        if key in cache:return cache[key]
        if stats['calls']>=limit:raise ArithmeticError('node budget reached')
        stats['calls']+=1;stats['max_outer_anchor']=max(stats['max_outer_anchor'],n,m)
        loL=0. if left else 1.;loR=0. if right else 1.;loM=0. if q<hi else 1.;best=None;proxy=None
        for mod,symbol in((common,'0'),(direct,'4'))if ta<2 else((direct,'4'),(common,'0')):
            got=mod.bound(ta,tb,loL,1.,loR,1.,loM,1.,float(q),float(hi),n,m,q);got['symbol']=symbol
            if 'grad_proxy'in got:proxy=got['grad_proxy']
            if best is None or got['upper']<best['upper']:best=got
            if best['upper']<=target:break
        if proxy is not None and 'grad'not in best:best['grad_proxy']=proxy
        cache[key]=best;return best
    def visit(n,left,m,right,q,hi):
        nonlocal maximum
        got=evaluate(n,left,m,right,q,hi)
        if got['upper']<=target:
            stats['leaves']+=1;maximum=max(maximum,got['upper']);stats['common_leaves'if got['symbol']=='0'else'direct_leaves']+=1;return got['symbol']
        if not left and not right and q==hi:raise ArithmeticError('singleton triple needs frequency refinement '+str((n,m,q,got['upper'],target)))
        if max(n,m)>160:raise ArithmeticError('outer anchor depth reached')
        grad=got.get('grad',got.get('grad_proxy',(0.,1.,1.,1.,1.)));scores=[float(grad[1])if left else -1.,float(grad[2])if right else -1.,float(grad[3])+float(grad[4])*(hi-q)if q<hi else -1.]
        count=(hi-q)//4+1;dim=2 if count>=4 else max(range(3),key=lambda j:scores[j])
        if dim==0:return'1'+visit(n,False,m,right,q,hi)+visit(n+4,True,m,right,q,hi)
        if dim==1:return'2'+visit(n,left,m,False,q,hi)+visit(n,left,m+4,True,q,hi)
        assert q<hi;stats['middle_splits']+=1;mid=q+4*(count//2-1)
        return'3'+visit(n,left,m,right,q,mid)+visit(n,left,m,right,mid+4,hi)
    try:
        for n in range(1,5):
            for m in range(1,5):
                for q in range(3,7):trees.append(visit(n,True,m,True,q,q+4*((45-q)//4)))
        return dict(status='HEURISTIC_COMPLETE_GROUPED_MIDDLE_COVER',maximum=maximum,trees=trees,stats=stats)
    except ArithmeticError as error:return dict(status='HEURISTIC_REFINEMENT_REQUIRED',reason=str(error),stats=stats)
if __name__=='__main__':
    cases=[(.375,.390625),(1.,1.03125),(4.,4.0625),(8.,8.0625),(15.9375,16.)]
    if len(sys.argv)>1:cases=[cases[int(sys.argv[1])]]
    for ta,tb in cases:
        target=1.35/(1+((ta+tb)/2)**2);start=time.perf_counter();result=solve(ta,tb,target);result.pop('trees',None);print(json.dumps(dict(a=ta,b=tb,target=target,seconds=time.perf_counter()-start,**result)),flush=True)
