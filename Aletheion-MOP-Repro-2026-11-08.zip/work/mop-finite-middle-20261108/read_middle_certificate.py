"""Exact finite middle and TWO unbounded outer length coverage; no float import."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,time,sys
import rational_grid
rational_grid.install()
import middle_ad5 as direct,middle_common_ad5 as common
import uniform_middle_tail as tail,net_interval as net
P=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def parse_tree(code,ta,tb,n,m,q,hi,target):
    position=leaves=maxouter=0;upper=F(0)
    def visit(n,left,m,right,q,hi):
        nonlocal position,leaves,maxouter,upper
        assert position<len(code),'truncated tree';symbol=code[position];position+=1;maxouter=max(maxouter,n,m)
        assert 3<=q<=hi<=45 and(hi-q)%4==0,'middle class endpoints'
        if symbol in'04':
            loL=F(0)if left else F(1);loR=F(0)if right else F(1);loM=F(0)if q<hi else F(1)
            got=(common if symbol=='0'else direct).bound(ta,tb,loL,F(1),loR,F(1),loM,F(1),F(q),F(hi),n,m,q)
            assert got['upper']<=target,'exact leaf misses target '+str((ta,tb,n,left,m,right,q,hi,got['method'],float(got['upper']),float(target)))
            upper=max(upper,got['upper']);leaves+=1;return
        if symbol=='1':
            assert left,'split isolated left';visit(n,False,m,right,q,hi);visit(n+4,True,m,right,q,hi)
        elif symbol=='2':
            assert right,'split isolated right';visit(n,left,m,False,q,hi);visit(n,left,m+4,True,q,hi)
        elif symbol=='3':
            assert q<hi,'split singleton middle';count=(hi-q)//4+1;mid=q+4*(count//2-1);visit(n,left,m,right,q,mid);visit(n,left,m,right,mid+4,hi)
        else:raise AssertionError('unknown tree symbol')
    visit(n,True,m,True,q,hi);assert position==len(code),'tree suffix';return upper,leaves,maxouter
def frequency(part,ta,tb,target):
    assert F(part['a'])==ta and F(part['b'])==tb and ta<tb,'frequency endpoints'
    if 'split'in part:
        assert 'trees'not in part and len(part['split'])==2;mid=(ta+tb)/2;a=frequency(part['split'][0],ta,mid,target);b=frequency(part['split'][1],mid,tb,target);return a[0]+b[0],a[1]+b[1],max(a[2],b[2]),a[3]+b[3]
    assert len(part['trees'])==64,'all64 ORDERED residue roots required';maximum=F(0);leaves=anchor=0
    for index,code in enumerate(part['trees']):
        n=1+index//16;m=1+(index//4)%4;q=3+index%4;hi=q+4*((45-q)//4);value,count,depth=parse_tree(code,ta,tb,n,m,q,hi,target);maximum=max(maximum,value);leaves+=count;anchor=max(anchor,depth)
    return(tb-ta)*maximum,leaves,anchor,1
def main():
    start=time.monotonic();reader_hash=sha(Path(__file__));live='--live'in sys.argv;cert=None
    if not live:cert=json.loads((P/'middle-certificate.json').read_bytes())
    grid=json.loads((P/'middle-frequency-grid.json').read_bytes());seen=[];areas=[];total=F(0);end=F(1,2);leaves=anchor=fcells=0
    for index,row in enumerate(grid):
        if live:
            path=P/'middle-checkpoints'/f'{index:04}.json';deadline=time.monotonic()+600
            while not path.exists():
                assert time.monotonic()<deadline,'bounded foreground checkpoint wait expired';time.sleep(.25)
            cell=json.loads(path.read_bytes())
        else:cell=cert['cells'][index]
        seen.append(cell);a,b=F(row['a']),F(row['b']);assert a==end and cell['index']==index;end=b
        target=F(cell['target']);assert target>=0;area,count,depth,fcount=frequency(cell['partition'],a,b,target);total+=area;leaves+=count;anchor=max(anchor,depth);fcells+=fcount;areas.append(dict(index=index,area=str(area),leaves=count,anchor=depth,frequency_cells=fcount))
        if index%5==0:print(json.dumps(dict(status='EXACT_GROUPED_MIDDLE_PROGRESS',index=index,total=len(grid),leaves=leaves,seconds=time.monotonic()-start)),flush=True)
    assert end==16
    if live:cert=json.loads((P/'middle-certificate.json').read_bytes())
    assert cert['format']=='grouped-finite-middle-two-infinite-outer-v1'and cert['cells']==seen and cert['frequency_grid_sha256']==sha(P/'middle-frequency-grid.json')
    for name,value in cert['source_sha256'].items():assert sha(P/name)==value,'changed producer/input '+name
    assert sha(Path(__file__))==reader_hash,'reader changed during run'
    It=sum((tail.tail(F(k,1024),F(k+1,1024))[1]/1024 for k in range(64)),F(0));gain=F(17,10)-F(1,2)-2*(total+It)/net.PI[0];assert gain>F(1,10)
    out=dict(status='PASS_EXACT_ALL_MIDDLE_q3_TO45_AND_TWO_UNBOUNDED_OUTER_ARMS',compact_integral_upper=str(total),tail_integral_upper=str(It),surplus_lower=str(gain),surplus_float=float(gain),middle_range=[3,45],residue_roots=64,frequency_cells=fcells,length_tree_leaves=leaves,max_outer_anchor=anchor,reader_sha256=reader_hash,certificate_sha256=sha(P/'middle-certificate.json'),seconds=time.monotonic()-start,original_global='OPEN',scope='External parent-child-sibling family only; complete analytic bridges/source intake and original coverage audit separate.')
    (P/'middle-reader-cells.json').write_text(json.dumps(areas,separators=(',',':'))+'\n');(P/'middle-reader-result.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
