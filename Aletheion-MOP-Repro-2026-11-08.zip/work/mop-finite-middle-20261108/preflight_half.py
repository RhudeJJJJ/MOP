from pathlib import Path
import json,time
import middle_tree_scout as scout
P=Path(__file__).resolve().parent;a,b=.5,.515625;target=1.3/(1+((a+b)/2)**2);start=time.perf_counter();result=scout.solve(a,b,target-1e-7)
assert result['status']=='HEURISTIC_COMPLETE_GROUPED_MIDDLE_COVER',result
(P/'half-preflight-trees.json').write_text(json.dumps(dict(a='1/2',b='33/64',trees=result['trees']),separators=(',',':'))+'\n');result.pop('trees');print(json.dumps(dict(a=a,b=b,target=target,seconds=time.perf_counter()-start,**result)))
