from fractions import Fraction as F
from pathlib import Path
import json
import rational_grid
rational_grid.install()
import middle_ad5 as ad,middle_physical as phys
import exact as e,complex_exact as z,geometry as g,disk_interval as h
P=Path(__file__).resolve().parent
def cont(t,n):
    d,dd=[F(1),t],[F(0),F(1)]
    for j in range(2,n+1):d.append(t*d[-1]+d[-2]);dd.append(d[-2]+t*dd[-1]+dd[-2])
    return d,dd
def endpoint(t,length,j):
    d,dp=cont(t,max(length,j));r=d[length-1]/d[length];s=1/d[length];u=d[j]/d[length];unit=(z.z(1),z.z(0,-1),z.z(-1),z.z(0,1))[(j-1)%4];root=2*r+t;sign=1 if j%2 else -1;st=-s*dp[j]/d[j];su=1/d[j]
    return dict(j=j,u=u,r=r,e=z.mul(unit,z.z(s)),rt=(t+4*sign*s*st)/(2*root)-F(1,2),ru=2*sign*s*su/root,et=z.mul(unit,z.z(st)),eu=z.mul(unit,z.z(su)),ud=u*(dp[j]/d[j]-dp[length]/d[length]))
def independent_head(t,L,R,M,gamma):
    w=z.z(t,2);I=z.z(0,1)
    def hh(E):return z.div(z.add(z.z(1),z.mul(I,z.add(z.z(E['r']),E['e']))),w)
    hl,hr,hm=map(hh,(L,R,M));sm=z.div(z.add(z.z(gamma),z.mul(z.z(0,2),hm)),w);Z=[[z.z(t+L['r']+M['r']),z.add(I,hm)],[z.add(I,hm),z.add(z.z(t+R['r']),sm)]];Ri=phys.inv(Z);U=[[z.sub(z.z(1),z.mul(I,hl)),z.z(1)],[z.z(),z.sub(z.z(1),z.mul(I,hr))]];fl=z.div(z.add(z.z(1),z.mul(z.z(0,2),hl)),w);fr=z.div(z.add(z.z(1),z.mul(z.z(0,2),hr)),w);trans=phys.trans
    value=z.mm(z.mm(U,Ri),trans(U));value[0][0]=z.add(value[0][0],fl);value[1][1]=z.add(value[1][1],fr);partials=[]
    for dim in range(5):
        ist=dim==0;dr=[];de=[];dh=[]
        for axis,E in enumerate((L,R,M),1):
            rr=E['rt']if ist else E['ru']if dim==axis else F(0);ee=E['et']if ist else E['eu']if dim==axis else z.z();dr.append(rr);de.append(ee)
        for rr,ee,hh0 in zip(dr,de,(hl,hr,hm)):dh.append(z.div(z.sub(z.mul(I,z.add(z.z(rr),ee)),hh0 if ist else z.z()),w))
        ds=z.div(z.sub(z.add(z.z(int(dim==4)),z.mul(z.z(0,2),dh[2])),sm if ist else z.z()),w)
        Zd=[[z.z(int(ist)+dr[0]+dr[2]),dh[2]],[dh[2],z.add(z.z(int(ist)+dr[1]),ds)]];Ud=[[z.neg(z.mul(I,dh[0])),z.z()],[z.z(),z.neg(z.mul(I,dh[1]))]]
        part=z.plus(z.mm(z.mm(Ud,Ri),trans(U)),z.mm(z.mm(U,Ri),trans(Ud)));part=z.plus(part,z.scale(z.mm(z.mm(z.mm(z.mm(U,Ri),Zd),Ri),trans(U)),z.z(-1)))
        for k,(hd,ff)in enumerate(zip((dh[0],dh[1]),(fl,fr))):part[k][k]=z.add(part[k][k],z.div(z.sub(z.mul(z.z(0,2),hd),ff if ist else z.z()),w))
        partials.append(part)
    return value,partials
def contains(interval,value):return interval[0]<=value<=interval[1]
def main():
    states=boxes=components=phases=tangents=0
    cases=[(p,q,ell)for q in(3,4,5,6)for p in range(1,5)for ell in range(1,5)]+[(2,45,4),(5,16,6),(8,24,9)]
    for p,q,ell in cases:
        B,T=g.cap(p,q,ell)
        for t in(F(1,4),F(1),F(8)):
            L,R,M=endpoint(t,p,(p-1)%4+1),endpoint(t,ell,(ell-1)%4+1),endpoint(t,q,(q-3)%4+3)
            Fc,df=independent_head(t,L,R,M,F(q));full=phys.response(p,q,ell,t);assert Fc==full,'independent2head elimination versus complete PRIVATE inverse'
            Ri=phys.inv(phys.pencil(B,t));dfull=z.scale(z.mm(z.mm(z.mm(z.real(T),Ri),Ri),z.real(e.tr(T))),z.z(-1));w=z.z(t,2)
            for k,length in enumerate((p,ell)):dfull[k][k]=z.add(dfull[k][k],z.div(z.z(length-1),z.mul(w,w)))
            for box in(False,True):
                rad=F(1,1000)if box else F(0);du=F(1,200)if box else F(0);dg=F(1,100)if box else F(0);ranges=[(t-rad,t+rad)]
                for E in(L,R,M):ranges.append((max(F(0),E['u']-du),min(F(1),E['u']+du)))
                ranges.append((max(F(3),F(q)-dg),min(F(45),F(q)+dg)));ad.set_box(tuple((b-a)/2 for a,b in ranges));variables=[ad.variable(a,b,j)for j,(a,b)in enumerate(ranges)]
                got=ad.response(*variables,L['j'],R['j'],M['j'])
                for i in range(2):
                    for j in range(2):
                        for k in range(2):
                            a=got[i][j][k];assert contains(a.v,Fc[i][j][k])
                            for dim in range(5):assert contains(a.d[dim],df[dim][i][j][k]);components+=1
                            tangent=a.d[0]
                            for axis,E in enumerate((L,R,M),1):tangent=h.add(tangent,h.times(a.d[axis],E['ud']))
                            assert contains(tangent,dfull[i][j][k]);tangents+=1
                if not box:
                    phase=ad.phase(variables[0],got);reference=h.times(phys.phase(p,q,ell,t),t);assert phase.v[0]<=reference[1]and reference[0]<=phase.v[1];phases+=1
                boxes+=1
            states+=1
    out=dict(status='PASS_FIVE_VARIABLE_MIDDLE_RESPONSE_ALL_PARTIALS_AND_FULL_PRIVATE_TANGENTS',physical_states=states,point_and_box_cases=boxes,independent_partial_components=components,full_private_tangent_components=tangents,independent_phase_cases=phases,grid_bits=96,scope='Calibrates the five-variable analytic continuation including independent middle bulk gamma, and true physical chain. Full ALL-length/grouped certificate remains OPEN.',original_global='OPEN');(P/'middle-ad5-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
