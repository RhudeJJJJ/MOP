"""Pure source-bound acceptance AFTER the terminal full exact reader and sealed proof."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json
P=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rd(n):return json.loads((P/n).read_bytes())

def main():
    expected={'uniform-private-budget-check.json':'PASS_UNIFORM_Q_AT_LEAST3_PRIVATE_BUDGET17_OVER10','uniform-tail-check.json':'EXACT_UNIFORM_MIDDLE_TAIL_INPUT_CHECK','common-polynomial-check.json':'PASS_FORMAL_EIGHT_VARIABLE_TWO_HEAD_COMMON_RESPONSE_AND_DETERMINANT','common-phase-identity-check.json':'PASS_RAW_ARBITRARY_COMPLEX_SYMMETRIC_COMMON_PHASE_DETERMINANT_IDENTITY','middle-ad5-check.json':'PASS_FIVE_VARIABLE_MIDDLE_RESPONSE_ALL_PARTIALS_AND_FULL_PRIVATE_TANGENTS','common-ad5-check.json':'PASS_COMMON_FIVE_VARIABLE_RESPONSE_PARTIALS_AND_INDEPENDENT_PHASE','middle-defect-check.json':'PASS_FINITE_MIDDLE_ALL_ARM_DEFECT_AND_FULL_PRIVATE_TAIL_IDENTITY_CONTROLS','middle-coverage-check.json':'PASS_GROUPED_MIDDLE_COVERAGE_AND_DAMAGED_ARTIFACT_REJECTION','grid-check.json':'PASS_EXACT_OUTWARD_GRID96_RATIONAL_CONTROLS','middle-reader-result.json':'PASS_EXACT_ALL_MIDDLE_q3_TO45_AND_TWO_UNBOUNDED_OUTER_ARMS'}
    for name,status in expected.items():assert rd(name)['status']==status,name
    r=rd('middle-reader-result.json');cert=rd('middle-certificate.json');manifest=rd('middle-checkpoints/producer-inputs.json')
    mandatory={'produce_middle_certificate.py','read_middle_certificate.py','middle_tree_scout.py','middle_ad5.py','middle_common_ad5.py','middle-frequency-grid.json','float_discovery.py','exact.py','disk_interval.py','net_interval.py','rational_grid.py','curve_interval.py','uniform_middle_tail.py'}
    assert set(manifest)==mandatory and cert['source_sha256']==manifest
    assert all(sha(P/n)==v for n,v in manifest.items())
    assert r['certificate_sha256']==sha(P/'middle-certificate.json')and r['reader_sha256']==sha(P/'read_middle_certificate.py')and F(r['surplus_lower'])>F(1,10)
    rows=rd('uniform-tail-check.json')['rows'];assert any(row.get('t_from')==16 and row.get('integral_upper')==r['tail_integral_upper']for row in rows)
    assert r['residue_roots']==64 and r['middle_range']==[3,45]
    assert 'LOCAL EXACT ACCEPTANCE PASSED.'in(P/'middle-payment-proof.md').read_text()
    names=['middle-payment-proof.md','middle-private-budget-proof.md','geometry.py','exact.py','poly.py','poly8.py','complex_exact.py','middle_physical.py','middle_ad5.py','middle_common_ad5.py','disk_interval.py','net_interval.py','rational_grid.py','curve_interval.py','uniform_middle_tail.py','check_uniform_private_budget.py','check_uniform_tail.py','check_common_polynomials.py','check_common_phase_identity.py','check_middle_ad5.py','check_common_ad5.py','check_middle_defects.py','check_middle_coverage.py','check_grid.py','read_middle_certificate.py','middle_tree_scout.py','produce_middle_certificate.py','float_discovery.py','middle-frequency-grid.json','middle-certificate.json','middle-reader-cells.json','middle-checkpoints/producer-inputs.json','half-exact-preflight.json','half-preflight-trees.json','preflight_exact_half.py','preflight_half.py','finalize_middle.py']+list(expected)
    out=dict(status='PASS_ALL_FINITE_MIDDLE_q3_TO45_AND_TWO_INFINITE_OUTER_ARMS',proof_sha256=sha(P/'middle-payment-proof.md'),private_proof_sha256=sha(P/'middle-private-budget-proof.md'),certificate_sha256=sha(P/'middle-certificate.json'),surplus_lower=r['surplus_lower'],proved_surplus='1/10',residue_roots=64,middle_range=[3,45],outer_lengths='BOTH_UNBOUNDED',frequency_cells=r['frequency_cells'],length_tree_leaves=r['length_tree_leaves'],max_outer_anchor=r['max_outer_anchor'],all_q_external_root_payment='FOLLOWS_WITH_PRIOR_q1_q2_AND_q>=40; common surplus>1/50 for old H>=3',original_global='OPEN',original_goal_complete=False,private_sibling_role='NOT_IDENTIFIED_WITH_EXTERNAL_b; separate q+ell>=50 theorem; smaller ordered pairs OPEN',all_small_old_whole_payment='NOT_INFERRED',method_effect='OPEN',native_intake='PENDING',source_sha256={n:sha(P/n)for n in dict.fromkeys(names)})
    (P/'middle-verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k!='source_sha256'}))
if __name__=='__main__':main()
