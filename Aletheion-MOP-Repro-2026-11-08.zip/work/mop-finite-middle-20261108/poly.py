"""Exact sparse rational coefficient algebra retained from the accepted checker."""
from fractions import Fraction as F
import itertools
class P:
    def __init__(self,v=0):self.c={k:F(x)for k,x in v.items()if x}if isinstance(v,dict)else{(0,)*5:F(v)}if v else{}
    def __add__(self,v):
        v=to(v);c=dict(self.c)
        for k,x in v.c.items():c[k]=c.get(k,F(0))+x
        return P(c)
    __radd__=__add__
    def __neg__(self):return P({k:-v for k,v in self.c.items()})
    def __sub__(self,v):return self+-to(v)
    def __rsub__(self,v):return to(v)+-self
    def __mul__(self,v):
        v=to(v);c={}
        for k,x in self.c.items():
            for l,y in v.c.items():
                m=tuple(a+b for a,b in zip(k,l));c[m]=c.get(m,F(0))+x*y
        return P(c)
    __rmul__=__mul__
    def __truediv__(self,v):return self*F(1,v)
    def __eq__(self,v):return self.c==to(v).c
    def reduce(self):
        out=P()
        for k,x in self.c.items():
            if k[3]>=2 or k[4]>=2:
                i=3 if k[3]>=2 else 4;j=1 if i==3 else 2;l=list(k);l[i]-=2
                out+= (P({tuple(l):x})*(V[j]*V[j]+V[0]*V[j]-1)).reduce()
            else:out+=P({k:x})
        return out
def to(v):return v if isinstance(v,P)else P(v)
V=[P({tuple(int(i==j)for i in range(5)):1})for j in range(5)]
def z(a=0,b=0):return to(a),to(b)
def ca(x,y):return x[0]+y[0],x[1]+y[1]
def cs(x,y):return x[0]-y[0],x[1]-y[1]
def cm(x,y):return x[0]*y[0]-x[1]*y[1],x[0]*y[1]+x[1]*y[0]
def ct(x,k):return x[0]*k,x[1]*k
def reduce(x):return tuple(v.reduce()for v in x)
def equal(x,y):return reduce(cs(x,y))==(P(),P())
def determinant(A):
    out=z()
    for p in itertools.permutations(range(len(A))):
        term=z((-1)**sum(p[i]>p[j]for i in range(len(A))for j in range(i+1,len(A))))
        for i,k in enumerate(p):term=cm(term,A[i][k])
        out=ca(out,term)
    return out
