"""Explicit foreground producer; atomic checkpoints, exact reader pays every leaf."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,time
import middle_tree_scout as scout
P=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def atomic(path,value):
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(value,separators=(',',':'))+'\n');temp.replace(path)
def main():
    folder=P/'middle-checkpoints';folder.mkdir(exist_ok=True)
    names=['produce_middle_certificate.py','read_middle_certificate.py','middle_tree_scout.py','middle_ad5.py','middle_common_ad5.py','middle-frequency-grid.json','float_discovery.py','exact.py','disk_interval.py','net_interval.py','rational_grid.py','curve_interval.py','uniform_middle_tail.py']
    hashes={name:sha(P/name)for name in names};manifest=folder/'producer-inputs.json'
    if manifest.exists():assert json.loads(manifest.read_bytes())==hashes,'changed sources: preserve checkpoints and inspect before resuming'
    else:atomic(manifest,hashes)
    grid=json.loads((P/'middle-frequency-grid.json').read_bytes());start=time.monotonic()
    def cell(a,b,target,depth=0):
        result=scout.solve(float(a),float(b),float(target)-1e-7)
        if result['status']=='HEURISTIC_COMPLETE_GROUPED_MIDDLE_COVER':return dict(a=str(a),b=str(b),trees=result['trees'],stats=result['stats'])
        assert depth<8,'bounded frequency refinement failed '+result['reason'];mid=(a+b)/2
        return dict(a=str(a),b=str(b),split=[cell(a,mid,target,depth+1),cell(mid,b,target,depth+1)])
    for index,row in enumerate(grid):
        path=folder/f'{index:04}.json'
        if path.exists():continue
        a,b=F(row['a']),F(row['b']);tm=(a+b)/2;target=F(13,10)/(1+tm*tm)
        if index==0:
            pre=json.loads((P/'half-exact-preflight.json').read_bytes());assert pre['status']=='PASS_EXACT_HALF_PREFLIGHT_ONLY'and pre['partition_sha256']==sha(P/'half-preflight-trees.json');partition=json.loads((P/'half-preflight-trees.json').read_bytes());assert F(partition['a'])==a and F(partition['b'])==b
        else:
            print(json.dumps(dict(status='HEURISTIC_CELL_STARTED',index=index,total=len(grid))),flush=True);partition=cell(a,b,target)
        atomic(path,dict(index=index,target=str(target),partition=partition))
        if index%5==0:print(json.dumps(dict(status='HEURISTIC_GROUPED_MIDDLE_CHECKPOINT',index=index,total=len(grid),seconds=time.monotonic()-start)),flush=True)
    cert=dict(format='grouped-finite-middle-two-infinite-outer-v1',middle_range=[3,45],source_sha256=hashes,frequency_grid_sha256=sha(P/'middle-frequency-grid.json'),cells=[json.loads((folder/f'{j:04}.json').read_bytes())for j in range(len(grid))],scope='Full discrete middle q3..45; two outer lengths unbounded; original global OPEN')
    assert all(sha(P/name)==value for name,value in hashes.items());atomic(P/'middle-certificate.json',cert);print(json.dumps(dict(status='HEURISTIC_GROUPED_MIDDLE_CERTIFICATE_READY_REQUIRES_EXACT_READER',base_cells=len(grid),seconds=time.monotonic()-start)),flush=True)
if __name__=='__main__':main()
