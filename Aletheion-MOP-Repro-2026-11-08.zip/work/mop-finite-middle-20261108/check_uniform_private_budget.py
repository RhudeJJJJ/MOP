"""Finite q<=9 polynomial/root proof pieces; q>=10 analytic in written proof."""
from fractions import Fraction as F
from pathlib import Path
import json
import exact as e,geometry as g
P=Path(__file__).resolve().parent
def add(a,b,k=1):return e.trim([(a[j]if j<len(a)else 0)+k*(b[j]if j<len(b)else 0)for j in range(max(len(a),len(b)))])
def scale(a,k):return e.trim([k*v for v in a])
def za(a,b):return add(a[0],b[0]),add(a[1],b[1])
def zm(a,b):return add(e.mul(a[0],b[0]),e.mul(a[1],b[1]),-1),add(e.mul(a[0],b[1]),e.mul(a[1],b[0]))
def divide(a,b):
    a=e.trim(a);b=e.trim(b);q=[F(0)]*max(1,len(a)-len(b)+1)
    while a!=[0]and len(a)>=len(b):
        k=len(a)-len(b);v=a[-1]/b[-1];q[k]+=v
        for j in range(len(b)):a[j+k]-=v*b[j]
        a=e.trim(a)
    assert a==[0];return e.trim(q)
def gcd(a,b):
    while b!=[0]:a,b=b,e.remainder(a,b)
    return scale(a,1/a[-1])
def root_lower(B):
    cp=e.characteristic(B);zero=0
    while cp[0]==0:cp=cp[1:];zero+=1
    layers=[];current=cp
    while len(current)>1:
        common=gcd(current,e.derivative(current));squarefree=divide(current,common);layers.append(e.sturm(squarefree));current=common
    seq=layers[0];bound=F(max(map(sum,B))+2);intervals=[];stack=[(-bound,bound)]
    while stack:
        a,b=stack.pop();count=e.variations(seq,a)-e.variations(seq,b)
        if not count:continue
        assert count>0
        if count==1 and b-a<=F(1,4096)and a*b>0:
            mult=sum(e.variations(s,a)-e.variations(s,b)for s in layers);intervals.append((a,b,mult));continue
        for k in range(1,len(cp)+2):
            mid=(k*a+b)/(k+1)
            if all(e.ev(s[0],mid)!=0 for s in layers):break
        else:raise AssertionError('nonroot rational split unavailable')
        stack.extend([(a,mid),(mid,b)])
    assert sum(m for a,b,m in intervals)+zero==len(B)
    lower=sum((m*a*a if a>0 else-m*a*a for a,b,m in intervals),F(0))
    return dict(characteristic=list(map(str,e.characteristic(B))),zero_modes=zero,roots=[[str(a),str(b),m]for a,b,m in sorted(intervals)],D_lower=str(lower)),lower
def main():
    D=[[F(1)],[F(0),F(1)]];E=[([F(0)],[F(0)]),([F(1)],[F(0)])];X=([F(1)],[F(0)]);rows=[];controls=0
    for m in range(2,17):
        dn=add(e.mul([0,1],D[-1]),D[-2]);en=za(za(zm(([0,1],[0]),E[-1]),E[-2]),za((D[-1],[0]),zm(([0],[-2]),X)));X=za((D[-1],[0]),zm(([0],[-1]),X));D.append(dn);E.append(en);q=m-1
        c0=add(e.mul([1,0,1],D[m]),e.mul([0,1],E[m][0]));c1=add(e.mul([1,0,1],D[m-1]),e.mul([0,1],E[m-1][0]));M0=scale(E[m][1],-1);M1=scale(E[m-1][1],-1);cross=add(e.mul(M0,c1),e.mul(M1,c0),-1)
        assert all(v>=0 for v in E[m][0]+E[m-1][0]+M0+M1+cross)and any(M0)and any(cross)
        row=dict(q=q,phase_derivative_cross_polynomial=list(map(str,cross)),all_required_coefficient_signs=True)
        for p in(1,2):
            for ell in(1,2):
                actual,_=g.cap(p,q,ell);char=e.characteristic(actual);degree=len(actual)
                for t in(F(1,4),F(1),F(4)):
                    dp,dl=[F(1),t],[F(1),t]
                    for j in range(2,p+1):dp.append(t*dp[-1]+dp[-2])
                    for j in range(2,ell+1):dl.append(t*dl[-1]+dl[-2])
                    r,s=dp[-2]/dp[-1],dl[-2]/dl[-1];C=(t+s)*(e.ev(D[m],t)+r*e.ev(D[m-1],t))+e.ev(E[m][0],t)+r*e.ev(E[m-1][0],t);M=e.ev(M0,t)+r*e.ev(M1,t)
                    units=((1,0),(0,1),(-1,0),(0,-1));got=tuple(sum(cc*t**k*units[(k-degree)%4][j]for k,cc in enumerate(char))for j in(0,1));assert got==(dp[-1]*dl[-1]*C,-dp[-1]*dl[-1]*M);controls+=1
        if q>=3:
            base,_=g.cap(1,q,1);root,lower=root_lower(base);assert lower>F(17,5);row['exact_base']=root
        elif q==1:
            base,_=g.cap(1,1,1);bull=e.mul([0,1],e.mul([-3,-1,1],[-1,1,1]));assert e.characteristic(base)==bull;row['bull_characteristic']=list(map(str,bull))
        rows.append(row)
    # f is increasing on r>=1 by its explicit derivative. sqrt11>33/10.
    large_lower=F(82,10)-F(20,41)-5-F(2,17)+F(1,289)
    assert large_lower>F(17,10)
    out=dict(status='PASS_UNIFORM_Q_AT_LEAST3_PRIVATE_BUDGET17_OVER10',small_q_range=[3,15],rows=rows,full_private_determinant_controls=controls,analytic_large_q_from=16,f17_minus1_lower=str(large_lower),conclusion='For ALL integers p,ell>=1 and q>=3, F(B)>N+q-1+17/10. Written finite q3..15 phase comparison and analytic q>=16 pinching proof required.',all_q_full_root_payment='OPEN',original_global='OPEN')
    (P/'uniform-private-budget-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k!='rows'}))
if __name__=='__main__':main()
