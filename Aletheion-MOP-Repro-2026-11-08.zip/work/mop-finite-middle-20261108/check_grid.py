from pathlib import Path
from fractions import Fraction as F
import json,random
import rational_grid as h
P=Path(__file__).resolve().parent
def contains(a,lo,hi):assert a[0]<=lo<=hi<=a[1]
def main():
    rng=random.Random(20261106);checks=0
    for i in range(2000):
        a=sorted(F(rng.randrange(-100000,100001),rng.randrange(1,10001))for _ in range(2));b=sorted(F(rng.randrange(-100000,100001),rng.randrange(1,10001))for _ in range(2));contains(h.add(a,b),a[0]+b[0],a[1]+b[1]);contains(h.sub(a,b),a[0]-b[1],a[1]-b[0]);v=[x*y for x in a for y in b];contains(h.mul(a,b),min(v),max(v));ss=[x*x for x in a];contains(h.square(a),F(0)if a[0]<=0<=a[1]else min(ss),max(ss));bp=sorted((abs(b[0])+F(1,10007),abs(b[1])+F(1,10007)));v=[x/y for x in a for y in bp];contains(h.div(a,bp),min(v),max(v));ap=sorted(map(abs,a));rr=h.sqrt(ap);assert rr[0]>=0 and F(rr[0])**2<=ap[0] and F(rr[1])**2>=ap[1];assert h.down(a[0])<=a[0]<=h.up(a[0]);checks+=7
        for z in(h.down(a[0]),h.up(a[1])):
            assert F(z)==F(z.n,h.G)and z.numerator==F(z.n,h.G).numerator and z.denominator==F(z.n,h.G).denominator
            assert F(z)+F(1,3)==z+F(1,3) and F(z)*F(2,7)==z*F(2,7);checks+=3
    tiny=F(1,2**200);contains(h.con(tiny),tiny,tiny);contains(h.con(-tiny),-tiny,-tiny)
    rejected=False
    try:h.con(.25)
    except AssertionError:rejected=True
    assert rejected
    out=dict(status='PASS_EXACT_OUTWARD_GRID96_RATIONAL_CONTROLS',rational_inequalities_and_numeric_protocol_checks=checks+2,float_input_rejected=True,grid_bits=96,rounding_proof='integer floor/ceiling of directed interval endpoints; finite tests calibrate implementation');(P/'grid-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
