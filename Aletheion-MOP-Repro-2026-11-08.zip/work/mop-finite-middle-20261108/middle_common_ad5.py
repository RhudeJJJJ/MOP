"""Common-denominator FIVE-variable variant; formal/physical checks obligatory."""
from fractions import Fraction as F
import middle_ad5 as ad
from middle_ad5 import z,ca,cs,cm,ct,cd,sq,rt,atan,arg,acos
def numerators(t,ul,ur,um,gamma,jl,jr,jm):
    rl,el=ad.endpoints(t,ul,jl);rr,er=ad.endpoints(t,ur,jr);rm,em=ad.endpoints(t,um,jm);w=z(t,2);w2=cm(w,w);w4=cm(w2,w2)
    aa=ca(z(t+rl,1),el);bb=ca(z(t+rr,1),er);mm=ca(z(t+rm,1),em);nl=cs(z(t-2*rl,4),ct(el,2));nr=cs(z(t-2*rr,4),ct(er,2));d=t+rl+rm
    J=ca(cs(ca(ct(w2,t+rr),ct(w,gamma)),ct(ca(z(rm),em),2)),z(0,2));D=ca(ct(J,d),cm(mm,mm));den=cm(w2,D)
    naa=ca(ca(cm(nl,D),cm(cm(aa,aa),J)),ca(ct(cm(cm(cm(z(0,-1),aa),mm),w2),2),ct(w4,d)))
    nab=cm(cm(bb,w),cs(ct(w2,d),cm(z(0,1),cm(aa,mm))));nbb=ca(cm(nr,D),ct(cm(cm(bb,bb),w2),d))
    pp=ca(cm(nr,naa),cm(cm(cm(bb,bb),w2),ca(ct(nl,d),cm(aa,aa))))
    return den,naa,nab,nbb,cd(pp,w2)
def response(t,ul,ur,um,gamma,jl,jr,jm):
    den,aa,ab,bb,_=numerators(t,ul,ur,um,gamma,jl,jr,jm);aa,ab,bb=(cd(v,den)for v in(aa,ab,bb));return[[aa,ab],[ab,bb]]
def expression(t,ul,ur,um,gamma,jl,jr,jm):
    den,aa,ab,bb,nd=numerators(t,ul,ur,um,gamma,jl,jr,jm);trace=ct(cs(ca(aa,bb),ab),F(2,3));c=z(1/t,-F(1,2));an=ca(ca(den,cm(c,trace)),ct(cm(cm(c,c),nd),F(1,3)))
    az=sq(an[0])+sq(an[1]);dz=sq(den[0])+sq(den[1]);rho=(sq(t)+4)/(4*sq(t));cross=(aa[0]*bb[0]+aa[1]*bb[1]-sq(ab[0])-sq(ab[1]))*F(2,3);ar,ai=cm(an,(den[0],-den[1]));gg=2*ar-dz+rho*cross
    co=(rt(gg)-rho*rt(sq(nd[0])+sq(nd[1]))/3)/rt(az);si=rt(1-sq(co));bot=ar*co-ai*si
    if ar.v[0]>0 and bot.v[0]>0:return t*atan((ai*co+ar*si)/bot)
    return t*(arg(ar,ai)+acos(co))
def bound(ta,tb,la,lb,ra,rb,ma,mb,ga,gb,jl,jr,jm):
    ad.set_box(((tb-ta)/2,(lb-la)/2,(rb-ra)/2,(mb-ma)/2,(gb-ga)/2));var=[ad.variable(a,b,j)for j,(a,b)in enumerate(((ta,tb),(la,lb),(ra,rb),(ma,mb),(ga,gb)))];cap=ad.h.up(2*ad.n.PI[1]*tb)
    try:
        f=expression(*var,jl,jr,jm);return dict(upper=min(cap,max(F(0),f.v[1])),method='common-centered5',grad=tuple(max(abs(v)for v in dd)for dd in f.d))
    except(ArithmeticError,AssertionError):return dict(upper=cap,method='common-cap')
