from pathlib import Path
from fractions import Fraction as F
import json,time
import read_middle_certificate as reader
P=Path(__file__).resolve().parent;part=json.loads((P/'half-preflight-trees.json').read_bytes());a,b=F(part['a']),F(part['b']);tm=(a+b)/2;target=F(13,10)/(1+tm*tm);start=time.monotonic();area,leaves,anchor,fcells=reader.frequency(part,a,b,target)
out=dict(status='PASS_EXACT_HALF_PREFLIGHT_ONLY',a=str(a),b=str(b),area=str(area),leaves=leaves,anchor=anchor,frequency_cells=fcells,partition_sha256=reader.sha(P/'half-preflight-trees.json'),seconds=time.monotonic()-start,original_global='OPEN');(P/'half-exact-preflight.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
