"""Independent exact full private inverse and phase; no AD/head formula."""
from fractions import Fraction as F
import complex_exact as z
import exact as e
import geometry as g
import disk_interval as h,net_interval as n
def trans(A):return list(map(list,zip(*A)))
def pencil(B,t):return[[z.z(t*int(i==j),B[i][j])for j in range(len(B))]for i in range(len(B))]
def inv(A):
    size=len(A);W=[list(row)+b for row,b in zip(A,z.eye(size))]
    for j in range(size):
        k=next(i for i in range(j,size)if W[i][j]!=z.z());W[k],W[j]=W[j],W[k];pv=W[j][j];W[j]=[z.div(v,pv)for v in W[j]]
        for i in range(size):
            if i!=j:
                v=W[i][j];W[i]=[z.sub(a,z.mul(v,b))for a,b in zip(W[i],W[j])]
    return[r[size:]for r in W]
def response(p,q,ell,t):
    B,T=g.cap(p,q,ell);R=inv(pencil(B,t));Fc=z.mm(z.mm(z.real(T),R),z.real(e.tr(T)))
    for k,length in enumerate((p,ell)):Fc[k][k]=z.sub(Fc[k][k],z.div(z.z(length-1),z.z(t,2)))
    return Fc
def phase(p,q,ell,t):
    Fc=response(p,q,ell,t);S=[[2*v[0]+t*v[1]for v in row]for row in Fc]
    assert S==e.tr(S)and S[0][0]>=0 and S[1][1]>=0 and S[0][0]*S[1][1]-S[0][1]**2>=0,'physical normalized sector'
    Ki=[[F(2,3),-F(1,3)],[-F(1,3),F(2,3)]];trace=z.trace(z.mm(z.real(Ki),Fc));df=z.div(z.det(Fc),z.z(3));cc=z.z(1/t,-F(1,2));ar,ai=z.add(z.add(z.z(1),z.mul(cc,trace)),z.mul(z.mul(cc,cc),df))
    S0=[[v/t for v in row]for row in S];gg=1+F(2,3)*(S0[0][0]+S0[1][1]-S0[0][1])+(S0[0][0]*S0[1][1]-S0[0][1]**2)/3;assert gg>=1
    rho=(t*t+4)/(4*t*t);cosine=h.div(h.sub(h.sqrt(h.con(gg)),h.times(h.sqrt(h.con(z.abs2(df))),rho)),h.sqrt(h.con(ar*ar+ai*ai)));assert -1<cosine[0]<=cosine[1]<1
    theta=n.acos_interval(cosine);hp=n.PI[0]/2,n.PI[1]/2
    if ar>0:center=n.atan_interval(h.con(ai/ar))
    elif ai>0:center=h.sub(hp,n.atan_interval(h.con(ar/ai)))
    else:assert ai<0;center=h.sub(h.neg(hp),n.atan_interval(h.con(ar/ai)))
    return h.add(center,theta)
