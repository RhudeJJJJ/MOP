# Uniform private reserve17/10 for every q>=3

8 November2026. ORIGINAL GLOBAL MOP conjecture and the remaining q3..45
actual root payment remain OPEN. This is a stronger PRIVATE theorem.
Use the same literal external E_(p,q)-child plus external sibling ell
family, N=p+q+ell+2, edges(B)=N+q-1, contact mass=N-q+1.

THEOREM. For EVERY p,ell>=1 and EVERY integer q>=3,

             F(B)>edges(B)+17/10,
             F(B)+Tr TTt>2N+17/10.                         (1)

For EACH q3..15, use the exact path-coronal recurrence and ordered
two-endpoint phase comparison of the accepted all-q-private-floor-proof.
check_uniform_private_budget.py recomputes every necessary polynomial
coefficient sign for this finite core range. Positive real determinant
and negative imaginary numerator fix the continuous phase without a
principal-product reset. First raise the right outer correction to1/t,
then the left to1/t. The verified positive derivative cross gives
D(B)>=D(B_min(q)) for ALL outer p,ell. Exact multiplicity-aware Sturm
isolation of EACH literal B_min(q), including explicit zero modes,
proves D(B_min(q))>17/5. This proves(1) on the stated finite q range.
The180 full-private determinant controls calibrate actual graph mapping;
the polynomial identities prove the unbounded outer-length quantifier.

For the ENTIRE range q>=16 pinch into the disjoint actual blocks
Fan_(q+2),P_p,P_ell. The accepted and explicitly derived analytic fan
bound gives F(B)>edges(B)+f(q+1)-1, where
f(r)=2sqrt r-2/sqrt r-4-2/r+1/r^2. Since f increases for r>=1 and
sqrt17>41/10,

 f(q+1)-1>=f(17)-1>
 82/10-20/41-5-2/17+1/289=153919/59245>17/10.

This proves(1) for all remaining q, without extrapolating the finite
spectra or treating a discovery profile as a bound. The original
private bull floor and sharper individual finite base bounds remain
true. This constant supplies a prospective common root-phase budget;
it does not itself pay the root cost or close the original conjecture.

For the finite middle range3..45 a new complete high-tail bound uses
Gram diagonals q+6<=51,q+3<=48 and ||B||<9. Indeed split B into its
star at c (q+2 leaves) and a path forest after removing those spokes.
Their norms are sqrt(q+2) and <2, so ||B||<2+sqrt47<9. Therefore
Cdiag[0,51],[0,48],|C01|<50 and absolute D bounds459,432,450 hold for
ALL actual outer lengths. The exact64-cell tail reader certifies t>=16
with integral upper6511453864378742765901551433033/
20282409603651670423947251286016, approximately0.32103946186.
The attempted t>=8 coarse bound FAILED and is not used. In the current
complete partition plan, all low0<t<1/2 costs at most1/2 by b<2pi.
This replaces the earlier trial allocation at3/8 after the measured
preflight cost, preserving the entire family and a strictly positive
target surplus1/10. The compact t in[1/2,16] and the
full discrete middle/outer length cover remain the actual open work.
Native intake of this new private/tail package is pending.
