# Finite middle core, two infinite outer arms: complete proof bridge

8 November 2026. LOCAL EXACT ACCEPTANCE PASSED. ORIGINAL every finite
simple UNIT MOP G,n>=8 satisfies F(G)=splus(G)>=2n remains GLOBAL OPEN.
Full compact certificate production and exact reading have passed all
320 base cells and every required unbounded-length class. Native source
intake/export verification remains a separate pending operation.

THEOREM. For EVERY p,ell>=1, EVERY q in3..45, EVERY old UNIT MOP H
with h>=3 and EVERY ordered boundary ab, keep ab ONCE, add parent abc,
an E_(p,q) child on ac with child apices a,c, and an EXTERNAL b-apex
sibling fan ell on cb. This adds N=p+q+ell+2 vertices and2N unit edges.
The intended actual increment is

                         DeltaF>2N+1/10.                    (1)

The private sibling apex c is a different family. This note neither
identifies its contacts nor claims a global decomposition. Auxiliary K2
is licensed by the physical sector/root-ball argument as an increment
domain here, not by extending the separate quantitative branch theorem.

## 1. Literal graph and private budget for ALL q>=3

Private order is left_p,d,middle_q,c,sibling_ell. Private B is the core
Fan_(q+2) on path d,middle_q and hub c, with pendant P_p at d and
pendant P_ell at c. Complete root contacts are
Ta=indicator{0,...,p}+e_(p+q+1), Tb=indicator{p+q+1,...,N-1}.
Thus edges(B)=N+q-1 and Tr(TTt)=N-q+1. geometry.py constructs literal
unit edges and checks the complete noncrossing outer cycle.

middle-private-budget-proof.md and its exact reader establish, for EVERY
q>=3 and both unbounded outer lengths,

               F(B)>edges(B)+17/10,
               F(B)+Tr(TTt)>2N+17/10.                     (2)

For EACH q3..15, exact Gaussian path-coronal recurrences give
Z=(t+s)(D_(q+1)+rD_q)+E_(q+1)+rE_q=C-iM, with C,M>0.
All coefficient signs, and the ordered right-then-left phase derivative
cross polynomial at s=1/t, are checked separately for each q. This gives
D(B)>=D(B_min(q)) for ALL p,ell. Full multiplicity-aware rational Sturm
isolation, counting every zero mode, proves EACH D(B_min(q))>17/5.
The exact recurrence and Coulson phase proof are retained in the accepted
all-q-private-floor-proof.md; extending its finite coefficient check to
q15 supplies this stronger bound, not an extrapolation of finite arms.

For EVERY q>=16, principal pinching into Fan_(q+2),P_p,P_ell and the
Rayleigh/interlacing fan bound yield surplus f(q+1)-1, where
f(r)=2sqrt(r)-2/sqrt(r)-4-2/r+1/r^2 is increasing for r>=1.
sqrt17>41/10 proves f17-1>153919/59245>17/10. This covers the entire
infinite private-core tail. The180 full-private determinant controls
calibrate geometry; the recurrences and coefficient signs supply the
unbounded outer-length quantifier.

## 2. One actual old root, lossless normalization and complete phase

For Fc=T(tI+iB)^-1Tt the accepted sharp same-old-root theorem gives

 DeltaF>=F(B)+Tr(TTt)-(2/pi)integral_0^infinity t b(Fc,t)dt.      (3)

The original all-MOP201 sector theorem applies to H and to the literal
cap over auxiliary K2, with both signs 2ReFc +/- t ImFc>=0 before
normalization. Its simultaneous path/pocket induction has no far-degree
or order bound. No independently optimized old roots are added.

Write w=t+2i and V=(B-2I)Tt. Literal multiplication gives
TV=-2I, TTt=[[p+2,1],[1,ell+1]], and

 Va=-e0+2e_(p+1)+sum_(j=2..q)e_(p+j)-e_c+e_(c+1),
 Vb=e_p+sum_(j=1..q)e_(p+j)-e_c-e_(N-1), c=p+q+1.

VtV has diagonals q+6,q+3 and cross q+2-indicator{ell=1}.
The exact sparse resolvent identity is

 Fc=TTt/w+2iI/w^2-Vt(tI+iB)^-1V/w^2.

Subtract ONLY the two nonnegative lossless outer rays
(p-1)e_a e_a^t/w and (ell-1)e_b e_b^t/w. The accepted algebraic
lossless-ray lemma preserves Wplus and increases the root-phase upper
b. The resulting F has fixed leading Q=[[3,1],[1,2]]. The middle
q-dependent bulk is RETAINED, not discarded or declared monotone.
No signed auxiliary response is assigned graph energy.

For K=[[2,1],[1,2]], c0=1/t-i/2 and rho=|c0|^2, put
tr=Tr(K^-1 F), df=det(F)/3, da=1+c0 tr+c0^2 df and
S=2ReF/t+ImF. The retained sharp two-by-two determinant formula is

 G=I+K^-1/2 S K^-1/2,
 cos(theta)=(sqrt(detG)-rho |df|)/|da|,
 b=liftedArg(da)+acos(cos(theta)), 0<=b<2pi,
 detG=1+Tr(K^-1 S)+det(S)/3.                              (4)

This follows from A*A-rho L*L=G for A=I+c0 L,
L=K^-1/2 F K^-1/2, retaining the full noncommuting determinant.
Each WHOLE box certifies the determinant quadrant and the radical,
divisor and angle domains. A positive-real-only assumption is absent.
The fast atan sum is used only if Re da>0 and its sum-angle denominator
is positive. In that case the actual sum lies in(-pi/2,pi/2), so no
principal-angle reset occurs. Otherwise the lifted quadrant formula is
used, or an outward safe fallback supplies the bound.

## 3. Eliminate the middle path without losing its bulk

For D0=1,D1=t,Dj=tD_(j-1)+D_(j-2), define
r_j=D_(j-1)/D_j, e_j=(-i)^(j-1)/D_j,
h_j=(1+i(r_j+e_j))/w. These are endpoint diagonal, opposite endpoint,
and endpoint-to-all-one path resolvent entries. Indeed
(tI+iA(P_j))1=w1-i(e_first+e_last), which proves the formula for h_j
and the coronal j/w+2i h_j/w.

Eliminating all THREE disjoint paths from the normalized actual response
leaves two heads d,c. With rL,hL,rR,hR,rM,hM for p,ell,q, its matrix is

 Zdd=t+rL+rM, Zdc=i+hM,
 Zcc=t+rR+q/w+2i hM/w,
 Ua=(1-i hL)e_d+e_c, Ub=(1-i hR)e_c,
 F=diag((1+2i hL)/w,(1+2i hR)/w)+U Z^-1 Ut.                (5)

The last transpose is NOT adjoint. The two-head formula follows directly
from Schur elimination of the literal private graph, not a regression
against finite spectra. The independent full-private inverse checks are
an additional calibration.

For interval work replace the middle integer bulk q by gamma in[q,hi],
independently of its endpoint envelope. This merely enlarges each
parameter box; it does not claim an artificial midpoint is a graph.
Every actual allowed middle integer m has gamma=m and its true endpoint
coordinate. The full q/w term survives all bounds.

## 4. Common denominator and formal coefficient identity

For the three endpoint pairs rL,eL;rR,eR;rM,eM put

 a=t+rL+eL+i, b0=t+rR+eR+i, m=t+rM+eM+i,
 d=t+rL+rM, nL=t-2(rL+eL)+4i, nR=t-2(rR+eR)+4i,
 J=(t+rR)w^2+gamma*w-2(rM+eM)+2i, D=dJ+m^2.

Then detZ=D/w^2, and the three response numerators over den=w^2 D are

 Naa=nL D+a^2 J-2i a m w^2+d w^4,
 Nab=b0 w(d w^2-i a m), Nbb=nR D+b0^2 d w^2.

Set P=nR Naa+b0^2 w^2(nL d+a^2). Formal coefficient multiplication
over Q[i][t,rL,rR,rM,eL,eR,eM,gamma], with NO endpoint relations, proves
Naa Nbb-Nab^2=D P. Thus detF=P/(w^4 D), and Nd=P/w^2 satisfies
detF=Nd/den. check_common_polynomials.py checks these identities and
the entire scaled adjugate:10 raw coefficient identities.

For An=den+c0 Tr(K^-1 N)+c0^2 Nd/3, define
X=(2/3)(Re(Naa conj(Nbb))-|Nab|^2) and
gn=2Re(An conj(den))-|den|^2+rho X. Then

 gn=|den|^2 detG,
 cos(theta)=(sqrt(gn)-rho |Nd|/3)/|An|,
 liftedArg(da)=arg(An conj(den)).                          (6)

For clarity, the determinant identity in(6) is the expansion
detG=2Re(da)-1+rho*(2/3)(Re(Faa conj(Fbb))-|Fab|^2).
Writing F=H+iI reduces it to the ordinary two-by-two determinant
of 2H/t+I. This is a polynomial identity, not a commuting-matrix
assumption or a necessary-only sector inequality.

Both common-denominator and direct formula (5) implement the SAME
analytic response. Choosing one certificate method per leaf changes
enclosure efficiency only; every leaf is recomputed exactly.

## 5. Five-variable analytic enclosures and discrete exhaustiveness

For residue anchor j, take s=u/D_j,0<=u<=1, sign=(-1)^(j+1) and

 e=(-i)^(j-1)s,
 r=2(1+sign*s^2)/(t+sqrt(t^2+4+4sign*s^2)).                 (7)

Every actual length m=j+4k has u=D_j/D_m, because
D_(n+2)-D_n=tD_(n+1)>0 and the endpoint quadratic identity holds
with this fixed parity. For singleton length j take u=1, retaining
the t-dependence of D_j. Even j has D_j>=1+t^2, so the radical is
strictly positive on the entire stated box. Odd j is immediate.

The AD expression carries interval values, interval center values and
ALL FIVE partial derivatives in(t,uL,uR,uM,gamma). At every analytic
node it intersects the natural enclosure with center plus the sum of
derivative supremum times radii. Induction on the expression graph
and the mean-value theorem prove the enclosure. Every intermediate
square root, division, acos derivative and lifted quadrant must be
valid on the ENTIRE box. No PSD-clipped quantity is differentiated.
Raw fallback uses physical constraints ONLY on the actual sector-valid
subset; certified necessary PSD failure may reject an empty subset.
Otherwise unresolved boxes receive the complete safe bound2pi*t.

Independent inverse differentiation and full actual private inverses
test EACH variant on201 physical states,402 point/box cases,16080
partial components,3216 physical tangent components including ALL
THREE endpoint chain terms, and201 independently computed phases.
Middle gamma derivatives are checked as the fifth independent direction;
physical t tangents keep gamma fixed at the actual integer. These finite
controls calibrate analytic expressions, not the infinite quantifiers.

Coverage starts with ALL64 ORDERED roots: left anchor1..4, right
anchor1..4, middle anchor3..6. For each middle q put
hi=q+4floor((45-q)/4). Its actual finite progression q,q+4,...,hi
is covered by uM in[0,1], gamma in[q,hi]; a singleton uses uM=1.
The four progressions are disjoint and exhaust ALL43 integers3..45.
Each outer tail j+4k splits into singleton j and the infinite tail j+4.
Balanced middle splits divide its finite progression into BOTH children.
No reflection merges ordered contacts and no longest anchor truncates a
tail. Artificial independent envelope values enlarge the boxes only.

The exact reader verifies every split, complete tree consumption, all64
roots at every frequency leaf, all rational target inequalities, and
contiguous frequency coverage. For EACH frequency cell take the MAXIMUM
over ALL parameter leaves and multiply by frequency width; there is no
averaging over length parameters. Twelve deliberately damaged artifacts
are rejected. Float code only proposes trees; the outward rational reader
imports no float selector. Its GRID96 arithmetic uses unbounded integers,
exact positive division and integer square-root bounds, rational atan
remainders and a Machin enclosure of pi.

## 6. Entire frequency axis and the acceptance condition

For0<t<1/2, the universal b<2pi charges at most1/2 in the ENERGY budget
of(3). This retains the entire low interval, including any large phase
that invalidates a stronger pointwise comparison.

For3<=q<=45 the actual B is the star at c with q+2 leaves plus a path
forest. Thus ||B||<sqrt(q+2)+2<=sqrt47+2<9 for ALL outer lengths.
With C=Vt(I+z^2 B^2)^-1V and D0=Vt B(I+z^2 B^2)^-1V, positivity,
contraction and Cauchy give Cdiag[0,51],[0,48],|C01|<50 and absolute
D0 bounds459,432,450. The uniform tail code uses THESE q-dependent
worst-case constants, despite inherited old-q2 comments. They follow
from the actual Gram diagonals q+6,q+3 and norm<9.

The accepted same-sector support/nuclear-norm rationalization is applied
on ALL64 exact cells of z=1/t in[0,1/16], certifying every positive-real
response and divisor. It bounds the entire infinite frequency tail by

 Itail=6511453864378742765901551433033/
       20282409603651670423947251286016.

The coarser attempted t>=8 bound FAILED and is not used. The compact
domain[1/2,16] has320 initial cells, with any frequency refinements
recorded recursively. Atomic checkpoints prevent partially written
leaves from being consumed. The live reader checks the final certificate
against every consumed checkpoint and its complete source hash map.

Let Icompact be the exact final sum of maximum bounds times cell widths.
Terminal acceptance requires

 17/10-1/2-2(Icompact+Itail)/pi_lower>1/10.                  (8)

The target hints alone do NOT prove (8): the reader computes every
actual rational bound. The terminal full result is now
PASS_EXACT_ALL_MIDDLE_q3_TO45_AND_TWO_UNBOUNDED_OUTER_ARMS,
with unchanged certificate/source binding. Its exact compact integral is
3372633371044008301581746056869/2535301200456458802993406410752,
giving actual surplus>0.148744>1/10. It covers512 frequency leaves and
547916 length leaves. Maximum outer anchor10 starts an infinite residue
tail, not a length cutoff. Complete certificate SHA256 is
d87b69d0539b0d033cf4d982eb603623e4b96119dae4b464b4cbfb6235f74eee.
Together with the analytic proof above these establish(1). A preflight,
checkpoint count or elapsed time alone would not.

## 7. Original consequence, conditional combination and remaining work

(1) excludes this exact EXTERNAL sibling family in an
original minimal counter WHERE deleting its private vertices leaves
old h>=8. Combining its range with accepted q1,q2 and q>=46 payments
then covers EVERY q>=1 and every p,ell for old h>=3, with common
surplus greater than1/50 (the weakest accepted q1 constant).

That combination still does NOT close the ORIGINAL global conjecture.
The private sibling role, bare Fork6, whole compensation/complete
grammar and all-small-old whole coverage keep their actual scopes.
The separately accepted exact degree4 retirement bound<141/20 now pays
the external q>=40 tail, refining its remaining middle work to q3..39.
This frozen certificate still retains its full q3..45 domain. Its overlap
with q40..45 is not extra independent credit. The private-c sibling tail
is separately paid for q+ell>=50, leaving ordered q+ell<=49 and p still
unbounded; neither that tail nor this external certificate pays those
small private-role pairs. Prior C1/S3/T5 cuts may overlap these caps;
no independent motif credit or strict new occurrence coverage is claimed
without a literal occurrence audit. The old quantitative front and any
inherited finite-order hypotheses remain intact.

This operation counts literal ordered unit graphs and disjoint vertex
partitions. Equal total lengths do not identify different root contacts.
The practical next work changes only after terminal acceptance: remove
this external-family phase obligation from the current frontier, while
preserving every other original obligation. No global completion,
priority, external formal audit or LOTSE method_effect is claimed.
Native intake and independent source-export replay remain PENDING.
