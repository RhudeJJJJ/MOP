"""Independent literal V and full PRIVATE C/D-to-response tail identity."""
from pathlib import Path
from fractions import Fraction as F
import json
import exact as e,geometry as g,middle_physical as phys

def main():
    cases=states=0
    triples=[(p,q,ell)for q in(3,4,5,6,15,45)for p in(1,2)for ell in(1,2)]+[(7,16,3),(2,44,5)]
    for p,q,ell in triples:
        B,T=g.cap(p,q,ell);N=len(B);c=p+q+1;V=e.mm(B,e.tr(T));V=[[a-2*b for a,b in zip(row,rr)]for row,rr in zip(V,e.tr(T))]
        wanted=[[F(-int(i==0)+2*int(i==p+1)+sum(int(i==p+j)for j in range(2,q+1))-int(i==c)+int(i==c+1)),F(int(i==p)+sum(int(i==p+j)for j in range(1,q+1))-int(i==c)-int(i==N-1))]for i in range(N)]
        assert V==wanted and e.mm(T,V)==[[-2,0],[0,-2]]
        assert e.mm(e.tr(V),V)==[[q+6,q+2-int(ell==1)],[q+2-int(ell==1),q+3]]
        assert e.mm(T,e.tr(T))==[[p+2,1],[1,ell+1]]
        for t in(F(16),F(32)):
            x=1/(t*t);BB=e.mm(B,B);Ri=e.inverse([[int(i==j)+x*BB[i][j]for j in range(N)]for i in range(N)]);C=e.mm(e.mm(e.tr(V),Ri),V);D=e.mm(e.mm(e.mm(e.tr(V),B),Ri),V)
            assert 0<=C[0][0]<=51 and 0<=C[1][1]<=48 and abs(C[0][1])<50
            assert abs(D[0][0])<=459 and abs(D[1][1])<=432 and abs(D[0][1])<450
            full=phys.response(p,q,ell,t);aa=1+4*x;Q=[[3,1],[1,2]]
            for i in range(2):
                for j in range(2):
                    qp=Q[i][j]/aa+8*x*int(i==j)/(aa*aa)-x*((1-4*x)*C[i][j]-4*x*D[i][j])/(aa*aa)
                    mp=2*Q[i][j]/aa-2*(1-4*x)*int(i==j)/(aa*aa)-x*((1-4*x)*D[i][j]+4*C[i][j])/(aa*aa)
                    assert qp==t*full[i][j][0]and mp==-t*t*full[i][j][1]
            cases+=1
        states+=1
    out=dict(status='PASS_FINITE_MIDDLE_ALL_ARM_DEFECT_AND_FULL_PRIVATE_TAIL_IDENTITY_CONTROLS',geometry_states=states,full_private_tail_cases=cases,analytic_uniformity='Written all-length V coordinate identity; B=star(q+2)+pathforest gives norm<9; Gram<=51,48 and actual sparse C/D signs retained',original_global='OPEN',full_root_payment='PENDING_COMPLETE_COMPACT_READER')
    (Path(__file__).resolve().parent/'middle-defect-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
