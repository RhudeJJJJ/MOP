from fractions import Fraction as F
from pathlib import Path
import json
import read_middle_certificate as r
def rejected(f):
    try:f()
    except(AssertionError,ArithmeticError):return 1
    raise AssertionError('damaged cover accepted')
def main():
    a,b,target=F(1),F(1001,1000),F(1);oldD,oldC=r.direct.bound,r.common.bound
    try:
        r.direct.bound=r.common.bound=lambda *args:dict(upper=F(1,10),method='GRAMMAR_ONLY_STUB')
        root=dict(a=str(a),b=str(b),trees=['0']*64);assert r.frequency(root,a,b,target)==((b-a)/10,64,4,1)
        tests=[lambda:r.parse_tree('',a,b,1,1,3,43,target),lambda:r.parse_tree('00',a,b,1,1,3,43,target),lambda:r.parse_tree('5',a,b,1,1,3,43,target),lambda:r.parse_tree('1',a,b,1,1,3,43,target),lambda:r.parse_tree('11000',a,b,1,1,3,43,target),lambda:r.parse_tree('33000',a,b,1,1,3,7,target),lambda:r.parse_tree('0',a,b,1,1,3,42,target),lambda:r.parse_tree('0',a,b,1,1,2,42,target),lambda:r.frequency(dict(root,trees=['0']*63),a,b,target),lambda:r.frequency(dict(root,a='0'),a,b,target),lambda:r.frequency(dict(root,split=[root]),a,b,target)]
        count=sum(rejected(f)for f in tests);assert r.parse_tree('300',a,b,1,4,3,43,target)==(F(1,10),2,4)
    finally:r.direct.bound=oldD;r.common.bound=oldC
    count+=rejected(lambda:r.parse_tree('0',a,b,1,1,3,3,F(0)))
    out=dict(status='PASS_GROUPED_MIDDLE_COVERAGE_AND_DAMAGED_ARTIFACT_REJECTION',damaged_cases_rejected=count,residue_roots=64,middle_domain=[3,45],outer_lengths='BOTH_UNBOUNDED',scope='Grammar/negative controls only; complete numerical certificate remains OPEN',original_global='OPEN');(Path(__file__).resolve().parent/'middle-coverage-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
