from fractions import Fraction as F
import exact
def cap(p,q,l):
    assert all(type(v)is int and v>=1 for v in(p,q,l))
    left=list(range(4,4+p));middle=list(range(4+p,4+p+q));right=list(range(4+p+q,4+p+q+l));es={(0,1),(0,2),(1,2),(0,3),(2,3)}
    for arc,hub in(([0]+left+[3],0),([3]+middle+[2],2),([2]+right+[1],1)):
        es|={tuple(sorted(e))for e in zip(arc,arc[1:])};es|={tuple(sorted((hub,v)))for v in arc if v!=hub}
    bd=[0]+left+[3]+middle+[2]+right+[1];n=p+q+l+4;exact.validate_outer(n,es,bd);order=left+[3]+middle+[2]+right;N=p+q+l+2
    B=[[F(int(i!=j and tuple(sorted((i,j)))in es))for j in order]for i in order];T=[[F(int(tuple(sorted((i,j)))in es))for j in order]for i in(0,1)]
    assert sum(map(sum,B))/2==N+q-1 and sum(v*v for row in T for v in row)==N-q+1
    return B,T
