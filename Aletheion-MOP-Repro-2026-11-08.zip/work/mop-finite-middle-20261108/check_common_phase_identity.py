"""Raw coefficients only: arbitrary complex symmetric response, no endpoint relations."""
from pathlib import Path
import json
from poly8 import P,V,z,ca,cm,ct,cs

def main():
    t,a,b,d,u,v,w,unused=V
    aa,ab,bb=z(a,u),z(b,v),z(d,w)
    trace=ct(cs(ca(aa,bb),ab),P(2)/3)
    det=cs(cm(aa,bb),cm(ab,ab))
    cnum=z(2,-t)
    ar=ca(ca(z(4*t*t),ct(cm(cnum,trace),2*t)),ct(cm(cm(cnum,cnum),det),P(1)/3))
    cross=(a*d+u*w-b*b-v*v)*P(2)/3
    numerator=2*ar[0]-4*t*t+(t*t+4)*cross
    sa,sb,sd=2*a+t*u,2*b+t*v,2*d+t*w
    target=4*t*t+4*t*(sa+sd-sb)*P(2)/3+4*(sa*sd-sb*sb)*P(1)/3
    assert not(numerator-target).c
    out=dict(status='PASS_RAW_ARBITRARY_COMPLEX_SYMMETRIC_COMMON_PHASE_DETERMINANT_IDENTITY',identities=1,domain='Q[t,Haa,Hab,Hbb,Iaa,Iab,Ibb]; NO endpoint reduction or sector assumption',identity='detG=2Re(da)-1+rho*(2/3)*(Re(Faa conjFbb)-abs(Fab)^2)',original_global='OPEN')
    (Path(__file__).resolve().parent/'common-phase-identity-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
