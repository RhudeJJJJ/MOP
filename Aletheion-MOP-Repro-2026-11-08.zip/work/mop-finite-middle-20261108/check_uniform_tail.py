from fractions import Fraction as F
from pathlib import Path
import json
import rational_grid
rational_grid.install()
import uniform_middle_tail as tail
P=Path(__file__).resolve().parent;rows=[]
for T in(8,16,24,32):
    try:
        total=sum((tail.tail(F(k,64*T),F(k+1,64*T))[1]/(64*T)for k in range(64)),F(0));rows.append(dict(t_from=T,cells=64,integral_upper=str(total),integral_float=float(total)))
    except(ArithmeticError,AssertionError)as error:rows.append(dict(t_from=T,not_certified=str(error)))
out=dict(status='EXACT_UNIFORM_MIDDLE_TAIL_INPUT_CHECK',q_range=[3,45],rows=rows,requires='Written star-plus-path-forest norm<9 and actual Gram bounds<=51,48; these checks do not certify the compact phase.',original_global='OPEN');(P/'uniform-tail-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
