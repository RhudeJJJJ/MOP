"""Provisional FIVE-variable middle-q reader; controls/certificate still required."""
"""Q2 response variant. Whole actual-response controls still required before full certificate."""
"""Whole-box mean-value AD in t,uL,uR for the correlated TWO-tail head.

Every intermediate node intersects its natural value enclosure with its
center plus rigorous derivative radii. No PSD clipping is differentiated.
Only the final upper is restricted to the sector-valid subset.
"""
from fractions import Fraction as F
import disk_interval as h
import net_interval as n
import rational_grid as grid
ZERO=h.con(0);ONE=h.con(1);ZD=(ZERO,)*5;RAD=(F(0),)*5;RINT=(0,)*5
def set_box(radii):
    global RAD,RINT
    RAD=tuple(radii)
    if getattr(h,'BACKEND',None)=='outward-integer-grid-96':RINT=tuple(grid.u(v)for v in radii)
def iszero(v):return v[0]==0 and v[1]==0
def da(a,b):return b if iszero(a)else a if iszero(b)else h.add(a,b)
def dm(a,b):return ZERO if iszero(a)or iszero(b)else h.mul(a,b)
def tighten(v,center,d):
    if all(iszero(x)for x in d):return v
    if getattr(h,'BACKEND',None)=='outward-integer-grid-96':
        r=sum(max(abs(grid.l(x[0])),abs(grid.u(x[1])))*q for x,q in zip(d,RINT));rr=-((-r)//grid.G);lo=max(grid.l(v[0]),grid.l(center[0])-rr);hi=min(grid.u(v[1]),grid.u(center[1])+rr)
        if lo>hi:raise ArithmeticError('inconsistent exact centered node enclosure')
        return grid.f(lo),grid.f(hi)
    rr=h.up(sum(max(abs(z)for z in x)*float(q)for x,q in zip(d,RAD)));lo=max(v[0],h.down(center[0]-rr));hi=min(v[1],h.up(center[1]+rr))
    if lo>hi:raise ArithmeticError('selector centered enclosure inconsistency')
    return lo,hi
class A:
    def __init__(self,v,d=ZD,center=None):
        self.c=v if center is None else center;self.d=d;self.v=tighten(v,self.c,d)
    def __add__(a,b):
        b=asA(b);return A(h.add(a.v,b.v),tuple(da(x,y)for x,y in zip(a.d,b.d)),h.add(a.c,b.c))
    __radd__=__add__
    def __neg__(a):return A(h.neg(a.v),tuple(h.neg(x)for x in a.d),h.neg(a.c))
    def __sub__(a,b):return a+-asA(b)
    def __rsub__(a,b):return asA(b)+-a
    def __mul__(a,b):
        b=asA(b);return A(h.mul(a.v,b.v),tuple(da(dm(x,b.v),dm(a.v,y))for x,y in zip(a.d,b.d)),h.mul(a.c,b.c))
    __rmul__=__mul__
    def __truediv__(a,b):return a*rec(asA(b))
    def __rtruediv__(a,b):return asA(b)*rec(a)
def asA(v):return v if isinstance(v,A)else A(h.con(v))
def variable(a,b,dim):return A((a,b),tuple(ONE if j==dim else ZERO for j in range(5)),h.con((a+b)/2))
def rec(a):
    vv=h.div(ONE,a.v);cc=h.div(ONE,a.c);ss=h.square(a.v);return A(vv,tuple(h.neg(h.div(x,ss))if not iszero(x)else ZERO for x in a.d),cc)
def sq(a):return A(h.square(a.v),tuple(h.times(h.mul(a.v,x),2)if not iszero(x)else ZERO for x in a.d),h.square(a.c))
def rt(a):
    if a.v[0]<=0:raise ArithmeticError('strict positive whole-box square-root domain required')
    v=h.sqrt(a.v);den=h.times(v,2);return A(v,tuple(h.div(x,den)if not iszero(x)else ZERO for x in a.d),h.sqrt(a.c))
def atan(a):
    den=h.add(ONE,h.square(a.v));return A(n.atan_interval(a.v),tuple(h.div(x,den)if not iszero(x)else ZERO for x in a.d),n.atan_interval(a.c))
def acos(a):
    den=rt(1-sq(a)).v;return A(n.acos_interval(a.v),tuple(h.neg(h.div(x,den))if not iszero(x)else ZERO for x in a.d),n.acos_interval(a.c))
def arg(re,im):
    hp=A((n.PI[0]/2,n.PI[1]/2))
    if re.v[0]>0:return atan(im/re)
    if im.v[0]>0:return hp-atan(re/im)
    if im.v[1]<0:return-hp-atan((-re)/(-im))
    raise ArithmeticError('whole-box lifted determinant quadrant unresolved')
def z(a=0,b=0):return asA(a),asA(b)
def ca(a,b):return a[0]+b[0],a[1]+b[1]
def cn(a):return-a[0],-a[1]
def cs(a,b):return ca(a,cn(b))
def cm(a,b):return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def ct(a,k):return a[0]*k,a[1]*k
def cd(a,b):
    den=sq(b[0])+sq(b[1]);v=cm(a,(b[0],-b[1]));return v[0]/den,v[1]/den
def det(A):return A[0][0]*A[1][1]-sq(A[0][1])
def trki(A):return(A[0][0]+A[1][1]-A[0][1])*F(2,3)
def endpoints(t,u,j):
    assert isinstance(j,int)and j>=1
    D0,D1=asA(1),t
    for k in range(2,j+1):D0,D1=D1,t*D1+D0
    s=u/D1;sign=1 if j%2 else -1;ss=sq(s);root=rt(sq(t)+4+4*sign*ss)
    r=2*(1+sign*ss)/(t+root)
    residue=(j-1)%4+1
    e=z(s)if residue==1 else z(-s)if residue==3 else z(0,-s)if residue==2 else z(0,s)
    return r,e
def response(t,ul,ur,um,gamma,jl,jr,jm):
    rl,el=endpoints(t,ul,jl);rr,er=endpoints(t,ur,jr);rm,em=endpoints(t,um,jm);w=z(t,2)
    hl=cd(ca(z(1),cm(z(0,1),ca(z(rl),el))),w);hr=cd(ca(z(1),cm(z(0,1),ca(z(rr),er))),w);hm=cd(ca(z(1),cm(z(0,1),ca(z(rm),em))),w)
    zz00=z(t+rl+rm);zz01=ca(z(0,1),hm);zz11=ca(z(t+rr),cd(ca(z(gamma),cm(z(0,2),hm)),w));den=cs(cm(zz00,zz11),cm(zz01,zz01))
    r00=cd(zz11,den);r22=cd(zz00,den);r02=cd(cn(zz01),den);alpha=cs(z(1),cm(z(0,1),hl));beta=cs(z(1),cm(z(0,1),hr))
    fl=cd(ca(z(1),cm(z(0,2),hl)),w);fr=cd(ca(z(1),cm(z(0,2),hr)),w)
    fa=ca(ca(ca(fl,cm(cm(alpha,alpha),r00)),ct(cm(alpha,r02),2)),r22);fab=cm(beta,ca(cm(alpha,r02),r22));fb=ca(fr,cm(cm(beta,beta),r22));return[[fa,fab],[fab,fb]]

def phase(t,Fm):
    # Direct complex2x2 determinants avoid artificial scaling by tQ and M.
    trace=ct(cs(ca(Fm[0][0],Fm[1][1]),Fm[0][1]),F(2,3));df=ct(cs(cm(Fm[0][0],Fm[1][1]),cm(Fm[0][1],Fm[0][1])),F(1,3));c=z(1/t,-F(1,2));da0=ca(ca(z(1),cm(c,trace)),cm(cm(c,c),df));ar,ai=da0;az=sq(ar)+sq(ai);dz=sq(df[0])+sq(df[1]);rho=(sq(t)+4)/(4*sq(t));S=[[2*a[0]/t+a[1]for a in row]for row in Fm];gg=1+trki(S)+det(S)/3;co=(rt(gg)-rho*rt(dz))/rt(az);si=rt(1-sq(co));den=ar*co-ai*si
    if ar.v[0]>0 and den.v[0]>0:return t*atan((ai*co+ar*si)/den)
    return t*(arg(ar,ai)+acos(co))
def raw_bound(t,Fm):
    # Uses physics constraints only on valid subset; no clipped derivative.
    H=[[a[0].v for a in row]for row in Fm];I=[[a[1].v for a in row]for row in Fm];cap=h.up(2*n.PI[1]*t[1]);S=[[h.add(h.div(h.times(H[i][j],2),t),I[i][j])for j in range(2)]for i in range(2)]
    def de(A):return h.sub(h.mul(A[0][0],A[1][1]),h.square(A[0][1]))
    def tk(A):return h.times(h.sub(h.add(A[0][0],A[1][1]),A[0][1]),F(2,3))
    if S[0][0][1]<0 or S[1][1][1]<0 or de(S)[1]<0:return dict(upper=F(0),method='empty-sector')
    try:
        # The same direct determinant formula, evaluated by interval complex ops.
        import curve_interval as q
        Fc=[[ (H[i][j],I[i][j])for j in range(2)]for i in range(2)];trace=q.ct(q.cs(q.ca(Fc[0][0],Fc[1][1]),Fc[0][1]),F(2,3));df=q.ct(q.cs(q.cm(Fc[0][0],Fc[1][1]),q.cm(Fc[0][1],Fc[0][1])),F(1,3));cc=(h.div(ONE,t),h.con(-F(1,2)));da0=q.ca(q.ca(q.cz(1),q.cm(cc,trace)),q.cm(q.cm(cc,cc),df));ar,ai=da0;az=h.add(h.square(ar),h.square(ai));dz=h.add(h.square(df[0]),h.square(df[1]));x=h.square(t);rho=h.div(h.add(x,h.con(4)),h.times(x,4));gg=h.add(h.add(ONE,tk(S)),h.times(de(S),F(1,3)))
        if gg[1]<1:raise ArithmeticError('unresolved sector determinant')
        gg=max(F(1),gg[0]),gg[1];co=h.div(h.sub(h.sqrt(gg),h.mul(rho,h.sqrt(h.positive(dz)))),h.sqrt(az));co=max(F(-1),co[0]),min(F(1),co[1])
        if not(-1<co[0]<=co[1]<=1):raise ArithmeticError('raw cosine/angle domain')
        theta=n.acos_interval(co);hp=n.PI[0]/2,n.PI[1]/2
        if ar[0]>0:center=n.atan_interval(h.div(ai,ar))
        elif ai[0]>0:center=h.sub(hp,n.atan_interval(h.div(ar,ai)))
        elif ai[1]<0:center=h.sub(h.neg(hp),n.atan_interval(h.div(h.neg(ar),h.neg(ai))))
        else:raise ArithmeticError('raw quadrant unresolved')
        value=h.positive(h.mul(t,h.add(center,theta)));return dict(upper=min(cap,value[1]),method='raw-net')
    except(ArithmeticError,AssertionError):return dict(upper=cap,method='cap-phase')
def bound(ta,tb,la,lb,ra,rb,ma,mb,ga,gb,jl,jr,jm):
    assert 0<ta<=tb and 0<=la<=lb<=1 and 0<=ra<=rb<=1 and 0<=ma<=mb<=1 and 3<=ga<=gb<=45
    set_box(((tb-ta)/2,(lb-la)/2,(rb-ra)/2,(mb-ma)/2,(gb-ga)/2))
    t=variable(ta,tb,0);ul=variable(la,lb,1);ur=variable(ra,rb,2);um=variable(ma,mb,3);gamma=variable(ga,gb,4);cap=h.up(2*n.PI[1]*tb)
    try:Fm=response(t,ul,ur,um,gamma,jl,jr,jm)
    except(ArithmeticError,AssertionError):return dict(upper=cap,method='cap-response')
    try:
        f=phase(t,Fm);return dict(upper=min(cap,max(F(0),f.v[1])),method='centered5-net',grad=tuple(max(abs(v)for v in dd)for dd in f.d))
    except(ArithmeticError,AssertionError):
        result=raw_bound((ta,tb),Fm);result['grad_proxy']=tuple(sum(max(abs(v)for v in part.d[k])for row in Fm for comp in row for part in comp)for k in range(5));return result
