from fractions import Fraction as F
import exact as e
from unary_floor_polynomials import polynomials,add
def leg(q):
    D0,D1=[F(1)],[F(0),F(1)]
    for _ in range(2,q+2):D0,D1=D1,add(e.mul([0,1],D1),D0)
    C0,C1,M0,M1,_=polynomials(q)
    return [D1,D0],[(add(C0,e.mul([0,1],D1),-1),[-x for x in M0]),(add(C1,e.mul([0,1],D0),-1),[-x for x in M1])]
def coefficients(q,r):
    L,EL=leg(q);R,ER=leg(r);C={};M={}
    for i in [0,1]:
        for j in [0,1]:
            C[i,j]=add(add(e.mul([0,1],e.mul(L[i],R[j])),e.mul(EL[i][0],R[j])),e.mul(ER[j][0],L[i]))
            M[i,j]=[-v for v in add(e.mul(EL[i][1],R[j]),e.mul(ER[j][1],L[i]))]
    return C,M
def cross(C,M,dim):
    def get(A,i,j):return A[i,j]if dim==0 else A[j,i]
    c00,c10,c01,c11=[get(C,*v)for v in [(0,0),(1,0),(0,1),(1,1)]];m00,m10,m01,m11=[get(M,*v)for v in [(0,0),(1,0),(0,1),(1,1)]]
    return [add(e.mul(m00,c10),e.mul(m10,c00),-1),add(add(e.mul(m00,c11),e.mul(m01,c10)),add(e.mul(m10,c01),e.mul(m11,c00)),-1),add(e.mul(m01,c11),e.mul(m11,c01),-1)]
