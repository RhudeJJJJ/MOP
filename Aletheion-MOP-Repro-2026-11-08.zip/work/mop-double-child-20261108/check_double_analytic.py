from pathlib import Path
from fractions import Fraction as F
import json,hashlib
import double_geometry as g,exact as e
P=Path(__file__).resolve().parent
def main():
    assert F(131,4)**2<1073 and F(1051,20)**2<2762 and F(2751,20)**2<18922
    assert F(345,128)>F(269,100)and F(525,121)>F(43,10)
    gain=F(3656,441)-F(351,50)-F(184,157);assert gain==F(340213,3461850)>F(9,100)
    cases=tips=0;pairs=[(q,r)for q in range(1,16)for r in range(1,16)]+[(1,41),(20,22),(21,21),(41,1)]
    for p in [1,3]:
        for s in [1,3]:
            for q,r in pairs:
                B,T=g.cap(p,q,r,s);N=len(B);c=p+q+1;d=p;ee=c+r+1;m=q+r
                full={(0,1),(0,N+2),(1,N+2)}|{(i+2,j+2)for i in range(N)for j in range(i+1,N)if B[i][j]}|{(a,j+2)for a in range(2)for j in range(N)if T[a][j]}
                deg=lambda u:sum(u in edge for edge in full);assert deg(c+2)==m+4
                removed={j+2 for j in list(range(p+1,c))+list(range(c+1,ee))};remaining=full-{edge for edge in full if set(edge)&removed}
                assert len(removed)==m and {v for edge in remaining if c+2 in edge for v in edge if v!=c+2}=={0,1,d+2,ee+2}
                order=list(range(p+1))+[c]+list(range(ee,N));k=len(order);assert k==p+s+3
                # Reconstruct the exact BARE external E_(p+1,s+1) private
                # path/contact edges independently in original vertex labels.
                expected={(0,1),(0,N+2),(1,N+2)}|{tuple(sorted((a+2,b+2)))for a,b in zip(order,order[1:])}|{tuple(sorted((0,j+2)))for j in order[:p+2]}|{tuple(sorted((1,j+2)))for j in order[p+1:]}
                assert remaining==expected and len(remaining)==2*(k+3)-3
                J=[c]+list(range(p+1,c))+list(range(c+1,ee));assert len(J)==m+1
                assert sum(B[i][j]for i in J for j in J)/2==2*m-2
                for length,private,prev in [(q,[p+q-1,p+q],p+q-2),(r,[c+1,c+2],c+3)]:
                    if length>=3:
                        u,v=[j+2 for j in private];root=prev+2;hub=c+2;assert deg(root)==3 and deg(root)+deg(hub)==m+7
                        expectedtip={tuple(sorted(edge))for edge in [(hub,root),(hub,u),(hub,v),(root,u),(u,v)]}if length==q and private==[p+q-1,p+q]else{tuple(sorted(edge))for edge in [(hub,root),(hub,u),(hub,v),(root,v),(u,v)]}
                        assert {edge for edge in full if set(edge)<={hub,root,u,v}}==expectedtip
                        assert all(not({u,v}&set(edge))or set(edge)<={hub,root,u,v}for edge in full);tips+=1
                cases+=1
    small={(q,r)for q in range(1,42)for r in range(1,42)if q<=2 and r<=2};band1={(q,r)for q in range(1,42)for r in range(1,42)if 14<=q+r<=19};band2={(q,r)for q in range(1,42)for r in range(1,42)if 20<=q+r<=41};assert len(small)==4 and len(band1)==93 and len(band2)==649
    out=dict(status='PASS_DOUBLE_CHILD_ALL_LENGTH_LARGE_TAIL_AND_PRIVATE_BAND_ANALYTIC_CONTROLS',literal_caps=cases,actual_terminal_tip_states=tips,large_internal_tail_from=42,large_tail_surplus_lower=str(gain),private_bands=[dict(total=[14,19],reserve='269/100',pairs=93),dict(total=[20,41],reserve='43/10',pairs=649)],small_pairs=4,remaining_ordered_internal_pairs=746,outer_lengths='BOTH_UNBOUNDED',proof_sha256=hashlib.sha256((P/'double-analytic-proof.md').read_bytes()).hexdigest(),original_global='OPEN',finite_root_payment='OPEN',native_intake='PENDING')
    (P/'double-analytic-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
