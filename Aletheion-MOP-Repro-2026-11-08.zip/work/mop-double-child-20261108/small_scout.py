"""Floating partition hints ONLY, two independent unbounded outer lengths."""
import float_discovery
float_discovery.install()
import double_model as model
def solve(q,r,a,b,target):
    calls=0
    def visit(p,ptail,s,stail):
        nonlocal calls
        calls+=1;assert calls<=16000 and max(p,s)<=100,'bounded double heuristic exhausted'
        got=model.bound(a,b,0. if ptail else 1.,1.,0. if stail else 1.,1.,p,q,r,s)
        if got['upper']<=target:return'0'
        if not ptail and not stail:raise ArithmeticError('isolated double pair requires frequency refinement')
        grad=got.get('grad');scores=[float(grad[1])if ptail else-1.,float(grad[2])if stail else-1.]if grad else[1/(p+1)if ptail else-1.,1/(s+1)if stail else-1.]
        if scores[0]>=scores[1]:return'1'+visit(p,False,s,stail)+visit(p+4,True,s,stail)
        return'2'+visit(p,ptail,s,False)+visit(p,ptail,s+4,True)
    return[visit(p,True,s,True)for p in range(1,5)for s in range(1,5)]
