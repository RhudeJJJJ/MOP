"""FAST HEURISTIC ONLY. Never imported by the certificate reader.

Binary float interval-like bounds select a partition. They are not evidence
for a theorem; a fresh standard-library rational reader recomputes EVERY leaf.
"""
import math
import disk_interval as h
import net_interval as n
def lo(v):return math.nextafter(float(v),-math.inf)
def hi(v):return math.nextafter(float(v),math.inf)
def rnd(a):return lo(a[0]),hi(a[1])
def con(v):return float(v),float(v)
def add(a,b):return rnd((a[0]+b[0],a[1]+b[1]))
def neg(a):return-a[1],-a[0]
def sub(a,b):return add(a,neg(b))
def mul(a,b):
    v=[x*y for x in a for y in b];return rnd((min(v),max(v)))
def div(a,b):
    if b[0]<=0:raise ArithmeticError('heuristic positive divisor')
    return mul(a,rnd((1/b[1],1/b[0])))
def square(a):return rnd((0 if a[0]<=0<=a[1]else min(a[0]**2,a[1]**2),max(a[0]**2,a[1]**2)))
def positive(a):
    if a[1]<0:raise ArithmeticError('heuristic positive quantity')
    return max(0.,a[0]),a[1]
def sqrt(a):
    a=positive(a);return max(0.,lo(math.sqrt(a[0]))),hi(math.sqrt(a[1]))
def install():
    for name,fun in dict(down=lo,up=hi,rnd=rnd,con=con,add=add,neg=neg,sub=sub,mul=mul,times=lambda a,k:mul(a,con(k)),div=div,square=square,positive=positive,sqrt=sqrt).items():setattr(h,name,fun)
    n.PI=tuple(map(float,n.PI));n.atan_interval=lambda a:(lo(math.atan(a[0])),hi(math.atan(a[1])))
    n.acos_interval=lambda a:(lo(math.acos(min(1.,a[1]))),hi(math.acos(max(-1.,a[0]))))
