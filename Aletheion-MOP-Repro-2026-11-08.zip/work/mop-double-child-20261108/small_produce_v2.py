from pathlib import Path
from fractions import Fraction as F
import json,hashlib,time,sys
import small_scout as scout
from small_cover import PAIRS
P=Path(__file__).resolve().parent
NAMES={'small_produce_v2.py','small_reader_v2.py','small_cover.py','small_scout.py','check_small_grammar.py','small-grammar-check.json','double_geometry.py','double_physical.py','double_model.py','double_tail.py','check_double_physical.py','double-physical-check.json','double_floor_polynomials.py','unary_floor_polynomials.py','read_small_floors.py','small-floor-check.json','small-private-grams.json','small-frequency-grid.json','small-budget-v2.json','ad_tools.py','exact.py','complex_exact.py','disk_interval.py','net_interval.py','rational_grid.py','curve_interval.py','float_discovery.py'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def atomic(path,value):
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(value,separators=(',',':'))+'\n');temp.replace(path)
def main():
    start=time.monotonic();prefix='--prefix'in sys.argv;folder=P/'small-v2-checkpoints';folder.mkdir(exist_ok=True);hashes={n:sha(P/n)for n in sorted(NAMES)};path=folder/'producer-inputs.json'
    if path.exists():assert json.loads(path.read_bytes())==hashes,'frozen double inputs changed'
    else:atomic(path,hashes)
    grid=json.loads((P/'small-frequency-grid.json').read_bytes());budget={(row['q'],row['r']):row for row in json.loads((P/'small-budget-v2.json').read_bytes())['rows']}
    def frequency(q,r,a,b,target,depth=0):
        try:return dict(a=str(a),b=str(b),trees=scout.solve(q,r,float(a),float(b),float(target)-1e-7))
        except(ArithmeticError,AssertionError)as ex:
            assert depth<8,'bounded double frequency refinement exhausted '+str(ex);mid=(a+b)/2
            return dict(a=str(a),b=str(b),split=[frequency(q,r,a,mid,target,depth+1),frequency(q,r,mid,b,target,depth+1)])
    for q,r in PAIRS:
        for index,row in enumerate(grid[:1]if prefix else grid):
            path=folder/f'q{q}-r{r}-{index:04}.json'
            if path.exists():continue
            a,b=F(row['a']),F(row['b']);target=F(budget[q,r]['amplitude'])/(1+((a+b)/2)**2)
            atomic(path,dict(q=q,r=r,index=index,target=str(target),partition=frequency(q,r,a,b,target)))
            if index%10==0:print(json.dumps(dict(status='HEURISTIC_SMALL_DOUBLE_CHECKPOINT',q=q,r=r,index=index,total=len(grid),seconds=time.monotonic()-start)),flush=True)
    assert all(sha(P/n)==h for n,h in hashes.items())
    if prefix:print(json.dumps(dict(status='HEURISTIC_SMALL_DOUBLE_PREFIX_REQUIRES_EXACT_READER',seconds=time.monotonic()-start)),flush=True);return
    cert=dict(format='double-child-four-small-inner-pairs-two-infinite-outers-v1',ordered_pairs=PAIRS,source_sha256=hashes,cells={str(q)+','+str(r):[json.loads((folder/f'q{q}-r{r}-{j:04}.json').read_bytes())for j in range(len(grid))]for q,r in PAIRS},original_global='OPEN');atomic(P/'small-v2-certificate.json',cert);print(json.dumps(dict(status='HEURISTIC_SMALL_DOUBLE_CERTIFICATE_REQUIRES_EXACT_READER',seconds=time.monotonic()-start)),flush=True)
if __name__=='__main__':main()
