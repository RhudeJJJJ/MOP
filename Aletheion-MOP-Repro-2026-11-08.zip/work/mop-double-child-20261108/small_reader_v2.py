from pathlib import Path
from fractions import Fraction as F
import json,hashlib,time,sys
import rational_grid
rational_grid.install()
import double_model as model,double_tail as tail,net_interval as net
from small_cover import PAIRS,frequency
P=Path(__file__).resolve().parent
NAMES={'small_produce_v2.py','small_reader_v2.py','small_cover.py','small_scout.py','check_small_grammar.py','small-grammar-check.json','double_geometry.py','double_physical.py','double_model.py','double_tail.py','check_double_physical.py','double-physical-check.json','double_floor_polynomials.py','unary_floor_polynomials.py','read_small_floors.py','small-floor-check.json','small-private-grams.json','small-frequency-grid.json','small-budget-v2.json','ad_tools.py','exact.py','complex_exact.py','disk_interval.py','net_interval.py','rational_grid.py','curve_interval.py','float_discovery.py'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def waitfile(path,live):
    deadline=time.monotonic()+1800
    while not path.exists():assert live and time.monotonic()<deadline,'bounded double checkpoint wait expired';time.sleep(.25)
    return json.loads(path.read_bytes())
def main():
    start=time.monotonic();prefix='--prefix'in sys.argv;live='--live'in sys.argv;reader_hash=sha(Path(__file__));folder=P/'small-v2-checkpoints';hashes=waitfile(folder/'producer-inputs.json',live);assert set(hashes)==NAMES and all(sha(P/n)==h for n,h in hashes.items())
    assert json.loads((P/'double-physical-check.json').read_bytes())['status']=='PASS_DOUBLE_CHILD_FULL_HEAD_PHYSICAL_TANGENTS_AND_SIGNED_TAIL_CONTROLS'
    assert json.loads((P/'small-floor-check.json').read_bytes())['status']=='PASS_ALL_p_s_SMALL_FOUR_DOUBLE_CHILD_PRIVATE_FLOORS'
    assert json.loads((P/'small-grammar-check.json').read_bytes())['status']=='PASS_SMALL_DOUBLE_TWO_INFINITE_AXES_AND_DAMAGED_GRAMMARS'
    grid=json.loads((P/'small-frequency-grid.json').read_bytes());budget={(row['q'],row['r']):row for row in json.loads((P/'small-budget-v2.json').read_bytes())['rows']};seen={};results={};areas={}
    cert=None if live or prefix else json.loads((P/'small-v2-certificate.json').read_bytes())
    for q,r in PAIRS:
        base=next(row for row in json.loads((P/'small-floor-check.json').read_bytes())['rows']if row['q']==q and row['r']==r)
        assert F(base['base_private_energy_lower'])-(2*(q+r)+4)>F(budget[q,r]['private_reserve']),'sharper reserve not supported by exact original Gram'
        key=str(q)+','+str(r);seen[key]=[];areas[key]=[];total=F(0);end=F(1,4);leaves=anchor=fcells=0
        for index,row in enumerate(grid[:1]if prefix else grid):
            data=waitfile(folder/f'q{q}-r{r}-{index:04}.json',live)if live or prefix else cert['cells'][key][index]
            a,b=F(row['a']),F(row['b']);assert a==end and data['q']==q and data['r']==r and data['index']==index;end=b;target=F(data['target']);assert target==F(budget[q,r]['amplitude'])/(1+((a+b)/2)**2)
            area,count,depth,nf=frequency(data['partition'],a,b,target,q,r,model);total+=area;leaves+=count;anchor=max(anchor,depth);fcells+=nf;seen[key].append(data);areas[key].append(dict(index=index,area=str(area),leaves=count,anchor=depth,frequency_cells=nf))
            if index%10==0:print(json.dumps(dict(status='EXACT_SMALL_DOUBLE_PROGRESS',q=q,r=r,index=index,total=len(grid),leaves=leaves,seconds=time.monotonic()-start)),flush=True)
        result=dict(compact_integral_upper=str(total),length_leaves=leaves,max_outer_anchor=anchor,frequency_cells=fcells)
        if not prefix:
            assert end==16
            It=sum((tail.tail(F(k,1024),F(k+1,1024),q,r)[1]/1024 for k in range(64)),F(0));assert str(It)==budget[q,r]['tail_integral_upper'];gain=F(budget[q,r]['private_reserve'])-F(1,8)-2*(total+It)/net.PI[0];assert gain>F(1,50);result.update(tail_integral_upper=str(It),surplus_lower=str(gain),surplus_float=float(gain))
        results[key]=result
    assert all(sha(P/n)==h for n,h in hashes.items())and sha(Path(__file__))==reader_hash
    if not prefix:
        if live:cert=waitfile(P/'small-v2-certificate.json',True)
        assert cert['format']=='double-child-four-small-inner-pairs-two-infinite-outers-v1'and cert['ordered_pairs']==[list(pair)for pair in PAIRS]and cert['source_sha256']==hashes and cert['cells']==seen
    out=dict(status='PASS_EXACT_SMALL_DOUBLE_INITIAL_FREQUENCY_PREFIX_ONLY'if prefix else'PASS_EXACT_DOUBLE_CHILD_FOUR_SMALL_INNER_PAIRS_BOTH_OUTER_LENGTHS_UNBOUNDED_FULL_PAYMENT',ordered_pairs=PAIRS,rows=results,reader_sha256=reader_hash,source_sha256=hashes,seconds=time.monotonic()-start,original_global='OPEN',remaining_double_internal_bands='14..41, both outer lengths unbounded; separate analytic large tail from42')
    if not prefix:out['certificate_sha256']=sha(P/'small-v2-certificate.json')
    stem='small-v2-prefix'if prefix else'small-v2-reader';(P/(stem+'-cells.json')).write_text(json.dumps(areas,separators=(',',':'))+'\n');(P/(stem+'-result.json')).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k!='source_sha256'}),flush=True)
if __name__=='__main__':main()
