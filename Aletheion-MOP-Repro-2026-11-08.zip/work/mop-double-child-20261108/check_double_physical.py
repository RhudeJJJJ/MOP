from pathlib import Path
from fractions import Fraction as F
import json,time
import rational_grid
rational_grid.install()
import double_geometry as g,double_physical as phys,double_model as model,ad_tools as ad,exact as e,complex_exact as z
P=Path(__file__).resolve().parent
def inside(x,I):assert I[0]<=x<=I[1]
def main():
    start=time.monotonic();heads=tangents=tails=0
    cases=[(p,q,r,s)for q,r in [(1,1),(1,2),(2,1),(2,2)]for p,s in [(1,1),(2,3),(5,2)]]+[(1,1,13,1),(1,7,7,1),(1,20,21,1)]
    for p,q,r,s in cases:
        B,T=g.cap(p,q,r,s);N=len(B);m=q+r;V=e.mm(B,e.tr(T));V=[[x-2*y for x,y in zip(row,rr)]for row,rr in zip(V,e.tr(T))]
        assert e.mm(T,V)==[[-2,0],[0,-2]]and e.mm(e.tr(V),V)==[[m+6,m+3],[m+3,m+6]]and e.mm(T,e.tr(T))==[[p+2,1],[1,s+2]]
        for t in [F(1,4),F(1),F(16)]:
            ad.set_box((F(0),)*5);actual=phys.response(p,q,r,s,t);got=model.response(ad.variable(t,t,0),ad.variable(F(1),F(1),1),ad.variable(F(1),F(1),2),p,q,r,s)
            for i in range(2):
                for j in range(2):
                    for k in range(2):inside(actual[i][j][k],got[i][j][k].v)
            R=phys.inverse([[z.z(t*int(i==j),B[i][j])for j in range(N)]for i in range(N)]);deriv=z.scale(z.mm(z.mm(z.real(T),z.mm(R,R)),z.real(e.tr(T))),z.z(-1))
            for index,length in [(0,p),(1,s)]:deriv[index][index]=z.add(deriv[index][index],z.div(z.z(length-1),z.mul(z.z(t,2),z.z(t,2))))
            for i in range(2):
                for j in range(2):
                    for k in range(2):inside(deriv[i][j][k],got[i][j][k].d[0]);tangents+=1
            heads+=1
            if t==16:
                x=1/(t*t);BB=e.mm(B,B);Ri=e.inverse([[int(i==j)+x*BB[i][j]for j in range(N)]for i in range(N)]);C=e.mm(e.mm(e.tr(V),Ri),V);D=e.mm(e.mm(e.mm(e.tr(V),B),Ri),V);aa=1+4*x;Q=[[3,1],[1,3]]
                norm=F(4)if m==2 else F(9,2)if m<=4 else F(7)if m<=19 else F(9);assert all(abs(v)<=norm*(m+6)for row in D for v in row)
                for i in range(2):
                    for j in range(2):
                        qp=Q[i][j]/aa+8*x*int(i==j)/aa**2-x*((1-4*x)*C[i][j]-4*x*D[i][j])/aa**2;mp=2*Q[i][j]/aa-2*(1-4*x)*int(i==j)/aa**2-x*((1-4*x)*D[i][j]+4*C[i][j])/aa**2
                        assert qp==t*actual[i][j][0]and mp==-t*t*actual[i][j][1]
                tails+=1
    out=dict(status='PASS_DOUBLE_CHILD_FULL_HEAD_PHYSICAL_TANGENTS_AND_SIGNED_TAIL_CONTROLS',full_head_states=heads,full_physical_tangent_components=tangents,full_signed_tail_states=tails,actual_TV=[[-2,0],[0,-2]],normalized_Q=[[3,1],[1,3]],uniformity='Written all-arm literal three-head Schur elimination and star/pathforest norm, full actual Gram identities; finite controls calibrate, not extrapolate',seconds=time.monotonic()-start,full_double_payment='OPEN',original_global='OPEN')
    (P/'double-physical-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
