"""Exact outward96bit grid arithmetic; exact dyadic rational endpoints.

Integer products/divisions implement directed rounding directly. Every
incoming rational is first enclosed on the same grid. No float is accepted.
"""
from fractions import Fraction as F
import math,numbers
import disk_interval as h
G=2**96
class Dyadic:
    __slots__=('n',)
    def __init__(self,n):self.n=n
    @property
    def numerator(self):
        k=min(96,(self.n&-self.n).bit_length()-1)if self.n else 96
        return self.n>>k
    @property
    def denominator(self):
        k=min(96,(self.n&-self.n).bit_length()-1)if self.n else 96
        return G>>k
    def frac(self):return F(self.n,G)
    def __str__(self):return str(self.frac())
    def __repr__(self):return 'Dyadic('+str(self.n)+')'
    def __hash__(self):return hash(self.frac())
    def __float__(self):return self.n/G
    def __bool__(self):return self.n!=0
    def __neg__(self):return Dyadic(-self.n)
    def __abs__(self):return Dyadic(abs(self.n))
    def __add__(self,o):return self.frac()+o
    __radd__=__add__
    def __sub__(self,o):return self.frac()-o
    def __rsub__(self,o):return o-self.frac()
    def __mul__(self,o):return self.frac()*o
    __rmul__=__mul__
    def __truediv__(self,o):return self.frac()/o
    def __rtruediv__(self,o):return o/self.frac()
    def __pow__(self,o):return self.frac()**o
    def cmp(self,o):
        if isinstance(o,Dyadic):return self.n-o.n
        if isinstance(o,int):return self.n-o*G
        if isinstance(o,F):return self.n*o.denominator-o.numerator*G
        return NotImplemented
    def __eq__(self,o):
        d=self.cmp(o);return False if d is NotImplemented else d==0
    def __lt__(self,o):
        d=self.cmp(o);return NotImplemented if d is NotImplemented else d<0
    def __le__(self,o):
        d=self.cmp(o);return NotImplemented if d is NotImplemented else d<=0
    def __gt__(self,o):
        d=self.cmp(o);return NotImplemented if d is NotImplemented else d>0
    def __ge__(self,o):
        d=self.cmp(o);return NotImplemented if d is NotImplemented else d>=0
numbers.Rational.register(Dyadic)
def l(q):
    if isinstance(q,Dyadic):return q.n
    assert isinstance(q,(int,F)),'rational endpoints only'
    return q.numerator*(G//q.denominator)if G%q.denominator==0 else q.numerator*G//q.denominator
def u(q):return-l(-q)
def f(n):return Dyadic(n)
def down(q):return f(l(q))
def up(q):return f(u(q))
def rnd(a):return down(a[0]),up(a[1])
def con(q):return down(q),up(q)
def add(a,b):return f(l(a[0])+l(b[0])),f(u(a[1])+u(b[1]))
def neg(a):return-a[1],-a[0]
def sub(a,b):return f(l(a[0])-u(b[1])),f(u(a[1])-l(b[0]))
def mul(a,b):
    aa=(l(a[0]),u(a[1]));bb=(l(b[0]),u(b[1]));v=[x*y for x in aa for y in bb];return f(min(v)//G),f(-((-max(v))//G))
def div(a,b):
    al,au,bl,bu=l(a[0]),u(a[1]),l(b[0]),u(b[1])
    if bl<=0:raise ArithmeticError('strictly positive whole grid divisor required')
    lower=al*G//(bu if al>=0 else bl);upper=-((-au*G)//(bu if au<=0 else bl));return f(lower),f(upper)
def square(a):
    al,au=l(a[0]),u(a[1]);low=0 if al<=0<=au else min(al*al,au*au);high=max(al*al,au*au);return f(low//G),f(-((-high)//G))
def positive(a):
    assert a[1]>=0;return max(F(0),a[0]),a[1]
def sqrt(a):
    a=positive(a);al,au=l(a[0]),u(a[1]);return f(math.isqrt(max(0,al)*G)),f(math.isqrt(au*G)+1)
def install():
    h.GRID=G
    for key,fun in dict(down=down,up=up,rnd=rnd,con=con,add=add,neg=neg,sub=sub,mul=mul,times=lambda a,k:mul(a,con(k)),div=div,square=square,positive=positive,sqrt=sqrt).items():setattr(h,key,fun)
    h.BACKEND='outward-integer-grid-96'
