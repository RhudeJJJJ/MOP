"""Three-head normalized response, initially fixed q,r and two infinite outsides."""
from fractions import Fraction as F
import ad_tools as ad
from ad_tools import z,ca,cs,cn,cm,cd,ct
def response(t,up,us,p,q,r,s):
    rp,ep=ad.endpoints(t,up,p);rs,es=ad.endpoints(t,us,s);rq,eq=ad.endpoints(t,ad.asA(1),q);rr,er=ad.endpoints(t,ad.asA(1),r);w=z(t,2)
    def hh(r,e):return cd(ca(z(1),cm(z(0,1),ca(z(r),e))),w)
    hp,hs,hq,hr=[hh(*v)for v in [(rp,ep),(rs,es),(rq,eq),(rr,er)]]
    A=t+rp+rq;E=t+rs+rr;B=ca(z(0,1),hq);D=ca(z(0,1),hr)
    C=ca(z(t),cd(ca(z(q+r),cm(z(0,2),ca(hq,hr))),w))
    den=cs(cs(ct(C,A*E),ct(cm(B,B),E)),ct(cm(D,D),A))
    Rdd=cd(cs(ct(C,E),cm(D,D)),den);Rcc=cd(z(A*E),den);Ree=cd(cs(ct(C,A),cm(B,B)),den);Rdc=cd(ct(cn(B),E),den);Rce=cd(ct(cn(D),A),den);Rde=cd(cm(B,D),den)
    alpha=cs(z(1),cm(z(0,1),hp));beta=cs(z(1),cm(z(0,1),hs));fl=cd(ca(z(1),cm(z(0,2),hp)),w);fs=cd(ca(z(1),cm(z(0,2),hs)),w)
    fa=ca(ca(ca(fl,cm(cm(alpha,alpha),Rdd)),ct(cm(alpha,Rdc),2)),Rcc);fb=ca(ca(ca(fs,cm(cm(beta,beta),Ree)),ct(cm(beta,Rce),2)),Rcc)
    fab=ca(ca(cm(alpha,Rdc),cm(cm(alpha,beta),Rde)),ca(Rcc,cm(beta,Rce)))
    return [[fa,fab],[fab,fb]]
def bound(a,b,pa,pb,sa,sb,p,q,r,s):
    assert 0<a<=b and 0<=pa<=pb<=1 and 0<=sa<=sb<=1 and all(j>=1 for j in [p,q,r,s])
    ad.set_box(((b-a)/2,(pb-pa)/2,(sb-sa)/2,F(0),F(0)));t=ad.variable(a,b,0);up=ad.variable(pa,pb,1);us=ad.variable(sa,sb,2);cap=ad.h.up(2*ad.n.PI[1]*b)
    try:mat=response(t,up,us,p,q,r,s)
    except(ArithmeticError,AssertionError):return dict(upper=cap,method='double-cap-response')
    try:
        f=ad.phase(t,mat);return dict(upper=min(cap,max(F(0),f.v[1])),method='double-centered-three-variable',grad=tuple(max(abs(v)for v in row)for row in f.d))
    except(ArithmeticError,AssertionError):return ad.raw_bound((a,b),mat)
