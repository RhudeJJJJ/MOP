# Four small double-child cores, with both outer lengths unbounded

8 November 2026. LOCAL EXACT ACCEPTANCE PASSED. Original universal UNIT
MOP conjecture F(G)=splus(G)>=2|G| remains GLOBAL OPEN; goal ACTIVE.

THEOREM. Let H be ANY finite simple unit maximal outerplanar graph of
order h>=3, and ab an ordered boundary edge. Retain that edge and add a
parent triangle abc, an external/external child E_(p,q) on ac (apices a,c),
and an external/external child E_(r,s) on cb (apices c,b). All edges have
weight one, each appears once, and there are no further private contacts.
For EVERY independently chosen p,s>=1 and EACH ORDERED pair
(q,r)=(1,1),(1,2),(2,1),(2,2), writing N=p+q+r+s+3, one has

                         F(G)-F(H)>2N+3/20.                 (1)

There is no upper bound on the old order, degrees, norm or spectrum.
Old K2 is not included in this increment theorem. Whole small-old graphs
use the separately proved parent-extraction domination<=4 bridge at its
declared inherited input boundary. Neither a global theorem nor an
unconditional upgrade of those inputs follows from (1).

1. Literal geometry and private floor.

In the ordered private coordinates
left_p,d,middle_q,c,middle_r,e,right_s, B is a path together with c joined
to d,e and every middle vertex. Put m=q+r. Its edge count is p+s+2m+2.
Ta is the indicator of left_p,d,c; Tb the indicator of c,e,right_s. Thus
Tr(TTt)=p+s+4, and edges(B)+Tr(TTt)=2N. All private vertices and contacts
are retained, with transpose rather than conjugate transpose below.

Let D0=1,D1=t,Dj=t Dj-1+Dj-2, t>0, and x=Dp-1/Dp,y=Ds-1/Ds.
Both actual x,y lie in (0,1/t]. Exact path elimination gives

             det(tI+iB)=Dp Ds [C(x,y)-i M(x,y)],

where C,M are bilinear in x,y. Their complete rational polynomial
coefficients are constructed in double_floor_polynomials.py from the
one-leg determinant identities in unary_floor_polynomials.py. For every
one of the four ordered pairs all C/M coefficients are nonnegative,
with positive constant parts. For each coordinate the numerator
M0 C1-M1 C0 of minus the derivative of M/C has three nonnegative
coefficient polynomials in the OTHER coordinate. Consequently M/C is
nonincreasing in x and in y over the whole nonnegative quadrant. It is
therefore at least its value at x=y=1/t, the actual p=s=1 graph.
No determinant phase wrap occurs: C,M stay positive. The equal-trace
Coulson identity gives D(B)>=D(B_(1,q,r,1)), with D=splus-sminus.
Since F(B)=edges(B)+D(B)/2, exact full base PSD witnesses imply the
following uniform reserves c above edges(B):

    (q,r)       c          exact base F lower (denominator 10^24)
     1,1       33/25       9324306893712994773121759
     1,2      187/100     11875117492970406155095389
     2,1      187/100     11875117492970406155095389
     2,2      239/100     14395440578017025040836347

The reader checks every integer Gram column using
X=ZZt/10^12 and F(B)>=2Tr(BX)-Tr(X^2). It also checks all coefficient
signs and 48 complete Newton-determinant controls against actual B.
The sign proof, not those finite controls, supplies all-p,s uniformity.
The sharper c values are checked again by the final full phase reader
against the exact same base Grams. The weaker earlier floor constants
remain true; no new spectral approximation is used to sharpen them.

2. Full actual two-root response and all infinite lengths.

Use the already accepted physical old-root sector and sharp root-ball
phase bound with K=[[2,1],[1,2]] and the SAME old H throughout the
Schur homotopy. They give

 DeltaF>=F(B)+Tr(TTt)-(2/pi) integral_0^infinity t b(Fcap,t) dt.       (2)

Only the two positive lossless rays (p-1)/(t+2i),(s-1)/(t+2i)
are removed from the two diagonal entries. Their Wplus is zero and
their removal can only increase the phase upper bound. Energy is never
assigned to this auxiliary normalized response.

For j>=1 put rj=Dj-1/Dj, ej=(-i)^(j-1)/Dj,
hj=(1+i(rj+ej))/(t+2i). Literal elimination of all four paths leaves
the symmetric three-head matrix

 Z=[[t+rp+rq, i+hq, 0],
    [i+hq, t+(q+r+2i(hq+hr))/(t+2i), i+hr],
    [0, i+hr, t+rs+rr]].

The old-root contact vectors on these heads are
Ua=(1-i hp,1,0), Ub=(0,1,1-i hs), and the normalized direct terms are
diag((1+2i hp)/(t+2i),(1+2i hs)/(t+2i)). The full response is
direct+U Z^-1 Ut, precisely double_model.py. No mode of B is omitted.
Independent full-private inverse controls check 45 actual head states,
360 true t-tangent components and 15 signed-tail states. They calibrate
the formula; the displayed exact elimination supplies its all-length
meaning.

For each outer residue anchor j=1,2,3,4 use the accepted whole path
envelope s0=u/Dj, 0<=u<=1,

 r=2(1+sign*s0^2)/(t+sqrt(t^2+4+4sign*s0^2)), sign=(-1)^(j+1),
 e=(-i)^(j-1)s0.

It contains EVERY length j+4k, k>=0. All SIXTEEN ordered combinations
of the two outer residues are required. A tree split includes both the
isolated current anchor (u=1) and the infinite tail at anchor+4. At each
frequency take the MAXIMUM over every parameter leaf, then multiply by
the frequency width. This is not averaging over graphs, nor a length
cutoff. The actual q,r and both ordered old-root contacts are preserved.
The damaged-grammar controls reject missing roots, illegal singleton
splits, suffixes, truncations and missing frequency subintervals.

The exact centered interval bound certifies all whole-box prerequisites,
positive divisors and radicands. Unresolved boxes receive the safe raw
sector bound or 2pi*t cap, then refine. Floating arithmetic proposes
partitions only; all accepted bounds are recomputed with outward exact
rational interval arithmetic by small_reader_v2.py.

3. Complete frequencies, sparse tail and terminal payment.

On 0<t<=1/4 the safe cap in (2) costs at most 1/8. On [1/4,16] the
certificate covers the entire interval, including every recorded
subdivision and all sixteen infinite outer-residue domains.
For the full tail t>=16 put V=(B-2I)Tt. Literal identities give
TV=-2I, VtV=[[m+6,m+3],[m+3,m+6]], and normalized
Q=[[3,1],[1,3]]. The resolvent identity

      Fcap=Q/(t+2i)+2iI/(t+2i)^2-Vt(tI+iB)^-1V/(t+2i)^2

is used with x=1/t^2, C=Vt(I+xB^2)^-1V and
D=VtB(I+xB^2)^-1V. Actual private norms are <=4 for m=2 and
<9/2 for m=3,4, uniformly in both pendant lengths (hub star plus a
path forest). Hence |Cij|<=m+6 and |Dij|<=(m+6)*norm, with C positive
semidefinite. The accepted sector support/nuclear-norm rationalization
in double_tail.py bounds the entire tail on all 64 exact intervals of
z=1/t in [0,1/16]; this is not a sampled high-frequency check.

The complete terminal reader, with unchanged frozen 27-source manifest,
passed all cells and the final certificate identity. Its exact margins
are retained as Fractions in small-v2-reader-result.json. Approximately:

    (q,r)   lower surplus    frequency leaves   length leaves
     1,1       .176285             524              21729
     1,2       .387271             487              17296
     2,1       .377281             487              17123
     2,2       .484712             412              10037

Each EXACT fraction exceeds 3/20. The maximum outer anchors 22,25,25,15
start infinite tails. For every row the reader computes the full bound
c-1/8-2(Icompact+Itail)/pi_lower, not merely its selection hint.
Certificate SHA256:
45b0f890541e41a79ebd9c38829d08fcc104b826f7a20051d6de2cbcf9a7f21b.
Exact reader SHA256:
9a21fd9505bdde6c43398905b66408b135eebe67cc3f942b425b5ffc0b06faa7.

4. Scope and next work.

This closes the four small ordered double-child increment families.
The original-counter small-tip cut leaves additionally 14<=q+r<=41;
that full phase payment is still under exact verification. The separate
analytic theorem pays q+r>=42. Neither a passing prefix in the larger
band nor this small-pair theorem closes all double-child graphs.
The original global conjecture, the input audit and native intake remain
open. Complete source-export replay is separate from this original full
exact reader pass. No external novelty, human/formal certification or
causal LOTSE method effect is asserted.
