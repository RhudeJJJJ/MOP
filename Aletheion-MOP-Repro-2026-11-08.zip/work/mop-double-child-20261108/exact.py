"""Small standard-library rational algebra; ascending polynomial coefficients."""
from fractions import Fraction as F
def require(v,s):
    if not v:raise AssertionError(s)
def eye(n):return [[F(i==j) for j in range(n)]for i in range(n)]
def tr(A):return list(map(list,zip(*A)))
def mm(A,B):return [[sum(a*b for a,b in zip(row,col))for col in zip(*B)]for row in A]
def inverse(A):
    n=len(A);R=[list(map(F,row))+e for row,e in zip(A,eye(n))]
    for j in range(n):
        k=next(i for i in range(j,n)if R[i][j]);R[j],R[k]=R[k],R[j]
        z=R[j][j];R[j]=[v/z for v in R[j]]
        for i in range(n):
            if i!=j:
                z=R[i][j];R[i]=[a-z*b for a,b in zip(R[i],R[j])]
    return [r[n:]for r in R]
def trim(p):
    p=list(map(F,p))
    while len(p)>1 and p[-1]==0:p.pop()
    return p
def mul(a,b):
    p=[F(0)]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):p[i+j]+=x*y
    return trim(p)
def ev(p,x):
    s=F(0)
    for c in reversed(p):s=s*x+c
    return s
def derivative(p):return trim([i*p[i]for i in range(1,len(p))]or[0])
def remainder(a,b):
    a=trim(a);b=trim(b);require(b!=[0],'polynomial divisor')
    while len(a)>=len(b)and a!=[0]:
        k=len(a)-len(b);z=a[-1]/b[-1]
        for j in range(len(b)):a[j+k]-=z*b[j]
        a=trim(a)
    return a
def sturm(p):
    seq=[trim(p),derivative(p)]
    while seq[-1]!=[0]:
        r=remainder(seq[-2],seq[-1])
        if r==[0]:break
        seq.append([-v for v in r])
    require(len(seq[-1])==1 and seq[-1][0]!=0,'squarefree characteristic')
    return seq
def variations(seq,x):
    v=[ev(p,x)for p in seq];v=[z for z in v if z]
    return sum(a*b<0 for a,b in zip(v,v[1:]))
def characteristic(A):
    n=len(A);P=eye(n);mom=[0]
    for j in range(n):P=mm(P,A);mom.append(sum(P[i][i]for i in range(n)))
    c=[F(1)]
    for j in range(1,n+1):c.append(-sum(c[j-k]*mom[k]for k in range(1,j+1))/j)
    return list(reversed(c))
def actual(edge):
    require(edge in((0,2),(2,3),(3,4),(4,1)),'literal second boundary edge')
    es={(0,1),(0,2),(0,3),(1,3),(1,4),(2,3),(3,4)}
    a,b=edge;x,y,z=5,6,7
    es|={tuple(sorted(e))for e in[(a,x),(a,y),(x,y),(y,z),(y,b),(z,b)]}
    bd=[0,2,3,4,1];ix=bd.index(a);require(bd[(ix+1)%5]==b,'boundary direction');bd[ix+1:ix+1]=[x,y,z]
    validate_outer(8,es,bd)
    A=[[F(int(i!=j and tuple(sorted((i,j)))in es))for j in range(8)]for i in range(8)]
    return es,bd,A,[row[2:]for row in A[2:]],[row[2:]for row in A[:2]]
def validate_outer(n,es,bd):
    require(len(bd)==n and set(bd)==set(range(n)),'full outer boundary')
    require(len(es)==2*n-3 and all(0<=a<b<n for a,b in es),'literal unit edge count')
    require(all(tuple(sorted((bd[i],bd[(i+1)%n])))in es for i in range(n)),'boundary contacts')
    pos={a:i for i,a in enumerate(bd)};arcs=[tuple(sorted((pos[a],pos[b])))for a,b in es]
    for a,b in arcs:
        for c,d in arcs:require(not(a<c<b<d or c<a<d<b),'no crossing')
