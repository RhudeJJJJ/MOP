from fractions import Fraction as F
import exact as e
def z(a=0,b=0):return F(a),F(b)
def add(a,b):return a[0]+b[0],a[1]+b[1]
def neg(a):return-a[0],-a[1]
def sub(a,b):return add(a,neg(b))
def mul(a,b):return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def conj(a):return a[0],-a[1]
def div(a,b):
    d=b[0]**2+b[1]**2;e.require(d>0,'nonzero complex divisor');v=mul(a,conj(b));return v[0]/d,v[1]/d
def real(A):return [[z(v)for v in row]for row in A]
def eye(n):return real(e.eye(n))
def adj(A):return [[conj(A[j][i])for j in range(len(A))]for i in range(len(A[0]))]
def plus(A,B):return [[add(a,b)for a,b in zip(x,y)]for x,y in zip(A,B)]
def scale(A,c):return [[mul(v,c)for v in row]for row in A]
def mm(A,B):return [[tuple(sum(mul(a,b)[k]for a,b in zip(row,col))for k in(0,1))for col in zip(*B)]for row in A]
def trace(A):return tuple(sum(A[i][i][k]for i in range(len(A)))for k in(0,1))
def det(A):return sub(mul(A[0][0],A[1][1]),mul(A[0][1],A[1][0]))
def inv(A):
    d=det(A);return [[div(A[1][1],d),div(neg(A[0][1]),d)],[div(neg(A[1][0]),d),div(A[0][0],d)]]
def abs2(a):return a[0]**2+a[1]**2
def hermitian_psd(A):
    e.require(A==adj(A),'full complex Hermitian matrix')
    return A[0][0][0]>=0 and A[1][1][0]>=0 and det(A)[1]==0 and det(A)[0]>=0
