"""Outward bounds on ALL sector-valid points of an endpoint rectangle.

An empty rectangle is accepted ONLY after a necessary PSD condition fails.
Every other algebraic/phase branch failure returns the universal2pi*t cap.
"""
from fractions import Fraction as F
import disk_interval as h
import net_interval as net
def cz(a=0,b=0):return h.con(a),h.con(b)
def ca(a,b):return h.add(a[0],b[0]),h.add(a[1],b[1])
def cn(a):return h.neg(a[0]),h.neg(a[1])
def cs(a,b):return ca(a,cn(b))
def cm(a,b):return h.sub(h.mul(a[0],b[0]),h.mul(a[1],b[1])),h.add(h.mul(a[0],b[1]),h.mul(a[1],b[0]))
def ct(a,k):return h.times(a[0],k),h.times(a[1],k)
def cd(a,b):
    dd=h.add(h.square(b[0]),h.square(b[1]));v=cm(a,(b[0],h.neg(b[1])));return h.div(v[0],dd),h.div(v[1],dd)
def det(A):return h.sub(h.mul(A[0][0],A[1][1]),h.square(A[0][1]))
def trki(A):return h.times(h.sub(h.add(A[0][0],A[1][1]),A[0][1]),F(2,3))
def response(t,u,j):
    assert j in(1,2,3,4) and 0<t[0]<=t[1] and 0<=u[0]<=u[1]<=1
    D0=h.con(1);D1=t
    for n in range(2,j+1):D0,D1=D1,h.add(h.mul(t,D1),D0)
    s=h.div(u,D1);s2=h.square(s);sign=1 if j%2 else -1
    rad=h.add(h.add(h.square(t),h.con(4)),h.times(s2,4*sign))
    # Every true point has r>=0 because even j has D_j>=1 and s<=1.
    rad=(max(F(0),rad[0]),rad[1]);root=h.sqrt(rad)
    rr=h.times(h.sub(root,t),F(1,2));r=(max(F(0),rr[0]),rr[1])
    if r[1]<0:raise ArithmeticError('refine correlated endpoint radical')
    ee=(s,h.con(0))if j==1 else(h.neg(s),h.con(0))if j==3 else(h.con(0),h.neg(s))if j==2 else(h.con(0),s)
    invt=h.div(h.con(1),t);z=(t,h.con(2));hh=cd(ca(cz(1),cm(cz(0,1),ca((r,h.con(0)),ee))),z)
    t2=h.square(t);t3=h.mul(t,t2);t4=h.square(t2)
    den=(h.add(h.add(h.add(h.add(h.mul(r,t3),h.times(h.mul(r,t),2)),t4),h.times(t2,4)),h.con(1)),h.times(t,-2))
    naa=(h.add(h.add(h.add(h.times(h.mul(r,t2),2),r),h.times(t3,3)),h.times(t,2)),h.neg(h.add(h.add(h.times(h.mul(r,t),2),h.times(t2,4)),h.con(2))))
    nab=(t3,h.sub(h.con(1),t2));nbb=(h.add(t3,h.times(t,2)),h.con(0));vb=cs(cz(1),cm(cz(0,1),hh))
    fa=cd(naa,den);fab=cm(vb,cd(nab,den));fb=ca(cd(ca(cz(1),cm(cz(0,2),hh)),z),cm(cm(vb,vb),cd(nbb,den)))
    return[[fa,fab],[fab,fb]]
def bound(a,b,ua,ub,j):
    t=(a,b);cap=h.up(2*net.PI[1]*b)
    try:Fm=response(t,(ua,ub),j)
    except(ArithmeticError,AssertionError):return dict(upper=cap,method='cap-response')
    S=[[h.add(h.times(v[0],2),h.mul(t,v[1]))for v in row]for row in Fm]
    if S[0][0][1]<0 or S[1][1][1]<0 or det(S)[1]<0:return dict(upper=F(0),method='empty-sector')
    try:
        # Fm=tQ-iM, with NO assumption Q>=0 for this signed auxiliary.
        Q=[[h.div(v[0],t)for v in row]for row in Fm];M=[[h.neg(v[1])for v in row]for row in Fm];x=h.square(t)
        q,m=trki(Q),trki(M);u,v=h.times(det(Q),F(1,3)),h.times(det(M),F(1,3));w=h.times(h.sub(h.add(h.mul(Q[0][0],M[1][1]),h.mul(Q[1][1],M[0][0])),h.times(h.mul(Q[0][1],M[0][1]),2)),F(1,3))
        r=h.sub(h.mul(x,u),v);rho=h.div(h.add(x,h.con(4)),h.times(x,4))
        ar=h.sub(h.add(h.sub(h.add(h.con(1),q),h.times(m,F(1,2))),h.mul(h.sub(h.div(h.con(1),x),h.con(F(1,4))),r)),w)
        ai=h.neg(h.div(h.add(h.add(h.add(m,h.times(h.mul(x,q),F(1,2))),h.mul(h.sub(h.con(1),h.times(x,F(1,4))),w)),r),t))
        az=h.add(h.square(ar),h.square(ai));dz=h.add(h.square(r),h.mul(x,h.square(w)))
        S0=[[h.sub(h.times(Q[i][j],2),M[i][j])for j in range(2)]for i in range(2)]
        gg=h.add(h.add(h.con(1),trki(S0)),h.times(det(S0),F(1,3)))
        # G>=I on the valid sector subset, so detG>=1. No subtraction
        # of nearly equal1-alpha+beta is needed for the angle cosine.
        if gg[1]<1:raise ArithmeticError('sector determinant enclosure')
        gg=(max(F(1),gg[0]),gg[1]);co=h.div(h.sub(h.sqrt(gg),h.mul(rho,h.sqrt(h.positive(dz)))),h.sqrt(az));co=(max(F(-1),co[0]),min(F(1),co[1]))
        if co[0]>co[1]:raise ArithmeticError('no physical cosine enclosure')
        si=h.sqrt(h.positive(h.sub(h.con(1),h.square(co))));den=h.sub(h.mul(ar,co),h.mul(ai,si))
        if ar[0]>0 and den[0]>0:
            num=h.positive(h.add(h.mul(ai,co),h.mul(ar,si)));val=net.atan_interval(h.div(num,den))
        else:
            halfpi=(net.PI[0]/2,net.PI[1]/2)
            if ar[0]>0:center=net.atan_interval(h.div(ai,ar))
            elif ai[0]>0:center=h.sub(halfpi,net.atan_interval(h.div(ar,ai)))
            elif ai[1]<0:center=h.sub(h.neg(halfpi),net.atan_interval(h.div(h.neg(ar),h.neg(ai))))
            else:raise ArithmeticError('unresolved WHOLE-box determinant quadrant')
            val=h.add(center,net.acos_interval(co))
        upper=h.positive(h.mul(t,val))[1]
        return dict(upper=min(cap,upper),method='net')
    except(ArithmeticError,AssertionError):return dict(upper=cap,method='cap-phase')
