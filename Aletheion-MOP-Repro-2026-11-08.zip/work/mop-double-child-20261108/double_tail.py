"""Both normalized outer rays removed: Q=[[3,1],[1,3]], TV=-2I."""
from fractions import Fraction as F
import disk_interval as h
def add(A,B):return[[h.add(x,y)for x,y in zip(a,b)]for a,b in zip(A,B)]
def scale(A,k):return[[h.mul(v,k)for v in row]for row in A]
def det(A):return h.sub(h.mul(A[0][0],A[1][1]),h.square(A[0][1]))
def trki(A):return h.times(h.sub(h.add(A[0][0],A[1][1]),A[0][1]),F(2,3))
def tail(a,b,q,r):
    m=q+r;assert 2<=m<=41
    Cmax=m+6;norm=F(4)if m==2 else F(9,2)if m<=4 else F(7)if m<=19 else F(9);Dmax=Cmax*norm
    x=(a*a,b*b);one=h.con(1);I=[[one,h.con(0)],[h.con(0),one]];Q=[[h.con(3),one],[one,h.con(3)]]
    C=[[(F(0),F(Cmax)),(F(-Cmax),F(Cmax))],[(F(-Cmax),F(Cmax)),(F(0),F(Cmax))]];D=[[(-Dmax,Dmax),(-Dmax,Dmax)],[(-Dmax,Dmax),(-Dmax,Dmax)]]
    aa=h.add(one,h.times(x,4));aa2=h.square(aa);factor=h.sub(one,h.times(x,4));inv=h.div(one,aa);inv2=h.div(one,aa2)
    A=add(add(scale(Q,inv),scale(I,h.times(h.mul(x,inv2),8))),scale(add(scale(C,factor),scale(D,h.times(x,-4))),h.neg(h.mul(x,inv2))))
    M=add(add(scale(Q,h.times(inv,2)),scale(I,h.times(h.mul(factor,inv2),-2))),scale(add(scale(D,factor),scale(C,h.con(4))),h.neg(h.mul(x,inv2))))
    qt,mt=trki(A),trki(M);u,v=h.times(det(A),F(1,3)),h.times(det(M),F(1,3));assert A[0][0][0]>0 and u[0]>0 and qt[0]>0
    w=h.times(h.sub(h.add(h.mul(A[0][0],M[1][1]),h.mul(A[1][1],M[0][0])),h.times(h.mul(A[0][1],M[0][1]),2)),F(1,3));disc=h.positive(h.sub(h.square(w),h.times(h.mul(u,v),4)));zz=h.sqrt(h.add(h.square(h.sub(u,h.mul(x,v))),h.mul(x,h.square(w))));hh=h.div(disc,h.add(h.add(zz,u),h.mul(x,v)))
    fac=h.add(one,h.times(x,4));num=h.add(h.square(h.sub(h.times(qt,2),mt)),h.times(h.mul(fac,hh),2));den=h.times(h.add(h.add(h.sqrt(h.mul(fac,h.positive(h.add(h.square(qt),h.mul(x,h.add(h.square(mt),h.times(hh,2))))))),qt),h.times(h.mul(x,mt),2)),2)
    return h.positive(h.div(num,den))
