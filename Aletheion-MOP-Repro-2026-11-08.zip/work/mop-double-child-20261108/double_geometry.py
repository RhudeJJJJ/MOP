from fractions import Fraction as F
import exact as e
def cap(p,q,r,s):
    assert all(type(v)is int and v>=1 for v in [p,q,r,s])
    # Roots0,1,parent2,leftchild3,rightchild4.
    left=list(range(5,5+p));lm=list(range(5+p,5+p+q));rm=list(range(5+p+q,5+p+q+r));right=list(range(5+p+q+r,5+p+q+r+s));es={(0,1),(0,2),(1,2),(0,3),(2,3),(2,4),(1,4)}
    for arc,hub in [([0]+left+[3],0),([3]+lm+[2],2),([2]+rm+[4],2),([4]+right+[1],1)]:
        es|={tuple(sorted(x))for x in zip(arc,arc[1:])};es|={tuple(sorted((hub,x)))for x in arc if x!=hub}
    bd=[0]+left+[3]+lm+[2]+rm+[4]+right+[1];e.validate_outer(p+q+r+s+5,es,bd);order=left+[3]+lm+[2]+rm+[4]+right
    B=[[F(int(i!=j and tuple(sorted((i,j)))in es))for j in order]for i in order];T=[[F(int(tuple(sorted((i,j)))in es))for j in order]for i in [0,1]]
    N=p+q+r+s+3;assert len(B)==N and sum(map(sum,B))/2==p+s+2*(q+r)+2 and sum(v*v for row in T for v in row)==p+s+4
    return B,T
