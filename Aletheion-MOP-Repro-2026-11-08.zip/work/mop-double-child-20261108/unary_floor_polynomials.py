"""Gaussian path-coronal coefficients, q FIXED, no false q15/16 comparison."""
from fractions import Fraction as F
import exact as e
def add(a,b,k=1):return e.trim([(a[j]if j<len(a)else 0)+k*(b[j]if j<len(b)else 0)for j in range(max(len(a),len(b)))])
def za(a,b):return add(a[0],b[0]),add(a[1],b[1])
def zm(a,b):return add(e.mul(a[0],b[0]),e.mul(a[1],b[1]),-1),add(e.mul(a[0],b[1]),e.mul(a[1],b[0]))
def polynomials(q):
    D=[[F(1)],[F(0),F(1)]];E=[([F(0)],[F(0)]),([F(1)],[F(0)])];X=([F(1)],[F(0)])
    for m in range(2,q+2):
        dn=add(e.mul([0,1],D[-1]),D[-2]);en=za(za(zm(([0,1],[0]),E[-1]),E[-2]),za((D[-1],[0]),zm(([0],[-2]),X)));X=za((D[-1],[0]),zm(([0],[-1]),X));D.append(dn);E.append(en)
    Z=[za((e.mul([0,1],D[j]),[F(0)]),E[j])for j in [q+1,q]]
    C0,C1=Z[0][0],Z[1][0];M0,M1=[[-x for x in row[1]]for row in Z]
    cross=add(e.mul(M0,C1),e.mul(M1,C0),-1)
    return C0,C1,M0,M1,cross
