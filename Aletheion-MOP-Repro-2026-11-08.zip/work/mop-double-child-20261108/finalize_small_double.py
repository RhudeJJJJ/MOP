"""Seal the already terminal full exact small-four-double-child result."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json
P=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rd(n):return json.loads((P/n).read_bytes())
def main():
    r=rd('small-v2-reader-result.json');c=rd('small-v2-certificate.json');m=rd('small-v2-checkpoints/producer-inputs.json')
    assert r['status']=='PASS_EXACT_DOUBLE_CHILD_FOUR_SMALL_INNER_PAIRS_BOTH_OUTER_LENGTHS_UNBOUNDED_FULL_PAYMENT'
    assert r['ordered_pairs']==[[1,1],[1,2],[2,1],[2,2]] and len(m)==27
    assert r['source_sha256']==c['source_sha256']==m and all(sha(P/n)==h for n,h in m.items())
    assert r['certificate_sha256']==sha(P/'small-v2-certificate.json') and r['reader_sha256']==sha(P/'small_reader_v2.py')
    assert all(F(v['surplus_lower'])>F(3,20) for v in r['rows'].values())
    expected={'small-floor-check.json':'PASS_ALL_p_s_SMALL_FOUR_DOUBLE_CHILD_PRIVATE_FLOORS','double-physical-check.json':'PASS_DOUBLE_CHILD_FULL_HEAD_PHYSICAL_TANGENTS_AND_SIGNED_TAIL_CONTROLS','small-grammar-check.json':'PASS_SMALL_DOUBLE_TWO_INFINITE_AXES_AND_DAMAGED_GRAMMARS'}
    assert all(rd(n)['status']==s for n,s in expected.items())
    assert 'LOCAL EXACT ACCEPTANCE PASSED.' in (P/'small-double-payment-proof.md').read_text()
    names=list(m)+['small-double-payment-proof.md','small-v2-reader-result.json','small-v2-reader-cells.json','small-v2-certificate.json','small-v2-checkpoints/producer-inputs.json','finalize_small_double.py']
    out=dict(status='PASS_ALL_p_s_FOUR_SMALL_DOUBLE_CHILD_INCREMENT_PAYMENTS',proved_increment='DeltaF>2N+3/20; all p,s>=1; ordered q,r in {1,2}^2; old UNIT MOP h>=3',proof_sha256=sha(P/'small-double-payment-proof.md'),certificate_sha256=sha(P/'small-v2-certificate.json'),source_sha256={n:sha(P/n)for n in names},original_global='OPEN',original_goal_complete=False,remaining_double_phase='14<=q+r<=41, full exact verification RUNNING; analytic tail from42 separate',native_intake='PENDING')
    (P/'small-double-verification.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items()if k!='source_sha256'}))
if __name__=='__main__':main()
