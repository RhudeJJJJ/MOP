from fractions import Fraction as F
import exact as e
import disk_interval as h
N=12
PI=h.machin_pi()
def atan_point(q):
    q=F(q)
    if q<0:return h.neg(atan_point(-q))
    if q>1:
        pL,pU=PI;return h.sub((pL/2,pU/2),atan_point(1/q))
    # Half-angle puts the whole series interval below sqrt(2)-1<1/2.
    z=h.div(h.con(q),h.add(h.con(1),h.sqrt(h.con(1+q*q))))
    e.require(0<=z[0]<=z[1]<F(1,2),'convergent arctangent series domain')
    poly=[F((-1)**j,2*j+1)for j in range(N)]
    series=h.mul(z,h.ev(poly,h.square(z)));remainder=h.up(z[1]**(2*N+1)/F(2*N+1))
    return h.times((series[0],series[1]+remainder),2)
def atan_interval(a):
    lo=atan_point(a[0])[0];hi=atan_point(a[1])[1];return lo,hi
def acos_point(q):
    e.require(-1<q<=1,'exact cosine argument inside physical branch')
    if q==1:return h.con(0)
    z=h.sqrt(h.con((1-q)/(1+q)));return h.times(atan_interval(z),2)
def acos_interval(a):
    a=(max(F(-1),a[0]),min(F(1),a[1]))
    if a[0]<=-1:raise ArithmeticError('split: cosine lower endpoint must exceed-1')
    return acos_point(a[1])[0],acos_point(a[0])[1]
def invariants(data,a,b):
    t=(a,b);x=(a*a,b*b);q,m,u,v,w=h.invariant(data['compact'],x);r=h.sub(h.mul(x,u),v)
    rho=h.div(h.add(x,h.con(4)),h.times(x,4))
    ar=h.sub(h.add(h.sub(h.add(h.con(1),q),h.times(m,F(1,2))),h.mul(h.sub(h.div(h.con(1),x),h.con(F(1,4))),r)),w)
    ai=h.neg(h.div(h.add(h.add(h.add(m,h.times(h.mul(x,q),F(1,2))),h.mul(h.sub(h.con(1),h.times(x,F(1,4))),w)),r),t))
    aa=h.add(h.square(ar),h.square(ai));dd=h.add(h.square(r),h.mul(x,h.square(w)))
    nf=h.add(h.mul(x,h.positive(h.sub(h.square(q),h.times(u,2)))),h.positive(h.sub(h.square(m),h.times(v,2))))
    cross=h.add(h.mul(h.sub(r,h.times(h.mul(x,w),F(1,2))),q),h.mul(h.add(w,h.times(r,F(1,2))),m))
    alpha=h.div(h.mul(rho,h.positive(h.add(h.add(nf,h.times(cross,2)),h.times(h.mul(rho,dd),2)))),aa)
    beta=h.div(h.mul(h.square(rho),dd),aa)
    return ar,ai,alpha,beta
def enclosure_angles(data,region,a,b):
    if region=='tail':return h.enclosure(data,'tail',a,b)
    ar,ai,alpha,beta=invariants(data,a,b)
    if ar[0]<=0:raise ArithmeticError('split: positive real determinant A required by THIS scalar certificate branch')
    center=atan_interval(h.div(ai,ar))
    defect=h.positive(h.add(h.sub(h.con(1),alpha),beta))
    cosine=h.sub(h.sqrt(defect),h.sqrt(h.positive(beta)))
    theta=acos_interval(cosine);bound=h.positive(h.add(center,theta))
    return h.mul((a,b),bound)
def enclosure(data,region,a,b):
    if region=='tail':return h.enclosure(data,'tail',a,b)
    ar,ai,alpha,beta=invariants(data,a,b)
    if ar[0]<=0:raise ArithmeticError('split: positive real detA needed for actual certificate phase branch')
    defect=h.positive(h.add(h.sub(h.con(1),alpha),beta))
    cosine=h.sub(h.sqrt(defect),h.sqrt(h.positive(beta)))
    cosine=(max(F(-1),cosine[0]),min(F(1),cosine[1]))
    sine=h.sqrt(h.positive(h.sub(h.con(1),h.square(cosine))))
    denominator=h.sub(h.mul(ar,cosine),h.mul(ai,sine))
    # ar>0 fixes argA in(-pi/2,pi/2); theta in[0,pi). Positive cos(sum)
    # puts the sum in(-pi/2,pi/2), and the proven zero-in-ball bound makes it>=0.
    numerator=h.positive(h.add(h.mul(ai,cosine),h.mul(ar,sine)))
    value=atan_interval(h.div(numerator,denominator))
    return h.mul((a,b),value)
