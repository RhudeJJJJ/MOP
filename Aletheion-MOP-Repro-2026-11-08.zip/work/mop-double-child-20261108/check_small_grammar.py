from fractions import Fraction as F
from pathlib import Path
import json
import rational_grid
rational_grid.install()
import double_model as model
from small_cover import PAIRS,tree,frequency
P=Path(__file__).resolve().parent
def reject(fn):
    try:fn()
    except(AssertionError,ArithmeticError):return 1
    raise AssertionError('damaged double grammar accepted')
def main():
    old=model.bound;a,b=F(1),F(1001,1000);part=dict(a=str(a),b=str(b),trees=['0']*16)
    try:
        model.bound=lambda *args:dict(upper=F(1,10))
        for q,r in PAIRS:
            assert frequency(part,a,b,F(1),q,r,model)==((b-a)/10,16,4,1)
            assert tree('100',a,b,F(1),1,1,q,r,model)[1]==2 and tree('200',a,b,F(1),1,1,q,r,model)[1]==2
        tests=[lambda:tree('',a,b,F(1),1,1,1,1,model),lambda:tree('00',a,b,F(1),1,1,1,1,model),lambda:tree('3',a,b,F(1),1,1,1,1,model),lambda:tree('1',a,b,F(1),1,1,1,1,model),lambda:tree('11000',a,b,F(1),1,1,1,1,model),lambda:tree('22000',a,b,F(1),1,1,1,1,model),lambda:tree('0',a,b,F(0),1,1,1,1,model),lambda:frequency(dict(part,trees=['0']*15),a,b,F(1),1,1,model),lambda:frequency(dict(part,a='0'),a,b,F(1),1,1,model),lambda:frequency(dict(a=str(a),b=str(b),split=[part]),a,b,F(1),1,1,model),lambda:frequency(dict(a=str(a),b=str(b),split=[part,part]),a,b,F(1),1,1,model)]
        damage=sum(reject(f)for f in tests)
    finally:model.bound=old
    damage+=reject(lambda:tree('0',a,b,F(0),1,1,1,1,model))
    out=dict(status='PASS_SMALL_DOUBLE_TWO_INFINITE_AXES_AND_DAMAGED_GRAMMARS',ordered_pairs=PAIRS,ordered_outer_residues_per_pair=16,damaged_cases_rejected=damage,scope='Grammar only; full exact analytic leaf and frequency acceptance required',original_global='OPEN');(P/'small-grammar-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
