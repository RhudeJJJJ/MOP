# A sharper hub compression pays the complete large double-child tail

8 November2026. ORIGINAL GLOBAL OPEN, goal ACTIVE. This proves an
all-length large-internal-tail increment and the private reserves for
two finite remaining bands. Full finite-band root payment is OPEN.

For two nonempty paths on R>=2 vertices let J be their join with one
new hub. The path forest has exactly R-2 edges, positive square energy
R-2 by bipartiteness, and largest eigenvalue square<4. Interlacing gives

                    F(J)>rho(J)^2+R-6.

In the orthonormal span of the hub vector and the uniform forest vector,
the adjacency compression is [[0,sqrtR],[sqrtR,2h]], h=1-2/R>=0.
Rayleigh-Ritz gives rho(J)>=h+sqrt(R+h²). Consequently

 F(J)>2R+G(R), G(R)=2h²+2h sqrt(R+h²)-6.                 (1)

For R>2, h and R strictly increase and all displayed positive operations
increase, so G increases. This retains the exact largest eigenvalue of
the two-dimensional compression, rather than replacing it by sqrtR+h.
No actual graph-energy monotonicity or missing-mode deletion is used.

Actual double-child group: old closing edge ab, new parent abc, external
E_(p,q) on ac with apices a,c and external E_(r,s) on cb with apicesc,b.
All p,q,r,s>=1, m=q+r, N=p+q+r+s+3. Keep every old unit edge once and
allow no extra outside private contact. Private B is the path in order
left_p,d,middle_q,c,middle_r,e,right_s with all c-to-middle edges and
c-d,c-e. Its edge count is p+s+2m+2, contact mass p+s+4, total2N.

THEOREM. For EVERY old UNIT MOP H,h>=3 and EVERY actual ordered boundary
ab, EVERY such independent four lengths with m>=42 satisfy

                       DeltaF>2N+9/100.                    (2)

Delete ONLY both middle paths, retaining d,e. The exact induced Hbar
is bare E_(p+1,s+1) relative to the SAME original H, with k=p+s+3 new
vertices. The accepted quantitative bare-branch theorem gives
F(Hbar)-F(H)>2k-184/157. Its private c has actual degree EXACTLY4,
neighbors a,b,d,e, independent of all four lengths. The accepted exact
degree4 retirement theorem gives F(Hbar)-F(Hbar-c)<351/50.

The FINAL G has the disjoint principal partition Hbar-c and
J=c join(P_q disjoint P_r), R=m. Hence(1) and block PSD pinching give

 DeltaF>2N+G(m)-351/50-184/157.                           (3)

At m42, h20/21 and G42=(40sqrt18922-1846)/441.
Since(2751/20)^2<18922,
G42>3656/441. Thus the surplus in(3) is greater than

                  340213/3461850>9/100.

Monotonicity covers EVERY m>=42, with both outer lengths unbounded.
The retired c and every private vertex are counted ONCE. The actual
old degrees, norm, upper order and spectrum are unrestricted. Old K2
is not inferred as an increment domain; its WHOLE graph is already
paid by the parent-extraction domination<=4 bridge at its exact old
gamma4/finite-base source boundary.

PRIVATE FLOOR THEOREMS. Pinch the actual B into its core
Jprime=c join(P_(q+1) disjoint P_(r+1)) and the TWO disjoint pendant
paths P_p,P_s. With R=m+2, equation(1) gives

                  F(B)>edges(B)+G(m+2).

At R16, G16=(7sqrt1073-143)/32. The exact square comparison
(131/4)^2<1073 gives G16>345/128>269/100. At R22,
G22=(20sqrt2762-526)/121 and(1051/20)^2<2762 give
G22>525/121>43/10. Therefore, for ALL independent outer lengths,
private reserve is>269/100 on14<=m<=19 and>43/10 for ALLm>=20.
The latter finite-phase work can now stop at41, using(2) beyond it.

QUALIFIED SMALL-INTERNAL CUT. In the original minimal-counter n>=72
domain, actual whole degree of c is m+4. If q>=3, its terminal two
middle vertices make a closed C0 rooted at c and the preceding retained
middle vertex of whole degree3. If r>=3 use the reflected terminal end
of that fan (the first two in the displayed middle_r path order).
Whole root-degree sum=m+7<=20 when m<=13, so existing source256 pays
that tip, its retained order n-2>=70 excluding the small exceptional case.
Thus remaining pairs have q,r<=2, or14<=m<=41. There are four small
ORDERED pairs and93+649 ordered pairs in the two large bands, total746.
Both outer lengths remain independently infinite. This is not a proof
that any such counter exists or that every remaining full graft pays.

These all-length arguments use literal disjoint vertex partitions and
the existing quantitative/retirement theorems, not numerical spectra.
The exact finite geometry/rational controller calibrates the actual
bare Hbar, the two path cores, root degrees, tips and integer constants.
Original global closure, unconditional finite-base upgrade, first-payment
priority, independent mathematical audit and LOTSE causal effect are not
claimed. Complete finite-band phase certificates and native intake of
this new double-child package remain PENDING.
