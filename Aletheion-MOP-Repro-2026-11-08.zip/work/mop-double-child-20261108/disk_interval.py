# Interval and matrix-disk formulas adapted from the retained 5 November proof.
from fractions import Fraction as F
import math
import exact as rat
from exact import mm,tr
GRID=2**192
def down(q):return F(q.numerator*GRID//q.denominator,GRID)
def up(q):return -down(-q)
def rnd(a):return down(a[0]),up(a[1])
def con(a):return F(a),F(a)
def add(a,b):return rnd((a[0]+b[0],a[1]+b[1]))
def neg(a):return -a[1],-a[0]
def sub(a,b):return add(a,neg(b))
def mul(a,b):
    v=[x*y for x in a for y in b];return rnd((min(v),max(v)))
def times(a,c):return mul(a,con(c))
def div(a,b):
    if b[0]<=0:raise ArithmeticError('split: positive denominator not enclosed')
    return mul(a,rnd((1/b[1],1/b[0])))
def square(a):
    lo=0 if a[0]<=0<=a[1] else min(a[0]*a[0],a[1]*a[1]);return rnd((F(lo),max(a[0]*a[0],a[1]*a[1])))
def positive(a):
    assert a[1]>=0;return max(F(0),a[0]),a[1]
def sqrt(a):
    a=positive(a)
    def lower(q):return F(math.isqrt(q.numerator*GRID*GRID//q.denominator),GRID)
    lo,hi=lower(a[0]),lower(a[1]);return lo,hi+F(1,GRID)
def ev(p,x):
    v=con(0)
    for c in reversed(p):v=add(mul(v,x),con(c))
    return v
def pa(a,b,k=1):
    n=max(len(a),len(b));return rat.trim([(a[i] if i<len(a) else 0)+k*(b[i] if i<len(b) else 0) for i in range(n)])
def ps(a,k):return [k*x for x in a]
def reverse(a,n):return list(reversed(a+[F(0)]*(n-len(a))))
def poly_data(B,T,route='adjugate'):
    n=len(B);B2=mm(B,B);cp=rat.characteristic(B2);p=[v*(-1)**(n+i) for i,v in enumerate(cp)];assert all(v>=0 for v in p) and any(v>0 for v in p)
    Q=[[[F(0)]*n for _ in range(2)] for _ in range(2)];M=[[[F(0)]*n for _ in range(2)] for _ in range(2)];cc=list(reversed(p))
    if route=='adjugate':
        C=[[F(int(i==j)) for j in range(n)] for i in range(n)]
        for j in range(n):
            q=mm(mm(T,C),tr(T));m=mm(mm(mm(T,B),C),tr(T))
            for a in range(2):
                for b in range(2):Q[a][b][n-1-j]=q[a][b];M[a][b][n-1-j]=m[a][b]
            AC=mm(B2,C);C=[[cc[j+1]*int(a==b)-AC[a][b] for b in range(n)] for a in range(n)]
        assert all(not x for row in C for x in row)
    else:
        assert route=='moments';v=tr(T);moms=[];bmoms=[]
        for j in range(n):moms.append(mm(T,v));bmoms.append(mm(mm(T,B),v));v=mm([[-x for x in row] for row in B2],v)
        for j in range(n):
            for a in range(2):
                for b in range(2):Q[a][b][n-1-j]=sum(cc[k]*moms[j-k][a][b] for k in range(j+1));M[a][b][n-1-j]=sum(cc[k]*bmoms[j-k][a][b] for k in range(j+1))
    assert Q[0][1]==Q[1][0] and M[0][1]==M[1][0]
    def pack(p,Q,M):
        q=ps(pa(pa(Q[0][0],Q[1][1]),Q[0][1],-1),F(2,3));m=ps(pa(pa(M[0][0],M[1][1]),M[0][1],-1),F(2,3))
        u=ps(pa(rat.mul(Q[0][0],Q[1][1]),rat.mul(Q[0][1],Q[0][1]),-1),F(1,3))
        v=ps(pa(rat.mul(M[0][0],M[1][1]),rat.mul(M[0][1],M[0][1]),-1),F(1,3))
        w=ps(pa(pa(rat.mul(Q[0][0],M[1][1]),rat.mul(Q[1][1],M[0][0])),rat.mul(Q[0][1],M[0][1]),-2),F(1,3))
        return [p,q,m,u,v,w]
    compact=pack(p,Q,M);tail=pack(reverse(p,n+1),[[reverse(z,n) for z in row] for row in Q],[[reverse(z,n) for z in row] for row in M])
    return dict(compact=compact,tail=tail)
def invariant(data,x):
    p,q,m,u,v,w=data;den=ev(p,x);den2=square(den)
    return div(ev(q,x),den),div(ev(m,x),den),div(ev(u,x),den2),div(ev(v,x),den2),div(ev(w,x),den2)
def enclosure(data,region,a,b):
    x=(a*a,b*b);q,m,u,v,w=invariant(data[region],x)
    q=positive(q);u=positive(u)
    if region=='compact':
        q2=positive(sub(square(q),times(u,2)));m2=positive(sub(square(m),times(v,2)))
        zz=sqrt(add(square(sub(mul(x,u),v)),mul(x,square(w))))
        norm2=positive(add(add(mul(x,q2),m2),times(zz,2)))
        ans=add(sub(neg(m),times(mul(x,q),F(1,2))),times(sqrt(mul(add(x,con(4)),norm2)),F(1,2)))
    else:
        disc=positive(sub(square(w),times(mul(u,v),4)))
        z=sqrt(add(square(sub(u,mul(x,v))),mul(x,square(w))))
        h=div(disc,add(add(z,u),mul(x,v)))
        fac=add(con(1),times(x,4));num=add(square(sub(times(q,2),m)),times(mul(fac,h),2))
        den=times(add(add(sqrt(mul(fac,positive(add(square(q),mul(x,add(square(m),times(h,2))))))),q),times(mul(x,m),2)),2)
        ans=div(num,den)
    return positive(ans)
def machin_pi():
    def atan(x,N=22):
        s=sum((-1)**j*x**(2*j+1)/F(2*j+1) for j in range(N));r=x**(2*N+1)/F(2*N+1);return s,s+r
    a,b=atan(F(1,5)),atan(F(1,239));L=16*a[0]-4*b[1];U=16*a[1]-4*b[0];assert F(314159,100000)<L<U<F(22,7);return L,U
