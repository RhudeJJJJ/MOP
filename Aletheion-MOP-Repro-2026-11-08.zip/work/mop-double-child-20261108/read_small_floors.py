from pathlib import Path
from fractions import Fraction as F
import json,hashlib
import exact as e,complex_exact as z,double_geometry as g,double_physical as phys
from double_floor_polynomials import coefficients,cross
P=Path(__file__).resolve().parent
def main():
    rows=json.loads((P/'small-private-grams.json').read_bytes());assert [(v['q'],v['r'])for v in rows]==[(1,1),(1,2),(2,1),(2,2)];results=[];controls=0
    for row in rows:
        q,r=row['q'],row['r'];B,T=g.cap(1,q,r,1);n=len(B);Q=row['scale'];Z=row['Z'];k=row['columns'];assert Q==10**6 and len(Z)==n and all(len(a)==k and all(type(v)is int for v in a)for a in Z)
        W=[[sum(x*y for x,y in zip(Z[i],Z[j]))for j in range(n)]for i in range(n)]
        value=F(2*Q*Q*sum(B[i][j]*W[i][j]for i in range(n)for j in range(n))-sum(v*v for a in W for v in a),Q**4);edges=2*(q+r)+4;reserve=F(13,10)if q==r==1 else F(23,10)if q==r==2 else F(9,5);assert value>edges+reserve
        C,M=coefficients(q,r);assert all(v>=0 for a in list(C.values())+list(M.values())for v in a)and any(C[0,0])and any(M[0,0]);assert all(v>=0 for dim in [0,1]for a in cross(C,M,dim)for v in a)
        for p,s in [(1,1),(1,3),(2,2),(3,1)]:
            B,T=g.cap(p,q,r,s)
            for t in [F(1,4),F(1),F(4)]:
                def path(n):
                    prev,dp=F(0),F(1)
                    for _ in range(n):prev,dp=dp,t*dp+prev
                    return dp,prev/dp
                dp,rp=path(p);ds,rs=path(s);real=sum(e.ev(C[i,j],t)*rp**i*rs**j for i in [0,1]for j in [0,1]);imag=-sum(e.ev(M[i,j],t)*rp**i*rs**j for i in [0,1]for j in [0,1]);assert phys.determinant(B,t)==z.z(dp*ds*real,dp*ds*imag);controls+=1
        results.append(dict(q=q,r=r,base_private_energy_lower=str(value),private_reserve=str(reserve)))
    out=dict(status='PASS_ALL_p_s_SMALL_FOUR_DOUBLE_CHILD_PRIVATE_FLOORS',rows=results,full_determinant_controls=controls,uniformity='Each of two full determinant phase ratios decreases in its own actual endpoint diagonal for EVERY nonnegative other diagonal; both actual diagonals<=1/t; full base Grams supply exact integrated D lower bound',gram_sha256=hashlib.sha256((P/'small-private-grams.json').read_bytes()).hexdigest(),full_double_root_payment='OPEN',original_global='OPEN')
    (P/'small-floor-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
