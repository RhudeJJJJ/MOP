from fractions import Fraction as F
PAIRS=[(1,1),(1,2),(2,1),(2,2)]
def tree(code,a,b,target,p,s,q,r,model):
    pos=leaves=anchor=0;maximum=F(0)
    def visit(p,ptail,s,stail):
        nonlocal pos,leaves,anchor,maximum
        assert pos<len(code),'truncated two-infinite-axis tree';symbol=code[pos];pos+=1;anchor=max(anchor,p,s)
        if symbol=='0':
            value=model.bound(a,b,F(0)if ptail else F(1),F(1),F(0)if stail else F(1),F(1),p,q,r,s)['upper'];assert value<=target,'exact double leaf misses target';maximum=max(maximum,value);leaves+=1;return
        if symbol=='1':assert ptail,'split isolated left';visit(p,False,s,stail);visit(p+4,True,s,stail)
        elif symbol=='2':assert stail,'split isolated right';visit(p,ptail,s,False);visit(p,ptail,s+4,True)
        else:raise AssertionError('unknown double tree symbol')
    visit(p,True,s,True);assert pos==len(code),'two-axis tree suffix';return maximum,leaves,anchor
def frequency(part,a,b,target,q,r,model):
    assert F(part['a'])==a and F(part['b'])==b and a<b
    if'split'in part:
        assert'trees'not in part and len(part['split'])==2;mid=(a+b)/2;x=frequency(part['split'][0],a,mid,target,q,r,model);y=frequency(part['split'][1],mid,b,target,q,r,model)
        return x[0]+y[0],x[1]+y[1],max(x[2],y[2]),x[3]+y[3]
    assert len(part['trees'])==16,'all SIXTEEN ordered outer residues required';maximum=F(0);leaves=anchor=0
    for index,code in enumerate(part['trees']):
        value,count,depth=tree(code,a,b,target,1+index//4,1+index%4,q,r,model);maximum=max(maximum,value);leaves+=count;anchor=max(anchor,depth)
    return(b-a)*maximum,leaves,anchor,1
