from pathlib import Path
from fractions import Fraction as F
import json,time
import rational_grid
rational_grid.install()
import unary_geometry as g,unary_physical as phys,unary_model as model,ad_tools as ad,exact as e
P=Path(__file__).resolve().parent
def inside(x,I):assert I[0]<=x<=I[1]
def main():
    start=time.monotonic();head=partials=tangents=tailcases=0
    for p in [1,2,5]:
        for q in [1,2,15,16,17,18]:
            B,T=g.cap(p,q);N=len(B);c=N-1;V=e.mm(B,e.tr(T));V=[[x-2*y for x,y in zip(row,rr)]for row,rr in zip(V,e.tr(T))]
            wanted=[[F(-int(i==0)+2*int(i==p+1)+sum(int(i==p+j)for j in range(2,q+1))-int(i==c)),F(int(i==p)+sum(int(i==p+j)for j in range(1,q+1))-2*int(i==c))]for i in range(N)]
            assert V==wanted and e.mm(T,V)==[[-2,-1],[-1,-2]]and e.mm(e.tr(V),V)==[[q+5,q+3],[q+3,q+5]]
            assert e.mm(T,e.tr(T))==[[p+2,1],[1,1]]
            for t in [F(1,4),F(1),F(4)]:
                ad.set_box((F(0),)*5);actual=phys.response(p,q,t);m=model.response(ad.variable(t,t,0),ad.variable(F(1),F(1),1),p,q)
                for i in range(2):
                    for j in range(2):
                        for k in range(2):inside(actual[i][j][k],m[i][j][k].v)
                # Physical endpoint u=1 fixed for anchor p; t derivative is the true path-chain tangent.
                R=phys.inverse([[phys.z.z(t*int(i==j),B[i][j])for j in range(N)]for i in range(N)])
                dd=phys.z.scale(phys.z.mm(phys.z.mm(phys.z.real(T),phys.z.mm(R,R)),phys.z.real(e.tr(T))),phys.z.z(-1));dd[0][0]=phys.z.add(dd[0][0],phys.z.div(phys.z.z(p-1),phys.z.mul(phys.z.z(t,2),phys.z.z(t,2))))
                for i in range(2):
                    for j in range(2):
                        for k in range(2):inside(dd[i][j][k],m[i][j][k].d[0]);tangents+=1
                head+=1
            # Complete signed tail controls at actual t16, distinct from the head formula.
            t=F(16);x=1/(t*t);BB=e.mm(B,B);Ri=e.inverse([[int(i==j)+x*BB[i][j]for j in range(N)]for i in range(N)]);C=e.mm(e.mm(e.tr(V),Ri),V);D=e.mm(e.mm(e.mm(e.tr(V),B),Ri),V);full=phys.response(p,q,t);aa=1+4*x;Q=[[3,1],[1,1]];K=[[2,1],[1,2]]
            Cmax=q+5;Dmax=3*Cmax if q<=2 else F(13,2)*Cmax
            assert 0<=C[0][0]<=Cmax and 0<=C[1][1]<=Cmax and abs(C[0][1])<=Cmax and all(abs(v)<=Dmax for row in D for v in row)
            for i in range(2):
                for j in range(2):
                    qp=Q[i][j]/aa+4*x*K[i][j]/aa**2-x*((1-4*x)*C[i][j]-4*x*D[i][j])/aa**2
                    mp=2*Q[i][j]/aa-(1-4*x)*K[i][j]/aa**2-x*((1-4*x)*D[i][j]+4*C[i][j])/aa**2
                    assert qp==t*full[i][j][0]and mp==-t*t*full[i][j][1]
            tailcases+=1
    out=dict(status='PASS_UNARY_FULL_PRIVATE_HEAD_TRUE_TANGENTS_AND_SIGNED_TAIL_CONTROLS',full_head_states=head,full_physical_tangent_components=tangents,full_signed_tail_states=tailcases,actual_sparse_TV=[[-2,-1],[-1,-2]],all_p_basis='Written literal Schur elimination and exact sparse coordinate identities; finite controls calibrate, not extrapolate',missing_before_root_payment='Full compact exact certificate and source proof intake',seconds=time.monotonic()-start,original_global='OPEN')
    (P/'unary-physical-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
