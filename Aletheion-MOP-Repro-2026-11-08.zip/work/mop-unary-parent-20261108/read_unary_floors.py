from pathlib import Path
from fractions import Fraction as F
import json,hashlib
import exact as e,complex_exact as z,unary_geometry as g
from unary_floor_polynomials import polynomials
from unary_physical import determinant
P=Path(__file__).resolve().parent
def gram(A,row,target):
    q=row['scale'];Z=row['Z'];n=len(A);k=row['columns'];assert q==10**6 and len(Z)==n and all(len(r)==k and all(type(x)is int for x in r)for r in Z)
    W=[[sum(x*y for x,y in zip(Z[i],Z[j]))for j in range(n)]for i in range(n)];value=F(2*q*q*sum(A[i][j]*W[i][j]for i in range(n)for j in range(n))-sum(x*x for r in W for x in r),q**4);assert value>target
    return str(value)
def main():
    rows=json.loads((P/'unary-grams.json').read_bytes());assert [r['label']for r in rows]==['base-q1','base-q2']+['fan-r'+str(r)for r in range(16,20)]
    values={};controls=0;polys={}
    for row in rows:
        label=row['label']
        if label.startswith('base'):
            q=int(label[-1]);A,T=g.cap(1,q);m=1+2*q+1;target=m+(F(4,5)if q==1 else F(7,5))
        else:r=int(label[5:]);A=g.fan(r);target=2*r+F(23,5)
        values[label]=gram(A,row,target)
    for q in [1,2]:
        C0,C1,M0,M1,cross=polynomials(q);assert all(v>=0 for row in [C0,C1,M0,M1,cross]for v in row)and any(C0)and any(M0)
        polys[str(q)]=[[str(v)for v in row]for row in [C0,C1,M0,M1,cross]]
        for p in [1,2,5,8]:
            for t in [F(1,4),F(1),F(4)]:
                B,T=g.cap(p,q);dp,prev=F(1),F(0)
                for _ in range(p):prev,dp=dp,t*dp+prev
                value=z.z(e.ev(C0,t)+prev/dp*e.ev(C1,t),-(e.ev(M0,t)+prev/dp*e.ev(M1,t)))
                actual=determinant(B,t);assert actual==z.mul(z.z(dp),value);controls+=1
    out=dict(status='PASS_ALL_p_UNARY_PRIVATE_FLOORS_SIX_FIXED_q',private_reserves={'1':'4/5','2':'7/5','15':'23/5','16':'23/5','17':'23/5','18':'23/5'},complete_gram_lower_values=values,exact_q1_q2_coronal_polynomials=polys,full_private_determinant_controls=controls,all_p_basis='q1,2 nonnegative derivative cross and exact p1 Gram energy; q15..18 actual disjoint fan/path principal partition, no p1 comparison used',gram_sha256=hashlib.sha256((P/'unary-grams.json').read_bytes()).hexdigest(),original_global='OPEN',full_unary_increment='OPEN')
    (P/'unary-floor-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
