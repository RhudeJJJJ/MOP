from fractions import Fraction as F
import exact as e
def cap(p,q):
    assert type(p)is int and type(q)is int and p>=1 and q>=1
    # actual old roots0,1, private parent2 and child center3
    left=list(range(4,4+p));middle=list(range(4+p,4+p+q));es={(0,1),(0,2),(1,2),(0,3),(2,3)}
    for arc,hub in [([0]+left+[3],0),([3]+middle+[2],2)]:
        es|={tuple(sorted(x))for x in zip(arc,arc[1:])};es|={tuple(sorted((hub,x)))for x in arc if x!=hub}
    bd=[0]+left+[3]+middle+[2,1];e.validate_outer(p+q+4,es,bd)
    order=left+[3]+middle+[2];B=[[F(int(i!=j and tuple(sorted((i,j)))in es))for j in order]for i in order];T=[[F(int(tuple(sorted((i,j)))in es))for j in order]for i in [0,1]]
    assert sum(map(sum,B))/2==p+2*q+1 and sum(v*v for row in T for v in row)==p+3
    return B,T
def fan(r):
    return [[F(int(i!=j and(i==0 or j==0 or abs(i-j)==1)))for j in range(r+1)]for i in range(r+1)]
