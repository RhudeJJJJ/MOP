# Unary parent over a deepest external/external branch: six exact families

8 November2026. LOCAL EXACT ACCEPTANCE PASSED. Original
ALL finite simple UNIT MOP n>=8,F=splus>=2n remains GLOBAL OPEN. The
all-p private floors, literal head/tangent/tail controls AND complete
exact frequency certificates have passed, paying the actual old roots.

THEOREM. For every old UNIT MOP H,h>=3 and ordered boundary ab,
retain ab, add parent abc with c private, and on ac add an actual
external/external E_(p,q) child with apices a,c, with NO sibling on cb.
For every p>=1 and q in{1,2,15,16,17,18}, N=p+q+2 private vertices and
2N unit edges are added. The intended actual increment is

                         DeltaF>2N+1/20.                    (1)

There is no old upper order, other degree, norm or spectrum bound.
This is not obtained by extending an ell>=1 sibling theorem to ell0.
Other q are handled only by the original minimal-counter cuts below,
not by claiming their full increment relative to arbitrary original H.

1. Private geometry and uniform reserves. In order left_p,d,middle_q,c,
B is the actual Fan_(q+2) on hub c and path d,middle_q, with pendant
P_p at d. Contacts are Ta=prefix0..p+e_c,Tb=e_c. Thus edges(B)=p+2q+1,
TrTTt=p+3 and their sum=2N. All private contacts are retained literally.

For q1,2, write D0=1,D1=t,Dj=tDprev+Dprevprev, r=Dp-1/Dp<=1/t.
Actual Gaussian path-coronal elimination gives the complete determinant

 det(tI+iB)=Dp[(C0+rC1)-i(M0+rM1)],

with, for q1, C0=t^3+3t,C1=t²+1,M0=2,M1=0;
for q2, C0=t^4+5t²,C1=t^3+3t,M0=4t,M1=2.
Every C/M is positive where needed at t>0 and r>0. The derivative cross
M0C1-M1C0 is respectively 2+2t² and 2t²+2t^4, positive for t>0.
Consequently the continuous negative phase magnitude of the whole private
determinant is at least its actual p1 value. Dp>0 introduces no phase
wrap. The full Coulson equal-trace identity therefore gives D(B)>=D(Bp1)
for ALLp, where D=splus-sminus and F(B)=edges(B)+D(B)/2.

Complete integer PSD witnesses prove F(Bp1)>edges+4/5 for q1 and
>edges+7/5 for q2. Thus these reserves hold for ALLp. The exact reader
uses X=ZZt/10^12 and checks 2Tr(BX)-Tr(X²), reading ALL integer columns
and the entire Frobenius square. No private eigenvalue is omitted. The
determinant calibration uses FULL Newton characteristics and the exact
identity det(tI+iB)=(-i)^N characteristic_B(i t), not a2x2 determinant.
All24 actual controls pass. The all-p inference is the explicit positive
cross-polynomial argument, not finite-control extrapolation.

For q15..18 the q15/16 cross polynomials do have negative coefficients;
no p1 comparison is used there. Pinch actual B into its disjoint Fan_(q+2)
and P_p blocks. The latter has F=p-1 exactly. Four full integer PSD Grams
give F(Fan_(r+1))>2r+23/5 for EACH r16..19. Since r=q+1, this proves
private reserve>23/5 above edges(B) for ALLp in these four q families.

2. Actual old roots and the unary two-head response. The accepted physical
old-root sector and sharp root-ball phase theorem give

 DeltaF>=F(B)+TrTTt-(2/pi) integral_0^infinity t b(Fcap,t)dt.

Subtract ONLY the positive left lossless ray (p-1)/(t+2i). Its Wplus is
zero and its removal can only increase the phase upper b. No original
energy is assigned to this normalized auxiliary response. The SAME actual
H supplies the old response throughout the integral and Schur homotopy.

Put w=t+2i,rj=Dj-1/Dj,ej=(-i)^(j-1)/Dj,hj=(1+i(rj+ej))/w. Eliminating
the actual two disjoint paths leaves heads d,c and EXACT matrices

 Z=[[t+rp+rq,i+hq],[i+hq,t+(q+2i hq)/w]],
 Ua=(1-i hp,1),Ub=(0,1),directdiag((1+2i hp)/w,0),
 Fnormalized=direct+U Z^-1 Ut.

The last transpose is NOT an adjoint. All q are fixed actual integers,
so only t and the p endpoint vary. ad_tools.py is a byte-identical copy
of the previously accepted outward centered AD implementation. The new
response is evaluated by ordinary exact interval algebra and derivatives
of its explicit formula. Whole-box phase prerequisites and strictly
positive divisors/square-root radicands are required. Unresolved boxes
receive the inherited safe raw-sector bound or2pi*t cap, then refine.
No physical graph is discarded merely because its artificial rectangle
contains an inconvenient nonphysical extension.

The new literal full-private inverse controls pass54 states and432 true
physical t-chain tangent components. Their inverse uses actual full N,
not the head formula. These checks calibrate the written Schur elimination;
they do not replace its all-p proof or assert independent human review.

3. Infinite p. For each anchor j1..4 modulo4 the known path envelope
has s=u/Dj,0<=u<=1,ej=(-i)^(j-1)s and

 rj=2(1+sign*s²)/(t+sqrt(t²+4+4sign*s²)),sign=(-1)^(j+1).

It contains EVERY physical length j+4k,k>=0. The exact reader checks ALL
four ORDERED roots. Every p tail split includes BOTH the isolated anchor
u1 and the infinite tail at anchor+4. The maximum explicit anchor is
not a cutoff. At each frequency take the MAXIMUM over all length leaves,
then multiply by width. Parameters are not averaged. Missing roots,
bad singletons, suffix/truncated codes and missing frequency subintervals
are rejected; the real grammar rejects11 damaged artifacts. Stub bounds
in grammar controls establish no analytic phase inequality.

4. Complete frequencies and the DIFFERENT sparse tail. The normalized
leading Q=[[3,1],[1,1]]. Crucially V=(B-2I)Tt satisfies TV=-K,
K=[[2,1],[1,2]], NOT -2I as in the nonempty-sibling family. In actual
private coordinates

 Va=-e0+2e_(p+1)+sum_(j2..q)e_(p+j)-e_c,
 Vb=e_p+sum_(j1..q)e_(p+j)-2e_c,
 VtV=[[q+5,q+3],[q+3,q+5]].

The exact resolvent identity is F=Q/w+iK/w²-Vt(tI+iB)^-1V/w².
Write x=1/t²,a=1+4x,C=Vt(I+xB²)^-1V,D=VtB(I+xB²)^-1V. Then

 Qhat=tReF=Q/a+4xK/a²-x[(1-4x)C-4xD]/a²,
 Mhat=-t²ImF=2Q/a-(1-4x)K/a²-x[(1-4x)D+4C]/a².

The18 FULL actual private-tail controls pass these signed identities.
For q1,2 maximum private degree<=3 gives normB<=3 for EVERYp. For
q15..18, B is a star_c(q+1) plus a path forest, hence normB<sqrt(q+1)+2
<13/2 uniformly in p. Positive contraction and Cauchy give C diagonals
[0,q+5], absolute cross<=q+5 and all absolute D entries <=3(q+5) or
(13/2)(q+5), respectively. These are the actual unary constants.

unary_tail.py applies the full same-sector support/nuclear-norm
rationalization to THESE Q,K,C,D. All64 outward rational z cells
partition[0,1/16], bounding the ENTIRE t>=16 tail. Positive real response,
positive divisions and outward square roots are checked on each entire
box. Symmetric M and SPD Q supply the nonnegative generalized-eigenvalue
radicands. Neither sign of an indefinite M nor a physical eigenvalue
bound on an arbitrary free endpoint is silently assumed.

For0<t<1/8 the universal b<2pi charges at most1/32 in ENERGY. Compact
t in[1/8,16] has92 contiguous base cells. Targets A/(1+t_mid²) use
A4/5 at q1,6/5 at q2,3 at q15..18. Float selection proposes only trees.
The stdlib reader imports no floating selector and recomputes EVERY leaf
with directed96-bit integer-grid bounds. Both children of every frequency
midpoint split, all final certificate/checkpoint identities and full
source/reader hashes are checked. No frequency tail is omitted.

For each fixed q, its own reserve c_q stays fixed across its ENTIRE
integral. Let I_q and T_q be the exact compact and tail upper areas.
The actual final areas certify

                  c_q-1/32-2(I_q+T_q)/pi_lower>1/20

for EVERY one of the six q. The reader's initial gate was1/50; the final
source-bound acceptance checks the stronger1/20 against EVERY actual
exact rational surplus. The q1 budget estimate .02816 was only a hint;
its actual complete surplus exceeds .08829. Actual q2 surplus exceeds
.45601, and all q15..18 exceed2.60460. These are exact rational area
comparisons, with decimals only as readable summaries. Terminal status
PASS_EXACT_UNARY_PARENT_SIX_FIXED_q_ALL_p_FULL_ROOT_PAYMENT has passed.
The complete certificate SHA256 is
01fdd9fe9df6efc88b89dad2de0572a4b422f7fd56cf08b526b33526512e52cd.
There are1451,520,238,238,237,236 frequency leaves and
9074,3069,1060,1057,1050,1044 length leaves for q1,2,15,16,17,18.
The greatest p anchor39 is an infinite-tail start, not a cutoff.

5. Exclusion of ALL unary parents at the inherited original input boundary.
Using(1), consider an actual U(E) parent of a deepest branch in
the current minimal-original-counter n>=72 domain. Whole reflection puts
its apices in the orientation above. For q3..14, the last two middle
vertices form a closed C0 with whole root degrees q+3 and3, summing
q+6<=20; the existing bounded-root C0 theorem pays this tip. Its retained
order n-2>=70 excludes the theorem's exceptional small rank-one case.
The literal degree/closedness calibration passed198 actual caps,
180 tip states and198 retained-degree3 checks; the displayed coordinate
degree argument supplies its ALL-length quantifier.

For q>=19 remove ONLY the q middle fan vertices. The actual retained
private c has degree EXACTLY3 (a,b,d), independently of p. The newly
accepted fan19 theorem pays this removal when retained order>=8.
If retained order<8, the ORIGINAL old H also has order<=7, and the
new whole-small-old grouped domination<=4 bridge pays the whole graph
at its exact existing gamma4 premises. No small old remainder is assumed
to satisfy2h. For q1,2,15..18 use(1) when original H>=8; H2..7 uses
that same whole bridge, including auxiliary K2 only as a whole graph.

Thus full acceptance plus those literal occurrence checks exclude
ALL unary parents, without asserting a universal full increment for all q.
The other two parent forms remain their own obligations. B(E,P) still
requires BOTH running exact sibling-role certificates; B(E,E) is OPEN
for arbitrary four arm lengths, not the already paid all-ones S3 alone.
Original global closure, priority, independent mathematical audit and a
LOTSE causal effect are not claimed. Native source intake remains PENDING.
