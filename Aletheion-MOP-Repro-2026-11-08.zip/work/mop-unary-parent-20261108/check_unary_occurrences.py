"""Literal tip and retained-degree calibration for ALL-q counter reduction."""
from pathlib import Path
import json
import unary_geometry as g,exact as e
P=Path(__file__).resolve().parent
def main():
    caps=tips=retirements=0
    for p in range(1,10):
        for q in range(1,23):
            B,T=g.cap(p,q);N=len(B);third=N+2;c=N+1;es={(0,1),(0,third),(1,third)}
            es|={(i+2,j+2)for i in range(N)for j in range(i+1,N)if B[i][j]}
            es|={(root,j+2)for root in range(2)for j in range(N)if T[root][j]}
            bd=[0]+list(range(2,N+2))+[1,third];e.validate_outer(N+3,es,bd)
            degree=lambda u:sum(u in edge for edge in es);assert degree(c)==q+3
            removed={p+j+2 for j in range(1,q+1)};remain=es-{edge for edge in es if set(edge)&removed};assert sum(c in edge for edge in remain)==3
            assert {v for edge in remain if c in edge for v in edge if v!=c}=={0,1,p+2}
            assert len(remain)==2*(N+3-q)-3;retirements+=1
            if q>=3:
                prev=p+q;u=p+q+1;v=p+q+2
                assert degree(prev)==3 and degree(c)+degree(prev)==q+6
                wanted={tuple(sorted(edge))for edge in [(c,prev),(c,u),(c,v),(prev,u),(u,v)]}
                assert {edge for edge in es if set(edge)<={c,prev,u,v}}==wanted
                assert all(not({u,v}&set(edge))or set(edge)<={c,prev,u,v}for edge in es)
                assert len(es-{edge for edge in es if {u,v}&set(edge)})==2*(N+1)-3;tips+=1
            caps+=1
    out=dict(status='PASS_UNARY_ALL_q_LITERAL_TIP_AND_RETAINED_APEX_DEGREE_CONTROLS',actual_caps=caps,tip_controls=tips,retained_degree3_controls=retirements,uniformity='Written unit fan paths: c degree q+3, preceding internal path vertex degree3, inward removal leaves neighbors a,b,d exactly; whole reflection preserves contacts',counter_q_remaining=[1,2,15,16,17,18],scope='Original n>=72, exact C0 source256 degree-sum/exception and fan19 degree3 theorem plus whole-small-old parent bridge retained; no all-q arbitrary-parent increment inferred',original_global='OPEN')
    (P/'unary-occurrence-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
