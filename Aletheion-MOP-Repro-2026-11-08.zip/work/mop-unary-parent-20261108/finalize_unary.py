from pathlib import Path
from fractions import Fraction as F
import json,hashlib
P=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rd(n):return json.loads((P/n).read_bytes())
def main():
    r=rd('unary-reader-result.json');cert=rd('unary-certificate.json');manifest=rd('unary-checkpoints/producer-inputs.json')
    assert r['status']=='PASS_EXACT_UNARY_PARENT_SIX_FIXED_q_ALL_p_FULL_ROOT_PAYMENT'and r['q_values']==[1,2,15,16,17,18]
    assert cert['source_sha256']==manifest==r['source_sha256']and all(sha(P/n)==h for n,h in manifest.items())
    assert r['certificate_sha256']==sha(P/'unary-certificate.json')and r['reader_sha256']==sha(P/'read_unary.py')
    assert all(F(row['surplus_lower'])>F(1,20)for row in r['rows'].values())
    expected={'unary-floor-check.json':'PASS_ALL_p_UNARY_PRIVATE_FLOORS_SIX_FIXED_q','unary-physical-check.json':'PASS_UNARY_FULL_PRIVATE_HEAD_TRUE_TANGENTS_AND_SIGNED_TAIL_CONTROLS','unary-grammar-check.json':'PASS_UNARY_FOUR_INFINITE_RESIDUES_AND_DAMAGED_GRAMMARS','unary-occurrence-check.json':'PASS_UNARY_ALL_q_LITERAL_TIP_AND_RETAINED_APEX_DEGREE_CONTROLS','unary-budget.json':'PASS_UNARY_SIX_q_EXACT_SELECTION_BUDGETS_COMPACT_OPEN'}
    assert all(rd(n)['status']==s for n,s in expected.items())
    assert 'LOCAL EXACT ACCEPTANCE PASSED.'in(P/'unary-payment-proof.md').read_text()
    names=list(manifest)+['unary-payment-proof.md','unary-reader-result.json','unary-reader-cells.json','unary-certificate.json','unary-checkpoints/producer-inputs.json','check_unary_occurrences.py','unary-occurrence-check.json','unary_floor_polynomials.py','propose_unary_grams.py','prepare_sources.py','helper-lineage.json','prepare_unary_budget.py','finalize_unary.py']
    out=dict(status='PASS_ALL_p_SIX_q_UNARY_PAYMENTS_AND_ALL_q_ORIGINAL_COUNTER_EXCLUSION',proved_increment='DeltaF>2N+1/20 for ALLp>=1,q1,2,15..18 and old UNIT MOP h>=3',original_counter_consequence='NO unary parent of a deepest branch at retained n>=72/input boundary: q3..14 actual C0 tip, q>=19 actual retained-degree3 fan19 removal, whole-small-old parent bridge; not a full all-q increment',proof_sha256=sha(P/'unary-payment-proof.md'),certificate_sha256=sha(P/'unary-certificate.json'),source_sha256={n:sha(P/n)for n in dict.fromkeys(names)},original_global='OPEN',original_goal_complete=False,remaining_parent_types='B(E,P) both exact role certificates still running; B(E,E) general four arms OPEN',native_intake='PENDING')
    (P/'unary-verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k!='source_sha256'}))
if __name__=='__main__':main()
