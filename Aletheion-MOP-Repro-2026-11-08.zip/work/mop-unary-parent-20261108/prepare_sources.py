from pathlib import Path
import hashlib,json
P=Path(__file__).resolve().parent;SOURCE=P.parent/'mop-private-sibling-middle-20261108'
def main():
    pairs=[(name,name)for name in ['exact.py','complex_exact.py','disk_interval.py','net_interval.py','rational_grid.py','curve_interval.py','float_discovery.py']]+[('private_ad5.py','ad_tools.py')]
    lineage=[]
    for old,new in pairs:
        data=(SOURCE/old).read_bytes();dest=P/new
        if dest.exists():assert dest.read_bytes()==data
        else:dest.write_bytes(data)
        lineage.append(dict(source=str(SOURCE/old),destination=new,sha256=hashlib.sha256(data).hexdigest()))
    (P/'helper-lineage.json').write_text(json.dumps(lineage,indent=2)+'\n');print(json.dumps(dict(status='COPIED_EXACT_HELPER_BYTES_NO_PARENT_SOURCE_EDITS',files=len(pairs))))
if __name__=='__main__':main()
