from fractions import Fraction as F
from pathlib import Path
import json
import read_unary as r
P=Path(__file__).resolve().parent
def reject(fn):
    try:fn()
    except(AssertionError,ArithmeticError):return 1
    raise AssertionError('damaged unary grammar accepted')
def main():
    original=r.model.bound;a,b=F(1),F(1001,1000);target=F(1);part=dict(a=str(a),b=str(b),trees=['0']*4)
    try:
        r.model.bound=lambda *args:dict(upper=F(1,10))
        for q in r.QS:
            assert r.frequency(part,a,b,target,q)==((b-a)/10,4,4,1)
            assert r.tree('100',a,b,target,1,q)[1]==2
        tests=[lambda:r.tree('',a,b,target,1,1),lambda:r.tree('00',a,b,target,1,1),lambda:r.tree('2',a,b,target,1,1),lambda:r.tree('1',a,b,target,1,1),lambda:r.tree('11000',a,b,target,1,1),lambda:r.frequency(dict(part,trees=['0']*3),a,b,target,1),lambda:r.frequency(dict(part,a='0'),a,b,target,1),lambda:r.frequency(dict(a=str(a),b=str(b),split=[part]),a,b,target,1),lambda:r.frequency(dict(a=str(a),b=str(b),split=[part,part]),a,b,target,1),lambda:r.tree('0',a,b,F(0),1,1)]
        damage=sum(reject(f)for f in tests)
    finally:r.model.bound=original
    damage+=reject(lambda:r.tree('0',a,b,F(0),1,1))
    out=dict(status='PASS_UNARY_FOUR_INFINITE_RESIDUES_AND_DAMAGED_GRAMMARS',q_values=r.QS,residue_roots_per_q=4,damaged_cases_rejected=damage,scope='Grammar only, no phase inequality accepted by stub; full exact frequency replay required',original_global='OPEN')
    (P/'unary-grammar-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
