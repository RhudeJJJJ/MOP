"""Entire exact fixed-q/ALL-p frequency coverage. NO floating selector import."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,time,sys
import rational_grid
rational_grid.install()
import unary_model as model,unary_tail as tail,net_interval as net
P=Path(__file__).resolve().parent
NAMES={'produce_unary.py','read_unary.py','check_unary_grammar.py','unary-grammar-check.json','unary_model.py','unary_tail.py','unary_geometry.py','unary_physical.py','check_unary_physical.py','unary-physical-check.json','unary_floor_polynomials.py','read_unary_floors.py','unary-floor-check.json','unary-grams.json','unary-frequency-grid.json','unary-budget.json','ad_tools.py','exact.py','complex_exact.py','disk_interval.py','net_interval.py','rational_grid.py','curve_interval.py','float_discovery.py'}
QS=[1,2,15,16,17,18]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def tree(code,a,b,target,p,q):
    pos=leaves=anchor=0;maximum=F(0)
    def visit(p,tail):
        nonlocal pos,leaves,anchor,maximum
        assert pos<len(code),'truncated unary tree';symbol=code[pos];pos+=1;anchor=max(anchor,p)
        if symbol=='0':
            upper=model.bound(a,b,F(0)if tail else F(1),F(1),p,q)['upper'];assert upper<=target,'exact unary leaf misses target';maximum=max(maximum,upper);leaves+=1;return
        assert symbol=='1'and tail,'invalid unary singleton/tail split';visit(p,False);visit(p+4,True)
    visit(p,True);assert pos==len(code),'unary tree suffix';return maximum,leaves,anchor
def frequency(part,a,b,target,q):
    assert F(part['a'])==a and F(part['b'])==b and a<b
    if'split'in part:
        assert'trees'not in part and len(part['split'])==2;mid=(a+b)/2;x=frequency(part['split'][0],a,mid,target,q);y=frequency(part['split'][1],mid,b,target,q)
        return x[0]+y[0],x[1]+y[1],max(x[2],y[2]),x[3]+y[3]
    assert len(part['trees'])==4,'all FOUR ordered residue roots required';maximum=F(0);leaves=anchor=0
    for p,code in enumerate(part['trees'],1):value,count,depth=tree(code,a,b,target,p,q);maximum=max(maximum,value);leaves+=count;anchor=max(anchor,depth)
    return(b-a)*maximum,leaves,anchor,1
def await_file(path,live):
    deadline=time.monotonic()+1200
    while not path.exists():assert live and time.monotonic()<deadline,'bounded unary wait expired';time.sleep(.25)
    return json.loads(path.read_bytes())
def main():
    start=time.monotonic();prefix='--prefix'in sys.argv;live='--live'in sys.argv;reader_hash=sha(Path(__file__));folder=P/'unary-checkpoints';hashes=await_file(folder/'producer-inputs.json',live)
    assert set(hashes)==NAMES and all(sha(P/n)==h for n,h in hashes.items())
    assert json.loads((P/'unary-physical-check.json').read_bytes())['status']=='PASS_UNARY_FULL_PRIVATE_HEAD_TRUE_TANGENTS_AND_SIGNED_TAIL_CONTROLS'
    assert json.loads((P/'unary-floor-check.json').read_bytes())['status']=='PASS_ALL_p_UNARY_PRIVATE_FLOORS_SIX_FIXED_q'
    assert json.loads((P/'unary-grammar-check.json').read_bytes())['status']=='PASS_UNARY_FOUR_INFINITE_RESIDUES_AND_DAMAGED_GRAMMARS'
    grid=json.loads((P/'unary-frequency-grid.json').read_bytes());budgets=json.loads((P/'unary-budget.json').read_bytes())['rows'];seen={};results={};areas={}
    for q in QS:
        total=F(0);end=F(1,8);leaves=anchor=fcells=0;seen[str(q)]=[];areas[str(q)]=[]
        for index,row in enumerate(grid[:1]if prefix else grid):
            data=await_file(folder/f'q{q}-{index:04}.json',live);a,b=F(row['a']),F(row['b']);assert a==end and data['index']==index and data['q']==q;end=b
            target=F(data['target']);assert target==F(budgets[str(q)]['amplitude'])/(1+((a+b)/2)**2)
            area,count,depth,nf=frequency(data['partition'],a,b,target,q);total+=area;leaves+=count;anchor=max(anchor,depth);fcells+=nf;seen[str(q)].append(data);areas[str(q)].append(dict(index=index,area=str(area),leaves=count,anchor=depth,frequency_cells=nf))
            if index%10==0:print(json.dumps(dict(status='EXACT_UNARY_PROGRESS',q=q,index=index,total=len(grid),leaves=leaves,seconds=time.monotonic()-start)),flush=True)
        result=dict(compact_integral_upper=str(total),length_leaves=leaves,max_p_anchor=anchor,frequency_cells=fcells)
        if not prefix:
            assert end==16
            It=sum((tail.tail(F(k,1024),F(k+1,1024),q)[1]/1024 for k in range(64)),F(0));assert str(It)==budgets[str(q)]['tail_integral_upper']
            gain=F(budgets[str(q)]['private_reserve'])-F(1,32)-2*(total+It)/net.PI[0];assert gain>F(1,50)
            result.update(tail_integral_upper=str(It),surplus_lower=str(gain),surplus_float=float(gain))
        results[str(q)]=result
    assert all(sha(P/n)==h for n,h in hashes.items())and sha(Path(__file__))==reader_hash
    if not prefix:
        cert=await_file(P/'unary-certificate.json',live);assert cert['format']=='unary-parent-six-fixed-q-one-infinite-p-v1'and cert['q_values']==QS and cert['source_sha256']==hashes and cert['cells']==seen
    out=dict(status='PASS_EXACT_UNARY_INITIAL_FREQUENCY_PREFIX_ONLY'if prefix else'PASS_EXACT_UNARY_PARENT_SIX_FIXED_q_ALL_p_FULL_ROOT_PAYMENT',q_values=QS,rows=results,seconds=time.monotonic()-start,reader_sha256=reader_hash,source_sha256=hashes,original_global='OPEN',all_q_increment='NOT_INFERRED: separate original minimal-counter q cuts required')
    if not prefix:out['certificate_sha256']=sha(P/'unary-certificate.json')
    stem='unary-prefix'if prefix else'unary-reader';(P/(stem+'-cells.json')).write_text(json.dumps(areas,separators=(',',':'))+'\n');(P/(stem+'-result.json')).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k!='source_sha256'}),flush=True)
if __name__=='__main__':main()
