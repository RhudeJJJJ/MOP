"""Foreground FLOAT selection only; full exact reader is obligatory."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,time,sys
import float_discovery
float_discovery.install()
import unary_model as model
P=Path(__file__).resolve().parent
NAMES={'produce_unary.py','read_unary.py','check_unary_grammar.py','unary-grammar-check.json','unary_model.py','unary_tail.py','unary_geometry.py','unary_physical.py','check_unary_physical.py','unary-physical-check.json','unary_floor_polynomials.py','read_unary_floors.py','unary-floor-check.json','unary-grams.json','unary-frequency-grid.json','unary-budget.json','ad_tools.py','exact.py','complex_exact.py','disk_interval.py','net_interval.py','rational_grid.py','curve_interval.py','float_discovery.py'}
QS=[1,2,15,16,17,18]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def atomic(path,value):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value,separators=(',',':'))+'\n');tmp.replace(path)
def solve(q,a,b,target):
    calls=0
    def visit(p,tail):
        nonlocal calls
        calls+=1;assert calls<=2000 and p<=100,'bounded unary heuristic exhausted'
        result=model.bound(a,b,0. if tail else 1.,1.,p,q)
        if result['upper']<=target:return '0'
        if not tail:raise ArithmeticError('unary singleton frequency refinement '+str((q,p,a,b,result['upper'],target)))
        return '1'+visit(p,False)+visit(p+4,True)
    return [visit(p,True)for p in range(1,5)]
def main():
    start=time.monotonic();prefix='--prefix'in sys.argv;folder=P/'unary-checkpoints';folder.mkdir(exist_ok=True);hashes={n:sha(P/n)for n in sorted(NAMES)};path=folder/'producer-inputs.json'
    if path.exists():assert json.loads(path.read_bytes())==hashes,'frozen unary inputs changed'
    else:atomic(path,hashes)
    grid=json.loads((P/'unary-frequency-grid.json').read_bytes());budgets=json.loads((P/'unary-budget.json').read_bytes())['rows']
    def frequency(q,a,b,target,depth=0):
        try:return dict(a=str(a),b=str(b),trees=solve(q,float(a),float(b),float(target)-1e-7))
        except(ArithmeticError,AssertionError)as ex:
            assert depth<8,'bounded unary frequency refinement exhausted '+str(ex);mid=(a+b)/2
            return dict(a=str(a),b=str(b),split=[frequency(q,a,mid,target,depth+1),frequency(q,mid,b,target,depth+1)])
    for q in QS:
        for index,row in enumerate(grid[:1]if prefix else grid):
            path=folder/f'q{q}-{index:04}.json'
            if path.exists():continue
            a,b=F(row['a']),F(row['b']);target=F(budgets[str(q)]['amplitude'])/(1+((a+b)/2)**2)
            atomic(path,dict(q=q,index=index,target=str(target),partition=frequency(q,a,b,target)))
            if index%10==0:print(json.dumps(dict(status='HEURISTIC_UNARY_CHECKPOINT',q=q,index=index,total=len(grid),seconds=time.monotonic()-start)),flush=True)
    assert all(sha(P/n)==h for n,h in hashes.items())
    if prefix:print(json.dumps(dict(status='HEURISTIC_UNARY_PREFIX_ONLY_REQUIRES_EXACT_READER',seconds=time.monotonic()-start)),flush=True);return
    cert=dict(format='unary-parent-six-fixed-q-one-infinite-p-v1',q_values=QS,source_sha256=hashes,cells={str(q):[json.loads((folder/f'q{q}-{j:04}.json').read_bytes())for j in range(len(grid))]for q in QS},original_global='OPEN');atomic(P/'unary-certificate.json',cert)
    print(json.dumps(dict(status='HEURISTIC_UNARY_CERTIFICATE_READY_REQUIRES_EXACT_READER',seconds=time.monotonic()-start)),flush=True)
if __name__=='__main__':main()
