"""Full actual private inverse and determinant, no two-head elimination."""
from fractions import Fraction as F
import exact as e,complex_exact as z,unary_geometry as g
def inverse(A):
    n=len(A);W=[list(row)+b for row,b in zip(A,z.eye(n))]
    for j in range(n):
        k=next(i for i in range(j,n)if W[i][j]!=z.z());W[k],W[j]=W[j],W[k];v=W[j][j];W[j]=[z.div(x,v)for x in W[j]]
        for i in range(n):
            if i!=j:
                v=W[i][j];W[i]=[z.sub(x,z.mul(v,y))for x,y in zip(W[i],W[j])]
    return[row[n:]for row in W]
def determinant(B,t):
    cp=e.characteristic(B);value=z.z()
    for c in reversed(cp):value=z.add(z.mul(z.z(0,t),value),z.z(c))
    for _ in B:value=z.mul(z.z(0,-1),value)
    return value
def response(p,q,t):
    B,T=g.cap(p,q);n=len(B);R=inverse([[z.z(t*int(i==j),B[i][j])for j in range(n)]for i in range(n)])
    ans=z.mm(z.mm(z.real(T),R),z.real(e.tr(T)));ans[0][0]=z.sub(ans[0][0],z.div(z.z(p-1),z.z(t,2)))
    return ans
