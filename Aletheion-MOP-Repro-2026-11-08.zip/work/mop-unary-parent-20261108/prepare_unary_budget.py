from pathlib import Path
from fractions import Fraction as F
import json
import rational_grid
rational_grid.install()
import unary_tail as tail,net_interval as net
P=Path(__file__).resolve().parent
def main():
    grid=[]
    for lo,hi,step in [(F(1,8),F(1,2),F(1,32)),(F(1,2),F(1),F(1,16)),(F(1),F(4),F(1,8)),(F(4),F(16),F(1,4))]:
        while lo<hi:grid.append(dict(a=str(lo),b=str(lo+step)));lo+=step
    assert len(grid)==92
    rows={}
    for q in [1,2,15,16,17,18]:
        reserve=F(4,5)if q==1 else F(7,5)if q==2 else F(23,5);A=F(4,5)if q==1 else F(6,5)if q==2 else F(3)
        It=sum((tail.tail(F(k,1024),F(k+1,1024),q)[1]/1024 for k in range(64)),F(0))
        Ic=sum(((F(r['b'])-F(r['a']))*A/(1+((F(r['a'])+F(r['b']))/2)**2)for r in grid),F(0));gain=reserve-F(1,32)-2*(Ic+It)/net.PI[0]
        assert gain>F(1,50),(q,float(gain))
        rows[str(q)]=dict(private_reserve=str(reserve),amplitude=str(A),tail_integral_upper=str(It),target_budget_surplus=str(gain),target_budget_surplus_float=float(gain))
    (P/'unary-frequency-grid.json').write_text(json.dumps(grid,indent=2)+'\n');(P/'unary-budget.json').write_text(json.dumps(dict(status='PASS_UNARY_SIX_q_EXACT_SELECTION_BUDGETS_COMPACT_OPEN',rows=rows,original_global='OPEN'),indent=2)+'\n')
    print(json.dumps(dict(status='PASS_UNARY_SIX_q_EXACT_SELECTION_BUDGETS_COMPACT_OPEN',surpluses={q:r['target_budget_surplus_float']for q,r in rows.items()},base_frequency_cells=92)))
if __name__=='__main__':main()
