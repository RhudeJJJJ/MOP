"""Normalized unary parent. Only t and ONE infinite-p endpoint vary."""
from fractions import Fraction as F
import ad_tools as ad
from ad_tools import z,ca,cs,cn,cm,cd,ct
def response(t,u,p,q):
    rp,ep=ad.endpoints(t,u,p);rq,eq=ad.endpoints(t,ad.asA(1),q);w=z(t,2)
    hp=cd(ca(z(1),cm(z(0,1),ca(z(rp),ep))),w);hq=cd(ca(z(1),cm(z(0,1),ca(z(rq),eq))),w)
    aa=t+rp+rq;bb=ca(z(0,1),hq);cc=ca(z(t),cd(ca(z(q),cm(z(0,2),hq)),w));den=cs(ct(cc,aa),cm(bb,bb))
    R00=cd(cc,den);R01=cd(cn(bb),den);R11=cd(z(aa),den);alpha=cs(z(1),cm(z(0,1),hp));fl=cd(ca(z(1),cm(z(0,2),hp)),w)
    fa=ca(ca(ca(fl,cm(cm(alpha,alpha),R00)),ct(cm(alpha,R01),2)),R11);fab=ca(cm(alpha,R01),R11)
    return [[fa,fab],[fab,R11]]
def bound(a,b,u,v,p,q):
    assert 0<a<=b and 0<=u<=v<=1 and p>=1 and q in [1,2,15,16,17,18]
    ad.set_box(((b-a)/2,(v-u)/2,F(0),F(0),F(0)));t=ad.variable(a,b,0);up=ad.variable(u,v,1);cap=ad.h.up(2*ad.n.PI[1]*b)
    try:mat=response(t,up,p,q)
    except(ArithmeticError,AssertionError):return dict(upper=cap,method='unary-cap-response')
    try:
        f=ad.phase(t,mat);return dict(upper=min(cap,max(F(0),f.v[1])),method='unary-centered-two-variable',grad=tuple(max(abs(x)for x in d)for d in f.d))
    except(ArithmeticError,AssertionError):return ad.raw_bound((a,b),mat)
