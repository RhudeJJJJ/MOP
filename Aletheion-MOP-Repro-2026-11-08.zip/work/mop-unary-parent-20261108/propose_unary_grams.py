"""FLOAT discovery only, six complete integer PSD factors."""
from pathlib import Path
import numpy as np,json
import unary_geometry as g
P=Path(__file__).resolve().parent
def main():
    rows=[]
    for label,A in [('base-q1',g.cap(1,1)[0]),('base-q2',g.cap(1,2)[0])]+[('fan-r'+str(r),g.fan(r))for r in range(16,20)]:
        vals,vec=np.linalg.eigh(np.array(A,float));keep=vals>1e-8;Z=np.rint(vec[:,keep]*np.sqrt(vals[keep])*10**6).astype(np.int64).tolist();rows.append(dict(label=label,scale=10**6,columns=int(sum(keep)),Z=Z))
    (P/'unary-grams.json').write_text(json.dumps(rows,separators=(',',':'))+'\n');print(json.dumps(dict(status='HEURISTIC_UNARY_GRAMS_REQUIRE_EXACT_READER',rows=len(rows))))
if __name__=='__main__':main()
