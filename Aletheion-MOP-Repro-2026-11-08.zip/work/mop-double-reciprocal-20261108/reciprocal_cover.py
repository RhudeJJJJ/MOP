from fractions import Fraction as F
def roots():return[(p,s,q,r)for p in range(1,5)for s in range(1,5)for q in range(7,11)for r in range(1,5)]
def tree(code,a,b,target,lengths,direct,common):
    pos=leaves=anchor=xdepth=0;maximum=F(0)
    def visit(lengths,tails,xa,xb,depth):
        nonlocal pos,leaves,anchor,xdepth,maximum
        assert pos<len(code),'truncated four-infinite-length tree';symbol=code[pos];pos+=1;anchor=max(anchor,*lengths);xdepth=max(xdepth,depth)
        if symbol in '06':
            intervals=[item for tail in tails for item in (F(0)if tail else F(1),F(1))]
            value=(common if symbol=='0'else direct).bound(a,b,*intervals,xa,xb,*lengths)['upper'];assert value<=target,'exact double reciprocal leaf misses target';maximum=max(maximum,value);leaves+=1;return
        if symbol in '1234':
            dim=int(symbol)-1;assert tails[dim],'split isolated length';single=list(tails);single[dim]=False;nextlength=list(lengths);nextlength[dim]+=4
            visit(lengths,tuple(single),xa,xb,depth);visit(tuple(nextlength),tails,xa,xb,depth)
        elif symbol=='5':
            assert xa<xb;mid=(xa+xb)/2;visit(lengths,tails,xa,mid,depth+1);visit(lengths,tails,mid,xb,depth+1)
        else:raise AssertionError('unknown four-infinite-length tree symbol')
    visit(tuple(lengths),(True,)*4,F(0),F(1,14),0);assert pos==len(code),'four-length tree suffix';return maximum,leaves,anchor,xdepth
def frequency(part,a,b,target,direct,common):
    assert F(part['a'])==a and F(part['b'])==b and a<b
    if 'split'in part:
        assert'trees'not in part and len(part['split'])==2;mid=(a+b)/2;x=frequency(part['split'][0],a,mid,target,direct,common);y=frequency(part['split'][1],mid,b,target,direct,common)
        return x[0]+y[0],x[1]+y[1],max(x[2],y[2]),max(x[3],y[3]),x[4]+y[4]
    assert len(part['trees'])==256,'ALL256 ordered four-length residues required';maximum=F(0);leaves=anchor=xdepth=0
    for code,lengths in zip(part['trees'],roots()):
        value,count,depth,xd=tree(code,a,b,target,lengths,direct,common);maximum=max(maximum,value);leaves+=count;anchor=max(anchor,depth);xdepth=max(xdepth,xd)
    return(b-a)*maximum,leaves,anchor,xdepth,1
