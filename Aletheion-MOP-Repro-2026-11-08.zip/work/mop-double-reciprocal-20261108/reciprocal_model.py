from fractions import Fraction as F
import ad6_tools as ad
from ad6_tools import z,ca,cs,cm,cd,ct
def response(t,up,us,uq,ur,lam,p,s,q,r):
    rp,ep=ad.endpoints(t,up,p);rs,es=ad.endpoints(t,us,s);rq,eq=ad.endpoints(t,uq,q);rr,er=ad.endpoints(t,ur,r);w=z(t,2)
    def hh(a,b):return cd(ca(z(1),cm(z(0,1),ca(z(a),b))),w)
    hp,hs,hq,hr=[hh(*v)for v in [(rp,ep),(rs,es),(rq,eq),(rr,er)]];a=t+rp+rq;e=t+rs+rr;b=ca(z(0,1),hq);f=ca(z(0,1),hr);alpha=cs(z(1),cm(z(0,1),hp));beta=cs(z(1),cm(z(0,1),hs));fl=cd(ca(z(1),cm(z(0,2),hp)),w);fs=cd(ca(z(1),cm(z(0,2),hs)),w)
    c0=ca(z(t),cd(cm(z(0,2),ca(hq,hr)),w));z0=cs(cs(c0,ct(cm(b,b),1/a)),ct(cm(f,f),1/e));eta=cd(ct(w,lam),ca(z(1),cm(ct(w,lam),z0)));va=cs(z(1),ct(cm(alpha,b),1/a));vb=cs(z(1),ct(cm(beta,f),1/e))
    aa=ca(ca(fl,ct(cm(alpha,alpha),1/a)),cm(cm(va,va),eta));bb=ca(ca(fs,ct(cm(beta,beta),1/e)),cm(cm(vb,vb),eta));ab=cm(cm(va,vb),eta);return[[aa,ab],[ab,bb]]
def bound(a,b,pa,pb,sa,sb,qa,qb,ra,rb,xa,xb,p,s,q,r):
    assert 0<a<=b and all(0<=lo<=hi<=1 for lo,hi in [(pa,pb),(sa,sb),(qa,qb),(ra,rb)])and 0<=xa<=xb<=F(1,14)and p>=1 and s>=1 and q>=7 and r>=1
    pairs=[(a,b),(pa,pb),(sa,sb),(qa,qb),(ra,rb),(xa,xb)];ad.set_box(tuple((hi-lo)/2 for lo,hi in pairs));vars=[ad.variable(lo,hi,j)for j,(lo,hi)in enumerate(pairs)];cap=ad.h.up(2*ad.n.PI[1]*b)
    try:mat=response(*vars,p,s,q,r)
    except(AssertionError,ArithmeticError):return dict(upper=cap,method='double-reciprocal-response-cap')
    try:
        value=ad.phase(vars[0],mat);return dict(upper=min(cap,max(F(0),value.v[1])),method='double-reciprocal-direct-six',grad=tuple(max(abs(v)for v in row)for row in value.d))
    except(AssertionError,ArithmeticError):
        result=ad.raw_bound((a,b),mat);result['grad_proxy']=tuple(sum(max(abs(v)for v in part.d[k])for row in mat for entry in row for part in entry)for k in range(6));return result
