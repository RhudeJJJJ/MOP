from pathlib import Path
from fractions import Fraction as F
import json,hashlib,time,sys
import rational_grid
rational_grid.install()
import reciprocal_model as direct,reciprocal_common as common,double_tail as tail,net_interval as net
from reciprocal_cover import frequency
P=Path(__file__).resolve().parent
NAMES={'produce_reciprocal.py','read_reciprocal.py','reciprocal_cover.py','reciprocal_scout.py','reciprocal_model.py','reciprocal_common.py','ad6_tools.py','poly10.py','check_polynomials.py','polynomial-check.json','check_ad6.py','ad6-check.json','check_physical.py','physical-check.json','double_geometry.py','double_physical.py','double_tail.py','double-analytic-proof.md','double-analytic-check.json','check_double_analytic.py','check_signed_tail.py','signed-tail-check.json','check_coverage.py','coverage-check.json','frequency-grid.json','budget.json','exact.py','complex_exact.py','disk_interval.py','net_interval.py','rational_grid.py','curve_interval.py','float_discovery.py'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def waitfile(path,live):
    deadline=time.monotonic()+1800
    while not path.exists():assert live and time.monotonic()<deadline,'bounded double reciprocal wait expired';time.sleep(.25)
    return json.loads(path.read_bytes())
def main():
    start=time.monotonic();prefix='--prefix'in sys.argv;live='--live'in sys.argv;reader_hash=sha(Path(__file__));folder=P/'checkpoints';hashes=waitfile(folder/'producer-inputs.json',live);assert set(hashes)==NAMES and all(sha(P/n)==h for n,h in hashes.items())
    expected={'polynomial-check.json':'PASS_RAW_TEN_SYMBOL_DOUBLE_RECIPROCAL_COMMON_RESPONSE_AND_PHASE_IDENTITIES','ad6-check.json':'PASS_GENERIC_AD6_ALL_SIX_PARTIALS_AND_64_EXACT_NONLINEAR_BOX_CORNERS','physical-check.json':'PASS_DOUBLE_RECIPROCAL_BOTH_FULL_HEADS_TRUE_FOUR_PATH_CHAINS_AND_REGULAR_ZERO','signed-tail-check.json':'PASS_DOUBLE_RECIPROCAL_ACTUAL_FINITE_TOTAL_SIGNED_TAIL_CONSTANTS','coverage-check.json':'PASS_DOUBLE_RECIPROCAL_FOUR_INFINITE_LENGTHS_CONTINUOUS_TOTAL_AND_DAMAGED_GRAMMARS'}
    assert all(json.loads((P/n).read_bytes())['status']==status for n,status in expected.items())
    grid=json.loads((P/'frequency-grid.json').read_bytes());cert=None if live or prefix else json.loads((P/'certificate.json').read_bytes());total=F(0);end=F(1,2);seen=[];areas=[];leaves=anchor=xdepth=fcells=0
    for index,row in enumerate(grid[:1]if prefix else grid):
        data=waitfile(folder/f'{index:04}.json',live)if live or prefix else cert['cells'][index];a,b=F(row['a']),F(row['b']);assert a==end and data['index']==index;end=b;target=F(data['target']);assert target==F(5,2)/(1+((a+b)/2)**2)
        area,count,depth,xd,nf=frequency(data['partition'],a,b,target,direct,common);total+=area;leaves+=count;anchor=max(anchor,depth);xdepth=max(xdepth,xd);fcells+=nf;seen.append(data);areas.append(dict(index=index,area=str(area),leaves=count,anchor=depth,lambda_depth=xd,frequency_cells=nf));print(json.dumps(dict(status='EXACT_DOUBLE_RECIPROCAL_PROGRESS',index=index,total=len(grid),leaves=leaves,seconds=time.monotonic()-start)),flush=True)
    assert all(sha(P/n)==h for n,h in hashes.items())and sha(Path(__file__))==reader_hash
    out=dict(status='PASS_EXACT_DOUBLE_RECIPROCAL_INITIAL_FREQUENCY_PREFIX_ONLY'if prefix else'PASS_EXACT_DOUBLE_CHILD_INTERNAL_TOTAL14_TO41_FOUR_INFINITE_CURVES_RECIPROCAL_FULL_PAYMENT',compact_integral_upper=str(total),length_lambda_leaves=leaves,max_explicit_anchor=anchor,max_lambda_subdivision_depth=xdepth,frequency_cells=fcells,reader_sha256=reader_hash,source_sha256=hashes,seconds=time.monotonic()-start,actual_energy_domain='p,s,q,r>=1,14<=q+r<=41; coherent whole reflection chooses q>=7',compact_phase_enlargement='Four independent infinite curves and lambda0..1/14; energy/norm stay on actual finite total14..41',original_global='OPEN')
    if not prefix:
        assert end==16
        if live:cert=waitfile(P/'certificate.json',True)
        assert cert['format']=='double-reciprocal-four-infinite-curves-continuous-total-v1'and cert['source_sha256']==hashes and cert['cells']==seen and cert['lambda_interval']==['0','1/14']and cert['actual_energy_domain']==out['actual_energy_domain']
        It=sum((tail.tail(F(k,1024),F(k+1,1024),1,40)[1]/1024 for k in range(64)),F(0));gain=F(269,100)-F(1,2)-2*(total+It)/net.PI[0];assert gain>F(1,20);out.update(tail_integral_upper=str(It),surplus_lower=str(gain),surplus_float=float(gain),proved_surplus='1/20',certificate_sha256=sha(P/'certificate.json'))
    stem='prefix'if prefix else'reader';(P/(stem+'-cells.json')).write_text(json.dumps(areas,separators=(',',':'))+'\n');(P/(stem+'-result.json')).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k!='source_sha256'}),flush=True)
if __name__=='__main__':main()
