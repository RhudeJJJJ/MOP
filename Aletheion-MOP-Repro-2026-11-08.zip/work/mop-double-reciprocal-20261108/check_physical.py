from pathlib import Path
from fractions import Fraction as F
import time,json
import rational_grid
rational_grid.install()
import reciprocal_model as direct,reciprocal_common as common,ad6_tools as ad,double_physical as phys,double_geometry as g,exact as e,complex_exact as z
P=Path(__file__).resolve().parent
def inside(x,I):assert I[0]<=x<=I[1]
def path_data(t,n):
    old,D=F(0),F(1);older,der=F(0),F(0)
    for _ in range(n):old,D,older,der=D,t*D+old,der,D+t*der+older
    return D,der
def main():
    start=time.monotonic();states=tangents=0
    for p,q,r,s in [(1,7,7,1),(2,7,7,3),(3,13,1,2),(1,20,21,1),(1,40,1,1)]:
        B,T=g.cap(p,q,r,s);N=len(B);lengths=[p,s,q,r];anchors=[1+(p-1)%4,1+(s-1)%4,7+(q-7)%4,1+(r-1)%4]
        for t in [F(1,2),F(1),F(4)]:
            amplitudes=[];ders=[]
            for length,anchor in zip(lengths,anchors):
                D,Dp=path_data(t,length);A,Ap=path_data(t,anchor);amplitudes.append(A/D);ders.append((Ap*D-A*Dp)/(D*D))
            ad.set_box((F(0),)*6);variables=[ad.variable(t,t,0)]+[ad.variable(u,u,j+1)for j,u in enumerate(amplitudes)]+[ad.variable(F(1,q+r),F(1,q+r),5)];reps=[module.response(*variables,*anchors)for module in [direct,common]];actual=phys.response(p,q,r,s,t)
            R=phys.inverse([[z.z(t*int(i==j),B[i][j])for j in range(N)]for i in range(N)]);dd=z.scale(z.mm(z.mm(z.real(T),z.mm(R,R)),z.real(e.tr(T))),z.z(-1))
            for index,length in [(0,p),(1,s)]:dd[index][index]=z.add(dd[index][index],z.div(z.z(length-1),z.mul(z.z(t,2),z.z(t,2))))
            for got in reps:
                for i in range(2):
                    for j in range(2):
                        for k in range(2):
                            inside(actual[i][j][k],got[i][j][k].v);tangent=got[i][j][k].d[0]
                            for dim,derivative in enumerate(ders,1):tangent=ad.h.add(tangent,ad.h.times(got[i][j][k].d[dim],derivative))
                            inside(dd[i][j][k],tangent);tangents+=1
            states+=1
    zero=0
    for t in [F(1,2),F(1),F(4),F(16)]:
        ad.set_box((F(0),)*6)
        for module in [direct,common]:
            got=module.response(ad.asA(t),ad.asA(1),ad.asA(1),ad.asA(1),ad.asA(1),ad.asA(0),1,1,7,1)
            assert got[0][1][0].v==(F(0),F(0))and got[0][1][1].v==(F(0),F(0));zero+=1
    out=dict(status='PASS_DOUBLE_RECIPROCAL_BOTH_FULL_HEADS_TRUE_FOUR_PATH_CHAINS_AND_REGULAR_ZERO',representations=['direct','common'],full_actual_private_states=states,full_true_tangent_components=tangents,actual_four_path_embeddings='u=Danchor/Dactual and all FOUR exact u derivatives retained; lambda fixed1/(q+r)',lambda_zero_regular_controls=zero,all_length_basis='Exact scalar Schur complement plus raw ten-symbol common identities; old literal double geometry and signed-tail controls retained',seconds=time.monotonic()-start,full_compact_payment='OPEN',original_global='OPEN');(P/'physical-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
