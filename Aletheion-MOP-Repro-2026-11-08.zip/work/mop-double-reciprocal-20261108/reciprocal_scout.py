"""FLOAT hints only, FOUR infinite path curves plus reciprocal actual total."""
import float_discovery
float_discovery.install()
import reciprocal_model as direct,reciprocal_common as common
from reciprocal_cover import roots
def solve(a,b,target,limit=64000):
    calls=0
    def visit(lengths,tails,xa,xb,depth):
        nonlocal calls
        calls+=1;assert calls<=limit and max(lengths)<=140,'bounded double reciprocal heuristic exhausted';best=None;proxy=None
        intervals=[v for tail in tails for v in(0. if tail else 1.,1.)]
        for module,symbol in [(common,'0'),(direct,'6')]:
            got=module.bound(a,b,*intervals,xa,xb,*lengths);got['symbol']=symbol
            if 'grad_proxy'in got:proxy=got['grad_proxy']
            if best is None or got['upper']<best['upper']:best=got
            if best['upper']<=target:break
        if best['upper']<=target:return best['symbol']
        gradient=best.get('grad',proxy)
        scores=[float(gradient[j+1])if tails[j]else-1. for j in range(4)]if gradient else[1/(lengths[j]+1)if tails[j]else-1. for j in range(4)]
        if depth>=12:scores.append(-1.)
        elif gradient:scores.append(float(gradient[5])*(xb-xa))
        else:scores.append(14*(xb-xa))
        dim=max(range(5),key=lambda j:scores[j]);assert scores[dim]>=0,'bounded double inverse-total split exhausted; refine frequency'
        if dim<4:
            single=list(tails);single[dim]=False;nextlength=list(lengths);nextlength[dim]+=4
            return str(dim+1)+visit(lengths,tuple(single),xa,xb,depth)+visit(tuple(nextlength),tails,xa,xb,depth)
        mid=(xa+xb)/2;return'5'+visit(lengths,tails,xa,mid,depth+1)+visit(lengths,tails,mid,xb,depth+1)
    return[visit(lengths,(True,)*4,0.,1/14,0)for lengths in roots()]
