from pathlib import Path
from fractions import Fraction as F
import json,hashlib,time,sys
import reciprocal_scout as scout
P=Path(__file__).resolve().parent
NAMES={'produce_reciprocal.py','read_reciprocal.py','reciprocal_cover.py','reciprocal_scout.py','reciprocal_model.py','reciprocal_common.py','ad6_tools.py','poly10.py','check_polynomials.py','polynomial-check.json','check_ad6.py','ad6-check.json','check_physical.py','physical-check.json','double_geometry.py','double_physical.py','double_tail.py','double-analytic-proof.md','double-analytic-check.json','check_double_analytic.py','check_signed_tail.py','signed-tail-check.json','check_coverage.py','coverage-check.json','frequency-grid.json','budget.json','exact.py','complex_exact.py','disk_interval.py','net_interval.py','rational_grid.py','curve_interval.py','float_discovery.py'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def atomic(path,value):
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(value,separators=(',',':'))+'\n');temp.replace(path)
def main():
    start=time.monotonic();prefix='--prefix'in sys.argv;assert json.loads((P/'physical-check.json').read_bytes())['representations']==['direct','common']
    folder=P/'checkpoints';folder.mkdir(exist_ok=True);hashes={n:sha(P/n)for n in sorted(NAMES)};path=folder/'producer-inputs.json'
    if path.exists():assert json.loads(path.read_bytes())==hashes,'frozen double reciprocal inputs changed'
    else:atomic(path,hashes)
    grid=json.loads((P/'frequency-grid.json').read_bytes())
    def frequency(a,b,target,depth=0):
        try:return dict(a=str(a),b=str(b),trees=scout.solve(float(a),float(b),float(target)-1e-7))
        except(AssertionError,ArithmeticError)as ex:
            assert depth<8,'bounded four-length frequency refinement exhausted '+str(ex);mid=(a+b)/2
            return dict(a=str(a),b=str(b),split=[frequency(a,mid,target,depth+1),frequency(mid,b,target,depth+1)])
    for index,row in enumerate(grid[:1]if prefix else grid):
        path=folder/f'{index:04}.json'
        if path.exists():continue
        a,b=F(row['a']),F(row['b']);target=F(5,2)/(1+((a+b)/2)**2);print(json.dumps(dict(status='HEURISTIC_DOUBLE_RECIPROCAL_CELL_STARTED',index=index,total=len(grid))),flush=True);atomic(path,dict(index=index,target=str(target),partition=frequency(a,b,target)))
        print(json.dumps(dict(status='HEURISTIC_DOUBLE_RECIPROCAL_CHECKPOINT',index=index,total=len(grid),seconds=time.monotonic()-start)),flush=True)
    assert all(sha(P/n)==h for n,h in hashes.items())
    if prefix:print(json.dumps(dict(status='HEURISTIC_DOUBLE_RECIPROCAL_PREFIX_REQUIRES_EXACT_READER',seconds=time.monotonic()-start)),flush=True);return
    cert=dict(format='double-reciprocal-four-infinite-curves-continuous-total-v1',source_sha256=hashes,lambda_interval=['0','1/14'],actual_energy_domain='p,s,q,r>=1,14<=q+r<=41; coherent whole reflection chooses q>=7',cells=[json.loads((folder/f'{j:04}.json').read_bytes())for j in range(len(grid))],original_global='OPEN');atomic(P/'certificate.json',cert);print(json.dumps(dict(status='HEURISTIC_DOUBLE_RECIPROCAL_CERTIFICATE_REQUIRES_EXACT_READER',seconds=time.monotonic()-start)),flush=True)
if __name__=='__main__':main()
