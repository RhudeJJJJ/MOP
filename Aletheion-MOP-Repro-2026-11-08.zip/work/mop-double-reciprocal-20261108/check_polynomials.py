from pathlib import Path
import json
import reciprocal_common as m
from poly10 import V,z,ca,cs,cm,ct
P=Path(__file__).resolve().parent
def equal(a,b):return all(not v.c for v in cs(a,b))
def main():
    a,e,fl,fs,alpha,beta,b,f,c0,nu=V;original={key:getattr(m,key)for key in ['z','ca','cs','cm','ct']}
    try:
        for key,value in dict(z=z,ca=ca,cs=cs,cm=cm,ct=ct).items():setattr(m,key,value)
        D,aa,ab,bb,dp=m.core(a,e,z(fl),z(fs),z(alpha),z(beta),z(b),z(f),z(c0),z(nu))
    finally:
        for key,value in original.items():setattr(m,key,value)
    X=a*fl+alpha*alpha;Z=e*fs+beta*beta;Y=a-alpha*b;W=e-beta*f
    assert equal(ct(aa,a),ca(cm(z(X),D),z(nu*e*Y*Y)))
    assert equal(ct(bb,e),ca(cm(z(Z),D),z(nu*a*W*W)))
    assert equal(cs(cm(aa,bb),cm(ab,ab)),cm(D,dp))
    t,A,B,C,D,E,F=V[:7];detR=A*C-B*B;detI=D*F-E*E;cross=A*F+C*D-2*B*E;detSnum=4*detR+t*t*detI+2*t*cross
    assert not(2*detSnum-(4-t*t)*(detR-detI)-4*t*cross-(t*t+4)*(detR+detI)).c
    out=dict(status='PASS_RAW_TEN_SYMBOL_DOUBLE_RECIPROCAL_COMMON_RESPONSE_AND_PHASE_IDENTITIES',raw_identities=4,coefficient_domain='Q[ten independent symbols], extends to arbitrary complex substitution; NO endpoint reductions',determinant='detF=P/D; Naa*Nbb-Nab^2=D*P',phase='Generic ANY-complex-symmetric2x2 common-phase identity after clearing2t²',original_global='OPEN');(P/'polynomial-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
