from fractions import Fraction as F
import ad6_tools as ad
from ad6_tools import z,ca,cs,cm,cd,ct,sq,rt,atan,arg,acos
def core(a,e,fl,fs,alpha,beta,b,f,c0,nu):
    X=ca(ct(fl,a),cm(alpha,alpha));Z=ca(ct(fs,e),cm(beta,beta));Y=cs(z(a),cm(alpha,b));W=cs(z(e),cm(beta,f));D=ca(z(a*e),cm(nu,cs(cs(ct(c0,a*e),ct(cm(b,b),e)),ct(cm(f,f),a))))
    aa=ca(ct(X,e),cm(nu,ca(cs(cs(ct(cm(X,c0),e),ct(cm(fl,cm(b,b)),e)),cm(X,cm(f,f))),cs(z(a*e),ct(cm(alpha,b),2*e)))))
    bb=ca(ct(Z,a),cm(nu,ca(cs(cs(ct(cm(Z,c0),a),ct(cm(fs,cm(f,f)),a)),cm(Z,cm(b,b))),cs(z(a*e),ct(cm(beta,f),2*a)))))
    ab=cm(cm(nu,Y),W)
    dp=ca(cm(X,Z),cm(nu,cs(ca(cs(cs(cm(cm(X,Z),c0),cm(cm(Z,fl),cm(b,b))),cm(cm(X,fs),cm(f,f))),ca(ct(X,e),ct(Z,a))),ca(ct(cm(cm(X,beta),f),2),ct(cm(cm(Z,alpha),b),2)))))
    return D,aa,ab,bb,dp
def numerators(t,up,us,uq,ur,lam,p,s,q,r):
    rp,ep=ad.endpoints(t,up,p);rs,es=ad.endpoints(t,us,s);rq,eq=ad.endpoints(t,uq,q);rr,er=ad.endpoints(t,ur,r);w=z(t,2)
    def hh(a,b):return cd(ca(z(1),cm(z(0,1),ca(z(a),b))),w)
    hp,hs,hq,hr=[hh(*v)for v in [(rp,ep),(rs,es),(rq,eq),(rr,er)]];a=t+rp+rq;e=t+rs+rr;b=ca(z(0,1),hq);f=ca(z(0,1),hr);alpha=cs(z(1),cm(z(0,1),hp));beta=cs(z(1),cm(z(0,1),hs));fl=cd(ca(z(1),cm(z(0,2),hp)),w);fs=cd(ca(z(1),cm(z(0,2),hs)),w);c0=ca(z(t),cd(cm(z(0,2),ca(hq,hr)),w))
    return core(a,e,fl,fs,alpha,beta,b,f,c0,ct(w,lam))
def response(t,up,us,uq,ur,lam,p,s,q,r):
    D,aa,ab,bb,_=numerators(t,up,us,uq,ur,lam,p,s,q,r);aa,ab,bb=[cd(v,D)for v in [aa,ab,bb]];return[[aa,ab],[ab,bb]]
def expression(t,up,us,uq,ur,lam,p,s,q,r):
    D,aa,ab,bb,dp=numerators(t,up,us,uq,ur,lam,p,s,q,r);trace=ct(cs(ca(aa,bb),ab),F(2,3));c=z(1/t,-F(1,2));A0=ca(ca(D,cm(c,trace)),ct(cm(cm(c,c),dp),F(1,3)));ar,ai=cm(A0,(D[0],-D[1]));az=sq(A0[0])+sq(A0[1]);dz=sq(D[0])+sq(D[1]);rho=(sq(t)+4)/(4*sq(t));cross=(aa[0]*bb[0]+aa[1]*bb[1]-sq(ab[0])-sq(ab[1]))*F(2,3);G=2*ar-dz+rho*cross
    co=(rt(G)-rho*rt(sq(dp[0])+sq(dp[1]))/3)/rt(az);si=rt(1-sq(co));bottom=ar*co-ai*si
    if ar.v[0]>0 and bottom.v[0]>0:return t*atan((ai*co+ar*si)/bottom)
    return t*(arg(ar,ai)+acos(co))
def bound(a,b,pa,pb,sa,sb,qa,qb,ra,rb,xa,xb,p,s,q,r):
    assert 0<a<=b and all(0<=lo<=hi<=1 for lo,hi in [(pa,pb),(sa,sb),(qa,qb),(ra,rb)])and 0<=xa<=xb<=F(1,14)and p>=1 and s>=1 and q>=7 and r>=1
    pairs=[(a,b),(pa,pb),(sa,sb),(qa,qb),(ra,rb),(xa,xb)];ad.set_box(tuple((hi-lo)/2 for lo,hi in pairs));vars=[ad.variable(lo,hi,j)for j,(lo,hi)in enumerate(pairs)];cap=ad.h.up(2*ad.n.PI[1]*b)
    try:
        value=expression(*vars,p,s,q,r);return dict(upper=min(cap,max(F(0),value.v[1])),method='double-reciprocal-common-six',grad=tuple(max(abs(v)for v in row)for row in value.d))
    except(AssertionError,ArithmeticError):return dict(upper=cap,method='double-reciprocal-common-cap')
