from pathlib import Path
from fractions import Fraction as F
from itertools import product
import json
import rational_grid
rational_grid.install()
import ad6_tools as ad
P=Path(__file__).resolve().parent
def analytic(values):
    prod=F(1)
    for x in values:prod*=1+x
    total=1+sum(values);value=prod+1/total+sum((j+1)*x*x for j,x in enumerate(values));gradient=[prod/(1+x)-1/(total*total)+2*(j+1)*x for j,x in enumerate(values)]
    return value,gradient
def main():
    points=[F(j+1,10)for j in range(6)];rad=F(1,1000);ad.set_box((rad,)*6);xs=[ad.variable(x-rad,x+rad,j)for j,x in enumerate(points)];out=ad.asA(1)
    for x in xs:out=out*(1+x)
    out=out+1/(1+sum(xs))+sum((j+1)*ad.sq(x)for j,x in enumerate(xs));assert len(out.d)==6
    count=0
    for signs in product([-1,1],repeat=6):
        values=[x+s*rad for x,s in zip(points,signs)];value,gradient=analytic(values);assert out.v[0]<=value<=out.v[1]
        for j,v in enumerate(gradient):assert out.d[j][0]<=v<=out.d[j][1];count+=1
    artifact=dict(status='PASS_GENERIC_AD6_ALL_SIX_PARTIALS_AND_64_EXACT_NONLINEAR_BOX_CORNERS',dimensions=6,corner_values=64,partial_components=count,scope='Checks generic dimension extension incl sixth component; full new complex model and actual path chains checked separately',original_global='OPEN');(P/'ad6-check.json').write_text(json.dumps(artifact,indent=2)+'\n');print(json.dumps(artifact))
if __name__=='__main__':main()
