from fractions import Fraction as F
class P:
    def __init__(self,value=0):self.c={k:F(v)for k,v in value.items()if v}if isinstance(value,dict)else{(0,)*10:F(value)}if value else{}
    def __add__(self,other):
        other=to(other);out=dict(self.c)
        for k,v in other.c.items():out[k]=out.get(k,F(0))+v
        return P(out)
    __radd__=__add__
    def __neg__(self):return P({k:-v for k,v in self.c.items()})
    def __sub__(self,other):return self+-to(other)
    def __rsub__(self,other):return to(other)+-self
    def __mul__(self,other):
        other=to(other);out={}
        for k,v in self.c.items():
            for l,w in other.c.items():
                key=tuple(a+b for a,b in zip(k,l));out[key]=out.get(key,F(0))+v*w
        return P(out)
    __rmul__=__mul__
    def __truediv__(self,n):return self*F(1,n)
def to(value):return value if isinstance(value,P)else P(value)
V=[P({tuple(int(i==j)for i in range(10)):1})for j in range(10)]
def z(a=0,b=0):return to(a),to(b)
def ca(a,b):return a[0]+b[0],a[1]+b[1]
def cs(a,b):return a[0]-b[0],a[1]-b[1]
def cm(a,b):return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def ct(a,k):return a[0]*k,a[1]*k
