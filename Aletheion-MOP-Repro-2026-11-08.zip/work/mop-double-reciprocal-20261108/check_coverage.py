from pathlib import Path
from fractions import Fraction as F
import json
import rational_grid
rational_grid.install()
import reciprocal_model as direct,reciprocal_common as common
from reciprocal_cover import roots,tree,frequency
P=Path(__file__).resolve().parent
def reject(fn):
    try:fn()
    except(AssertionError,ArithmeticError):return 1
    raise AssertionError('damaged four-length reciprocal grammar accepted')
def main():
    a,b=F(1),F(1001,1000);target=F(1);oldD,oldC=direct.bound,common.bound;part=dict(a=str(a),b=str(b),trees=['0']*256)
    try:
        direct.bound=common.bound=lambda *args:dict(upper=F(1,10))
        assert frequency(part,a,b,target,direct,common)==((b-a)/10,256,10,0,1)
        def parse(code):return tree(code,a,b,target,(1,1,7,1),direct,common)
        for code in ['100','200','300','400','500']:assert parse(code)[1]==2
        tests=[lambda:parse(''),lambda:parse('00'),lambda:parse('7'),lambda:parse('1'),lambda:parse('5'),lambda:parse('11000'),lambda:parse('22000'),lambda:parse('33000'),lambda:parse('44000'),lambda:frequency(dict(part,trees=['0']*255),a,b,target,direct,common),lambda:frequency(dict(part,a='0'),a,b,target,direct,common),lambda:frequency(dict(a=str(a),b=str(b),split=[part]),a,b,target,direct,common),lambda:frequency(dict(a=str(a),b=str(b),split=[part,part]),a,b,target,direct,common),lambda:tree('0',a,b,F(0),(1,1,7,1),direct,common)]
        damage=sum(reject(fn)for fn in tests)
    finally:direct.bound=oldD;common.bound=oldC
    damage+=reject(lambda:tree('0',a,b,F(0),(1,1,7,1),direct,common))
    assert len(set(roots()))==256 and len({tuple(j%4 for j in x)for x in roots()})==256
    # Explicit finite calibration of the ALL-length coherent reflection
    # argument: if q+r>=14 and q<7, the swapped inner r is>=8.
    reflected=0
    for q in range(1,42):
        for r in range(1,42):
            if 14<=q+r<=41:
                qq,rr=(q,r)if q>=7 else(r,q);assert qq>=7 and qq+rr==q+r;reflected+=int(q<7)
    out=dict(status='PASS_DOUBLE_RECIPROCAL_FOUR_INFINITE_LENGTHS_CONTINUOUS_TOTAL_AND_DAMAGED_GRAMMARS',ordered_length_roots=256,q_root_anchors=[7,8,9,10],lambda_interval=['0','1/14'],damaged_cases_rejected=damage,coherent_reflection_calibration_cases=reflected,scope='Cover/grammar only. Actual14<=q+r<=41 chooses q>=7 by WHOLE reflection (p,s,q,r)->(s,p,r,q). Independent continuous boxes are phase-only enlargement, not graph identification or energy/norm extension.',original_global='OPEN');(P/'coverage-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
