from pathlib import Path
from fractions import Fraction as F
import json,time
import double_geometry as g,double_physical as phys,exact as e
P=Path(__file__).resolve().parent
def main():
    start=time.monotonic();count=0
    for p,q,r,s in [(1,7,7,1),(2,13,1,3),(1,20,21,1)]:
        B,T=g.cap(p,q,r,s);N=len(B);m=q+r;V=e.mm(B,e.tr(T));V=[[a-2*b for a,b in zip(row,rr)]for row,rr in zip(V,e.tr(T))]
        assert e.mm(T,V)==[[-2,0],[0,-2]]and e.mm(e.tr(V),V)==[[m+6,m+3],[m+3,m+6]]
        t=F(16);x=1/(t*t);BB=e.mm(B,B);R=e.inverse([[int(i==j)+x*BB[i][j]for j in range(N)]for i in range(N)]);C=e.mm(e.mm(e.tr(V),R),V);D=e.mm(e.mm(e.mm(e.tr(V),B),R),V);actual=phys.response(p,q,r,s,t);a=1+4*x;Q=[[3,1],[1,3]]
        assert 0<=C[0][0]<=47 and 0<=C[1][1]<=47 and abs(C[0][1])<=47 and all(abs(v)<=423 for row in D for v in row)
        for i in range(2):
            for j in range(2):
                qr=Q[i][j]/a+8*x*int(i==j)/a**2-x*((1-4*x)*C[i][j]-4*x*D[i][j])/a**2;mr=2*Q[i][j]/a-2*(1-4*x)*int(i==j)/a**2-x*((1-4*x)*D[i][j]+4*C[i][j])/a**2
                assert qr==t*actual[i][j][0]and mr==-t*t*actual[i][j][1]
        count+=1
    out=dict(status='PASS_DOUBLE_RECIPROCAL_ACTUAL_FINITE_TOTAL_SIGNED_TAIL_CONSTANTS',full_private_tail_states=count,actual_total=[14,41],norm_upper='9 from star degree m+2 and pathforest: sqrt43+2<9',C_diagonal_upper=47,D_absolute_upper=423,actual_TV=[[-2,0],[0,-2]],normalized_Q=[[3,1],[1,3]],compact_lambda_zero='NOT assigned a finite-order graph or this norm/private reserve',seconds=time.monotonic()-start,original_global='OPEN');(P/'signed-tail-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
