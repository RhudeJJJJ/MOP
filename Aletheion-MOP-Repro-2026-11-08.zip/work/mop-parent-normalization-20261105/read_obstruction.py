from pathlib import Path
from fractions import Fraction as F
import json,sys,hashlib
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'mop-dual-debt-20261105'))
from read_ledger import peel

Z=(F(0),F(0));ONE=(F(1),F(0))
def add(x,y):return x[0]+y[0],x[1]+y[1]
def neg(x):return -x[0],-x[1]
def mul(x,y):return x[0]*y[0]-x[1]*y[1],x[0]*y[1]+x[1]*y[0]
def div(x,y):return mul(x,(y[0]/(y[0]**2+y[1]**2),-y[1]/(y[0]**2+y[1]**2)))
def inv(A):
 n=len(A);M=[r[:]+[ONE if i==j else Z for j in range(n)]for i,r in enumerate(A)]
 for j in range(n):
  k=next(i for i in range(j,n)if M[i][j]!=Z);M[j],M[k]=M[k],M[j]
  z=M[j][j];M[j]=[div(x,z)for x in M[j]]
  for i in range(n):
   if i==j:continue
   q=M[i][j];M[i]=[add(x,neg(mul(q,y)))for x,y in zip(M[i],M[j])]
 return[r[n:]for r in M]
def mm(A,B):return[[sum(A[i][k]*B[k][j]for k in range(len(B)))for j in range(len(B[0]))]for i in range(len(A))]
def ct(A):return[[(x[0],-x[1])for x in row]for row in zip(*A)]
def cm(A,B):
 return[[tuple(sum(mul(A[i][k],B[k][j])[p]for k in range(len(B)))for p in range(2))for j in range(len(B[0]))]for i in range(len(A))]
def det2(A):return add(mul(A[0][0],A[1][1]),neg(mul(A[0][1],A[1][0])))
def key(a,b):return tuple(sorted((a,b)))

def family(m):
 assert m>=2
 a=0;b=2*m+1;x=list(range(1,m+1));y=list(range(m+1,2*m+1));cycle=[a]
 for u,v in zip(x,y):cycle.extend((u,v))
 cycle.append(b);E={key(a,v)for v in x+[b]}
 for j in range(m):
  u=x[j];v=x[j+1]if j+1<m else b;w=y[j]
  E|={key(u,v),key(u,w),key(v,w)}
 assert len(E)==4*m+1
 _,_,nb=peel(cycle,E)
 assert len(nb[a])==m+1 and len(nb[b])==3
 # Sparse Gram product, including the exceptional left endpoint.
 qrows=[{w for w in y if w in nb[u]}for u in x]
 for i in range(m):
  for j in range(m):assert len(qrows[i]&qrows[j])==(2-int(i==0)if i==j else int(abs(i-j)==1))
 rootrows=[nb[a]-{b},nb[b]-{a}];G=[[len(r&s)for s in rootrows]for r in rootrows]
 assert G==[[m,1],[1,2]]
 for i in range(2):
  for j in range(2):
   moment=sum(len(nb[u]&rootrows[j])for u in rootrows[i])
   assert 2*G[i][j]-moment==2*int(i==j)
 assert max(len(nb[v]-{a})for v in cycle if v!=a)==4
 return cycle,E,nb

def exact_response(E,roots,t):
 V=set(v for e in E for v in e);vs=sorted(V-set(roots));B=[[int(key(a,b)in E)if a!=b else 0 for b in vs]for a in vs]
 T=[[int(key(a,b)in E)for b in vs]for a in roots]
 R=inv([[(t if i==j else F(0),F(B[i][j]))for j in range(len(vs))]for i in range(len(vs))])
 response=[[tuple(sum(T[i][a]*R[a][b][p]*T[j][b]for a in range(len(vs))for b in range(len(vs)))for p in range(2))for j in range(2)]for i in range(2)]
 G=mm(T,[list(row)for row in zip(*T)])
 return response,G

def direct(m,t):
 cycle,E,nb=family(m);F0,G=exact_response(E,(0,2*m+1),t)
 C=[]
 for i in range(m):
  row=[]
  for j in range(m):
   row.append((t+F(2,t)-F(int(i==j==0),t)if i==j else F(int(abs(i-j)==1),t),F(int(abs(i-j)==1))))
  C.append(row)
 R=inv(C);aa=tuple(sum(R[i][j][p]for i in range(m)for j in range(m))for p in range(2))
 assert aa==F0[0][0]
 for i in range(m):
  target=(t+F(4,t),F(2));r=(F(0),F(0))
  if i==0:r=add(r,(F(2,t),F(1)))
  if i==m-1:r=add(r,(F(1,t),F(1)))
  assert tuple(sum(C[i][j][p]for j in range(m))for p in range(2))==add(target,neg(r))
 if t==1:
  err=add(aa,neg(div((F(m),F(0)),(F(5),F(2)))))
  assert err[0]**2+err[1]**2<=F(7*m,29)
 return True

def polyadd(a,b,sign=1):
 out=[0]*max(len(a),len(b))
 for i,x in enumerate(a):out[i]+=x
 for i,x in enumerate(b):out[i]+=sign*x
 while len(out)>1 and not out[-1]:out.pop()
 return out
def polymul(a,b):
 out=[0]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):out[i+j]+=x*y
 return out
def char(B):
 n=len(B);M=[[int(i==j)for j in range(n)]for i in range(n)];ts=[0]
 for j in range(1,n+1):M=mm(M,B);ts.append(sum(M[i][i]for i in range(n)))
 c=[1]
 for k in range(1,n+1):
  z=-sum(c[k-j]*ts[j]for j in range(1,k+1));assert z%k==0;c.append(z//k)
 return c[::-1]

def spectral_blocks(s):
 x=list(range(s));ears=list(range(s,2*s-1));left=2*s-1;right=2*s;n=2*s+1
 E={key(i,i+1)for i in range(s-1)}|{key(0,left),key(s-1,right)}
 for i,e in enumerate(ears):E|={key(i,e),key(i+1,e)}
 Q=[[int(key(i,j)in E)for j in ears+[left,right]]for i in x]
 assert mm(Q,[list(r)for r in zip(*Q)])==[[2*int(i==j)+int(abs(i-j)==1)for j in x]for i in x]
 if s<=8:
  B=[[int(i!=j and key(i,j)in E)for j in range(n)]for i in range(n)]
  old,cur=[1],[-2,0,1]
  for j in range(2,s+1):old,cur=cur,polyadd(polymul([-2,0,1],cur),polymul([1,2,1],old),-1)
  assert char(B)==[0]+cur
 # Deleting both pendants is exactly H_(s-1) minus its hub, for s>=3.
 if s>=3:
  cycle,HE,nb=family(s-1);H=sorted(set(cycle)-{0});pos={v:i for i,v in enumerate(H)}
  # Relabel by roles, not the interleaved outer cycle.
  m=s-1;b=2*m+1;ordinary=list(range(1,m+1))+[b];yy=list(range(m+1,2*m+1));mapping={v:i for i,v in enumerate(ordinary+yy)}
  HE={key(mapping[a],mapping[b])for a,b in HE if a!=0 and b!=0}
  assert HE=={e for e in E if left not in e and right not in e}
 return True

def tiny_counter():
 raw=json.loads((P/'scout-result.json').read_text())['best'];E={tuple(e)for e in raw['edges']};peel(list(range(6)),E)
 roots=tuple(raw['roots']);t=F(4);R,G=exact_response(E,roots,t);assert G==[[2,1],[1,2]]
 S=[[div(add(mul((t,F(2)),R[i][j]),(-F(G[i][j]),F(0))),(F(0),F(2)))for j in range(2)]for i in range(2)]
 gram=cm(ct(S),S);D=[[add((F(int(i==j)),F(0)),neg(mul((t*t,F(0)),gram[i][j])))for j in range(2)]for i in range(2)]
 det=det2(D);assert det[1]==0 and det[0]<0
 sectors={}
 for sign in(-1,1):
  W=[[2*R[i][j][0]+sign*t*R[i][j][1]for j in range(2)]for i in range(2)]
  dw=W[0][0]*W[1][1]-W[0][1]**2;assert W[0][0]>0 and dw>0;sectors[str(sign)]=str(dw)
 return dict(order=6,roots=roots,t='4',det_I_minus_t2_SstarS=str(det[0]),strict_sector_determinants=sectors)

def contract(m,near):
 assert m>=2
 if near:assert m<38
def rejects(fn):
 try:fn()
 except AssertionError:return True
 return False

def main():
 geometries=0
 for m in list(range(2,41))+[100,400]:family(m);geometries+=1
 direct_count=sum(direct(m,t)for m in range(2,9)for t in(F(1,4),F(1),F(4)))
 blocks=sum(spectral_blocks(s)for s in range(2,26));tiny=tiny_counter()
 assert F(35,116)<1 and F(2800,29)<100
 negative=-F(1600,145)+10+F(2,5);assert negative==-F(92,145)<0
 assert F(21,2)<F(169,16)and F(9,4)**2>5
 assert F(8*35-273,13)>0 and F(8*38-273,13)>F(19,10)
 damage=dict(near_threshold_claim_for_large_family=rejects(lambda:contract(400,True)),empty_family=rejects(lambda:contract(1,False)))
 out=dict(status='PASS_EXACT_ACTUAL_OLD_NORMALIZATION_OBSTRUCTION_AND_WHOLE_FAMILY_PAYMENT',literal_geometry_states=geometries,
      direct_rational_controls=direct_count,spectral_block_controls=blocks,full_integer_characteristics=7,tiny_counter=tiny,
      concrete_nonaccretive=dict(m=400,old_order=802,real_aa_upper=str(negative)),
      unbounded='ForALLm>=2,||S0(1)||>=10m/29-sqrt(35m/116); hence no absolute old-parent normalized norm bound.',
      whole_payment='ForALLm>=35,H_m orderh=2m+2: F(H_m)-2h>(8m-273)/13>0; forALLm>=38reserve>19/10.',
      damaged_scope_rejected=damage,original_status='GLOBAL_OPEN',near_threshold_normalization_status='OPEN_NOT_REFUTED_BY_THIS_FAMILY',
      scope='All-order inequalities are written Schur/resolvent/error/spectral-pair proofs. Exact finite controls calibrate them. Tiny6witness is independently rationalized numerical discovery. Shared ear topology utility; no external formal/human review.',
      proof_sha256=hashlib.sha256((P/'parent-normalization-proof.md').read_bytes()).hexdigest())
 (P/'obstruction-reader-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
