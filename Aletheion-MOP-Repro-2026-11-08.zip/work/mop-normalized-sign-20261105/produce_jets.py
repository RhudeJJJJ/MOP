from pathlib import Path
from functools import lru_cache
import json
from poly_scout import model,add,mul
P=Path(__file__).resolve().parent
def ma(A,B,c=1):return[[add(A[i][j],B[i][j],c)for j in range(2)]for i in range(2)]
def scale(A,p):return[[mul(v,p)for v in row]for row in A]
@lru_cache(None)
def R(p,q):return model(p,q)[1]
def op(fn,axis,typ,p,q):
 A=fn(p,q);u,v=(4,0)if axis=='p'else(0,4)
 if typ=='I':return A
 if typ=='D':return ma(fn(p+u,q+v),A,-1)
 if typ=='K':return ma(ma(fn(p+2*u,q+2*v),scale(fn(p+u,q+v),[2,4,1]),-1),scale(A,[1,4,1]))
 raise ValueError(typ)
def check(M):
 count=0
 for j in range(max(len(v)for row in M for v in row)):
  get=lambda a,b:M[a][b][j]if j<len(M[a][b])else 0
  a,b,c=get(0,0),get(0,1),get(1,1)
  assert min(a,c)>=0 and a*c>=b*b;count+=1
 return count
def main():
 rows=[];count=0
 for p in range(1,5):
  for q in range(1,5):
   for a in('I','D','K'):
    fun=lambda u,v:op(R,'p',a,u,v)
    for b in('I','D','K'):
     M=op(fun,'q',b,p,q);count+=check(M);rows.append(dict(p=p,q=q,p_operator=a,q_operator=b,matrix=M))
 out=dict(status='PRODUCED_ALL144_PSD_COEFFICIENT_JETS',cases=len(rows),coefficient_matrices=count,cases_data=rows,
  scope='Finite coefficient certificate; use ONLY with the written all-index four-step recurrences and two-stage positivity induction. Finite matrices alone do not imply all p/q.')
 (P/'normalized-sign-jets.json').write_text(json.dumps(out,separators=(',',':'))+'\n');print(json.dumps({k:out[k]for k in('status','cases','coefficient_matrices')}))
if __name__=='__main__':main()
