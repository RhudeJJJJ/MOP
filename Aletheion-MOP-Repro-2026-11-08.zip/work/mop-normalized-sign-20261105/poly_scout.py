from pathlib import Path
from math import comb
import json,sympy as s
P=Path(__file__).resolve().parent
def add(a,b,c=1):
 z=[0]*max(len(a),len(b))
 for i,x in enumerate(a):z[i]+=x
 for i,x in enumerate(b):z[i]+=c*x
 while len(z)>1 and not z[-1]:z.pop()
 return z
def mul(a,b):
 z=[0]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):z[i+j]+=x*y
 return z
def D(k):
 z=[0]*(k+1)
 for j in range(k//2+1):z[k-2*j]=comb(k-j,j)
 return z
def model(p,q):
 k=p+q+1;den=D(k);DD=[D(j)for j in range(k+1)];M=[[[]for j in range(2)]for i in range(2)]
 sets=(set(range(p+1)),set(range(p,k)))
 for a in range(2):
  for b in range(2):
   num=[0]
   for i in sets[a]:
    for j in sets[b]:
     if (i-j)%2==0:continue
     lo,hi=sorted((i,j));sign=(-1)**((hi-lo-1)//2);num=add(num,mul(DD[lo],DD[k-hi-1]),sign)
   M[a][b]=num
 R=[[add(mul([4,0,1],M[a][b]),den,-2*((p-1 if a==0 else q-1)if a==b else 0))for b in range(2)]for a in range(2)]
 def xpoly(poly):
  if k%2:assert not poly[0];poly=poly[1:]
  assert all(poly[j]==0 for j in range(1,len(poly),2));return poly[::2]
 R=[[xpoly(v)for v in row]for row in R];det=add(mul(R[0][0],R[1][1]),mul(R[0][1],R[1][0]),-1)
 return xpoly(den),R,det

if __name__=='__main__':
 worst=[];negative=[];x=s.Symbol('x');examples=[]
 for p in range(1,17):
  for q in range(1,17):
   den,R,det=model(p,q)
   if any(c<0 for poly in(R[0][0],R[1][1],det)for c in poly):negative.append([p,q])
   if p<=3 and q<=5:
    form=lambda v:s.factor(sum(c*x**j for j,c in enumerate(v)))
    examples.append(dict(p=p,q=q,aa=str(form(R[0][0])),bb=str(form(R[1][1])),ab=str(form(R[0][1])),det=str(form(det))))
 out=dict(status='EXACT_FINITE_POLYNOMIAL_DISCOVERY_NOT_ALL_ORDER_PROOF',negative=negative,examples=examples)
 (P/'poly-scout.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
