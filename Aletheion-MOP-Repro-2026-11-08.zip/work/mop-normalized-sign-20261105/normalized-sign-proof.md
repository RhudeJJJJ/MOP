# A normalized path sign at every length, and a branch debt below1.42

5 November2026. Original EVERY finite simple UNIT maximal outerplanar
G,n>=8,F=splus>=2n remains GLOBAL OPEN; goal ACTIVE. This closes an
all-length sign property of the NEW normalized twofan response and
improves its universal phase/debt bounds. It does NOT prove the full
nonnegative external-branch increment UB, Fork6 or global compensation.

1. Exact object, retaining signed state and zero modes. For the literal
external/external cap p,q>=1 put k=p+q+1. In long-arc private order
0,...,k-1, B is the unit path and contact rows are prefixes0..p and
suffixes p..k-1. For t>0 let

 Fcap=T(tI+iB)^-1Tt,
 E=diag(p-1,q-1)>=0, Z=t+2i,
 Fstar=Fcap-E/Z.

The prior fixed isometric Neumann-path state proves Fstar strictly
accretive, both2ReFstar+/-tImFstar>0, and the same-parent nonnegative
shaving phase domination. Fstar is a SIGNED algebraic response, not a
physical graph/energy or a response at arbitrary complex frequency.

THEOREM A, new all-length sign:

                       Im Fstar(t)<=0                 (1)

for EVERY p,q>=1 and EVERY t>0. Semidefinite is intended: the Fork6
p=q1 case has a zero imaginary direction, whose real zero-mode pole
is not discarded. This theorem is not claimed for the OLD normalized
parent response, already refuted in larger domains.

2. Exact continuant polynomial and the matrix to prove positive.
Set D0=1,D1=t,D_n=t D_(n-1)+D_(n-2). Thus
D_n=sum_j binom(n-j,j)t^(n-2j)>0. For path inverse coordinates i<=j,

 [(tI+iB)^-1]_ij=(-i)^(j-i)D_i D_(k-j-1)/D_k.

Only odd j-i contribute to the imaginary part. Let Aaa,Aab,Abb be the
numerators of -ImFcap after multiplication by D_k. They are EXACT sums
over their actual contact sets: each ordered pair of opposite parity
contributes(-1)^((|i-j|-1)/2)D_min(i,j)D_(k-max(i,j)-1). The diagonal
entry counts both orientations; the cross entry respects prefix/suffix
root roles and their single common vertex.

Define H(t)=(t^2+4)A(t)-2E D_k(t). If k is odd both H and D_k have a
factor t. Divide that common factor t^nu,nu=k mod2, and write x=t^2,
R_(p,q)(x)=H(t)/t^nu,d_k(x)=D_k(t)/t^nu. All are integer polynomials,
and the exact identity is

          -ImFstar=R_(p,q)(x)/[(x+4)d_k(x)].           (2)

No private coordinate or zero eigenvalue has been deleted; only a
common polynomial factor has canceled at t>0. We prove that EVERY
coefficient matrix of R is PSD, which implies(1)through(2).

3. Prove the all-index recurrences, not just a finite pattern.
Let h(z)=1-tz-z^2. The aa numerator before normalization is

 Aaa(p,q)=2[z^(p-1)] (D_q+D_(q-1)z)/[(1+z^2)h(z)^2].

Indeed write an odd-distance contact pair as i,j=i+2r+1, and m=p-j.
Then i+2r+m=p-1 and its suffix continuant is D_(q+m). Sum i,r,m;
the three generating functions are1/h,1/(1+z^2), and
(D_q+D_(q-1)z)/h. Both ordered orientations give the factor2.

Put A=D_q,B0=D_(q-1). Since sum_(p>=0)D_(p+q+1)z^p
=(tA+B0+Az)/h, the p-linear subtraction in Haa CANCELS the double
path poles exactly. Direct formal differentiation and multiplication give

 sum_(p>=0)Haa(p,q)z^p
 =2[A(t+4z+2tz^2+2z^3)+B0(1-tz+3z^2)]/[(1+z^2)h]. (3)

The formal p0 extension uses Aaa0=0 and Eaa=-1; only p>=1 is used for
the actual theorem. Hbb(p,q)=Haa(q,p). At fixed q, Hbb is a linear
combination of D_p,D_(p-1), because its finite sums only shift the
second continuant parameter. Its generating denominator is h.

For the cross entry define U_p=sum_(r=0..p)(-i)^r D_(p-r), whose
generating function is1/[(1+iz)h]. The contact sums give
Aab=-Im(U_p U_q). Its p and q generating poles are the path poles
and +/-i after real/imaginary parts are taken. Multiplication by t^2+4
does not change those poles.

Let lambda+/- solve lambda^2=t lambda+1. Their fourth powers have
product1 and sum a(x)=x^2+4x+2; the fourth powers of +/-i equal1.
All generating functions above are proper with distinct poles for t>0.
Thus on EACH residue class p=r+4m the matrix H obeys characteristic
(mu-1)(mu^2-a mu+1). Divide the common t^nu, constant along these
subsequences. This proves the POLYNOMIAL identities

 L_p R=R(p+8,q)-aR(p+4,q)+R(p,q),
 L_p R(p+4,q)=L_p R(p,q),                             (4)

and the symmetric q identities, for ALL p,q>=1. Equality at every
t>0 makes them polynomial identities in x. This derivation supplies
the unbounded quantifier; finite recurrence checks alone do not.

4. A cone recurrence lemma and the finite144 jet certificate.
Use the cone of symmetric polynomial matrices whose EVERY coefficient
is PSD. It is closed under addition and multiplication by any scalar
polynomial with nonnegative coefficients. Put b=a-2=x^2+4x.
For a sequence Z_m satisfying Z_(m+2)-aZ_(m+1)+Z_m=L independent of m,
write Delta0=Z1-Z0 and K0=bZ0+L. If Z0,Delta0,K0 are in the cone,
then all Z_m and all successive differences are in the cone. Indeed

 Delta_(m+1)=Delta_m+K0+b(Z_(m+1)-Z0).

This proves the claim by induction; L ITSELF need not be PSD and in
our problem generally is not. Omitting K0 would be an invalid induction.

Define I_pR=R, Delta_pR=R(p+4,q)-R(p,q), and
K_pR=R(p+8,q)-aR(p+4,q)+(a-1)R(p,q); similarly in q.
The exact certificate checks EVERY matrix

       O_q O_p R(r,s), r,s in{1,2,3,4},
                    O_p,O_q in{I,Delta,K}.            (5)

There are16*3*3=144 finite matrices, retaining every coefficient. On
EACH coefficient [[u,v],[v,w]], the integer inequalities u,w>=0 and
uw-v^2>=0 prove PSD. First apply the cone lemma in q to the three
p-initial objects R(r,q),Delta_pR(r,q),K_pR(r,q); their q-recurrences
follow by commuting the constant-coefficient operators in(4). They
are cone-positive for ALL q. Then apply the lemma in p to obtain
R(p,q)in the cone for ALL p,q. This proves TheoremA via(2).

The producer uses interval/cofactor continuants. The separate stdlib
reader reconstructs every needed R by the full actual path adjacency
adjugate recurrence, checks the formal two-variable identity behind(3),
every one of(5), and direct rational physical inverses. No numerical
eigenvalue, length cutoff, or unperformed recurrence transfer accepts(1).

5. Sharper low phase from imaginary order and the root sectors.
Keep ONE actual old boundary response F0 at every frequency. Set
Z0=tI+iJ+F0,Z1=Z0+Fstar. The previous both-sector theorem gives
2ReZj+/-tImZj>0 for j0,1. Write Rj=ReZj>0,Hj=ImZj and
Bj=Rj^-1/2 Hj Rj^-1/2. Their real eigenvalues lie in(-2/t,2/t), and
the accretive continuous trace phase is sum arctan(eigenvaluesBj).
By(1),H1<=H0. If m is the negative inertia of H0 and r the positive
inertia of H1, then m+r<=2: their negative/positive subspaces cannot
intersect, since H1<=H0. With theta=atan(2/t),

 phase(Z0)>=-m theta, phase(Z1)<=r theta,
               delta_star(t)<2atan(2/t).              (6)

The first bound is strict when m>0, and the second when r>0. If both
inertias are zero, the phase difference is<=0, so(6)still holds strictly.
The congruence determinant has positive real factor detRj, and the
sum-of-arctangents is the SAME accretive trace-log lift anchored at
infinity; no principal determinant rewrapping occurs.

6. Entire integrals and exact improved constants. The old nonnegative
shaving still gives delta_full<=delta_star and its positive length
reserve; the full tail support t delta_star<=10/(9t^2) is unchanged.
For epsilon=4/5, integration of(6)on the ENTIRE0..epsilon interval gives

 Jstar<pi*epsilon^2/2+2epsilon-(epsilon^2+4)atan(epsilon/2)
                                         +10/(9epsilon).

Use the10-term alternating LOWER sum for atan(2/5), and the retained
exact Machin bounds157/50<pi<22/7. The SAME actual graph energy identity
therefore proves, for every old UNIT MOP order>=3, ordered boundary,
and EVERYp,q>=1,k=p+q+1,

 DeltaF>2k-c, c=4122211549032501145082/2904608402252197265625
                                                <71/50=1.42. (7)

No signed normalized object is assigned a graph energy. The old parent,
private path energy k-1 and contact mass k+1 remain the physical ones.
Any actual whole old reserve>=1.42 pays the WHOLE new graph.

The complete rational Jstar upper is
2061951520365859947541/925034523010253906250.
The earlier length-reserve proof applies at sqrt(alpha)>=39:
alpha=max(p-1,q-1)>=max(D0,1521),D0=max OLD root degrees, implies
reserve>=3861/1681. With2/pi>7/11 the increment surplus is greater than
105417787607579760214829/2443544766426086425781250>1/50.
Thus the universal long-arm threshold improves from2401 to1521.

7. Exact effect on the unchanged original goal. The complete actual
dual grammar can use the new c in(7): with the SAME named inherited
B71 finite input, F(G)>=2n-c*b(T), where b counts unrooted degree-three
dual faces, not candidate multiplicities. This remains a branch-corrected
bound rather than the original2n theorem.
With the SAME declared B71/gamma<=4 boundary and the already verified
old-parent cover8..13, every deepest branch of a minimal original
counter n>=72 now has h>=14,0<=eta<c<1.42,
max(p,q)<=max(D0,1521). Preserve own-root retirement, joint payment,
and root-pair-plus-two domination exclusions. No such parents are shown
to exist or to be impossible in all orders.

N1/N207 remain true norm counterexamples on their original declared
near domains; the new counter front is a DIFFERENT domain. No false
M1/M2 assertion is reopened, and the old normalized accretivity question
is not solved. Generic gluing, barefan/C0, pointwise-phase and nonouter
Fork counters remain valid. UniversalFork6/fullUB/global nonnegative
compensation remain OPEN. The new coefficient theorem concerns THIS
literal new path state, not generic old-MOP coefficient positivityC196,
unequal monomers, empty arms, or arbitrary spectral-state surrogates.
Shared software primitives are declared; no external formal/human audit,
exhaustive priority, corpus/Drive refresh or automatic entry repair.
The next global work must use actual large-parent pockets in the new
near-reserve region; the sign/debt improvement alone is not completion.
