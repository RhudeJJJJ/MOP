from pathlib import Path
from functools import lru_cache
from fractions import Fraction as F
from itertools import product
import json,sys,copy,hashlib
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'mop-parent-normalization-20261105'))
from read_obstruction import inv,add,neg,mul,div,key
sys.path.insert(0,str(P.parent/'mop-dual-debt-20261105'))
from read_ledger import peel

def trim(p):
 p=list(p)
 while len(p)>1 and p[-1]==0:p.pop()
 return p
def pa(a,b,c=1):
 z=[0]*max(len(a),len(b))
 for i,x in enumerate(a):z[i]+=x
 for i,x in enumerate(b):z[i]+=c*x
 return trim(z)
def pm(a,b):
 z=[0]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):z[i+j]+=x*y
 return trim(z)
def ma(A,B,c=1):return[[pa(A[i][j],B[i][j],c)for j in range(2)]for i in range(2)]
def sm(A,p):return[[pm(v,p)for v in row]for row in A]
def value(p,x):
 z=F(0)
 for y in reversed(p):z=z*x+y
 return z
def continuants(n):
 d=[[1],[0,1]]
 for j in range(2,n+1):d.append(pa([0]+d[-1],d[-2]))
 return d

@lru_cache(None)
def actual_R(p,q):
 assert p>=1 and q>=1
 k=p+q+1;d=continuants(k)[k];contact=(list(range(p+1)),list(range(p,k)))
 # Full adjugate recurrence of the ACTUAL integer path, independent of
 # the producer's interval/cofactor summation.
 U=[[int(i==j)for j in range(k)]for i in range(k)];N=[[[0]*k for j in range(2)]for i in range(2)]
 for l in range(1,k):
  c=d[k-l];alpha=((-1)**(l//2)*c)if l%2==0 else 0
  V=[[alpha*int(i==j)-(U[i-1][j]if i else 0)-(U[i+1][j]if i+1<k else 0)for j in range(k)]for i in range(k)];U=V
  if l%2:
   factor=(-1)**((l+1)//2);power=k-1-l
   for i in range(2):
    for j in range(2):N[i][j][power]=factor*sum(U[a][b]for a in contact[i]for b in contact[j])
 H=[[pa(pm([4,0,1],N[i][j]),d,-2*((p-1 if i==0 else q-1)if i==j else 0))for j in range(2)]for i in range(2)]
 def normalize(poly):
  if k%2:assert poly[0]==0;poly=poly[1:]
  assert all(poly[i]==0 for i in range(1,len(poly),2))
  return trim(poly[::2])
 return normalize(d),[[normalize(v)for v in row]for row in H]
def R(p,q):return actual_R(p,q)[1]
def operator(fn,axis,typ,p,q):
 base=fn(p,q);u,v=(4,0)if axis=='p'else(0,4)
 if typ=='I':return base
 if typ=='D':return ma(fn(p+u,q+v),base,-1)
 if typ=='K':return ma(ma(fn(p+2*u,q+2*v),sm(fn(p+u,q+v),[2,4,1]),-1),sm(base,[1,4,1]))
 raise AssertionError('unknown operator')
def coefficient_PSD(A):
 count=0
 for power in range(max(len(v)for row in A for v in row)):
  get=lambda i,j:A[i][j][power]if power<len(A[i][j])else 0
  a,b,c=get(0,0),get(0,1),get(1,1)
  assert get(1,0)==b and a>=0 and c>=0 and a*c>=b*b;count+=1
 return count

# Exact formal polynomial algebra in independent variables(t,z).
def ba(A,B,c=1):
 C=A.copy()
 for ij,x in B.items():C[ij]=C.get(ij,0)+c*x
 return{k:v for k,v in C.items()if v}
def bm(A,B):
 C={}
 for(a,b),x in A.items():
  for(c,d),y in B.items():C[a+c,b+d]=C.get((a+c,b+d),0)+x*y
 return{k:v for k,v in C.items()if v}
def bs(A,c):return{k:v*c for k,v in A.items()if v*c}
def dz(A):return{(a,b-1):v*b for(a,b),v in A.items()if b}
def formal_identity():
 one={(0,0):1};z={(0,1):1};t={(1,0):1};h={(0,0):1,(1,1):-1,(0,2):-1};z2=bm(z,z)
 for A,B in((1,0),(0,1)):
  N={(1,0):A,(0,0):B,(0,1):A};N={k:v for k,v in N.items()if v}
  first=bs(bm(bm({(2,0):1,(0,0):4},z),{(0,0):A,(0,1):B}),2)
  diff=ba(bm(z,ba(bm(dz(N),h),bm(N,dz(h)),-1)),bm(N,h),-1)
  raw=ba(first,bs(bm(ba(one,z2),diff),2),-1)
  target={(1,0):A,(0,1):4*A,(1,2):2*A,(0,3):2*A,(0,0):B,(1,1):-B,(0,2):3*B}
  target={k:v for k,v in target.items()if v}
  assert raw==bs(bm(target,h),2)
 # lambda fourth-power sum: (t^2+2)^2-2=t^4+4t^2+2.
 assert pa(pm([2,0,1],[2,0,1]),[2],-1)==[2,0,4,0,1]
 return True

def verify_jets(rows):
 expected=set(product(range(1,5),range(1,5),'IDK','IDK'));seen=set();count=0
 for row in rows:
  p,q,a,b=row['p'],row['q'],row['p_operator'],row['q_operator'];tag=(p,q,a,b);assert tag in expected and tag not in seen;seen.add(tag)
  fn=lambda u,v:operator(R,'p',a,u,v)
  actual=operator(fn,'q',b,p,q);assert actual==row['matrix'];count+=coefficient_PSD(actual)
 assert seen==expected
 return count

def direct(p,q,t):
 d,RR=actual_R(p,q);k=p+q+1;B=[[int(abs(i-j)==1)for j in range(k)]for i in range(k)]
 T=[[int(j<=p)for j in range(k)],[int(j>=p)for j in range(k)]]
 E={key(i,i+1)for i in range(k-1)}|{key(k,j)for j in range(p+1)}|{key(k+1,j)for j in range(p,k)}|{key(k,k+1)}
 peel([k]+list(range(k))+[k+1],E)
 Q=inv([[(t*int(i==j),F(B[i][j]))for j in range(k)]for i in range(k)])
 Fcap=[[tuple(sum(T[i][a]*Q[a][b][part]*T[j][b]for a in range(k)for b in range(k))for part in range(2))for j in range(2)]for i in range(2)]
 star=[[add(Fcap[i][j],neg(div((F((p-1 if i==0 else q-1)*int(i==j)),F(0)),(t,F(2)))))for j in range(2)]for i in range(2)]
 x=t*t;M=[[value(RR[i][j],x)/((x+4)*value(d,x))for j in range(2)]for i in range(2)]
 assert M==[[-v[1]for v in row]for row in star]
 assert M[0][0]>=0 and M[1][1]>=0 and M[0][0]*M[1][1]>=M[0][1]**2
 return True

def atan_bounds(x,N):
 assert 0<x<1 and N%2==0
 L=sum((-1)**j*x**(2*j+1)/F(2*j+1)for j in range(N));return L,L+x**(2*N+1)/F(2*N+1)
def constants():
 l,u=atan_bounds(F(1,5),10);a,b=atan_bounds(F(1,239),10);assert F(157,50)<16*l-4*b<16*u-4*a<F(22,7)
 e=F(4,5);A,_=atan_bounds(e/2,10);br=2*e-(e*e+4)*A+F(10,9)/e
 assert 2*e-(e*e+4)*e/2+F(10,9)/e>0
 c=e*e+F(100,157)*br;assert c==F(4122211549032501145082,2904608402252197265625)<F(71,50)
 J=F(22,7)*e*e/2+br;ell=F(39);assert 1/ell+4/ell**2<F(1,10)and ell**2/(ell**2+4)>F(99,100)
 reserve=99*ell/1681;bonus=F(7,11)*(reserve-J);assert bonus>F(1,50)
 return dict(epsilon=str(e),atan_lower=str(A),debt_upper=str(c),Jstar_upper=str(J),long_arm_alpha=1521,reserve=str(reserve),long_arm_surplus_lower=str(bonus))
def rejects(fn):
 try:fn()
 except(AssertionError,KeyError):return True
 return False

def main():
 data=json.loads((P/'normalized-sign-jets.json').read_text());assert formal_identity();count=verify_jets(data['cases_data']);assert count==924==data['coefficient_matrices']
 controls=sum(direct(p,q,t)for p in range(1,6)for q in range(1,6)for t in(F(1,4),F(1),F(4)))
 recurrence=0
 for p in range(1,9):
  for q in range(1,9):
   L=lambda u,v:ma(ma(R(u+8,v),sm(R(u+4,v),[2,4,1]),-1),R(u,v))
   assert L(p+4,q)==L(p,q);recurrence+=1
 con=constants()
 altered=copy.deepcopy(data['cases_data']);altered[0]['matrix'][0][0][0]-=1
 damage=dict(missing_K_jet=rejects(lambda:verify_jets([r for r in data['cases_data']if not(r['p']==1 and r['q']==1 and r['p_operator']=='K'and r['q_operator']=='K')])),
 changed_coefficient=rejects(lambda:verify_jets(altered)),empty_arm=rejects(lambda:actual_R(0,2)))
 assert all(damage.values())
 # A nonnegative start and first difference alone do not license the lemma.
 scalar=[0,1]
 for j in range(3):scalar.append(2*scalar[-1]-scalar[-2]-1)
 assert scalar==[0,1,1,0,-2]and -1<0 # K0=-1 fails, as required.
 out=dict(status='PASS_ALL_LENGTH_NORMALIZED_IMAGINARY_SIGN_AND_DEBT71OVER50',finite_jets=144,PSD_coefficient_matrices=count,
  direct_rational_path_controls=controls,recurrence_controls=recurrence,formal_GF_identity=True,constants=con,damaged_rejected=damage,
  original_status='GLOBAL_OPEN',full_original_goal_complete=False,
  theorem='ForALLp,q>=1,t>0,ImFstar<=0. All-indexpropergeneratingpolesgivefour-stepconstant-remaindermatrixrecurrences; complete144jets+two-stageconepositivityinductionprovesALLlengths.',
  phase='Withbothold/newrootsectors,H1<=H0impliesnminus(H0)+nplus(H1)<=2; sameaccretivetracephaseliftgivesdelta_star<2atan(2/t). m=r0impliesdelta<=0,notnecessarilyzero.',
  effect='UnconditionalexternalbranchDeltaF>2k-c, c<71/50; alpha>=max(D0,1521)gives>2k+1/50. ExistingB71/gamma4/parentcoverkeepsh>=14witheta<c<1.42; globalFork6/fullUB/compensationOPEN.',
  scope='Finitecertificateonlywithwrittenall-indexrecurrenceproofandconeinduction; no length extrapolation or genericold-MOPcoefficient claim. Independentactualpathadjugatevsproducercofactorroute; sharedcomplex/topologyhelpers, noexternalformalreview.',
  source_hashes={n:hashlib.sha256((P/n).read_bytes()).hexdigest()for n in('normalized-sign-proof.md','normalized-sign-jets.json')})
 (P/'sign-reader-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
