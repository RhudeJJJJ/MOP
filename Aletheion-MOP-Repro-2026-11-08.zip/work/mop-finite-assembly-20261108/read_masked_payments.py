"""Portable complete SOURCE/SCALAR check; deliberately NOT a new Catalan DP run."""
from pathlib import Path
from fractions import Fraction as Q
import json,hashlib
P=Path(__file__).resolve().parent;M=P.parent/'mop-masked-input-dp-20261108'
def rd(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
r=rd(M/'full-masked-result.json');assert r['status']=='PASS_FRESH_ALL130_CAPPED_AND_RESTRICTED_MASK0_MAXIMA_AND_ACTUAL_PAYMENTS'
assert all(sha(M/n)==h for n,h in r['source_sha256'].items())
targets=rd(M/'targets.json')['rows'];wanted={(t['n'],t['d'],t['C'],t['k'],t['l']):t for t in targets};assert len(wanted)==130
seen=set();empty=0;gains=[]
for group in r['results']:
    p=M/group['result_file'];assert sha(p)==group['result_sha256'];saved=rd(p);assert saved['source_sha256']==r['source_sha256']and saved['checks']==group['checks']
    for c in group['checks']:
        t=c['target'];n,d,C,k,l=(t[x]for x in ['n','d','C','k','l']);key=n,d,C,k,l;assert key not in seen and t==wanted[key];seen.add(key);assert n==d+k+1 and 2<=C<=d
        maximum=c['actual_mask0_maximum']
        if maximum is None:assert t['M2_R']is None and c['payment']=='VACUOUS_NO_ADMITTED_MASK0_GRAPH';empty+=1;continue
        assert maximum<=t['M2_R']
        if t['comparison']=='EXACT_SAME_MASK0_DOMAIN':assert maximum==t['M2_R']
        else:assert(n,d,C,k,l)==(60,31,31,28,2)
        x=Q(t['shift']);m=d-1+2*k;mu2,mu3,mu4=2*m,6*k,2*maximum-2*m+8*(k-l);den=mu4+4*x*mu3+6*x*x*mu2+(d+k)*x**4;assert den>0
        rho=(mu3+2*x*mu2)**2/den-(d+k-1);h=Q(d-1,d);required=k+5+Q(2*(k+3*l),d)-Q(6,d*d)-rho;gain=Q(1)if required<=0 else 4*h*h*(d+h*h)-required**2
        assert gain==Q(c['positive_payment_indicator'])>0 and required==Q(c['required']);gains.append(gain)
assert seen==wanted.keys()and len(r['results'])==29
print(json.dumps(dict(status='PASS_ALL130_COMPLETE_SOURCE_BOUND_EXACT_SCALAR_PAYMENTS',targets=len(seen),vacuous=empty,nonvacuous=len(gains),minimum_payment_indicator=str(min(gains)),source_hashes_unchanged=True,scope='Fresh original Catalan maxima are source-bound stored input; this portable check does not claim to rerun their optimization.')))
