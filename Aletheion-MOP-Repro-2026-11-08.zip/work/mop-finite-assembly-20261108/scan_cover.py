"""Fresh complete parameter scan; unresolved/conditional rows remain explicit."""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
from functools import lru_cache
import sys,json,hashlib,time
P=Path(__file__).resolve().parent;W=P.parent
sys.path.insert(0,str(W/'mop-early-cover-20261108'))
from read_early import threshold,hub,qbound
def read(p):return json.loads(p.read_bytes())
@lru_cache(None)
def balanced_weights(l):
    if l==1:return(F(1),)
    c=F(8,9);a=l//2
    return tuple(c*x for x in balanced_weights(a)+balanced_weights(l-a))
def balanced(k,l):
    w=balanced_weights(l)
    return F(496,567)*sum(w)+F(2,7)+F(64,81)*(k-l)*min(w)
def residual_best(d,k,l):
    M=4*d-6+qbound(k,l)+13*k;m=d-1+2*k;u2=2*m;u3=6*k;u4=2*M-2*m+8*(k-l)
    return max(((u3+2*r*u2)**2/(u4+4*r*u3+6*r*r*u2+(d+k)*r**4)-(d+k-1),r)for r in(F(j,16)for j in range(16,65)))
def main():
    start=time.monotonic();env=read(W/'mop-global-input-audit-20261108/finite-degree-envelope-check.json');caps={r['n']:r['D']for r in env['rows']}
    pos=read(W/'mop-finite-input-dp-20261108/full-positive-result.json');assert pos['status']=='PASS_FRESH_ALL328_REMAINING_POSITIVE_CATALAN_MAXIMA_AND_ACTUAL_ENERGY_PAYMENTS'
    paid={(r['n'],r['d'],r['k'],r['l']):r for g in pos['results']for r in g['checks']};assert len(paid)==328
    masked=read(W/'mop-masked-input-dp-20261108/targets.json')['rows'];maskmap={(r['n'],r['d'],r['k'],r['l']):r for r in masked}
    rules=Counter();rows=[];unresolved=[];largest=0
    for n in range(43,72):
        T,_=threshold(n)
        for d in range(caps[n]+1,n):
            k=n-d-1
            for l in([0]if k==0 else range(1,min(k,d-1)+1)):
                key=(n,d,k,l);U=min(n*n+7*n-18,(2*d+8)*n-6*d-12,d*d+9*d-10+qbound(k,l)+15*k+2*l);r=dict(n=n,d=d,k=k,l=l)
                if U<=T:r.update(rule='whole_moment',margin=str(T-U))
                elif hub(d,k,l)>=0:r.update(rule='rho0_hub',margin=str(hub(d,k,l)))
                elif key in paid:r.update(rule='fresh_positive328',margin=paid[key]['positive_squared_margin'])
                elif l==1:
                    assert d>=23 and 3<=k+2<=42
                    r.update(rule='single_gap_B42',gap_order=k+2)
                elif l and k+2<=42 and hub(d,k,l,balanced(k,l))>=0:
                    largest=max(largest,k+2);r.update(rule='balanced_block_B42',reserve=str(balanced(k,l)),margin=str(hub(d,k,l,balanced(k,l))))
                elif key in maskmap:r.update(rule='PENDING_MASKED_AND_COMPLEMENTS',cap=maskmap[key]['C'])
                else:
                    reserve,shift=residual_best(d,k,l)
                    if hub(d,k,l,max(F(0),reserve))>=0:r.update(rule='coarse_residual_moment',reserve=str(reserve),shift=str(shift),margin=str(hub(d,k,l,max(F(0),reserve))))
                    else:r.update(rule='UNRESOLVED');unresolved.append(r)
                rows.append(r);rules[r['rule']]+=1
    out=dict(status='COMPLETE_PARAMETER_SCAN_WITH_EXPLICIT_GAPS',rules=dict(rules),rows=rows,unresolved=unresolved,largest_balanced_block=largest,seconds=time.monotonic()-start,original_global='OPEN',scope='Scan only; conditional classes do not become paid merely because a matching target is listed.')
    (P/'scan-result.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in ['rows','unresolved']},indent=2));print(json.dumps(dict(unresolved_count=len(unresolved),first_unresolved=unresolved[:12])))
if __name__=='__main__':main()
