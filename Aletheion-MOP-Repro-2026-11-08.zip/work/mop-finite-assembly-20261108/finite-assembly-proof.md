# Fresh finite original target through71: exact assembly contract

8 November2026. ORIGINAL ALL UNIT MOP n>=8 GLOBAL OPEN. This proof is
conditional on the complete130-target masked reader reaching PASS;
an unfinished run or source manifest does not supply that premise.

Target here: every finite simple unweighted maximal outerplanar graph
of order8<=n<=71 has F=splus>=2n. This is the finite input B71 only.

1. Actual proved parents and literal graph parameters.

The fresh8..42 theorem supplies every graph in that range and also
F(B)>=2p-2 for every MOP block of order3<=p<=42. Its all6853 base
graph and61 small-gap Gram witnesses,4636 parameter inequalities and
legal cutvertex proof are natively stored with complete portable replay.
For n43..71 the fresh finite-degree-envelope theorem supplies the
table n43..46,D29;47..48,D28;49,D27;50,D25;51..54,D26;55..58,D27;
59..64,D28;65..71,D29. All29 histogram/knapsack maxima were checked
independently and replayed from complete native sources. These inputs
do not assume any smaller-order energy theorem beyond their stated scope.

For a graph outside this table choose an ACTUAL maximum-degree hub v,
d=deg(v)>D(n),k=n-d-1. Its ordered neighbors induce a path, with d-1
polygon gaps. Let l count the nonempty gaps; the complete necessary
domain is l0 when k0, else1<=l<=min(k,d-1). The scan regenerates this
whole domain from the integer bounds; no sampled graph index defines it.
Different gap positions and shared-root contacts are preserved by the
maximization and masks, not identified because their totals agree.

2. Written universal inequalities used by the scalar rules.

Write Q(0,0)=0 and, for k>0,
Q(k,l)=min(k^2,(k-l)^2+6(k-l)+3l-2).
The early proof derives S=sum over nonneighbors of squared neighbor
counts<=k+3l and the full moment upper
U=min(n^2+7n-18,(2d+8)n-6d-12,d^2+9d-10+Q+15k+2l).
The first bound follows by ear induction and the adjacent-degree sum;
the others by the degree-product inequality and expanding all coupled
root increments. No triangle count is silently discarded.
There are n-2 triangles and n-3 four-cycles in a MOP, so mu2=4n-6,
mu3=6n-12,mu4=2M2+4n-18. For X=t(A+rI)^2>=0, optimize t to get
F>=Tr(A(A+rI)^2)^2/Tr((A+rI)^4). Inserting U gives the exact rational
threshold T_r(n) in read_early.py. The41 shifts j/16,j24..64 suffice
wherever this rule is used; no assertion of a continuous optimum.

Let R=G-v,N=d+k,m=d-1+2k. It is connected via the outer cycle minus v.
The actual hub compression and orthogonal pinching bound from the early
proof gives, for every lower bound f<=rho(R)=F(R)-(N-1),

 F(G)-2n >=2h sqrt(d+h^2)-k-5-2S/d+6/d^2+f, h=(d-1)/d.

Thus put a=k+5+2(k+3l)/d-6/d^2-f. If a<=0 the rule pays immediately;
otherwise4h^2(d+h^2)-a^2>=0 suffices. The code's positive indicator1
in the a<=0 branch is a branch marker, not an asserted numerical margin.
The connected n-1 theorem supplies f0 when needed, at its actual graph
scope, as in the complete early proof.

There is also a direct residual moment upper independent of Catalan DP:

                  M2(R)<=4d-6+Q(k,l)+13k.

Start with the d-vertex neighbor path, M2=4d-6. A gap of mass m0 has
M2(block)<=m0^2+11m0 by the early ear bound. If its two root degrees
inside the block are r,s, the residual neighbor-path base root degrees
are<=2. Expanding their increments r-1,s-1 shows that its contribution
is<=M2(block)+2(r+s)-6<=m0^2+13m0, since r+s<=m0+3. Two consecutive
nonempty gaps add cross term at most2m_i*m_j; summing gives Q+13k.
For R, mu2=2m,mu3=6k,mu4<=2M2(R)-2m+8(k-l). The same PSD witness
at the49 shifts j/16,j16..64 yields
f=(mu3+2r*mu2)^2/(mu4+4r*mu3+6r^2*mu2+N*r^4)-(N-1).
Choose the largest of these rational values and0. This is a lower
reserve, with no disconnected-graph or outside energy premise.

3. A bounded block-chain input from B42.

All rows in which the new balanced-block rule is used have actual
gap block order<=26; all single-gap rows have block order<=42. More
generally the scan checks k+2<=42 before using either premise.
Hence every such block B has rho(B)>=m+1, for gap mass m>=1.
As in the early complete proof, the residual graph is a chain of these
blocks and bridge paths, not disjoint overlapping principal pieces.
The published8/9 cutvertex lemma applies only to connected graphs of
order>=2 with both attaching-vertex deletions connected. Terminal
polygon roots and the distinct end paths satisfy those hypotheses at
each cut. Two possible attached bridge paths reduce a leaf reserve to
f(m)=(64m+30)/81. Every bridge path has rho0. Empty paths only improve
this conservative bound. All this uses the exact early graph proof,
not a general8/9 rule without its deletion hypotheses.

Fix any ordered full binary gluing tree for l gap blocks and set c=8/9.
If its leaf depths are t_i, the resulting reserve is at least

 (64/81) sum c^t_i*m_i +(30/81)sum c^t_i
                         -(2/9)sum over internal nodes c^depth.

For any full binary tree, W=sum_leaf c^depth satisfies
W=1+(2c-1)sum_internal c^depth. Since m_i>=1,sum m_i=k,
sum c^t_i*m_i>=W+(k-l)min_i c^t_i. Therefore a uniform reserve is

        (496/567)W+2/7+(64/81)(k-l)min_i c^t_i.       (*)

Use a balanced ordered tree with leaf depths a=floor(log2 l) or a+1.
There are2^(a+1)-l shallow and2l-2^(a+1) deep leaves. Such a tree
exists by expanding the required leaves of the complete depth-a tree;
its leaves remain the actual gap order. Thus W and its minimum weight
are explicit rational numbers. The independent closed formula and the
recursive midpoint construction agree for every used l. Formula(*)
is conservative for every actual ordered composition, without needing
to enumerate exponentially many compositions or assume a best tree.
The hub test with(*) pays2201 rows in the complete scan.

For l1 use the stronger disjoint induced partition: its single block
and the remaining hub with d-2 leaves are disjoint. The latter is a
join with at most two paths. With L=d-2>=21,h=1-2/L,
4h^2(L+10)>=100 is sufficient for a surplus>2 over its own2|T|.
At L21 its strict squared gap is664/441, and the left side increases.
Since F(block)>=2p-2, PSD superadditivity pays527 selected l1 rows.
No roots shared between different blocks are treated as disjoint.

4. Exact finite dynamic inputs and their complements.

The remaining positive328 literal(n,d,k,l) classes have full fresh
integer Catalan maxima, all-mass/all-gap coverage and actual rational
PSD/hub payments, already natively accepted and completely replayed.
Their full interface proof retains root degree information and bounds
every actual G-v. The scan matches the actual quadruple to the checked
payment, not merely a source filename or an order range.

The130 other literal classes split into125 with actual nonhub degree
cap C<d and5 unrestricted C=d. The full-mask recurrence computes the
exact maximum M2(R) of graphs having NO dominating triangle through v,
at each actual cap. Full candidate masks, not a single Boolean, retain
which hub face might dominate. Candidate elimination follows the exact
root coverage of each nonempty polygon gap. Polygon interior cap is C,
neighbor residual cap C-1 because its edge to v is restored in G.
The all-size proof and full direct graph diagnostic n3..9 are separate
from the complete130-target computation. An empty final mask0 domain
is vacuous only after that exact domain computation passes.

Every graph in one of these classes either has a dominating triangle
through v, paid by the independent ALLn>=60 theorem; or has another
degree>C, paid by the complete actual cap-complement theorem; or is
in the precise mask0 capped/unrestricted domain. The latter uses its
fresh maximum and strict rational payment. All these n are>=60, so
no n8..59 premise enters the dominating-triangle proof. The high-pair
theorem checks all1150 actual degree/adjacency/common-neighbor cases
using full4760 core/splitfan witnesses and54870 ear extensions. The
five C=d classes have no high-second-degree complement.

5. Closing condition, current state, and limits.

The scan independently enumerates all11885 high-degree tuples and gives
3718 whole-moment,932rho0-hub,4049 coarse-residual-moment,527single-gap,
2201 balanced-block,328 fresh positive-Catalan and130 mask0/complement
rows. There is no additional unclassified tuple. Low-degree parents
cover all other degrees; B42 covers all earlier orders.

Once the full130-target computation and every precise rational margin
have terminal PASS, these clauses prove the finite original statement
through71. The terminal assembly reader must check the complete tuple
index, exact source versions, every scalar inequality and actual target
class. Until then B71 is CONDITIONAL_PENDING, not proved by this note.

Even a completed B71 discharges only a finite input to the separate
minimal-counter argument. Both unbounded parent-family certificates
and the named remaining global proof inputs retain their own scope.
No finite-order result, favorable prefix, byte hash or source readback
is the original all-order conclusion. No human/formal audit or
external novelty claim is made.
