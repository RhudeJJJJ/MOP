"""Independent exact reader of the full finite assembly, with explicit pending inputs."""
from pathlib import Path
from fractions import Fraction as Q
from collections import Counter
import json,hashlib,time
P=Path(__file__).resolve().parent;W=P.parent
def load(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def bound_q(k,l):return 0 if not k else min(k*k,(k-l)**2+6*(k-l)+3*l-2)
def degree_cap(n):return 29 if n<=46 else 28 if n<=48 else 27 if n==49 else 25 if n==50 else 26 if n<=54 else 27 if n<=58 else 28 if n<=64 else 29
def moment_value(n,U,r):
    u2,u3,u4=4*n-6,6*n-12,2*U+4*n-18
    den=u4+4*r*u3+6*r*r*u2+n*r**4;assert den>0
    return(u3+2*r*u2)**2/den
def residual(d,k,l,M,r):
    N=d+k;m=d-1+2*k;u2,u3,u4=2*m,6*k,2*M-2*m+8*(k-l)
    den=u4+4*r*u3+6*r*r*u2+N*r**4;assert den>0
    return(u3+2*r*u2)**2/den-(N-1)
def hub(d,k,l,f=Q(0)):
    h=Q(d-1,d);a=k+5+Q(2*(k+3*l),d)-Q(6,d*d)-f
    return Q(1)if a<=0 else 4*h*h*(d+h*h)-a*a
def closed_balanced(k,l):
    a=l.bit_length()-1;c=Q(8,9);shallow=2**(a+1)-l;deep=2*l-2**(a+1);W=shallow*c**a+deep*c**(a+1);least=c**(a+1)if deep else c**a
    return Q(496,567)*W+Q(2,7)+Q(64,81)*(k-l)*least
def check_native_sources(folder,name):
    source=folder/name;obj=load(source)
    for p,h in obj.items():assert sha(Path(p))==h,(p,'changed accepted native source')
    return {str(Path(p).relative_to(W)):h for p,h in obj.items()}
def main():
    start=time.monotonic();source_hashes={};parents={}
    for folder,audit,expected,mapping in [
        ('mop-early-cover-20261108','early-native-audit.json','PASS_NATIVE_FRESH_COMPLETE8_TO42_AND_ALL_EXACT_SOURCE_REPLAY','early-source-hashes.json'),
        ('mop-global-input-audit-20261108','finite-degree-native-audit.json','PASS_NATIVE_ALL29_FINITE_DEGREE_ENVELOPES_AND_FULL_PORTABLE_MATH_REPLAY','finite-degree-source-hashes.json'),
        ('mop-finite-input-dp-20261108','positive-native-audit.json','PASS_NATIVE_FRESH328_COMPLETE_SOURCES_AND_FULL_EXACT_PORTABLE_REPLAY','positive-source-hashes.json'),
        ('mop-high-pair-inputs-20261108','class-native-audit.json','PASS_NATIVE_COMPLETE_FINITE_COMPLEMENTS_AND_FULL_EXACT_PORTABLE_REPLAY','class-source-hashes.json')]:
        path=W/folder/audit
        if not path.exists():parents[folder]='PENDING_NATIVE_READBACK';continue
        data=load(path);assert data['status']==expected;parents[folder]=data['native_run_id'];source_hashes.update(check_native_sources(W/folder,mapping));source_hashes[str(path.relative_to(W))]=sha(path)
    env=load(W/'mop-global-input-audit-20261108/finite-degree-envelope-check.json');assert len(env['rows'])==29 and all(r['D']==degree_cap(r['n'])and Q(r['margin'])>0 for r in env['rows'])and{r['n']for r in env['rows']}==set(range(43,72))
    pos=load(W/'mop-finite-input-dp-20261108/full-positive-result.json');assert pos['status']=='PASS_FRESH_ALL328_REMAINING_POSITIVE_CATALAN_MAXIMA_AND_ACTUAL_ENERGY_PAYMENTS';positive={}
    for group in pos['results']:
        path=W/'mop-finite-input-dp-20261108'/group['result_file'];assert sha(path)==group['result_sha256'];source_hashes[str(path.relative_to(W))]=sha(path)
        for r in group['checks']:
            key=(r['n'],r['d'],r['k'],r['l']);assert key not in positive;positive[key]=r
    targets=load(W/'mop-finite-input-dp-20261108/positive-targets.json');pmap={(r['n'],r['d'],r['k'],r['l']):r for r in targets};assert len(pmap)==len(positive)==328 and pmap.keys()==positive.keys()
    maskfolder=W/'mop-masked-input-dp-20261108';masktargets=load(maskfolder/'targets.json')['rows'];maskmap={(r['n'],r['d'],r['k'],r['l']):r for r in masktargets};assert len(maskmap)==130
    complete=maskfolder/'full-masked-result.json';maskchecks={};mask_complete=complete.exists()
    if mask_complete:
        masked=load(complete);assert masked['status']=='PASS_FRESH_ALL130_CAPPED_AND_RESTRICTED_MASK0_MAXIMA_AND_ACTUAL_PAYMENTS'and masked['target_rows']==130 and masked['groups']==29
        assert all(sha(maskfolder/n)==h for n,h in masked['source_sha256'].items());source_hashes.update({str((maskfolder/n).relative_to(W)):h for n,h in masked['source_sha256'].items()})
        for group in masked['results']:
            path=maskfolder/group['result_file'];assert sha(path)==group['result_sha256'];saved=load(path);assert saved['source_sha256']==masked['source_sha256']and saved['checks']==group['checks'];source_hashes[str(path.relative_to(W))]=sha(path)
            for r in group['checks']:
                t=r['target'];key=(t['n'],t['d'],t['k'],t['l']);assert key not in maskchecks and t==maskmap[key];maskchecks[key]=r
        assert maskchecks.keys()==maskmap.keys();source_hashes[str(complete.relative_to(W))]=sha(complete)
    high=load(W/'mop-high-pair-inputs-20261108/class-result.json');kernels=load(W/'mop-high-pair-inputs-20261108/high-pair-result.json');assert high['status']=='PASS_FRESH_DOMINATING_TRIANGLE_N60_PLUS_AND_ALL_ACTUAL_CAP_COMPLEMENTS'and kernels['status']=='PASS_FRESH_ALL_HIGH_PAIR_EXACT_KERNELS_AND_54870_EARS'
    assert high['high_pair_result_sha256']==sha(W/'mop-high-pair-inputs-20261108/high-pair-result.json');complements={(r['n'],r['d'],r['cap'],r['e'],r['adjacent'],r['common'])for r in high['complement_cases']};assert len(complements)==1150
    scan=load(P/'scan-result.json');seen=set();counts=Counter();usedpos=set();usedmask=set();margin_min={};largest=0;vacuous=0
    for r in scan['rows']:
        n,d,k,l=r['n'],r['d'],r['k'],r['l'];key=(n,d,k,l);assert key not in seen;seen.add(key);rule=r['rule'];counts[rule]+=1;assert k==n-d-1 and 43<=n<=71 and degree_cap(n)<d<n
        assert(l==0 and k==0)or(1<=l<=min(k,d-1));gain=None
        if rule=='whole_moment':
            U=min(n*n+7*n-18,(2*d+8)*n-6*d-12,d*d+9*d-10+bound_q(k,l)+15*k+2*l);gain=max(moment_value(n,U,Q(j,16))-2*n for j in range(24,65));assert gain>=0
        elif rule=='rho0_hub':gain=hub(d,k,l);assert gain==Q(r['margin'])>=0
        elif rule=='coarse_residual_moment':
            M=4*d-6+bound_q(k,l)+13*k;f=residual(d,k,l,M,Q(r['shift']));assert f==Q(r['reserve']);gain=hub(d,k,l,max(Q(0),f));assert gain==Q(r['margin'])>=0
        elif rule=='balanced_block_B42':
            assert 1<=l<=k and k+2<=42;largest=max(largest,k+2);f=closed_balanced(k,l);assert f==Q(r['reserve']);gain=hub(d,k,l,f);assert gain==Q(r['margin'])>=0
        elif rule=='single_gap_B42':
            assert l==1 and d>=23 and 3<=k+2<=42 and r['gap_order']==k+2;L=d-2;h=Q(L-2,L);gain=4*h*h*(L+10)-100;assert gain>0
        elif rule=='fresh_positive328':
            t=pmap[key];p=positive[key];assert p['M2_R']==t['M2_R'];f=residual(d,k,l,p['M2_R'],Q(t['shift']));gain=hub(d,k,l,f);assert gain==Q(p['positive_squared_margin'])==Q(r['margin'])>0;usedpos.add(key)
        elif rule=='PENDING_MASKED_AND_COMPLEMENTS':
            t=maskmap[key];assert n>=60 and r['cap']==t['C'];C=t['C'];assert 2<=C<=d
            for e in range(C+1,d+1):
                for adj,hs in[(True,[1,2]),(False,[0,1,2])]:assert all((n,d,C,e,adj,h)in complements for h in hs)
            if mask_complete:
                c=maskchecks[key];M=c['actual_mask0_maximum']
                if M is None:assert t['M2_R']is None and c['payment']=='VACUOUS_NO_ADMITTED_MASK0_GRAPH';vacuous+=1
                else:
                    assert M<=t['M2_R'];f=residual(d,k,l,M,Q(t['shift']));gain=hub(d,k,l,f);assert gain==Q(c['positive_payment_indicator'])>0
            usedmask.add(key)
        else:raise AssertionError(('unpaid rule',r))
        if gain is not None:margin_min[rule]=min(margin_min.get(rule,gain),gain)
    expected={(n,d,n-d-1,l)for n in range(43,72)for d in range(degree_cap(n)+1,n)for l in([0]if n-d-1==0 else range(1,min(n-d-1,d-1)+1))}
    assert seen==expected and len(seen)==11885 and usedpos==positive.keys()and usedmask==maskmap.keys()and largest==26
    assert dict(counts)==scan['rules']and not scan['unresolved']
    names=['finite-assembly-proof.md','scan_cover.py','scan-result.json','read_finite_assembly.py']
    source_hashes.update({str((P/n).relative_to(W)):sha(P/n)for n in names})
    out=dict(status='PASS_FRESH_COMPLETE_ORIGINAL_UNIT_MOP_FINITE_COVER_8_TO71'if mask_complete else'CONDITIONAL_PENDING_COMPLETE_MASKED130_FINITE_COVER',finite_target='EVERY finite simple UNIT MOP8<=n<=71,F>=2n',high_degree_parameter_rows=len(seen),low_degree_orders=29,rule_counts=dict(counts),actual_positive328_used=len(usedpos),actual_masked130_used=len(usedmask),masked_complete=mask_complete,vacuous_masked_classes=vacuous,largest_balanced_gap_block=largest,minimum_exact_indicators_by_rule={k:str(v)for k,v in margin_min.items()},native_parents=parents,source_sha256=source_hashes,seconds=time.monotonic()-start,scope='Complete finite original2n theorem only when full130-terminal acceptance is present. Every tuple checked independently, balanced-block reserve evaluated by closed depth counts, PSD moment payments checked from direct trace ratio. Published connected n-1, cutvertex8/9 and Jao-West degree inputs retain their precise written scopes. Remaining unbounded parent families are separate.',original_global='OPEN',original_goal_complete=False)
    (P/'finite-assembly-result.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k!='source_sha256'},indent=2))
if __name__=='__main__':main()
