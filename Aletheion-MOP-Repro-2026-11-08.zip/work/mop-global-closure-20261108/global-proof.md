# Ein computergestützter Beweis der positiven Quadratenergie-Schranke für maximal außenplanare Graphen

8. November 2026. Vollständige Beweisfassung mit den unten genau benannten
analytischen Sätzen und exakten endlichen Zertifikaten. Die letzte lokale
Doppelzweig-Lücke ist durch einen vollständig beendeten exakten Lauf
geschlossen. Quellenrücklese und Wiederholung der vollständigen Schlussrechnung
aus dem Aletheion haben bestanden. Unabhängige fachliche Begutachtung oder
Formalisierung und weltweite Priorität sind damit nicht behauptet.

## Satz und unveränderte Zielaussage

Für jeden endlichen einfachen ungewichteten maximal außenplanaren Graphen
G mit n>=8 gilt

             F(G) = Summe_(lambda>0) lambda² >= 2n,

wobei lambda die Eigenwerte seiner tatsächlichen Adjazenzmatrix durchläuft,
jeweils mit algebraischer Vielfachheit. Wegen |E(G)|=2n-3 ist dies genau
gleichbedeutend mit splus(G)-sminus(G)>=6. Gleichheit ist zugelassen.
Dies ist die ausgewählte ursprüngliche Conjecture9.5(ii) von
https://arxiv.org/html/2506.07264v1, keine eingeschränkte Ersatzvermutung.

## 1. Die verwendeten vollständigen Eingaben

Für jede reelle symmetrische Matrix A gilt

 F(A)=max_(X positiv semidefinit) [2Tr(AX)-Tr(X²)].             (1)

Ein blockdiagonaler Zeuge liefert insbesondere
F(G)>=F(G[S])+F(G[T]) für eine disjunkte Zerlegung der tatsächlichen
Vertexmenge. Das ist kein Monotoniesatz für das Hinzufügen von Kanten.

**Endlicher Anfang B71.** Jeder ursprüngliche Graph der Ordnung8..71
erfüllt den Satz. Die neue vollständige endliche Beweisroute prüft alle
11885 notwendigen Hochgrad-Parametertupel,29 Gradschranken,328 positive
Catalan-Klassen und130 Maskenklassen mit ihren tatsächlichen Komplementen.
Keine Klasse bleibt unbezahlt. Die benannten publizierten Grad-,
Zusammenhangs- und8/9-Verklebungslemmata behalten ihre Voraussetzungen.
Vollständige Quelle und Annahme:
../mop-finite-assembly-20261108/finite-assembly-proof.md und
../mop-finite-assembly-20261108/finite71-acceptance.md.

**Ganzgraphen mit Dominationszahl höchstens vier.** Für gamma<=2 gibt
die neue analytische Zerlegung in zwei disjunkte tatsächliche Hub-Path-
Joins den Satz für n>=61; B71 bezahlt die kleineren Ordnungen. Siehe
../mop-gamma2-analytic-input-20261108/gamma2-analytic-proof.md.
Für gamma3 gelten der allordentliche Komponenten-/Pfadhaushalt, die
vollständige exakte Brücke72..104 mit3795253 Parameterfällen und der
analytische Schwanz ab105. Für gamma4 gelten die9 Kernformen, alle
zulässigen geteilten Nachbarprofile mit ihren tatsächlichen Eigentümern,
die vollständige Kopplungsbrücke72..159 mit286769 Fällen und der
analytische Schwanz ab160. Die Kopplung behält sowohl positive
Semidefinitheit als auch Varianzkosten. Siehe
../../component_deficit_domination_three_189_proof.txt und
../../coupled_gamma4_244_proof.txt sowie die dort vollständig benannten
Spektral- und Strukturbeweise. Der vormals bedingte Anfang8..71 wird
jetzt durch das vollständige neue B71 geliefert. Die anderen bewiesenen
Eingaben werden dadurch nicht aus Dateihashes erschlossen.

Die vollständigen ursprünglichen gamma3/4-Rechnungen und der volle
Quellenexport-Replay vom Oktober bleiben ihre tatsächlichen Belege;
sie wurden nicht als neue November-Millionenrechnung ausgegeben.
Die aktuellen Quellen- und Knotenfassungen wurden abgeglichen.
Der Zusammenhangssatz mit n-1 in den Ganzhub-Fallbacks ist der getrennte
publizierte Satz auf dem zusammenhängenden G-v, nicht unser2n-Ziel.
Diese Ganzgraphenbeweise verwenden die nachfolgende terminale Reduktion
nicht; es liegt hier kein Zirkelschluss vor.

**Die zwölf tatsächlich benötigten C0-Eingaben.** Für jeden endlichen
Hermiteschen Fernblock C und jede reelle Kontaktmatrix mit
RR^t=[[r,1],[1,1]],r=3..14, gewinnt die wörtliche asymmetrische
P2-Erweiterung mit T=[[1,1],[1,0]] mehr als4.09 an F. Das ist durch
den vollständigen Cayley-/Phasenbeweis, alle2304 frisch exakt berechneten
Knoten-Hüllen und die komplette vorzeichenbehaftete unendliche Frequenz-
Schranke bewiesen und aus dem Quellenexport erneut berechnet:
../mop-c0-needed-input-20261108/needed-c0-proof.md.
Keine Ordnung-, Norm- oder Gradhypothese auf C und kein alter R0-Selektor
wird hier importiert. Der alte vorgeschriebene serielle Gegenbeweis mit
Gram(2370,8) liegt außerhalb dieser zwölf Fälle und bleibt bestehen.

## 2. Die Struktur eines kleinsten ursprünglichen Gegenbeispiels

Angenommen, es gebe einen Graphen mit F(G)<2n. Wähle einen mit kleinster
Ordnung. B71 erzwingt n>=72. Jeder echte kleinere induzierte maximal
außenplanare Graph H mit |H|>=8 erfüllt F(H)>=2|H| durch Minimalität.
Auf H der Ordnung2..7 wird diese Induktionsannahme niemals angewandt.

Eine erste Wendung eines ansonsten geraden terminalen Dreieckspfades
hat einen PRIVATEN Fächer mit L Vertices als tatsächliche private Matrix.
Für L3 ist dies der bewiesene Dreiecksflügel mit Zuwachs>6.07, für L4
die wörtliche OperationD mit Zuwachs>8.3, für L5..7 gelten die drei
vollständigen endlichen Erstwendungszahlungen>2L. Bei L>=8 und |H|>=8
sind H und der private Fächer zwei disjunkte echte induzierte MOPs;
Minimalität und(1) bezahlen gemeinsam den ganzen Graphen. Bei |H|<=7
ergänzt man die alte dominierende Menge{a,b,v} um den privaten Fächerscheitel;
damit hat der ganze Graph Dominationszahl<=4 und ist bezahlt. Daher kann kein erster
Scheitelwechsel auftreten: Jeder terminale Pfad ist ein gerader Fächer
mit einem äußeren Wurzelscheitel. Die bloße schwachduale Pfadform wurde
nicht als Beweis dieser stärkeren Aussage benutzt.

An einer tiefsten Verzweigung sind deshalb beide Kinder gerade Fächer.
Von ihren vier Scheitelzuweisungen lassen sich alle bis auf die Darstellung
mit beiden Scheiteln außen ausschließen beziehungsweise wörtlich umbenennen.
Für beide privaten Scheitel ist die private Matrix c join(Pp disjunkt Pq).
Bei d=p+q>=16 ergibt Interlacing und die Hub-/Gleichvektorkompression

 F(private)>2d+G(d), G(d)=2h²+2h sqrt(d+h²)-6,h=1-2/d,
 G(16)>345/128.

Damit ist F(private)>2(d+1)+89/128; blockweises Pinching bezahlt sie.
Bei d<=15 und einem Arm>=3 hat die abnehmbare C0-Spitze tatsächliche
Gesamtwurzelgrade(d+2,3), erhaltene Grade(d,2), also Gram(d-1,1).
Alle101 solchen geordneten Fälle gehören zu den zwölf Eingaben oben.
Die Fälle(1,2)/(2,1) sind wörtlich OperationB und ihre Spiegelung,
Zuwachs>8.07. Der vollständige positive-Modenfilter gibt für(2,2)
analytisch>10.04 bei fünf privaten Vertices; seine komplette Eigenbasis
und die exakten Radikalvergleiche sind geprüft. Für(1,1) dürfen beide
Dreiecke mit äußeren Scheiteln beschrieben werden.

Bei gemischter Scheitelzuweisung dürfen Arme der Länge1 wörtlich neu
zugewiesen werden. Sonst sind beide Längen>=2. Für den inneren Arm q2
gilt der vollständige alle-p-Satz. Für q3..14 greift C0 mit Gram(q,1).
Für q15..18 gelten die vorhandenen universellen gemischten Zahlungen.
Für q>=19 wird nur der innere Fächer entfernt; sein tatsächlich
erhaltener privater Scheitel hat Grad genau3, unabhängig vom äußeren Arm.
Der vollständige Fan19-Satz bezahlt diesen Schritt. Die erhaltene
Ordnung ist mindestens8, sobald der ursprüngliche alte Rest dies ist.
C0 hinterlässt in allen verwendeten Fällen einen echten MOP der
Ordnung n-2>=70. Kleine alte Reste benutzt wiederum die Ganzgraphenbrücke.

Der vollständige kürzere Strukturbeweis mit den wörtlichen Wurzelabbildungen
und dem analytischen Bowtie-Filter steht in
../mop-global-input-audit-20261108/normalization-shortcut-proof.md.
Die symbolischen Spektral-, Skalaren- und Literalprüfungen stehen daneben
in front-shortcuts-check.json. Endliche Geometriekalibrierungen ersetzen
die geschriebenen allordentlichen Argumente nicht. Eine neue Verbesserung
der schon früher vollständig ausgeschlossenen gemischten Front wird
nicht behauptet; die Fan19-Scope-Korrektur bleibt Bestandteil der Quellen.

## 3. Genau drei Elternformen

Wurzle den schwachen Dualbaum an einer Blattfläche. Enthält er keine
Verzweigung, ist der ganze Graph nach Abschnitt2 ein Fächer und bereits
durch gamma<=4 bezahlt. Andernfalls wähle eine tiefste Verzweigung X.
Sie ist nicht die Wurzel und besitzt einen Elternknoten Y. Ihre beiden
Kinder haben die gerade bewiesene Darstellung E_(p,q),p,q>=1, mit
beiden Fächerscheiteln außen.

Hat Y nur ein Kind, ist seine vollständige geschlossene Kappe U(E_(p,q)).
Hat Y ein unverzweigtes Geschwisterkind von X, ist die Kappe
B(E_(p,q),Pell),ell>=1. Dabei sind BEIDE verschiedenen Geschwister-
Scheitelrollen erforderlich. Enthält das Geschwisterkind eine Verzweigung,
muss es selbst auf derselben größten Tiefe verzweigen; ein unary Zwischenschritt
würde eine tiefere Verzweigung erzwingen. Also ist die dritte Form
B(E_(p,q),E_(r,s)),alle vier Längen positiv und unabhängig.
Eine kohärente Gesamtspiegelung vertauscht beide alten Wurzeln und alle
zugehörigen Armrollen gemeinsam. Gleiche Summen identifizieren keine
unterschiedlichen Kontaktmatrizen. Der vollständige Extraktionsbeweis ist
../mop-parent-extraction-20261108/parent-extraction-proof.md.

Das Entfernen genau dieser geschlossenen Kappe lässt einen echten
induzierten MOP H oder die Hilfskante K2. Private Vertices haben keine
Außenkontakte außer den beiden tatsächlichen Schließwurzeln a,b; der
private Elternvertex c wird genau einmal gezählt.

Ist2<=|H|<=7, besitzt H eine dominierende Menge{a,b,v}, wobei v entfallen
darf: Die benachbarten Außenzyklusvertices a,b decken vier Zykluspositionen;
der höchstens dreigliedrige übrige zusammenhängende Abschnitt wird durch
seine Mitte gedeckt. Bei K2/K3 reichen die Wurzeln. Jede der drei Kappen
wird durch{a,b,c} dominiert. Somit hat der GANZE ursprüngliche Graph
Dominationszahl<=4 und ist bereits bezahlt. Dies ist kein K2-Inkrementsatz.

## 4. Vollständige Zahlungen der drei Formen

Es bleibt |H|>=8. Schreibe N=|G|-|H| für die tatsächliche private Ordnung.
Die folgenden Aussagen betreffen durchweg die unveränderte Einheitsgraph-
Geometrie mit ihren geordneten alten Wurzeln.

**U(E).** Für q1,2,15..18 und jedes p>=1 gibt die vollständig beendete
exakte Rechnung DeltaF>2N+1/20,N=p+q+2. Für q3..14 entfernt C0 zwei
Vertices mit Gewinn>4.09. Für q>=19 greift der tatsächliche Grad3-Fan19-
Schritt aus Abschnitt2. Die erhaltenen Graphen sind bezahlt. Dies
schließt jede unary Gegenbeispielform aus, ohne ein stärkeres universelles
alle-q-Inkrement relativ zu beliebigem alten H zu behaupten.
Quelle: ../mop-unary-parent-20261108/unary-payment-proof.md, ergänzt durch
die zwölf frischen C0-Eingaben und die aktuelle Fan19-Scope-Korrektur.

**B(E,P).** BEIDE Geschwisterrollen haben für jedes unabhängige
p,q,ell>=1 das Inkrement DeltaF>2N+1/50,N=p+q+ell+2. Die äußere Rolle
ist durch ihre kleinen q, das vollständige q3..45-Zertifikat und den
analytischen Schwanz vollständig gedeckt. In der privaten Rolle ist
ell1 dieselbe wörtliche Ein-Dreieck-Struktur; bei ell>=2 bleiben genau
S=q+ell=3,4..49 oder>=50. Der Spezialfall S3 und der analytische
Schwanz waren vollständig bewiesen. Das neue vollständige Zwei-Band-
Zertifikat bezahlt ALLE S4..49 und jedes p, einschließlich aller
unendlichen Restklassen, mit stärkerem Inkrement>2N+1/20.
Alle766777 numerischen Längenblätter und beide kompletten Frequenzenden
haben bestanden; kleine/große Bandreserve>.109508943 und>.550083273.
Vollständiger Beweis und Annahme:
../mop-private-completion-20261108/private-completion-proof.md.

**B(E,E).** N=p+q+r+s+3. Für die vier GEORDNETEN Paare(q,r)in{1,2}²
und alle unabhängig unendlichen p,s gilt der vollständige Satz>2N+3/20.
Bei m=q+r<=13 und einem inneren Arm>=3 hat die C0-Spitze Gesamtgrade
(m+4,3), erhaltene Grade(m+2,2) und Gram(m+1,1),m4..13. Sie ist bezahlt.
Für jedes m>=42 geben die tatsächliche private Kompression und genau
eine Grad4-Retirement-Anwendung den universellen Zuwachs>2N+9/100.

Die einzig fehlende Mitte14<=m<=41 ist jetzt vollständig bewiesen:
DeltaF>2N+1/20 für JEDES alte H>=3 und alle unabhängigen p,s>=1.
Die vollständigen ursprünglichen numerischen Teilbeweise aller36
kompakten Frequenzabschnitte[1/2,5] wurden quellen-/datengebunden
übernommen; sie enthalten284102 exakt geprüfte Blätter. Der echte
Ausführungsbeleg des Originalreaders reicht durch Abschnitt35.
Die neue Zusammensetzung hat anschließend ALLE28*128 Intervalle des
vorzeichenbehafteten GANZEN unendlichen Frequenzendes und alle28
Schlussungleichungen vollständig berechnet und ist mit Exitcode0 beendet.
Das schlechteste exakte Plus ist>.3998686104, damit>1/20.
Die kompakte Integralobergrenze ist exakt
2917035500068696040498097339077/1267650600228229401496703205376.

Jede tatsächliche mittlere Gesamtlänge behält über ihr GANZES Integral
die eigene gültige private Reserve G(m+2). Beide Wurzelrichtungen und
beide unabhängig unendlichen äußeren Arme bleiben erhalten. Der gesamte
niedrige Frequenzbereich kostet höchstens1/2 an Energie. Die32-Teil-
Quellenhülle enthält sämtliche72 Rohdaten-/exakten Teilbeweisdateien,
die echten Ausführungsbelege und das vollständige Resultat. Sie erfordert
die vollständigen früheren77+20 Methodenquellen. Aus diesem nativen
Export wurden alle36 Grammatiken,3584 ganzen Schwanzintervalle und28
Schlussungleichungen identisch erneut berechnet. Das ist ausdrücklich
keine zweite Rechnung aller ursprünglichen kompakten AD-Blätter.
Beweis und Annahme:
../mop-double-completion-20261108/acceptance-proof.md und native-audit.json.
Der alte56-Abschnitt-Lauf wird nicht als erfolgreich abgeschlossen ausgegeben.

## 5. Schluss für die ursprünglichen Quantoren

Jeder kleinstmögliche ursprüngliche Gegenbeispielgraph hat nach den
Abschnitten2 und3 eine der drei Elternformen. Kleine alte Reste sind als
GANZE Graphen bezahlt. Bei großen alten Resten ist der erhaltene Graph
ein echter kleinerer MOP mit mindestens8Vertices und daher bezahlt.
Die jeweils einschlägige vollständige Zahlung oder bezahlte C0-/Fan19-
Entfernung liefert F(G)>=2n, bei den Elterninkrementen sogar strikt.
Das widerspricht F(G)<2n. Also existiert kein ursprüngliches Gegenbeispiel.
Damit gilt der Satz für JEDEN endlichen einfachen UNIT MOP mit n>=8. QED.

Die Aussage wurde gegenüber dem ausgewählten Ziel nicht geändert. Es
wird weder nur ein endlicher Bereich noch nur eine Dominationsklasse
geschlossen. Falsch gebliebene allgemeinere Hilfsbehauptungen, beliebige
Bare-UB-Inkremente und andere alte Vermutungen werden damit nicht bewiesen.
Überlappende Dreiecksbeschreibungen und Familienüberlappungen erzeugen
keine doppelte Energiezahlung.

## 6. Prüfbarkeit und verbleibende Grenzen

Der vollständige Quantorenabgleich steht zusätzlich in
../mop-global-input-audit-20261108/original-quantifier-audit.md. Sein
damaliger Hinweis auf die noch fehlende Doppelmitte wird durch die oben
genannte tatsächliche vollständige Annahme ersetzt, nicht durch einen
Fortschrittszähler. global-input-final-audit.json daneben prüft409
verschiedene erhaltene Quelldateien und die genauen Annahmebelege.
Dieser Code ersetzt das geschriebene geometrische und mathematische
Zusammensetzungsargument nicht.

Die verwendeten älteren Unterklassensätze behalten ihre konkreten
Quellen-/Reproduktionsbelege. Exakte Softwarearithmetik, Quellenidentität,
mathematische Lektüre/Gültigkeit, native Aufnahme, automatische Lieferung
im begrenzten Sitzungseinstieg und unabhängige Begutachtung sind verschiedene
Behauptungen. Die alte Aletheion-Kennung kann wegen ihrer Abrufgrenze nur
einen Korrekturverweis liefern; die vollständige direkte Quellenrücklese
macht diese automatische Lieferlücke nicht unsichtbar.

Ein sinnvoller nächster unabhängiger Review konzentriert sich auf die
allordentliche terminale/Eltern-Extraktion, die tatsächliche Rootball-/
Lossless-Phasenbrücke und die vollständige Domination-vier-Kopplung.
Weltweite Erstpriorität, Veröffentlichung, Lean-/Coq-Formalisierung oder
kausale Wirkung von LOTSE/Aletheion werden hier nicht behauptet.
