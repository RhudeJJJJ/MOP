# Full private-cap homotopy pays C1 and C2 at every original boundary

5 November2026. Original fixed target: EVERY finite simple UNIT maximal
outerplanar graph G,n>=8 has F(G)=splus(G)>=2n, equivalently D(G)>=6.
GLOBAL OPEN / goal ACTIVE. This note proves two universal incremental
payments and a further minimal-counter cut. It does not prove original
global coverage, a paying serial-C0 selector or unrestricted Fork6.
No external formal audit or exhaustive priority claim.

## 1. Literal actual unit caps and the all-parent conclusion

Use the SAME C_m of256..261 and the previous C3proof: roots a0,b(2m+3),
private z1,v_i=2i+2 for i0..m, y_i=2i+3 for i0..m-1. Retain ab.
Add az,zv0, all av_i, pathv0..v_m, each ear y_i on v_iv_(i+1), and v_mb.
The long outer arc is a,z,v0,y0,v1,...,y_(m-1),v_m,b. Private vertices
have NO other contacts. This is an actual triangulated polygon, not a
weighted substitute or a graph identified only by its degree data.

THEOREM. For EVERY old finite simple UNIT MOP A,n_A>=3, EVERY ordered
actual boundary edge ab and coherent whole reflection, the SAME unit
graft satisfies

    C1: +4private vertices/+8edges, F(new)-F(A)>81/10=8.1;
    C2: +6private vertices/+12edges, F(new)-F(A)>25/2=12.5.       (1)

There are no upper bounds on old order, degrees, norm, domination or
spectra. In particular the apex may be arbitrarily large. Thus no actual
closed C1 or C2 occurs in a minimal original counterexample of order>=14.
The inherited n>=72 minimal-counter domain is covered by this consequence.
The previous universal C3gain>16.07 remains true and is not weakened.

## 2. Keep the COMPLETE private response through a homotopy

Put J=[[0,1],[1,0]], K=2I+J. For the actual old root let

 Z0=tI+iJ+F0(t), H0=Z0^(-1), t>0.

The already PROVEN201 actual old response gives Wplus(F0)=2ReF0+tImF0>=0.
Let B,T be the actual private adjacency and two contact rows of the cap,

 Fcap(t)=T(tI+iB)^(-1)T^t=R+iS.

Because the COMPLETE cap is itself an actual unit MOP rooted at its
closing boundary edge, source201 also gives Wplus(Fcap)>=0.
For every real s in[0,1] define Z_s=Z0+sFcap and H_s=Z_s^(-1).
All these matrices are strictly accretive: ReZ_s>=tI. Directly,

 2ReZ_s+tImZ_s=tK+Wplus(F0)+sWplus(Fcap)>=tK.

Inverse congruence therefore proves the full complex Hermitian inequality

                2ReH_s-tImH_s>=t H_s^* K H_s.           (2)

Every positive AND negative private eigenvalue remains in Fcap. We do not
drop the negative-mode contact gains, or suppose a separate positive-filter
floor. The parameter s is an exact algebraic homotopy of Schur responses;
no original-energy inequality is applied to a weighted intermediate graph.
The same old parent supplies F0 at every t and s.

## 3. The exact root matrix ball and its trace-norm support

Write c=1/t+i/2. Dividing(2) by t and completing a MATRIX square gives

 (K^(1/2) H_s K^(1/2)-conjugate(c)I)^*
 (K^(1/2) H_s K^(1/2)-conjugate(c)I)<=|c|^2 I.

Thus K^(1/2) H_s K^(1/2)=conjugate(c)I+|c|U for a contraction U.
Set L=K^(-1/2) Fcap K^(-1/2). Trace duality gives
ImTr(U L)<=||L||_*, where the norm is the sum of singular values.
For clarity this follows by a singular-value decomposition: the diagonal
entries of the resulting contraction have absolute value<=1. No pairwise
commutation, entrywise positivity or real-transpose replacement is used.
Consequently, at EVERY t,s,

 ImTr(H_s Fcap)<=E(t),
 E(t)=ImTr(K^-1Fcap)/t - ReTr(K^-1Fcap)/2
             +sqrt(t^2+4)/(2t)*||K^-1/2 Fcap K^-1/2||_*.       (3)

This is a support bound on a larger matrix ball. It needs neither a
physically attainable maximizer nor the same maximizer at different t.
The ball contains zero, so E(t)>=0. The actual H_s has extra restrictions;
discarding them only enlarges this upper bound.

Strict accretivity licenses the continuous trace-log derivative

 delta_root(t)=ImTrLog Z1-ImTrLog Z0
             =integral_0^1 ImTr(H_s Fcap)ds<=E(t).       (4)

Each trace-log is its accretive branch, anchored at infinity. The full
determinant identity is

 det(tI+iA_new)/[det(tI+iA_old)det(tI+iB)]=detZ1/detZ0.

It agrees at infinity and continuously for all t>0. We never rewrap the
phase of a product to one principal determinant argument. Equation(4)
is why the complete private cap can be bounded uniformly without treating
its negative and positive modes as unrelated payments.

## 4. Convert the phase bound to the SAME actual energy increment

Compare the new matrix with A_old direct-sum B. Their traces agree,
including any zero modes. The standard equal-trace spectral-phase identity
and the exact trace-square increase2Tr(TT^t) give

 F(A_new)-F(A_old)
 =F(B)+Tr(TT^t)-(2/pi) integral_0^infinity t*delta_root(t)dt
 >=F(B)+Tr(TT^t)-(2/pi) I,
 I=integral_0^infinity V(t)dt, V(t)=tE(t)>=0.            (5)

This is one actual full graft. No independently optimized graph witness
is added to another witness, and no private vertex is removed from n.
All remaining work in this proof is finite, intrinsic cap algebra for I.

## 5. An explicit scalar integrand with all noncommuting terms retained

Let x=t^2 and

 Q(x)=T(xI+B^2)^(-1)T^t,
 M(x)=TB(xI+B^2)^(-1)T^t, Fcap=tQ-iM.

For these two caps B is invertible and T has full row rank. Thus Q>0
also at x0, and the following five functions are rational and finite:

 q=Tr(K^-1Q), m=Tr(K^-1M), u=detQ/detK, v=detM/detK,
 w=[Q11M22+Q22M11-2Q12M12]/detK.

Put C=K^-1Q,N=K^-1M. They need not be symmetric or commute, but each is
similar to a real symmetric matrix, C positive definite. Exact2by2 identities
give TrC^2=q^2-2u, TrN^2=m^2-2v, and

 |detL|=sqrt((xu-v)^2+xw^2),
 ||L||_*^2=x(q^2-2u)+(m^2-2v)+2sqrt((xu-v)^2+xw^2).

Hence the exact integrand used by the reader is

 V(t)=-m-xq/2
      +(1/2)sqrt((x+4)[x(q^2-2u)+(m^2-2v)
                                      +2sqrt((xu-v)^2+xw^2)]). (6)

Absolute determinants, both contact rows and the full singular-value norm
are retained. Replacing the trace norm by a scalar trace or dropping a
signed determinant is not licensed.

## 6. Normalize the entire infinite tail, without truncation

For t>=4 set z=1/t,y=z^2, and define
Qhat=T(I+yB^2)^(-1)T^t, Mhat=TB(I+yB^2)^(-1)T^t.
Use q,m,u,v,w for the same five invariants of these HATTED matrices.
Let

 h=(w^2-4uv)/[sqrt((u-yv)^2+yw^2)+u+yv].

Then exact rationalization of(6) proves

 V(t)=y W(y),
 W(y)=[(2q-m)^2+2(1+4y)h] /
       [2(sqrt((1+4y)[q^2+y(m^2+2h)])+q+2ym)].          (7)

To check signs, Qhat>0. The generalized eigenvalues of Mhat relative
to Qhat are real in[-4,4], since ||B||<=4. It follows that
w^2-4uv>=0, u>0, u+yv>=u(1-16y)>=0, and
q+2ym>=q(1-8y)>=q/2>0 on0<=y<=1/16.
The other denominator in h is strictly positive: its two nonnegative
parts cannot both vanish when u>0. Thus W extends continuously to y0.
The normalization includes the complete infinite tail:

          integral_4^infinity V(t)dt=integral_0^(1/4) W(z^2)dz. (8)

No tail is dropped, estimated by an unproved numerical cutoff, or
implicitly regenerated. The two finite domains are exactly[0,4] and[0,1/4].

## 7. Exact finite certificate and a separate full reader

full-cap-phase-certificates.json preserves all18856interval cells:
6836 for C1 and12020 for C2. On every cell, homotopy_interval.py evaluates
(6) or(7) with directed rational72bit dyadic interval arithmetic. Integer
square roots enclose every radical outward. Every multiplication, division
and polynomial evaluation is rounded outward; no floating quantity accepts
an interval. Positivity clamps use only the explicit proven properties:
q,u>=0, TrC^2,TrN^2>=0, absolute-determinant radicands>=0, E>=0,
and the tail discriminant>=0. A denominator must have a strictly positive
lower enclosure, otherwise the producer subdivides before accepting a cell.

The producer obtains the exact polynomials by the full adjugate recurrence
for xI+B^2. The reader reconstructs them from a DIFFERENT direct contact-
moment/divided-difference formula, using actual B,T. It verifies the full
Cayley-Hamilton identity and exact coefficient equality. Both routes use
the retained stdlib Newton characteristic utility; no external independence
or formal-assistant audit is claimed.

For EACH cell the reader recomputes the full outward enclosure, then
checks disjoint, gap-free coverage of BOTH closed finite domains and sums
the exact rational upper areas. Its independent actual-matrix inversions
check the five invariants and the nuclear-norm radicands at rational t.
The reversed tail polynomials and their powers of1/t^2 are checked exactly
against the original polynomials; the two integrand forms agree in tight
point intervals at t4,8,16. Fifteen or more matrix/frequency controls are
not substituted for this full integral proof.

The resulting rational integral bounds satisfy the simpler human-checkable

                   I_C1<21/20, I_C2<28/25.             (9)

The earlier complete actual private root isolation independently gives
F(B_C1)>2403/500=4.806 and F(B_C2)>8441/1000=8.441.
Their contact masses are exactly4and5. Machin's identity with rational
alternating arctangent bounds gives pi>157/50. Substituting these slightly
WEAKER rational endpoints in(5) gives

 C1gain>2403/500+4-105/157
       =81/10+2921/78500>81/10;
 C2gain>8441/1000+5-112/157
       =25/2+35737/157000>25/2.                         (10)

This proves(1) for ALL original old parents; the unbounded quantifier
comes from sections2-4, not enumeration of parents.

Two complete actual unit grafts on the old triangle have separate whole
integer Gram certificates, with their ENTIRE squared Frobenius norms
scored against actual edges. Since F(K3)=4 exactly, each gives a direct
finite gain above its target. These controls supply no new finite-base
coverage or first-payment credit. Missing interval coverage, a damaged
normalized tail polynomial and stale/missing actual cap contacts are
rejected by the reader's literal-graph/partition contracts.

The numerical homotopy scout only suggested the direction. Gauss-Legendre
quadrature did not accept these statements; the directed rational cells
and complete infinite-tail normalization do. The source file, full cells,
all supporting code and final reader report are retained, not only a manifest.

## 8. Actual global effect and remaining work

The new statements remove C1 and C2 without the older degree conditions.
Together with the retained universal C3payment and earlier C4..C9payments,
the inherited terminal selector leaves ONLY the literal serial C0 in a
minimal original counterexample. Its private count is2, not a claim that
only one occurrence or one graph remains. Private closedness and the
actual old parent must be checked at each removal.

The existing fixed cap-only E46/E4/E3selectors were already REFUTED by an
infinite original UNIT C0-only fan/ear family whose WHOLE graphs are paid.
That family contains no C1,C2,C3 and survives this further exclusion.
Thus the corresponding fixed cap-only E1selector is likewise REFUTED,
not reopened as an OPEN global proof bridge. A practical residual must
retain ALL whole-paid exclusions and other valid cuts. Its universal
serial-payment OR whole-graph-compensation problem remains OPEN, as does
the original all-MOP2n target. No original energy counterexample is given.

The old true C3theorem, conditional260/261bounds, scalar-sector sharpness,
fixed-core236obstruction and E46C0counter retain their scopes. A failed
positive-only C1/C2lower bound was not an actual cap counterexample;
retaining the complete response here closes those two increments.

The discarded simpler positive-filter premise4/9 is independently false
on the UNIT diamond at a boundary root. With lambda=(1+sqrt17)/2,
its root-plus filter is U=(13lambda+20)/(40lambda+48)<4/9, because
43lambda+12>0. The characteristic x(x+1)(x^2-x-4) is checked exactly.
This was a counter to a proposed helper, not to original2n (the old parent
has order4). The weaker quarter-filter floor remains unproved and UNUSED.

Next justified global work is simultaneous serial-C0/whole-region
compensation on the actual remaining domain. The present enlarged matrix
ball contains H=0, so its root-phase support is nonnegative. For C0,
F(B)+TrTT^t=1+3=4 before any root penalty; this particular certificate
cannot supply a universal gain4, which is already false in the actual
original domain. More quadrature of the same C0envelope cannot discharge
the remaining global obligation.
