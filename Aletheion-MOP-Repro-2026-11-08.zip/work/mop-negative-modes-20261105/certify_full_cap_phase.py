from pathlib import Path
from fractions import Fraction as F
import hashlib,heapq,json,time
import homotopy_interval as h
HERE=Path(__file__).resolve().parent;SOURCE=HERE.parent/'mop-root-sector-20261105/anisotropic-cap-certificates.json'
def serialize(d):return {r:[[str(x) for x in p] for p in v] for r,v in d.items()}
def integral(data,tol=F(1,25),limit=50000):
    heap=[];lo=hi=F(0);counter=0
    def put(region,a,b,depth=0):
        nonlocal lo,hi,counter
        try:v=h.enclosure(data,region,a,b)
        except ArithmeticError:
            assert depth<30;mid=(a+b)/2;put(region,a,mid,depth+1);put(region,mid,b,depth+1);return
        low=(b-a)*v[0];high=(b-a)*v[1];lo+=low;hi+=high;counter+=1
        heapq.heappush(heap,(-(high-low),counter,region,a,b,v))
    put('compact',F(0),F(4));put('tail',F(0),F(1,4));start=time.monotonic();splits=0
    while hi-lo>tol:
        assert len(heap)<limit
        _,_,region,a,b,v=heapq.heappop(heap);lo-=(b-a)*v[0];hi-=(b-a)*v[1];mid=(a+b)/2;put(region,a,mid);put(region,mid,b);splits+=1
        if splits%2000==0:print(json.dumps(dict(progress='exact_interval_integration',leaves=len(heap),width=str(h.up(hi-lo)),elapsed_seconds=time.monotonic()-start)),flush=True)
    leaves=[dict(region=r,a=str(a),b=str(b),lower=str(v[0]),upper=str(v[1])) for _,_,r,a,b,v in heap]
    leaves.sort(key=lambda c:(c['region'],F(c['a'])));return dict(lower=str(lo),upper=str(hi),width=str(hi-lo),leaves=leaves,splits=splits,elapsed_seconds=time.monotonic()-start)
def main():
    src=json.loads(SOURCE.read_text());piL,piU=h.machin_pi();cases=[]
    for c in src['cases'][1:3]:
        A,B,T=h.old.actual(c);data=h.poly_data(B,T,'adjugate');assert data==h.poly_data(B,T,'moments');res=integral(data)
        old=h.old.check(c);base=F(old['private_F_lower'])+sum(x*x for row in T for x in row);gain=base-2*F(res['upper'])/piL;target=F(81,10) if c['label']=='C1' else F(25,2)
        assert gain>target;cases.append(dict(label=c['label'],cap=c,polynomials=serialize(data),integral=res,private_F_lower=old['private_F_lower'],contact_mass=str(sum(x*x for row in T for x in row)),gain_lower=str(h.down(gain)),target=str(target)))
        print(json.dumps(dict(completed=c['label'],leaves=len(res['leaves']),integral_upper=str(h.up(F(res['upper']))),gain_lower=str(h.down(gain)),target=str(target))),flush=True)
    d=dict(format='full-cap-matrix-disk-exact-certificate-v1',source=str(SOURCE),source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),pi_lower=str(piL),pi_upper=str(piU),cases=cases,
       scope='Universal all-parent proof uses201rootresponse and the COMPLETEcap homotopy. Exact finite interval integration, no numerical quadrature acceptance. Original all-MOP2n stillOPEN.')
    p=HERE/'full-cap-phase-certificates.json';p.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(status='EXACT_FULL_CAP_PHASE_CERTIFICATES_PREPARED',bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())))
if __name__=='__main__':main()
