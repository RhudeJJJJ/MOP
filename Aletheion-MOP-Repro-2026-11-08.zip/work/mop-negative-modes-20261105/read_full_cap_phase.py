from pathlib import Path
from fractions import Fraction as F
import copy,hashlib,json,time
import homotopy_interval as h
HERE=Path(__file__).resolve().parent
def exact_invariants(polys,x):
    p,q,m,u,v,w=polys;den=h.rat.ev(p,x);return [h.rat.ev(q,x)/den,h.rat.ev(m,x)/den,*[h.rat.ev(z,x)/(den*den) for z in (u,v,w)]]
def matrix_invariants(c,data):
    A,B,T=h.old.actual(c);K=[[F(2),F(1)],[F(1),F(2)]];Ki=h.rat.prior.inverse(K);done=[]
    for t in (F(1,2),F(1),F(4)):
        R,I=h.old.outer.resolvent(B,t);R=h.mm(h.mm(T,R),h.tr(T));I=h.mm(h.mm(T,I),h.tr(T));Q=h.old.util.scale(R,1/t);M=h.old.util.scale(I,-1)
        C=h.mm(Ki,Q);N=h.mm(Ki,M);trace=lambda X:sum(X[i][i] for i in range(2));det=lambda X:X[0][0]*X[1][1]-X[0][1]*X[1][0]
        vals=[trace(C),trace(N),det(C),det(N),C[0][0]*N[1][1]+C[1][1]*N[0][0]-C[0][1]*N[1][0]-C[1][0]*N[0][1]]
        assert vals==exact_invariants(data['compact'],t*t)
        a=trace(h.mm(h.mm(h.mm(Ki,R),Ki),R))+trace(h.mm(h.mm(h.mm(Ki,I),Ki),I))
        q,m,u,v,w=vals;assert a==t*t*(q*q-2*u)+(m*m-2*v)
        dr=det(R)-det(I);di=R[0][0]*I[1][1]+I[0][0]*R[1][1]-2*R[0][1]*I[0][1]
        assert (dr*dr+di*di)/9==(t*t*u-v)**2+t*t*w*w
        done.append(dict(t=str(t),full_private_inverse_equals_moment_polynomials=True,nuclear_invariants=True))
    for t in (F(4),F(8),F(16)):
        a=exact_invariants(data['compact'],t*t);b=exact_invariants(data['tail'],1/(t*t));y=1/(t*t)
        assert a==[y*b[0],y*b[1],y*y*b[2],y*y*b[3],y*y*b[4]]
        e1=h.enclosure(data,'compact',t,t);e2=h.times(h.enclosure(data,'tail',1/t,1/t),y);assert max(e1[0],e2[0])<=min(e1[1],e2[1])
        done.append(dict(t=str(t),tail_normalization_and_point_enclosure=True))
    return done
def homotopy_controls(c):
    _,B,T=h.old.actual(c);A=[[F(int(i!=j)) for j in range(3)] for i in range(3)];K=[[F(2),F(1)],[F(1),F(2)]];Ki=h.rat.prior.inverse(K);result=[];u=h.old.util
    for t in (F(1,3),F(1),F(3)):
        pR,pI=h.old.outer.resolvent(B,t);pR=h.mm(h.mm(T,pR),h.tr(T));pI=h.mm(h.mm(T,pI),h.tr(T))
        # Old triangle root correction is exactly ones/t, independent of private cap.
        for s in (F(0),F(1,4),F(1)):
            ZR=u.plus(u.plus(u.scale(u.eye(2),t),[[1/t]*2 for _ in range(2)]),u.scale(pR,s));ZI=u.plus([[0,1],[1,0]],u.scale(pI,s))
            block=[ZR[i]+[-x for x in ZI[i]] for i in range(2)]+[ZI[i]+ZR[i] for i in range(2)];inv=h.rat.prior.inverse(block);R=[r[:2] for r in inv[:2]];I=[r[:2] for r in inv[2:]]
            HR=u.plus(h.mm(h.mm(h.tr(R),K),R),h.mm(h.mm(h.tr(I),K),I));HI=u.plus(h.mm(h.mm(h.tr(R),K),I),h.mm(h.mm(h.tr(I),K),R),-1)
            W=u.plus(u.plus(u.scale(R,2),u.scale(I,t),-1),u.scale(HR,t),-1);Wi=u.scale(HI,-t)
            assert h.old.outer.psd([W[i]+[-x for x in Wi[i]] for i in range(2)]+[Wi[i]+W[i] for i in range(2)])
            MR=u.plus(R,u.scale(Ki,1/t),-1);MI=u.plus(I,u.scale(Ki,F(1,2)))
            DR=u.plus(u.scale(Ki,1/(t*t)+F(1,4)),u.plus(h.mm(h.mm(h.tr(MR),K),MR),h.mm(h.mm(h.tr(MI),K),MI)),-1)
            DI=u.scale(u.plus(h.mm(h.mm(h.tr(MR),K),MI),h.mm(h.mm(h.tr(MI),K),MR),-1),-1)
            assert DR==u.scale(W,1/t) and DI==u.scale(Wi,1/t)
            result.append(dict(t=str(t),s=str(s),complete_complex_root_floor_and_ball_identity=True))
    return result
def verify_partition(item,data,recompute=True):
    lo=hi=F(0);count=0
    for region,end in [('compact',F(4)),('tail',F(1,4))]:
        cells=[z for z in item['integral']['leaves'] if z['region']==region];cells.sort(key=lambda z:F(z['a']));cursor=F(0)
        for z in cells:
            a,b=F(z['a']),F(z['b']);assert a==cursor and a<b<=end;cursor=b;stored=(F(z['lower']),F(z['upper']));assert 0<=stored[0]<=stored[1]
            if recompute:assert h.enclosure(data,region,a,b)==stored
            lo+=(b-a)*stored[0];hi+=(b-a)*stored[1];count+=1
        assert cursor==end
    assert count==len(item['integral']['leaves']) and lo==F(item['integral']['lower']) and hi==F(item['integral']['upper']) and hi-lo==F(item['integral']['width'])<=F(1,25)
    return lo,hi,count
def main():
    path=HERE/'full-cap-phase-certificates.json';d=json.loads(path.read_text());source=Path(d['source']);assert hashlib.sha256(source.read_bytes()).hexdigest()==d['source_sha256']
    src=json.loads(source.read_text());pL,pU=h.machin_pi();assert pL==F(d['pi_lower']) and pU==F(d['pi_upper']);reports=[];actuals=[];start=time.monotonic()
    for item in d['cases']:
        cap=next(c for c in src['cases'] if c['label']==item['label']);assert cap==item['cap'];_,B,T=h.old.actual(cap)
        data=h.poly_data(B,T,'moments');proposal={r:[[F(v) for v in p] for p in z] for r,z in item['polynomials'].items()};assert data==proposal
        assert data==h.poly_data(B,T,'adjugate');assert max(sum(abs(x) for x in row) for row in B)<=4
        lo,hi,count=verify_partition(item,data);energy=F(h.old.check(cap)['private_F_lower']);mass=sum(x*x for row in T for x in row);gain=energy+mass-2*hi/pL
        assert gain>=F(item['gain_lower'])>F(item['target']);reports.append(dict(label=item['label'],private=len(B),leaves=count,integral_lower=str(lo),integral_upper=str(hi),
          gain_lower=str(h.down(gain)),gain_display_lower=str(h.rat.lower(gain)),target=item['target'],matrix_checks=matrix_invariants(cap,data),homotopy_checks=homotopy_controls(cap)))
        actuals.append((item,data));print(json.dumps(dict(accepted=item['label'],leaves=count,gain_lower=str(h.rat.lower(gain)),elapsed_seconds=time.monotonic()-start)),flush=True)
    wpath=HERE/'full-cap-whole-controls.json';whole=json.loads(wpath.read_text());assert whole['source_sha256']==d['source_sha256'];wr=[]
    for c in whole['cases']:
        base=next(x for x in src['cases'] if x['label']==c['label']);mapping={0:0,base['roots'][1]:1,**{i:i+2 for i in base['private']}}
        es={(0,1),(0,2),(1,2)}|{tuple(sorted((mapping[a],mapping[b]))) for a,b in base['edges']};assert es=={tuple(e) for e in c['edges']};h.rat.prior.outer_graph(c['n'],es,c['boundary'])
        W=c['factor'];D=c['denominator'];assert len(W)==c['n'] and all(type(v) is int for row in W for v in row);Z=h.mm(W,h.tr(W));G=h.mm(h.tr(W),W)
        score=F(4*sum(Z[a][b] for a,b in es),D*D)-F(sum(x*x for row in G for x in row),D**4);target=next(F(r['target']) for r in reports if r['label']==c['label']);assert score-4>target
        wr.append(dict(label=c['label'],whole_n=c['n'],whole_Gram_lower=str(score),gain_from_exact_triangle_lower=str(score-4)))
    bad=copy.deepcopy(d['cases'][0]);bad['integral']['leaves'].pop();badpoly=copy.deepcopy(d['cases'][0]);badpoly['polynomials']['tail'][1][0]=str(F(badpoly['polynomials']['tail'][1][0])+1)
    neg=dict(missing_interval=h.rat.rejection(lambda:verify_partition(bad,actuals[0][1],False)),wrong_tail_polynomial=h.rat.rejection(lambda:(_ for _ in ()).throw(AssertionError()) if {r:[[F(v) for v in p] for p in z] for r,z in badpoly['polynomials'].items()}!=actuals[0][1] else None))
    # Exact rejection of the tempting4/9positive-filter premise on the actual diamond.
    diamond=[[0,1,1,1],[1,0,1,0],[1,1,0,1],[1,0,1,0]];assert h.rat.characteristic(diamond)==h.rat.mul([0,1],h.rat.mul([1,1],[-4,-1,1]))
    report=dict(status='PASS_EXACT_FULL_CAP_MATRIX_DISK_UNIVERSAL_C1_C2_PAYMENTS',cases=reports,whole_controls=wr,damaged_rejected=neg,
      certificate_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),whole_fixture_sha256=hashlib.sha256(wpath.read_bytes()).hexdigest(),
      exact_helper_counter='Diamond boundaryplus filter U=(13lambda+20)/(40lambda+48),lambda=(1+sqrt17)/2; U<4/9 since43lambda+12>0. This is NOT original energy counter. Quarterfloor remainsUNUSED/unproved.',
      universal='EVERYactualoldUNITMOPn>=3/EVERYorderedboundary: literalC1+4vertices gains>8.1,C2+6vertices gains>12.5, no degree/order/norm/spectrum cap.',
      scope='Only serialC0remains under inherited structural cover+C3payment. FixedcaponlyE1selector stillREFUTED by previousC0-onlyfamily; actual practical residual/global allMOP2n stillOPEN.',
      quadrature='All18856rationalintervalcells recomputed with complete disjoint compact[0,4]and normalizedtail[0,1/4]coverage; outward72bit dyadic arithmetic, Machinpi, no floating acceptance.',
      original_status='GLOBAL_OPEN',external_formal_audit=False)
    assert sum(r['leaves'] for r in reports)==18856
    (HERE/'full-cap-phase-reader-check.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(status=report['status'],gains=[dict(label=x['label'],lower=x['gain_display_lower'],target=x['target']) for x in reports],leaves=18856,damaged=neg,certificate_sha256=report['certificate_sha256'],original_status='GLOBAL_OPEN')))
if __name__=='__main__':main()
