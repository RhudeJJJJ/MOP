# Complete private sibling, and the two distinct sibling roles

8 November 2026. Original global UNIT MOP conjecture remains OPEN.

For every old UNIT maximal outerplanar H of order at least3, every ordered
boundary ab, and every independent p,q,ell>=1, the PRIVATE-c sibling
B(E_(p,q),P_ell), N=p+q+ell+2, has DeltaF>2N+1/50.
The same statement, with its own actual contacts, holds for the EXTERNAL-b
sibling. These are two theorems, not an identification by equal lengths.

The formerly missing private range ell>=2,4<=q+ell<=49 is now proved with
the stronger margin1/20. Its full original producer AND independent exact
reader terminated with exit0. The reader checked all766777 numerical
length leaves in160 base slabs, all68224 exact arithmetic-empty leaves,
all64 ordered residue roots per slab, and all finite q,ell AP domains.
Every p+4k tail remains infinite. Maximum anchors9 and10 are not cutoffs.
The frozen21 source files, complete160-cell certificate and terminal
execution receipts are mandatory evidence; a progress prefix is not used.

The exact method and whole-domain proof are the earlier
private-two-band-proof.md, now retained as a dated CONDITIONAL draft whose
two acceptance inequalities have actually been discharged. Old physical
root sector, normalized direct/common identities, private floors, derivative
bounds, complete low-frequency charge and signed high tail retain their
original proofs and all counterexamples/limits. The complete77-file native
private-model envelope is required. The false blanket p1 pointwise floor
and artificial commuting-phase shortcuts remain false.

For the small fixed band4..19 the compact integral upper is
4417155359231149968867890058221/2535301200456458802993406410752,
tail upper10364992106262897311035309910561/81129638414606681695789005144064,
reserve9/5. For the large fixed band20..49 these are respectively
5370849293250040634441958593125/1267650600228229401496703205376,
32197540213698234376907766372339/81129638414606681695789005144064,
reserve4. Each graph chooses ONE band for its ENTIRE integral. Using the
same exact lower pi and low energy charge1/2, both reserve-1/2-
2(compact+tail)/pi_lower exceed1/20 (about.10950894 and.55008327).
No reserve is moved between bands and no parameter averaging is allowed.

The new portable acceptance audit replays ALL160 complete grammars with a
zero callback ONLY to check domains/counts, and recomputes all128 signed
tail cells and final scalar inequalities. It reuses, and explicitly does
not freshly repeat, the766777 original exact AD numerical leaves. The
certificate retains every raw checkpoint object, and the audit verifies
that deterministic JSON hydration recovers ALL160 original checkpoint
bytes and hashes. A manifest alone is not substituted for the full data.

Complete private length coverage: ell1 is the SAME literal single-triangle
sibling as the already accepted external-allq family; its common margin
is1/50. For ell>=2,S=q+ell=3, the only pair(q,ell)=(1,2) has its earlier
all-p special margin1/4. For S4..49 use the new full two-band result.
For S>=50 use the earlier analytic private cap theorem, margin3/20.
Thus every independent triple is covered, with no duplicate credit on
overlaps. The previously complete external family remains separate.

Old H2..7 are NOT included in either increment theorem. In original
counter extraction they use the independently proved whole gamma<=4
bridge. No ell0 extrapolation, arbitrary bare E payment, whole good-ear
property, K2 increment, global closure, priority, human/formal verification
or causal LOTSE effect is asserted. General double-child14<=q+r<=41 and
the final original-quantifier audit are still required.

The next mathematical work changes precisely because the private sibling
no longer supplies an unpaid parent: only the stated DOUBLE middle family
remains unpaid in that parent list. Native intake, revision binding,
actual entry delivery and mathematical validity remain distinct checks.
