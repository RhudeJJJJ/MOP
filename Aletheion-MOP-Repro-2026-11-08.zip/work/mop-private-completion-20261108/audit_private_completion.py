"""Portable source/grammar/tail acceptance, NOT a repeat of numeric AD leaves."""
from pathlib import Path
from fractions import Fraction as F
import sys,json,hashlib,types,time
P=Path(__file__).resolve().parent;W=P.parent;S=W/'mop-private-sibling-middle-20261108'
sys.path.insert(0,str(S))
import rational_grid
rational_grid.install()
import bulk_small_tail as st,uniform_private_tail as lt,net_interval as net
from bulk_band_cover import Cover
def rd(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    start=time.monotonic();manifest=rd(S/'bulk-band-v2-checkpoints/producer-inputs.json');assert len(manifest)==21 and all(sha(S/n)==h for n,h in manifest.items())
    cert=rd(S/'bulk-band-v2-certificate.json');result=rd(S/'bulk-band-v2-reader-result.json');areas=rd(S/'bulk-band-v2-reader-cells.json');assert cert['source_sha256']==result['source_sha256']==manifest and result['reader_sha256']==sha(S/'read_bulk_bands_v2.py')and result['certificate_sha256']==sha(S/'bulk-band-v2-certificate.json')
    status='PASS_EXACT_PRIVATE_SIBLING_ell_AT_LEAST2_TOTAL4_TO49_ALL_p_PAYMENT';assert result['status']==status
    reader=rd(S/'private-reader-terminal-tool.json');producer=rd(S/'private-producer-terminal-tool.json');assert reader['exit_code']==producer['exit_code']==0
    terminal=json.loads(reader['output'].splitlines()[-1]);assert terminal=={k:v for k,v in result.items()if k!='source_sha256'}
    assert json.loads(producer['output'].splitlines()[-1])['status']=='HEURISTIC_TWO_BAND_CERTIFICATE_READY_REQUIRES_EXACT_READER'
    grid=rd(S/'bulk-frequency-grid.json');assert len(grid)==80;dummy=types.SimpleNamespace(bound=lambda *args:dict(upper=F(0)));checkpoints={};counts={}
    for name,tail in [('small',st),('large',lt)]:
        cover=Cover(name);total=F(0);end=F(1,2);leaves=empty=anchor=fcells=0
        assert len(cert['cells'][name])==len(areas[name])==80
        for i,(item,row,record)in enumerate(zip(cert['cells'][name],grid,areas[name])):
            a,b=F(row['a']),F(row['b']);assert a==end and item['index']==record['index']==i and item['band']==name;end=b;target=cover.amplitude/(1+((a+b)/2)**2);assert F(item['target'])==target
            # Original pathlib.write_text on Windows translated the final LF.
            hydration=(json.dumps(item,separators=(',',':'))+'\r\n').encode();rel=f'bulk-band-v2-checkpoints/{name}-{i:04}.json';expected=rd(P/'checkpoint-hashes.json')[rel];assert hashlib.sha256(hydration).hexdigest()==expected
            actual=S/rel
            if actual.exists():assert actual.read_bytes()==hydration
            checkpoints[rel]=expected
            zero,n,e,p,fc=cover.cell(item['partition'],a,b,target,dummy,dummy);assert zero==0 and(n,e,p,fc)==(record['leaves'],record['empty'],record['anchor'],record['frequency_cells']);area=F(record['area']);assert 0<=area<=(b-a)*target;total+=area;leaves+=n;empty+=e;anchor=max(anchor,p);fcells+=fc
        assert end==16;v=result['bands'][name];assert str(total)==v['compact_integral_upper']and(leaves,empty,anchor,fcells)==(v['length_leaves'],v['arithmetic_empty_leaves'],v['max_p_anchor'],v['frequency_cells'])
        high=sum((tail.tail(F(k,1024),F(k+1,1024))[1]/1024 for k in range(64)),F(0));gain=cover.reserve-F(1,2)-2*(total+high)/net.PI[0];assert str(high)==v['tail_integral_upper']and str(gain)==v['surplus_lower']and gain>F(1,20);counts[name]=dict(leaves=leaves,empty=empty,frequency_cells=fcells,max_anchor=anchor,surplus_lower=str(gain))
    assert len(checkpoints)==160 and all(sha(S/n)==h for n,h in manifest.items());out=dict(status='PASS_PRIVATE_COMPLETE_SOURCE_GRAMMARS128_SIGNED_TAILS_AND_EXACT_BAND_BUDGETS',full_raw_checkpoint_objects=160,byte_exact_hydration=True,bands=counts,numerical_AD_leaf_proofs='766777 original full independent exact reader leaves reused; no fresh second numeric AD replay',terminal_original_producer_and_reader_exit0=True,original_global='OPEN',seconds=time.monotonic()-start);dest=P/('portable-audit-result.json'if'--export'in sys.argv else'acceptance-audit.json');dest.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
