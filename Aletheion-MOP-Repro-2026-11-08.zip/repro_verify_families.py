"""Portable family replay. Compact modes perform real leaf arithmetic.

The fast mode replays the named finite universal-cap certificates; it is not
the full global theorem. All writes go into an explicitly materialized tree.
"""
if not __debug__:
    raise RuntimeError('Assertions must remain enabled; do not use python -O')

from pathlib import Path
from fractions import Fraction as F
import argparse,hashlib,json,sys,shutil,time,subprocess,importlib.util
ROOT=Path(__file__).resolve().parent
def rd(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
FAST=[
 ('serial','work/mop-serial-turns-20261105/read_serial_turns.py'),
 ('wing','work/mop-triangle-wing-20261105/read_triangle_wing.py'),
 ('singular','work/mop-singular-turns-20261105/read_singular_turns.py'),
 ('firstturn','work/mop-first-turn-20261105/read_first_turn_fans.py'),
 ('mixed2','work/mop-mixed-q2-uniform-20261105/read.py'),
 ('mixed15','work/mop-mixed-q15-20-20261105/read_mixed.py'),
 ('fan19','work/mop-degree3-fan19-20261108/read_grams.py'),
 ('quantitative','work/mop-quantitative-trace-20261105/read_quantitative.py')]
def tree(args):
    dest=args.output/'f';dest.mkdir(exist_ok=True)
    for r in rd(ROOT/'REPRO_MEMBERS.json')['members']:
        rel=Path(r['relative']);assert not rel.is_absolute()and'..'not in rel.parts
        src=ROOT/rel;assert src.stat().st_size==r['bytes']and sha(src)==r['sha256']
        target=dest/rel;target.parent.mkdir(parents=True,exist_ok=True)
        if target.exists():assert sha(target)==r['sha256'],('Use a fresh output folder',rel)
        else:shutil.copyfile(src,target)
    return dest
def run(args,root,label,rel,seconds=900):
    start=time.monotonic();out=args.output/(label+'.stdout.txt');err=args.output/(label+'.stderr.txt');command=[sys.executable,'-B','-X','utf8',str(root/rel)]
    with out.open('w',encoding='utf8')as o,err.open('w',encoding='utf8')as e:
        p=subprocess.Popen(command,cwd=root,stdout=o,stderr=e)
        try:code=p.wait(timeout=seconds)
        except subprocess.TimeoutExpired:p.kill();code=p.wait();save(args.output/(label+'.process.json'),dict(command=command,pid=p.pid,exit_code=code,timed_out=True,seconds=time.monotonic()-start));raise
    meta=dict(command=command,pid=p.pid,exit_code=code,timed_out=False,seconds=time.monotonic()-start,stdout_file=str(out),stderr_file=str(err));save(args.output/(label+'.process.json'),meta);assert code==0,(label,err.read_text());print(label,'COMPLETE',meta['seconds'],flush=True)
def fast(args):
    root=tree(args)
    for label,rel in FAST:run(args,root,label,rel)
    save(args.output/'families_fast.json',dict(mode='FRESH_EIGHT_NAMED_FAMILY_READERS',entries=dict(FAST),scope='Actual mathematical reader executions, no database/native receipts; not fresh slow compact families and not a global theorem by itself.'))
def load(name,path):
    sys.path.insert(0,str(path.parent));spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def unary(args):
    root=tree(args);rel='work/mop-unary-parent-20261108/';p=root/rel
    for label,name in [('unary_floor','read_unary_floors.py'),('unary_physical','check_unary_physical.py'),('unary_grammar','check_unary_grammar.py')]:run(args,root,label,rel+name)
    m=load('repro_unary_math',p/'read_unary.py');cert=rd(p/'unary-certificate.json');grid=rd(p/'unary-frequency-grid.json');budgets=rd(p/'unary-budget.json')['rows'];rows={};floors=rd(p/'unary-floor-check.json')['private_reserves']
    assert cert['q_values']==m.QS and len(cert['cells'])==6
    assert all(F(budgets[str(q)]['private_reserve'])<=F(floors[str(q)])for q in m.QS)
    for q in m.QS:
        total=F(0);end=F(1,8);leaves=0
        items=cert['cells'][str(q)];assert len(items)==len(grid)
        for i,(row,item)in enumerate(zip(grid,items)):
            a,b=F(row['a']),F(row['b']);assert a==end and item['q']==q and item['index']==i;end=b
            target=F(budgets[str(q)]['amplitude'])/(1+((a+b)/2)**2);assert F(item['target'])==target
            area,n,anchor,fc=m.frequency(item['partition'],a,b,target,q);total+=area;leaves+=n;print('unary',q,i,leaves,flush=True)
        assert end==16;tail=sum((m.tail.tail(F(j,1024),F(j+1,1024),q)[1]/1024 for j in range(64)),F(0));gain=F(budgets[str(q)]['private_reserve'])-F(1,32)-2*(total+tail)/m.net.PI[0];assert gain>F(1,50)
        rows[str(q)]=dict(compact_upper=str(total),tail_upper=str(tail),surplus_lower=str(gain),numerical_leaves=leaves)
    save(args.output/'unary_full.json',dict(mode='FULL_FRESH_UNARY_SIX_q_ALL_p',rows=rows,no_stored_area_or_native_receipt_used=True))
def small_double(args):
    root=tree(args);rel='work/mop-double-child-20261108/';p=root/rel
    for label,name in [('small_floor','read_small_floors.py'),('small_physical','check_double_physical.py'),('small_grammar','check_small_grammar.py')]:run(args,root,label,rel+name)
    m=load('repro_small_math',p/'small_reader_v2.py');cert=rd(p/'small-v2-certificate.json');grid=rd(p/'small-frequency-grid.json');budget={(r['q'],r['r']):r for r in rd(p/'small-budget-v2.json')['rows']};floors=rd(p/'small-floor-check.json')['rows'];rows={}
    assert cert['ordered_pairs']==[list(z)for z in m.PAIRS]
    for q,r in m.PAIRS:
        total=F(0);end=F(1,4);leaves=0;key=str(q)+','+str(r);items=cert['cells'][key];assert len(items)==len(grid)
        floor=next(t for t in floors if(t['q'],t['r'])==(q,r));assert F(floor['base_private_energy_lower'])-(2*(q+r)+4)>F(budget[q,r]['private_reserve'])
        for i,(row,item)in enumerate(zip(grid,items)):
            a,b=F(row['a']),F(row['b']);assert a==end and(item['q'],item['r'],item['index'])==(q,r,i);end=b
            target=F(budget[q,r]['amplitude'])/(1+((a+b)/2)**2);assert F(item['target'])==target
            area,n,anchor,fc=m.frequency(item['partition'],a,b,target,q,r,m.model);total+=area;leaves+=n;print('small-double',q,r,i,leaves,flush=True)
        assert end==16;tail=sum((m.tail.tail(F(j,1024),F(j+1,1024),q,r)[1]/1024 for j in range(64)),F(0));gain=F(budget[q,r]['private_reserve'])-F(1,8)-2*(total+tail)/m.net.PI[0];assert gain>F(1,50)
        rows[key]=dict(compact_upper=str(total),tail_upper=str(tail),surplus_lower=str(gain),numerical_leaves=leaves)
    save(args.output/'small_double_full.json',dict(mode='FULL_FRESH_SMALL_DOUBLE_FOUR_PAIRS_BOTH_OUTERS',rows=rows,no_stored_area_or_native_receipt_used=True))
def external(args):
    root=tree(args)
    # Unchanged reader executes every numerical leaf. The 96-bit backend is
    # installed only in this separate process and cannot pollute tail192.
    run(args,root,'external_full','work/mop-finite-middle-20261108/read_middle_certificate.py',seconds=86400)
    save(args.output/'external_full.json',rd(root/'work/mop-finite-middle-20261108/middle-reader-result.json'))
def normalized_sign(args):
    root=tree(args);run(args,root,'normalized_sign','work/mop-normalized-sign-20261105/read_sign.py')
def main():
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['fast','normalized-sign','unary','small-double','external']);p.add_argument('--output',type=Path,default=ROOT/'family_results');a=p.parse_args();a.output=a.output.resolve();a.output.mkdir(parents=True,exist_ok=True);{'fast':fast,'normalized-sign':normalized_sign,'unary':unary,'small-double':small_double,'external':external}[a.mode](a)
if __name__=='__main__':main()
