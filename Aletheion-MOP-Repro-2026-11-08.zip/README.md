# Explicit mathematical reproduction package

This package accompanies the independent review and mathematical paper by Jonas J. Gebendorfer. `REPRO_MEMBERS.json` enumerates original sources/data and new replay code with relative paths, raw byte counts, and SHA256. It is a conservative explicit dependency closure, not a claim of minimum possible bytes. No database or previous full ZIP is included. Historical PASSs/absolute path inventories, where preserved as provenance, are not premises of the new mathematical replay commands.

Use Python3.12 with NumPy. The actual independent runs used CPython3.12.14 and NumPy2.3.5; standard-library rational/integer algorithms do not use floating eigenvalues as proof. Keep assertions on (no `python -O`); new drivers explicitly raise an error if optimization is enabled, and six such negative controls were checked. Frozen original validators require normal nonoptimized Python. Extract into a short path on Windows to avoid legacy MAX_PATH limits. Run the commands from the extracted root. Each copied family tree needs a fresh output folder; the manifest checker checks source bytes, not mathematics. `ARCHIVE_MEMBERS.json` indexes the complete archive except that self-index; `REPRO_MEMBERS.json` is the mathematical source/code subset.

```text
python -B repro_check_integrity.py
python -B repro_verify_finite.py quick --output finite_results
python -B repro_verify_finite.py positive --output finite_results
python -B repro_verify_finite.py masked --output finite_results
python -B repro_verify_finite.py assemble --output finite_results
python -B repro_verify_finite.py charge190 --output charge_results
python -B extraction_gamma3_verify.py
python -B extraction_gamma_tail_checks.py
python -B verify_coupled_bridge_244.py
python -B verify_removed_runs_244.py
python -B repro_verify_core.py c0 --output c0_results
python -B repro_verify_families.py fast --output family_results
python -B repro_verify_families.py normalized-sign --output sign_results
```

For one complete fresh B71 command use `python -B repro_replay_b71.py --output fresh_B71` **instead of** the four individual finite stages. It refuses an existing output directory and runs every finite mathematical stage before assembly, checking source hashes before/after. `assemble` alone is a composition check conditional on its five numeric inputs, not proof of their freshness from JSON names. In this review the component stages were actually run separately; the combined launcher was not used for an unnecessary second full replay.

The finite quick command checks B42, all29 degree envelopes,4,760 high-pair kernels,54,870 exterior ears and1,150 complements. Positive and masked commands recompute all328 and130 DP targets; stored target maxima are checked, not trusted as proof. The finite assembler requires **all five** fresh mathematical input result files and then recomputes all11,885 parameter rows. It has no native-parent or database requirement. Omitting a required input is an error, not a conditional success. The code and finite enumeration establish their explicit arithmetic domains; the paper proves why those domains cover the graphs.

The190 command executes the four exact original validators plus direct equality between freshly discovered residual(q,p,s) triples and the two initial exceptional sets. Gamma3 checks3,795,253 finite allocations; gamma4 checks286,769 profiles and rebuilds its literal integer tables and small Gram witnesses. The normalized sign includes144 PSD matrix jets/924 coefficient checks and actual-path controls. Its written all-index recurrence is part of the proof; a finite table alone would not imply all lengths. Quantitative trace similarly includes288 jets and256 scalar tail intervals with an independent polynomial reconstruction.

Full compact numerical replay commands (potentially many hours):

```text
python -B repro_verify_families.py unary --output unary_results
python -B repro_verify_families.py small-double --output small_results
python -B repro_verify_families.py external --output external_results
python -B repro_verify_core.py private --output private_results
python -B repro_verify_core.py double-compact --output double_results
python -B repro_verify_core.py double-tail --compact double_results/double_compact.json --output double_results
```

These compact commands evaluate the real interval bound at every accepted leaf, including selected double slab23. They do not accept stored compact areas or prior session receipts as numerical proof. **Use separate Python processes**: compact stages install rational_grid96, selected double tail uses the original default192 backend, and private tail stays96. No backend may be silently carried between stages.

Small independent controls:

```text
python -B repro_verify_core.py private --smoke --output smoke_results
python -B repro_verify_core.py double-compact --smoke --output smoke_results
python -B repro_verify_core.py double-tail --output tail_results
```

Private smoke checks only24+60 actual leaves; double smoke checks only eight leaves in slab23/first root. Neither proves the full family. The final command without `--compact` freshly computes all3,584 signed-tail intervals and28 budget inequalities, **conditional on the target compact upper bound**, not an independently proved compact bound.

Observed review timings: positive328370.36s; degree299.33s; early cover2.06s; high pair/ears31.61s; class payments0.77s; normalized sign1.72s; coupled gamma417.44s. Original private compact completion records766,777 leaves and26,494s (~7.36h). The original selected double composition retains284,102 completed source-bound numerical leaves. The review did not repeat those two multi-hour compact computations; it preserved their exact raw partitions, sources and original scoped results, completed true small numeric controls, and supplied the full arithmetic replay commands. No full fresh global replay is claimed.

All eight named family readers completed freshly: serial205.56s, wing4.31s, singular23.30s, firstturn1.16s, mixedq2 129.56s, mixed15..20 65.38s, fan19 .19s, quantitative .52s. All mathematical fields of the seven saved result objects agree with originals (only runtime/source-location fields excluded). Removed-run n4..9 calibration completed21.17s. Full masked130/29groups completed2331.39s (38.86min), including a fresh31/31 group; new full B71 composition completed4.98s. All five required-input omission controls and an altered actual-maximum control rejected. Thus the entire finite arithmetic recipe was freshly run; no fresh full global numeric replay is claimed. A final observed-scope index accompanies the completed package. Command availability, source identity, actual execution and mathematical truth are different claims.

Exact source variants are retained under `review_results/live_source_variants`: the running masked script stayed byte-identical to its preguard version until terminal; the guarded successor was copied afterwards. Its masked/payment/helper ASTs agree, and original DP kernels/targets never changed. The bounded-runner preguard bytes and exact diff are included. A launch-time hash of the whole earlier positive wrapper was not captured before unrelated modes were added; the record does not claim complete source-file identity for that launcher. Its mathematical positive/payment functions and original integer DP kernels remained unchanged.

The mathematical paper must still be read: finite/B71 reductions, published connected/cut-vertex/degree inputs, gamma reductions, rooted dual extraction, coherent reflections, retained root degrees, lossless Neumann and phase lift, residue and recurrence coverage, and the complete parent-role partition are not replaced by this archive or its hashes. See `repro-review.md` for exact old-checker findings and their original line locations.

The two general graph inputs were checked against their current primary statements: [Liu–Tang–Zhang, Theorem1.2](https://arxiv.org/html/2607.18031v1) gives both square energies at leastn−1 for every connected finite simple graph; [Akbari–Hu–Liu, Lemma2.5(2.11)](https://arxiv.org/html/2609.06778v1) gives the8/9 surplus gluing bound for two disjoint connected graphs, each of order at least2, with **both** gluing-vertex deletions connected. Their complete external proofs and the cited Lean kernel were not independently audited in this reproduction subtask.

A separate approximate counterobject search used522 starts in total:517 at large orders72,73,74,80,88,96,112,128, and5 one-start controls8,9,10,12,16. It made220,931 floating eigensolves and138,860 floating flip evaluations in285.05s, with no floating candidate below2n. These are operation counts, not distinct graphs or exhaustive coverage. The best retained large graph has n72; its independently verified integer Gram gives F−144 >=423972407978449381/36028797018963968 >0. All9 original source/data/terminal files (66,888bytes) are under `review_results/countersearch/`. Run its guarded exact reader with `python -B review_results/countersearch/phase_countersearch_verify_best.py`. The search is additional adversarial evidence, not a proof by sampling.
