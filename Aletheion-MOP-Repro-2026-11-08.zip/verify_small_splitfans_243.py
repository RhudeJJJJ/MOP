"""Ordered-composition coverage, independently rebuilt edges and row-Gram."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,copy
import numpy as np
ROOT=Path(__file__).resolve().parent

def compositions(total):
    # Each bitmask cuts the ordered q-vertex line into nonempty components.
    out=set()
    for mask in range(1<<(total-1)):
        parts=[];last=0
        for i in range(total-1):
            if mask>>i&1:parts.append(i+1-last);last=i+1
        parts.append(total-last);out.add(tuple(sorted(parts)))
    return out

def check(c,arrays):
    scale=c['scale'];assert type(scale)is int and scale>0
    assert set(arrays)=={r['key'] for r in c['rows']};score_values={};coverage={q:set() for q in range(1,13)}
    for r in c['rows']:
        q=r['q'];ls=tuple(r['lengths']);assert q==sum(ls) and r['p']==len(ls) and tuple(sorted(ls))==ls and ls not in coverage[q];coverage[q].add(ls)
        # Graph route: create each isolated component first, then cone it.
        E=set();v=1
        for l in ls:
            vertices=list(range(v,v+l));E.update((0,w) for w in vertices);E.update(zip(vertices,vertices[1:]));v+=l
        assert sorted(E)==list(map(tuple,r['edges'])) and len(E)==2*q-len(ls)
        W=arrays[r['key']];d=r['score'];assert W.dtype==np.int64 and W.shape==(q+1,d['columns']) and max(W.shape)*int(np.max(np.abs(W)))**2<2**63
        H=W@W.T;norm=sum(int(x)**2 for x in H.ravel());tr=sum(2*int(H[a,b]) for a,b in E);num=2*scale*scale*tr-norm;value=F(num,scale**4)
        assert str(norm)==d['norm_squared'] and str(tr)==d['signed_adjacency_trace'] and str(num)==d['score_numerator'] and str(value)==d['score'];score_values[r['key']]=value
    counts=[]
    for q,seen in coverage.items():assert seen==compositions(q);counts.append(len(seen))
    assert counts==c['partition_counts']==[1,2,3,5,7,11,15,22,30,42,56,77] and len(c['rows'])==271
    assert len(c['at_most_p_table'])==78;seen=set()
    for z in c['at_most_p_table']:
        q=z['q'];cap=z['path_component_cap'];assert 1<=cap<=q<=12 and (q,cap) not in seen;seen.add((q,cap))
        family=[r for r in c['rows'] if r['q']==q and r['p']<=cap];minimum=min(score_values[r['key']] for r in family);assert len(family)==z['family_count'] and minimum==F(z['lower'])==score_values[z['minimizer']]
    lookup={(r['q'],tuple(r['lengths'])):score_values[r['key']] for r in c['rows']}
    assert F(9999,10000)<lookup[1,(1,)]<=1 and F(39999,10000)<lookup[2,(2,)]<=4
    assert F(656,100)<lookup[3,(3,)]<F(6562,1000) and F(29999,10000)<lookup[3,(1,1,1)]<=3
    return counts

def main():
    c=json.loads((ROOT/'small-splitfans-243-certificate.json').read_text());archive=ROOT/'small-splitfans-243-witnesses.npz';assert hashlib.sha256(archive.read_bytes()).hexdigest()==c['archive_sha256']
    with np.load(archive,allow_pickle=False) as z:arrays={k:z[k] for k in z.files}
    counts=check(c,arrays)
    for damage in ('missing_partition','zero_factor','wrong_score'):
        bad=copy.deepcopy(c);weights=dict(arrays)
        if damage=='missing_partition':del bad['rows'][25]
        elif damage=='zero_factor':weights['g5']=np.zeros_like(weights['g5'])
        else:bad['rows'][5]['score']['score_numerator']='0'
        try:check(bad,weights)
        except AssertionError:pass
        else:raise AssertionError('Damage accepted:'+damage)
    v=dict(status='PASS_COMPLETE_SMALL_SPLITFAN_TABLE243',original='GLOBAL OPEN',certificate_sha256=hashlib.sha256((ROOT/'small-splitfans-243-certificate.json').read_bytes()).hexdigest(),archive_sha256=c['archive_sha256'],graphs=271,table_cells=78,ordered_compositions=4095,partition_counts=counts,controls=dict(known_K2_K3_Fan4_Star4_distinguished=True,missing_partition_zero_factor_wrong_score_rejected=True,whole_row_vs_column_Gram=True),scope='Allq<=12pathforests/atmostp lowerenergytable; notallgamma4/globalMOPclosure.')
    (ROOT/'small-splitfans-243-verification.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf8');print('PASS_SMALL_SPLITFAN_TABLE243 271forests/78cells/4095orderedcompositions',flush=True)
if __name__=='__main__':main()
