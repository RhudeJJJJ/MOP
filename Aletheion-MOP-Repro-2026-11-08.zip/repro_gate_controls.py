"""Omission and altered-number controls for the new standalone B71 gate."""
if not __debug__:
    raise RuntimeError('Assertions must remain enabled; do not use python -O')
from pathlib import Path
import argparse,subprocess,sys,json,time,shutil,hashlib
ROOT=Path(__file__).resolve().parent
FILES=['positive_fresh.json','masked_fresh.json','degree_fresh.json','early_fresh.json','high_fresh.json']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def run(output):
    command=[sys.executable,'-B','-X','utf8',str(ROOT/'repro_verify_finite.py'),'assemble','--output',str(output)];start=time.monotonic();r=subprocess.run(command,capture_output=True,text=True,encoding='utf8')
    return dict(command=command,exit_code=r.returncode,seconds=time.monotonic()-start,stdout=r.stdout,stderr=r.stderr)
def main():
    p=argparse.ArgumentParser();p.add_argument('--results',type=Path,required=True);p.add_argument('--output',type=Path,default=ROOT/'gate_controls');a=p.parse_args();a.results=a.results.resolve();a.output=a.output.resolve();a.output.mkdir(parents=True,exist_ok=True)
    assert all((a.results/name).is_file()for name in FILES)
    rows=[]
    for name in FILES:
        case=a.output/('omit_'+name.removesuffix('.json'));assert not case.exists(),'Use fresh control output folder';case.mkdir()
        for other in FILES:
            if other!=name:shutil.copyfile(a.results/other,case/other)
        result=run(case);assert result['exit_code']!=0 and name in result['stderr']and not(case/'finite_assembly.json').exists();rows.append(dict(omitted=name,**result))
    save(a.output/'repro_omission_all.json',dict(mode='ALL_FIVE_MATHEMATICAL_INPUT_OMISSIONS_REJECTED',cases=rows,source_result_sha256={n:sha(a.results/n)for n in FILES},driver_sha256=sha(ROOT/'repro_verify_finite.py')))
    case=a.output/'altered_actual_positive_maximum';assert not case.exists();case.mkdir()
    for name in FILES:shutil.copyfile(a.results/name,case/name)
    target=case/'positive_fresh.json';v=json.loads(target.read_bytes());before=v['rows'][0]['actual_maximum'];v['rows'][0]['actual_maximum']-=1;save(target,v);result=run(case);assert result['exit_code']!=0 and not(case/'finite_assembly.json').exists()
    save(a.output/'repro_bad_result_control.json',dict(mode='ALTERED_ACTUAL_MAXIMUM_REJECTED',original_actual_maximum=before,altered_actual_maximum=before-1,**result))
    print('ALL_FIVE_MATHEMATICAL_INPUT_OMISSIONS_AND_ALTERED_MAXIMUM_REJECTED')
if __name__=='__main__':main()
