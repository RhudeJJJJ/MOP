"""Separate direct allocation enumeration, rather than producer min-plus DP."""
from pathlib import Path
from fractions import Fraction as F
from math import isqrt,comb
import json,hashlib
ROOT=Path(__file__).resolve().parent
read=lambda n:json.loads((ROOT/n).read_text(encoding='utf-8-sig'))

def block(q,p,scale):
    m=q-p
    if not m:return F(q)
    shapes=[]
    for s in range(1,min(p,m)+1):
        l=m-s+2
        cap=(F(0),F(1),F(2),F(8,3),F(3))[l-1] if l<=5 else F(4)-F(16,(l+1)**2)
        trace=F(8*m-4*s,q)-F(4*m*m,q*q)
        r=isqrt((q**3+m*m)*scale*scale)
        assert r*r<=(q**3+m*m)*scale*scale<(r+1)**2
        value=F(q+m)-min(cap,trace)+F(2*m*m,q*q)+F(2*m*r,q*q*scale)
        shapes.append(value)
    return max(F(q),min(shapes))

def require_count(count):
    expected=sum(comb(P-1,2)*comb(n-1-P,2) for n in range(72,105) for P in range(3,8))
    assert count==expected
    return expected

def main():
    screen=read('domination-three-paths-189-screen.json')
    fine={(x['q'],x['p']):F(x['lower']) for x in screen['cells']}
    cells={}
    for q in range(1,100):
        for p in range(1,min(q,7)+1):
            assert fine[q,p]==block(q,p,10**6)
            cells[q,p]=block(q,p,10**5);assert cells[q,p]<=fine[q,p]
    rows=[];count=0;minimum=None
    for n in range(72,105):
        Q=n-3;best=None;arg=None;fine_best=None
        for pa in range(1,6):
            for pb in range(1,7-pa):
                for pc in range(1,8-pa-pb):
                    for qa in range(pa,Q-pb-pc+1):
                        for qb in range(pb,Q-qa-pc+1):
                            qc=Q-qa-qb;count+=1
                            value=cells[qa,pa]+cells[qb,pb]+cells[qc,pc]-2*n
                            exact_fine=fine[qa,pa]+fine[qb,pb]+fine[qc,pc]-2*n
                            assert value>0,(n,qa,qb,qc,pa,pb,pc,value)
                            if best is None or value<best:best=value;arg=((qa,pa),(qb,pb),(qc,pc))
                            if fine_best is None or exact_fine<fine_best:fine_best=exact_fine
        producer=next(r for r in screen['rows'] if r['n']==n and r['path_budget']==7)
        assert F(producer['margin'])==fine_best
        rows.append({'n':n,'margin':str(best),'blocks':arg})
        if minimum is None or best<minimum[0]:minimum=(best,n,arg)
    expected=require_count(count)
    try:require_count(count-1)
    except AssertionError:damaged=True
    else:raise AssertionError('Missing allocation accepted')
    ceilings={}
    for h in range(2,101):
        for triangles in range(h-1):
            loss=14*h-2-3*triangles;assert loss>=11*h+4>0
            threshold=F(2*h-1)+F(loss*loss,16)
            ceiling=-(-threshold.numerator//threshold.denominator)
            assert F(ceiling-1)<threshold<=ceiling
            if not triangles:ceilings[str(h)]=ceiling
    assert ceilings['3']==105 and ceilings['4']==190 and ceilings['21']==5370 and ceilings['22']==5896
    assert 49*21**2-6*21-3-4*5701<0<49*22**2-6*22-3-4*5701
    order71=read('order71-repaired-cover-verification.json')
    for name,sha in order71['dependency_sha256'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==sha
    source=read('aletheion-connected-triple-189-source.txt');packet=read('aletheion-packet-connected-triple-188.json')
    assert any(e['id']==3523 and e['content']==packet['essays'][0]['content'] for e in source['essays'])
    out={'status':'PASS_DIRECT_GAMMA3_PARAMETER_COVER_AND_GENERAL_TAIL',
      'range':[72,104],'allocation_cases':count,'expected_cases':expected,
      'minimum_margin':str(minimum[0]),'minimum_order':minimum[1],'minimum_blocks':minimum[2],
      'rows':rows,'missing_allocation_rejected':damaged,'tail0_ceilings':ceilings,
      'n5701_counterexample_gamma_at_least':22,'inherited71_hashes_current':True,
      'central188_exact_source_readback':True,'original':'GLOBAL OPEN',
      'independence':'Separate Fraction expression/direct enumeration, shared author and176/71 premises'}
    (ROOT/'domination-three-189-replay.json').write_text(json.dumps(out,indent=2)+'\n')
    print({k:v for k,v in out.items() if k not in ('rows','tail0_ceilings')},flush=True)
if __name__=='__main__':main()
