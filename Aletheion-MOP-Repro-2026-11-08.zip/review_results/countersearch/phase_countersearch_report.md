# Independent diagonal-flip counterobject attempt

The fresh search completed normally with owned session handle74196 and
terminal exit code0. Its fixed search budget was285 seconds; the measured
time including the final Gram certificate was285.04620649991557 seconds.
No other process was stopped or controlled. The executable search code,
complete best graph, result JSON, environment/code hashes and terminal
tool response are retained with the `phase_countersearch_` prefix.

The graph generator is newly written root-triangle recursion on literal
convex polygon intervals, with fan, balanced, zigzag, uniformly selected
pivot and endpoint-biased starts. It imports no project graph producer,
template, energy code or certificate. Subsequent mutations replace an
internal diagonal by the other diagonal of its two incident triangles.
Every flip has exactly two common neighboring vertices and a previously
absent replacement edge. Matrix eigensolves use NumPy only as a search
objective. The derivative of the positive-square energy ranks flips;
actual proposed matrices are then eigensolved, with energy-decreasing
and small annealing moves, a reversal tabu, and repeated fresh starts.

The actual scope was eight selected large orders72,73,74,80,88,96,112,128,
with five small controls8,9,10,12,16. Intermediate orders were not part
of this run. It performed522 starts,220931 floating eigensolves,
138860 floating flip evaluations,81548 accepted flips, and7495743
gradient-scored legal proposals. These are visits/evaluations, not a
count of distinct graphs; duplicates and isomorphic graphs were not
removed. The result JSON gives the exact per-order counts and best
observed floating values. No floating candidate below2n was encountered.

| Order | Starts | Energy-evaluated visits | Lowest observed float surplus |
|---:|---:|---:|---:|
|8|1|16|0.22473061167953645|
|9|1|20|0.57382173869415|
|10|1|148|0.9005645324851201|
|12|1|25|1.5353121721670355|
|16|1|25|2.63957310053118|
|72|66|16979|11.7676029162742|
|73|66|16378|11.886225252466318|
|74|57|15282|12.00400946760044|
|80|55|13249|12.694501943356329|
|88|65|18034|13.575416898748443|
|96|79|22546|14.416565226209514|
|112|62|17124|15.998353258028658|
|128|67|19556|17.469366578316794|

The retained best graph from the requested large-order range has72
vertices,141 edges, degree histogram{2:2,3:69,71:1}; it is a fan. Its
complete edge list is in `phase_countersearch_best_graph.json`.
Floating energy was155.7676029162742. A rounded spectral Gram factor
with72 rows,36 columns and scale16384 supplies an exact independent
lower bound. The separate pure-standard-library verifier checks the
literal polygon boundary, every edge, distinctness, noncrossing,
2n-3 edges and every integer factor entry, then recomputes with
unbounded integers

    splus(A) >= 2Tr(AX)-Tr(X^2),  X=YY^T/16384^2 >=0.

It confirms the exact lower bound

    5612119178709260773/36028797018963968

and exact positive margin over144

    423972407978449381/36028797018963968.

Its observed terminal exit code is0. This proves the target only for
that one retained graph. The other floating values are search
diagnostics. The run is neither an all-order proof, exhaustive coverage
of any order, a counterexample exclusion in unvisited regions, nor an
external human/formal review. A genuine under-target floating candidate
would have required an exact upper energy certificate; none arose.

Reproduce the deterministic exact check with ordinary Python3:

    python -B phase_countersearch_verify_best.py

The search uses the declared seed811202617 and a wall-time stopping
rule; a rerun can have a different evaluation count. Python3.12.14 and
NumPy2.3.5 were used. The complete retained graph and exact check are
independent of such timing differences.
