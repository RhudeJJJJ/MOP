"""Pure-stdlib verification of the retained single graph and its Gram score."""
if not __debug__:
    raise RuntimeError('Exact verifier requires assertions; Python -O is unsupported.')
from pathlib import Path
from fractions import Fraction
import json

P=Path(__file__).resolve().parent
g=json.loads((P/'phase_countersearch_best_graph.json').read_text(encoding='utf-8'))
n=g['n'];raw=g['edges'];edges={tuple(e)for e in raw}
assert len(raw)==len(edges)==2*n-3
assert all(isinstance(a,int)and isinstance(b,int)and 0<=a<b<n for a,b in edges)
assert all(tuple(sorted((i,(i+1)%n)))in edges for i in range(n))
for a,b in edges:
    for c,d in edges:
        assert not(a<c<b<d or c<a<d<b)
# These conditions imply a maximal triangulation of the convex n-gon.
cert=g['integer_gram'];s=cert['scale'];Y=cert['integer_factor'];r=len(Y[0])
assert isinstance(s,int)and s>0 and len(Y)==n
assert all(len(row)==r and all(isinstance(v,int)for v in row)for row in Y)
tr=2*sum(sum(Y[a][j]*Y[b][j]for j in range(r))for a,b in edges)
sq=0
for i in range(r):
    for j in range(r):
        x=sum(Y[a][i]*Y[a][j]for a in range(n));sq+=x*x
score=Fraction(2*tr,s*s)-Fraction(sq,s**4)
assert score==Fraction(cert['score'])
margin=score-2*n
assert margin==Fraction(cert['margin_over_2n'])and margin>=0
out={'status':'VERIFIED_ONE_LITERAL_MOP_AND_EXACT_GRAM_LOWER_BOUND',
     'n':n,'edges':len(edges),'factor_rank_columns':r,'scale':s,
     'exact_lower_bound':str(score),'exact_margin_over_2n':str(margin),
     'scope':'One explicit graph only. Float search statistics do not prove the global theorem.',
     'proof':'For X=YY^T/s^2 PSD and A Hermitian, 2Tr(AX)-Tr(X^2)<=sum_j max(lambda_j(A),0)^2; verify by diagonalizing A and maximizing each real diagonal variable, or PSD projection.'}
(P/'phase_countersearch_best_verification.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps(out))
