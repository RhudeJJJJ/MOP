"""Fresh counterobject search: polygon recursion, diagonal flips, NumPy proposals.

No imports of project graph constructors, energy routines or certificates.
Float eigensolves are search only.  An optional integer Gram lower bound
for the best full graph is evaluated with Python unbounded integers.
"""
import os
for _name in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS',
              'BLIS_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):
    os.environ[_name] = '1'
from pathlib import Path
import json, random, time, math
from fractions import Fraction
import numpy as np

HERE=Path(__file__).resolve().parent
OUT=HERE/'phase_countersearch_result.json'
BEST=HERE/'phase_countersearch_best_graph.json'
SEED=811202617
rng=random.Random(SEED)
started=time.perf_counter()
deadline=started+285.0
counts={'starts':0,'float_eigensolves':0,'flip_proposals_scored':0,
        'float_flip_evaluations':0,'accepted_flips':0,'restarts':0}
by_order={}
best=None
candidates=[]

def pair(a,b):return (a,b) if a<b else (b,a)

def triangulate(n,kind):
    """Root triangle recursion on literal convex polygon intervals."""
    E={pair(i,(i+1)%n) for i in range(n)}
    def recurse(a,b):
        if b-a<2:return
        if kind=='fan':k=a+1
        elif kind=='balanced':k=(a+b)//2
        elif kind=='zigzag':k=a+1 if (a+b)%2 else b-1
        elif kind=='uniform_pivot':k=rng.randrange(a+1,b)
        else:
            # Concentrate at polygon ends while keeping fresh random pockets.
            k=(a+1 if rng.random()<.5 else b-1) if rng.random()<.75 else rng.randrange(a+1,b)
        E.add(pair(a,k));E.add(pair(k,b))
        recurse(a,k);recurse(k,b)
    recurse(0,n-1)
    assert len(E)==2*n-3
    return E

def matrix(n,E):
    A=np.zeros((n,n),dtype=np.float64)
    for a,b in E:A[a,b]=A[b,a]=1.
    return A

def spectrum(A,vec=False):
    counts['float_eigensolves']+=1
    if vec:
        d,V=np.linalg.eigh(A)
        energy=float(np.dot(d[d>0],d[d>0]))
        gradient=2*(V*np.maximum(d,0))@V.T
        return energy,d,V,gradient
    d=np.linalg.eigvalsh(A)
    return float(np.dot(d[d>0],d[d>0]))

def validate(n,E):
    assert len(E)==2*n-3 and all(0<=a<b<n for a,b in E)
    assert all(pair(i,(i+1)%n) in E for i in range(n))
    for a,b in E:
        for c,d in E:
            assert not(a<c<b<d or c<a<d<b)
    return True

def options(n,E,grad):
    neighbors=[set() for _ in range(n)]
    for a,b in E:neighbors[a].add(b);neighbors[b].add(a)
    result=[]
    for a,b in E:
        if b==a+1 or (a==0 and b==n-1):continue
        common=neighbors[a]&neighbors[b]
        assert len(common)==2
        c,d=sorted(common)
        assert pair(c,d) not in E
        score=2*(grad[c,d]-grad[a,b])
        result.append((float(score),a,b,c,d))
    counts['flip_proposals_scored']+=len(result)
    result.sort()
    return result

def remember(n,E,energy,kind):
    global best
    surplus=energy-2*n
    row=by_order.setdefault(str(n),{'starts':0,'evaluated':0,'best_surplus':float('inf')})
    row['evaluated']+=1
    if surplus<row['best_surplus']:row['best_surplus']=surplus
    if best is None or (n>=72 and best['n']<72) or ((n>=72)==(best['n']>=72) and surplus<best['float_surplus']):
        validate(n,E)
        best={'n':n,'edges':[list(e) for e in sorted(E)],
              'float_energy':energy,'float_surplus':surplus,
              'origin':kind,'elapsed_seconds':time.perf_counter()-started}
        BEST.write_text(json.dumps(best,indent=2)+'\n',encoding='utf-8')
        print(json.dumps({'event':'new_best','n':n,'surplus':surplus,
                          'elapsed':best['elapsed_seconds']}),flush=True)
    if surplus< -1e-7:
        p=HERE/f'phase_countersearch_candidate_{n}_{len(candidates)}.json'
        p.write_text(json.dumps({'n':n,'edges':sorted(E),'float_energy':energy},indent=2)+'\n')
        candidates.append(str(p))
        print(json.dumps({'event':'FLOAT_CANDIDATE_REQUIRES_EXACT_CERTIFICATE','path':str(p)}),flush=True)
        return True
    return False

orders=[8,9,10,12,16,72,73,74,80,88,96,112,128]
kinds=['fan','balanced','zigzag','uniform_pivot','end_biased']
iteration=0
while time.perf_counter()<deadline and not candidates:
    # First complete every declared order; then emphasize the requested range.
    n=orders[iteration] if iteration<len(orders) else rng.choice(orders[5:])
    kind=kinds[(iteration//len(orders))%len(kinds)] if iteration<len(orders) else rng.choice(kinds)
    E=triangulate(n,kind);A=matrix(n,E)
    energy,d,V,grad=spectrum(A,True)
    counts['starts']+=1;by_order.setdefault(str(n),{'starts':0,'evaluated':0,'best_surplus':float('inf')})['starts']+=1
    if remember(n,E,energy,kind):break
    tabu=set()
    # Gradient ranks flips; each considered mutation is evaluated spectrally.
    # At a local basin, permit a bounded small uphill move, then cool again.
    temperature=.18 if iteration>=len(orders) else .04
    stale=0
    for step in range(220 if n>=72 else 80):
        if time.perf_counter()>=deadline:break
        opts=options(n,E,grad)
        shortlist=opts[:min(8,len(opts))]
        rng.shuffle(shortlist)
        chosen=None
        for score,a,b,c,d0 in shortlist:
            if pair(a,b) in tabu:continue
            A[a,b]=A[b,a]=0.;A[c,d0]=A[d0,c]=1.
            proposal=spectrum(A)
            counts['float_flip_evaluations']+=1
            A[a,b]=A[b,a]=1.;A[c,d0]=A[d0,c]=0.
            remember(n,E-{pair(a,b)}|{pair(c,d0)},proposal,kind)
            if candidates:break
            gain=proposal-energy
            if gain < -1e-10 or (temperature>0 and rng.random()<math.exp(-max(gain,0)/temperature)):
                chosen=(a,b,c,d0,proposal);break
        if candidates:break
        if chosen is None:
            stale+=1
            if stale>=3:break
            temperature*=1.7
            continue
        a,b,c,d0,energy=chosen
        E.remove(pair(a,b));E.add(pair(c,d0));A[a,b]=A[b,a]=0.;A[c,d0]=A[d0,c]=1.
        counts['accepted_flips']+=1
        tabu={pair(c,d0)} # forbid immediate reversal only
        energy,d,V,grad=spectrum(A,True)
        temperature*=.985
        stale=0
    iteration+=1;counts['restarts']=iteration-1
    if iteration%10==0:
        print(json.dumps({'event':'progress','starts':counts['starts'],
                          'eigensolves':counts['float_eigensolves'],
                          'seconds':time.perf_counter()-started}),flush=True)

def gram_certificate(graph):
    n=graph['n'];E={tuple(e)for e in graph['edges']};A=matrix(n,E)
    energy,d,V,grad=spectrum(A,True)
    s=16384
    # YY^T/s^2 is positive semidefinite for the integer matrix Y.
    mask=d>0
    Y=np.rint(s*(V[:,mask]*np.sqrt(d[mask]))).astype(np.int64)
    rows=[[int(v)for v in row]for row in Y.tolist()]
    r=len(rows[0])
    # All certificate score operations use Python's unbounded integers.
    traceAX=2*sum(sum(rows[a][j]*rows[b][j]for j in range(r))for a,b in E)
    square=0
    for i in range(r):
        for j in range(r):
            v=sum(rows[a][i]*rows[a][j]for a in range(n));square+=v*v
    score=Fraction(2*traceAX,s*s)-Fraction(square,s**4)
    margin=score-2*n
    cert={'scale':s,'integer_factor':rows,'score':str(score),
          'margin_over_2n':str(margin),'proves_target_for_this_graph':margin>=0,
          'rationale':'For X=YY^T/s^2 PSD, splus(A)>=2Tr(AX)-Tr(X^2). All score sums use Python integers.'}
    return cert

if best is not None:
    best['integer_gram']=gram_certificate(best)
    BEST.write_text(json.dumps(best,indent=2)+'\n',encoding='utf-8')
result={'status':'FLOAT_CANDIDATE_PENDING_EXACT_REVIEW'if candidates else 'NO_FLOAT_COUNTEROBJECT_FOUND_IN_DECLARED_SEARCH',
        'seed':SEED,'search_time_budget_seconds':285,'elapsed_seconds':time.perf_counter()-started,
        'counts':counts,'by_order':by_order,'best_graph_file':BEST.name,'float_candidates':candidates,
        'scope':'Finite stochastic/adversarial search, not a proof in any order and not external human review. No project producer templates or energy routines imported.',
        'generator':'Fresh root-triangle recursion on convex polygon intervals; all search mutations are legal two-triangle diagonal flips.',
        'acceptance':'Floating energy is only a search objective. Integer Gram is an exact lower bound for the single retained best full graph.'}
OUT.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result),flush=True)
