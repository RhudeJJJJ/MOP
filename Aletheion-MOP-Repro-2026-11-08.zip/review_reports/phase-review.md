# Independent adversarial review: Rootball and Lossless phase bridge

8 November 2026. Reviewed by a separate mathematical-review agent. This is
an independent derivation within the same AI-assisted workflow, not an
independent human referee report or formal-assistant certification. No
central Aletheion state or original source was changed.

## Conclusion

No fatal mathematical gap or counterexample was found in the stated
two-root sector, enlarged-rootball, sharp 2-by-2 determinant-phase,
same-root energy identity, or Lossless positive-ray monotonicity theorem.
Their signs, adjoints, factors of t and pi, nonvanishing conditions and
lifted-phase normalizations survive an independent derivation.

One small but precise calibration-scope defect should be corrected before
submission. A further explicit boundary example prevents an unjustified
extension of the tail argument. Neither finding contradicts the global
energy statement or invalidates the correctly scoped core phase theorem.
This review does not verify every numerical integration leaf or the
separate all-order graph extraction.

## F1. The printed over-pi tuple is not a coupled Rootball tuple

**Location:** `work/mop-net-phase-20261106/net-phase-proof.md:210-212`;
the corresponding comment is `work/mop-net-phase-20261106/checks.py:45`.

**Exact old phrase:**

> with A=(3+4i)I and the sharp singular values3/5,4/5 has lifted phase>pi

The code comment says:

> A=(3+4i)I and the sharp sigmas3/5,4/5 give det(I+UW)=12i/25.

**Counterfinding.** The coupled definitions are A=I+cL and W=rho L A^-1.
If A is scalar, L=(A-I)/c and W are scalar. Both singular values must be
equal. Thus the specified scalar A and unequal pair(3/5,4/5) cannot be
one jointly admissible(A,L,W) tuple. The separate multiplication of two
phase contributions in the old control remains valid as an UNCOUPLED
branch-aggregation test. It must not be described as a coupled Rootball
or physical-graph control. The universal proof does not use this control
as a premise, and the certificate arithmetic using actual A,L,W is not
changed by this finding.

**Fully admissible replacement, retaining the old A.** At t=1 let
K=[[2,1],[1,2]], F=4iK and H=((1+i)/2)K^-1. Then

- Wplus(F)=2ReF+ImF=4K>0;
- 2ReH-ImH=H*KH=(1/2)K^-1, so H is on the enlarged Rootball boundary;
- L=4iI, c=1-i/2, A=I+cL=(3+4i)I;
- both squared singular values of W are4/5;
- I+HF=(-1+2i)I, with determinant-3-4i;
- the lifted phase is2pi-2atan2>pi, while the principal determinant
  argument is negative.

All entries of F and H are rational complex numbers. This is an
ALGORITHMIC/ALGEBRAIC enlarged-sector example; it does not assert that F
and H are responses of an actual MOP. In fact ReF=0 with F nonzero rules
out a nonempty physical finite cap response at t>0.

**Canonical source requiring a narrow correction:**
`math:mop:net-root-phase:sourcepart0:20261106`, field`body`, contains BOTH
exact phrases above. The source header is
`math:mop:net-root-phase:proofsource:20261106`. The theorem claim
`math:mop:net-root-phase:bound:20261106` remains mathematically valid;
its proof/certificate scope should be retained. A correction should revise
only the interpretation of the example and supply the consistent tuple.

**Suggested exact successor effect:**
“The old scalar A=(3+4i)I with unequal singular values(3/5,4/5) is valid
only as an uncoupled phase-aggregation test, not as one jointly admissible
(A,L,W) Rootball witness. A consistent algebraic witness is t=1,F=4iK,
H=((1+i)/2)K^-1, for which A=(3+4i)I and BOTH squared singular values
are4/5; its lifted phase is2pi-2atan2>pi and its determinant has negative
principal argument. The universal phase/Lossless theorems and existing
actual numerical certificate inequalities are unchanged.”

## F2. Sector membership alone does not imply a finite infinite-tail bound

**Locations:** `work/mop-fork-fan-20261106/fork-fan-proof.md:164-192`
extends the pointwise theorem to arbitrary algebraic sector responses;
`work/mop-net-phase-20261106/net-phase-proof.md:155-160` claims a decaying
tail for physical finite B,T. These statements have different domains.

For gamma>0 consider F(t)=-gamma K/(t+2i). It has Wplus(F)=0 for every
t>0. With a=gamma/(2t), A=(1+ia)I and both singular values of W are
a/sqrt(1+a²). Hence b(F,t)=4atan a, and t*b(F,t) tends to2gamma.
The integral of t*b therefore diverges at infinity.

This is a counterexample to the UNSTATED extension “every sector response
has an integrable phase envelope”, not to the actual physical-cap claim
at lines155-160. Arbitrary lossless shaving preserves the pointwise
sector and monotonicity but can destroy tail integrability. Every actual
normalized certificate must retain its specific positive leading matrix,
norm/Gram estimates and whole-cell infinite-tail proof. The supplied
paper section states this boundary explicitly.

## Independently checked universal steps

1. **Physical sector201.**
   `work/mop-private-sibling-middle-20261108/inherited/port_sector_201_proof.txt:21-101`.
   The union of the two boundary-neighbor paths meets at the unique common
   neighbor. An exclusive cross-edge would force an induced4cycle.
   Pocket separation follows from noncrossing closing chords. Eliminating
   pockets produces the SAME unit path and actual child corrections.
   The two simultaneous inequalities at lines76-91 require the OPPOSITE
   child sign, and the inverse congruence gives the asserted parent sign.
   Rank-two contacts make strictness valid exactly for order>=4.

2. **Square completion and noncommuting contraction.**
   `net-phase-proof.md:28-48`. The center is c=1/t-i/2. The identity
   A*A-rho²L*L=I+2ReL/t+ImL is correct without commutation. It gives
   I-W*W=A^-*(A*A-rho²L*L)A^-1>0 and hence strict ||W||<1.

3. **Sharp contraction determinant lemma.**
   `net-phase-proof.md:52-94`. The SVD substitution preserves the whole
   contraction ball. Harmonic maximum first puts the two singular-radius
   variables on the unit torus. The determinant ellipse avoids zero and
   the negative real axis because I+UD is strictly accretive. Its boundary
   is diagonal U; the two scalar tangent angles optimize independently.
   Degenerate ellipses, zero/equal singular values and nonnormal matrices
   are covered. The filled-ellipse argument is sound in dimension two.

4. **The phase lift, rather than product principal argument.**
   `net-phase-proof.md:98-116`, `fork-fan-proof.md:184-188`.
   Nonvanishing holds on the convex sector and the convex Rootball.
   Their product is simply connected, so a continuous phase normalized
   at F=0 exists globally. The factor phases agree modulo2pi and agree
   exactly at F=0, hence add exactly throughout the radial path. This
   makes the original short continuity argument rigorous without choosing
   independent principal arguments for a determinant product.

5. **Inverse invariance and the Lossless derivative.**
   `net-phase-proof.md:142-151`, `fork-fan-proof.md:175-188`.
   H invertible in the ball implies2Re(H^-1)+tIm(H^-1)>=tK. Adding any
   sector F preserves that inequality, and determinant nonvanishing
   supplies the new inverse even when its real part is not positive.
   For P=vv^T/(t+2i), d/ds phase=Im(v^T H_s v/(t+2i))<=0.
   Taking the maximum AFTER the pointwise inequality is legitimate.
   Singular H are limits of invertible points inside the ball, and the
   normalized phase is continuous. No derivative of a maximizing H(s)
   is used or needed.

6. **Energy signs/constants.**
   `net-phase-proof.md:118-129` and
   `work/mop-negative-modes-20261105/full-cap-matrix-disk-proof.md:93-111`.
   The exact graft determinant ratio has a PLUS Schur correction because
   the offdiagonal blocks are iT and iT^T. The two compared spectra have
   equal trace. Integrating t*atan(lambda/t) cancels the linear terms and
   gives -pi*lambda*|lambda|/4. The trace-square increase is2Tr(TT^T),
   yielding Delta splus=splus(B)+Tr(TT^T)-(2/pi)integral t*delta.
   The low-frequency cost below epsilon is2epsilon². Private negative
   and zero modes remain in the full response.

## Deliverables and reproducibility

- `phase_section.tex`: full English journal-style derivation with all
  source201 induction, square completion, sharp phase lemma, lifts,
  inverse invariance, Lossless rays, linear-support dominance, energy
  constants and the corrected consistent example. Labels use`phase:`.
- `phase_exact_checks.py`: standard-library Fraction implementation for
  exact complex2x2 matrices. No NumPy/SymPy or floating arithmetic.
- `phase_exact_checks.json`: observed successful result. It checks the
  consistent over-pi tuple, exact noncommuting A/W identities, inverse
  congruence, and exact negative Lossless derivatives at three rational
  nodes. Those nodes are diagnostics; the universal derivative sign is
  proved analytically in the TeX section.

Run with ordinary Python3:

    python -B phase_exact_checks.py

Source files reviewed were read directly. PASS/status/hash strings were
not used as substitutes for the mathematical derivations. No source in
the earlier frozen computation or Aletheion was edited by this review.

## Additional submission sections completed during this review

### The twelve used C0 kernels

`c0_section.tex` proves the matrix lemma for every finite Hermitian far
matrix C and each ordered Gram matrix G(r,1), r=3,...,14. The far matrix
need not preserve the two-dimensional contact subspace: compressing its
unitary Cayley transform gives a contraction on that subspace. This is
the reason the two-dimensional sharp phase lemma applies; no unproved
simultaneous diagonalization or extra norm restriction on C is used.
The branch constant is fixed by X=sI tending to positive infinity.

The compact quadrature differentiates the SAME actual common-source
phase, not its optimized pointwise upper envelope. The spectral-shift
function lies in [0,2]; the resulting derivative and midpoint errors are
uniform in C. The complete tail retains the negative root term -4/t^3.
Dropping that term would fail to establish the stated gain.

After reading the original proof, reader and its arithmetic modules,
`phase_c0_replay.py` copied thirteen byte-identical required inputs to
`phase_c0_replay/` and ran the copied reader there. The observed terminal
exit code was zero; all 2304 rational node bounds and all non-timing
mathematical output fields were identical to the frozen source result.
The exact minimum certified gain is
131605851646082517349/32115916800000000000 (at r=14), strictly exceeding
409/100. Process metadata and result comparison are retained separately
in `phase_c0_replay_process.json` and `phase_c0_replay_result.json`.
This is a fresh isolated reproduction using the same arithmetic kernel,
not a claim that a second independently authored kernel was implemented.
The appendix supplies the mathematical semantics of those certificates.

### Hereditary retirement after actual induced deletions

`retirement_section.tex` derives both root-sector signs for chordal
outerplanar graphs with one root or two adjacent roots, including bridges,
cut vertices and isolates. It does not reuse the rank-two boundary-root
strictness assertion on an arbitrary internal edge. Strictness for a
nonisolated single root is sufficient for the scalar retirement bound.

The complete integral is evaluated by a logarithmic-derivative residue
identity. Root multiplicities are retained, including the repeated-root
case D=27. The exact bound R(D) is determined by
R(D)(R(D)-D)^2=4D^2 and R(D)>D. The two constants actually used in parent
payments follow from rational polynomial excesses 711/8000 and
3151/125000, giving R(3)<111/20 and R(4)<351/50. The scope is the actual
degree at the particular retained induced deletion; an earlier degree
before a different deletion cannot be substituted. No further adverse
finding was identified in these two analytic dependencies.
