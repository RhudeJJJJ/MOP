# Adversarial review of the new submission draft

Scope: root's newly written `output/paper/sections/payments_section.tex`,
`finite_section.tex`, `dp_section.tex`, and the priority low-frequency
argument in `branch_section.tex`. Review files only were edited. Draft
line references describe the version read on2026-11-08; later line
numbers may move. These notes are not an acceptance based on old PASS
strings or a claim that every finite certificate has been independently
implemented twice.

## P1. Genuine missing premise in the new branch-low argument

**Location:** `output/paper/sections/branch_section.tex:135-146`.
The old text asserts `delta<2 arctan(2/t)` and says:

> each of the two root matrices Z0 and Z1 is accretive, and their sector
> bounds imply that the eigenvalue arguments of the corresponding
> normalized inverse factors lie within the two-root angular sector of
> half-width arctan(2/t). Equivalently, applying the same root-ball
> factorization ... gives this bound.

The stated premise alone bounds each two-dimensional trace phase in
(-2theta,2theta), so it only bounds their difference by4theta. The
claimed factor2 does not follow. This is a missing derivation in the
new draft, not a counterexample to the completed source result.

The exact source distinction is explicit:

- `work/mop-refined-debt-20261105/refined-debt-proof.md`, section2,
  uses both sectors alone and obtains4atan(2/t).
- `work/mop-normalized-sign-20261105/normalized-sign-proof.md:34-130`
  separately proves the all-length matrix sign ImFstar<=0 with144
  PSD-polynomial jets and an all-index generating-function recurrence.
- The latter source at lines132-149 then proves the factor2 by inertia.
  The later quantitative-trace source uses that theorem as an inherited
  premise; its288 scalar coefficient jets do not replace the144 matrix
  jets for this missing sign.

**Complete repair:** `normalized_sign_section.tex` supplies both the
144-jet sign lemma and the low-phase proof. If Hj=ImZj, then H1<=H0.
Let m=nminus(H0), r=nplus(H1). Their signed subspaces cannot intersect,
so m+r<=2. The two sector bounds put the generalized Hermitian imaginary
eigenvalues in(-2/t,2/t). Thus phaseZ0>=-m theta and phaseZ1<=r theta,
strict if the respective inertia is nonzero. Their difference is less
than2theta; if both inertias vanish it is<=0. The argument uses the
continuous accretive trace phase and retains the same old graph.

The repair must be accompanied by the complete finite proof objects
`normalized-sign-jets.json` and `read_sign.py` and the reader's transitive
arithmetic dependencies. The helper has144 polynomial matrices and924
coefficient matrices. A proof-text-only bundle would leave the finite
premise unverified. The exact reader checks u,w>=0 and uw-v^2>=0 on
each symmetric coefficient, reconstructs the full index set and actual
adjacency adjugates, and rejects missing/altered jets.

## P2. Bowtie literal graph is underspecified

**Location:** `payments_section.tex:120-123`. It names hub c and lists
only the private edges x1x2,y1y2. The spectrum subsequently stated is
the graph with the additional four edges cx1,cx2,cy1,cy2. If the listed
edges alone are read literally, the private graph is two disjoint
edges and an isolate, and the displayed spectrum is false. State all
six edges explicitly. The intended bowtie spectrum and projector
calculation are compatible with the six-edge graph; this is a definition
repair in the new draft.

## P3. Finite-rule count equation has a TeX transcription error

**Location:** `finite_section.tex:273-275`.
The literal expression is
`3718,quad932,quad4049,quad527,quad2201,quad328,quad130`.
Six `quad` strings are missing their backslashes. The seven integers
sum to11885; this is a typesetting error, not a changed partition count.

## Analytic formulas directly checked so far

The following checks are independent derivations of the equations,
not blanket approval of every associated finite result:

- `payments_section.tex:45-103`: the scalar mode ball, p/X substitution,
  positive-phase quadratic inequality, integrated penalty coefficient,
  and complete-eigenspace grouping are consistent. Nonpositive modes
  can be installed first by pinching. The metric for b>=2 is
  sigmaI+J, but its penalty is zero, so the subsequent K^-1 definition
  of the unused zeta in that case does not change the bound.
- Lines135-173: metric-dependent support and its trace-norm invariant
  expression are correct, including the mixed determinant and the
  two radicands. The support is nonincreasing because the enlarged
  root balls are nested as the metric increases.
- Lines213-255: the continuant signs, endpoint responses, coronal
  identity, Wronskian and rationalized residue-four curve are correct
  for t>0, including the j=1 doubled endpoint convention.
- Lines257-335: the sparse resolvent expansion and both signed A/M
  formulas agree algebraically. The rationalized tail density,
  positivity floors and centered off-diagonal resolvent estimate are
  consistent. The statement requires A positive definite on every
  entire tail cell; sector positivity alone does not replace it.
- Lines398-550: the displayed mixed/unary/sibling Schur matrices and
  ordered contacts agree with eliminating the stated paths. Their
  transposes are ordinary transposes of symmetric complex matrices.
- Lines554-646: the coronal recurrence and bordered determinant
  identity are consistent. The claimed blanket p=1 phase comparison
  is explicitly avoided where the signed polynomial is negative.
- `finite_section.tex:18-132`: the moment identities, exact threshold,
  contact-square count, three M2 bounds, residual M2 bound and hub
  inequality agree by direct expansion. In particular the residual
  correction yields exactly -k-5-2S/d+6/d^2, not an edge-monotonicity
  assumption.
- `dp_section.tex:1-148`: the polygon degree interface, shared degree
  u+w, unmasked future state, completed residual degree cap d-1,
  exact candidate masks and identical-mask merging are logically
  consistent. The zero-mask theorem is conditional on the stated
  degree cap and on absence of a dominating triangle through the hub;
  its complements are required for the finite theorem.

Review is continuing on the remaining finite-domain and graph-constructor
claims. The priority repair P1 is necessary before claiming that the
current branch appendix independently proves its184/157 debt.

## Completion of the displayed-formula audit

The appended double-parent text was read through its final large-middle
payment (draft `payments_section.tex:785-924`). Its three-head Schur
matrix, scalar eta elimination, defect columns, rotated Gram
diag((2m+9)/3,3), and leading matrix diag(4/3,2) agree algebraically.
The two outer rays leave precisely the displayed Q. The large-middle
partition removes/retire-counts c exactly once and has the correct
private leaf count. At line811 another literal `,quad v_b` needs a
backslash; the eta reciprocal itself is correct.

The remainder of `finite_section.tex:180-480` and all of
`dp_section.tex` were read. Direct expansions confirm the balanced
gluing coefficient496/567, the histogram threshold
1359n/32-729/2+441/n, adjacent/nonadjacent pair thresholds, and the
literal core constructor degrees/orders. The positive pair reserve
calculations have the stated constants. An exact standard-library
Fraction check completed with exit code0 and returned:

- Seven finite-rule counts sum to11885.
- Listed base Gram counts, including15 split fans at q=28, sum to4760.
- The q=32 full-fan Rayleigh margin is36368919.
- The four q=29 split-fan Rayleigh margins N^2-41D^2 are
  381879703,64799927,17506375,14659079, all positive.
- The single-gap L=21 margin is664/441.
- The q=33 full-fan compression margin is4375/1089.
- The q=30 split-fan product is10976/75=32928/225, exceeding144.

No additional mathematical counterfinding was identified in these
displayed formulas and graph interfaces. This statement does not
independently certify the large stored interval trees or finite Gram
factor files: their complete executable reproduction remains the
separate supplement verification obligation. In particular P1 cannot
be resolved by successful scalar288-jet replay alone; the144 matrix
jets are a distinct necessary input to the sharp low-phase argument.
