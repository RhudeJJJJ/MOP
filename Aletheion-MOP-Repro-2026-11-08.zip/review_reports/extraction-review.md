# Independent adversarial review: rooted geometry and parent extraction

Review date: 8 November 2026. Reviewer: a separate Codex review agent,
with an independently written combinatorial implementation. This is not
independent human peer review and is not a certification of the numerical
energy lemmas or the rootball/lossless phase bridge.

## Outcome and exact boundary

No fatal mathematical counterexample or missing structural case was found
in the parent extraction **conditional on the precisely stated energy
inputs**. The all-depth tree argument, rooted chord separation, first-turn
geometry, four child-apex patterns, ordered tip degree calculations and
whole-small-old domination argument have valid written repairs/expansions
in `extraction_section.tex`. The component has no imports from the prior
calibration/model code. The original frozen sources were not modified.

The review does **not** establish the entire global theorem by itself.
Its structural result requires B71, the independent whole domination-four
theorem, the short first-turn payments, the twelve ordered C0 kernels,
the literal Type B theorem, the positive-mode filter, the mixed payments,
and degree-three fan19. These must be proved, with their full hypotheses,
in the paper or reproducible appendices. PASS metadata alone does not
discharge these mathematical dependencies.

## Findings with exact locations

### E-01. A child is confused with its whole branch cap

**Location:** `work/mop-global-closure-20261108/global-proof.md:145-147`.
The text says that the two children of deepest branch X have the
representation E_(p,q). Each child is a straight fan; **X's whole closed
cap**, consisting of X's triangle and both children, is E_(p,q).

**Severity:** repairable statement/notation error, not a counterexample to
the intended extraction. The underlying source already says the right
thing at `work/mop-parent-extraction-20261108/parent-extraction-proof.md:21-23`.

**Repair:** define fan caps explicitly and state the whole-cap identification.
The supplied `ext:definitions` and `ext:parent-trichotomy` do this.

### E-02. The first-turn step is an outline, not the requested no-leaps lemma

**Locations:** `global-proof.md:88-99`,
`normalization-shortcut-proof.md:40-56` (both under the work folders above).
The latter contains the right local orientation argument, but the main
proof does not spell out why a one-triangle choice is ambiguous, why the
first genuine turn has L>=3, why its private matrix is an induced fan,
why only three external contacts survive, and why an entire dual path
does not receive a smaller-graph induction hypothesis.

**Severity:** exposition/self-contained-proof gap, with a direct repair;
no geometric counterexample was found. The supplied first-turn signature
proves these facts for arbitrary path length. The terminal normalization
then treats L3..7 by actual old-parent payments, L>=8 by two induced MOP
blocks or whole domination, and the entire-path graph by domination one.

### E-03. Path notation and rooted-fan notation must be distinguished

**Locations:** `global-proof.md:104` uses P_p/P_q for ordinary private paths,
whereas `global-proof.md:151,188` uses P_ell for a rooted fan cap. No formal
definition in that file distinguishes the two. This is especially dangerous
for the private graph c join(P_p disjoint P_q), which is not itself a MOP.

**Severity:** publication-level definition ambiguity, not evidence that the
actual operators or certificates used the wrong graph. In the supplied
section, ordinary paths are P_k and rooted fans are mathsf P_ell. All
operators, apex choices, vertex counts, outer arcs, closedness and coherent
reflection are defined before use.

### E-04. The grouped C0 occurrences need their literal tip orientation

**Locations:** `global-proof.md:179-184,202-207` and
`normalization-shortcut-proof.md:74-79,124-128` give the correct degrees but
delegate the edge-level identification. A no-leaps paper must state which
two vertices are deleted, which ordered root sees both, which sees only
the first, and why the retained root edge has one common old neighbor.

**Severity:** missing explicit transfer detail, repaired in the supplied
`ext:ordered-tips` and `ext:grouped-tips`. Independent literal tests verify
all 101 bounded both-private tips, 240 mixed examples, 96 unary examples
and 1184 double-parent examples. The universal proof is the neighbor/path
description, not extrapolation from those tests.

For a unary E child on (a,c), the inner q-fan has apex c on edge (d,c)
and outer arc d,Q1,...,Qq,c. The tip is Q_(q-1),Q_q with retained root
Q_(q-2). For the right inner fan on (c,e), it is R1,R2 with retained
root R3. Reversing these choices without also reversing the fan's root
orientation can give a degree-two proposed root; the supplied proof
keeps the actual orientation.

### E-05. Counter-occurrence elimination is the actual sufficient premise

**Locations:** `parent-extraction-proof.md:78-82` states a sufficient
stronger all-old increment route; `global-proof.md:179-184,238-245` uses
the weaker but sufficient C0/fan19 counter-occurrence route for some unary
lengths. This is legitimate: the retained graph after a C0 deletion has
order n-2>=70, and after the fan19 removal it contains the old H>=8.
Minimality supplies the required energy there.

**Severity:** no contradiction found. The paper must preserve the exact
scope and must not silently promote this to a universal all-q full unary
increment at every arbitrary old H. The supplied last paragraph explicitly
preserves that distinction.

## Positive all-order checks

1. A root at a weak-dual leaf has at most one child. A deepest branching
   face therefore is not the root and has a parent. If its sibling contains
   a branch below a unary node, that branch would have greater depth. Thus
   the sibling is either an unbranched path or branches immediately. This
   proves the three-form tree trichotomy for all depths.
2. All cap boundaries are chord-side polygon arcs. Chord separation proves
   the old remainder is induced and triangulated (or K2), with no outside
   private contacts. Neither vertex/edge counts nor an abstract tree
   isomorphism alone is used for this conclusion.
3. For h2..7, the cycle-uncovered interval after adjacent roots has length
   at most three. Its cycle midpoint, plus the roots, dominates every old
   graph. Each grouped parent's new vertices are dominated by the roots
   and its one private parent c. The whole graph has gamma<=4; no false
   induction inequality on h<8 and no K2 increment is used.
4. The private large both-apex energy formula is correct: interlacing gives
   F(B)>=rho(B)^2+F(L)-rho(L)^2, uniform compression gives
   rho(B)>=h+sqrt(d+h^2), and rho(L)^2<4. At d16 the strict rational lower
   G16>345/128 leaves surplus89/128 above2(d+1). This uses the actual
   private join and not minimality on that non-MOP join.
5. The bowtie algebra is correct under the stated complete positive-mode
   filter. Its five eigenvalues, contact weights and exact score simplify
   to59/8+(47/68)sqrt17-sqrt2/8>10.04. Validation of that filter remains
   with the independent phase review, not this geometric review.
6. The inspected selected-hub gamma3/4 proof chain is formulated using
   chosen dominating sets, original path forests and independent spectral
   bounds. No terminal-path or deepest-parent lemma was found among its
   stated premises. This supports structural noncircularity; it does not
   constitute a fresh verification of the historical millions-case runs.

## Independent executable calibration

Run from the workspace root with Python3, standard library only:

    python -B -X utf8 work/mop-independent-review-20261108/extraction_geometry_checks.py

The accepted result is `extraction_geometry_checks.json`. It checks:

- Every convex-polygon triangulation n3..11: 6917 distinct edge sets, with
  independently checked Catalan cardinalities by order.
- 59279 chord-side closed caps; 3651 first-turn signatures; 10710
  nonstraight terminal caps containing an actual first turn.
- Actual leaf-rooted dual trees: 4379 U,1234 EP,24 EE chosen deepest parents.
- 1600 explicitly built four-apex caps;101 both-private C0 tips;
  240 mixed C0 tips;400 actual retained-degree-three mixed graphs.
- Every 65 old K2/MOP graph of order2..7 grafted with1040 U,8320 EP and
  16640 EE examples: anchored whole domination at most four.
- 96 unary and1184 double actual C0 tips, including literal contacts,
  retained degrees and exactly one common old root neighbor.

These are finite calibration checks and cannot prove unbounded structural
or numerical assertions by themselves. The all-order arguments appear in
the LaTeX section.

## A concrete negative control, not an error in the original proof

An initial reviewer implementation chose the midpoint of the graph's
currently undominated vertices instead of the midpoint of the original
cycle interval. That alternative rule is false. For the seven-cycle with
diagonals13,16,36,35 and roots0,6, the actual remaining undominated set is
{2,4}; selecting4 leaves2 undominated. The correct cycle interval is
{2,3,4}, whose midpoint3 dominates both ends. The original written source
`parent-extraction-proof.md:45-51` correctly uses the cycle interval.
The independent checker was corrected before its accepted run. This
negative control must not be reported as a counterexample to the stated
anchored-domination theorem or the energy conjecture.

## Submission boundary

The supplied extraction section is complete at its explicitly declared
energy-input boundary. A submission-ready unconditional paper still must
include the analytic proofs and standalone exact verifiers/data for those
inputs, especially the positive-mode/rootball bridge and the finite base
and gamma4 certificates. No submission-ready or global-validity approval
is inferred solely from this component passing.


## Follow-up: complete domination appendix

`gamma_section.tex` expands the domination-at-most-four input in English, without repeating the theorem label. It supplies residual pinching, uniform/weighted/three-dimensional spectral estimates, normalized minimum dominating sets, component-deficit and priority-assignment budgets, all ownership/path/run caps, rational-vector common-core coupling, the whole-hub fallback, and both unbounded tails. It states the exact finite domains, exceptional-carrier coverage, square-root rounding, integer Gram and minor calculations, candidate enumeration and orbit identity rule. The connected-graph theorem remains explicitly cited to Liu–Tang–Zhang, Theorem 1.2; the order8..71 basis remains the root paper's separate input. No extraction argument is used to prove either.

A fresh standalone stdlib reader `extraction_gamma3_verify.py` covers all 3,795,253 positive allocations in orders72..104 with a certified excess at least200606059/5000000000. It does not import the historical8..71 or gamma4 energy implementations. `extraction_gamma_tail_checks.py` checks the6 and33 exact constants in the A/B infinite-tail proofs and the threshold31301/196. Both executions finished with exit code0. These checks certify their displayed scalar domains, not the entire global paper.

The new aggregate replay also explicitly checks that the freshly discovered A/B residual shape sets equal the respective initial-screen shape sets (21 and62). Exact historical locations are `verify_tighter_split_fan_charge_190.py:54–62`, `verify_tighter_charge_small_190.py:28–38`, `verify_nonlinear_split_fan_190.py:43–51`, and `verify_nonlinear_small_190.py:13–20`. This is a transparent extra linkage guard, **not an established old soundness counterexample**: the old main reader's requirement for at least one carrier at each residual shape, together with the small reader's full record-set equality and complete cell counts, already implies the needed carrier coverage. The direct equality makes that implication inspectable.

The full final assembly was appended to `extraction_section.tex`: every unary, fan-sibling and double-E parameter range is explicitly exhausted against minimality. Its external cross-references are `thm:b71`, `thm:gamma4`, `lem:c0`, `prop:local-payments`, and `thm:main`. All energy uses now share the root paper's macro\F. Sources in this review and historical certificates were left unchanged.


Assertion hardening: both new gamma readers explicitly raise RuntimeError under python -O before any certificate work. The two optimized negative controls both exited1 with that message; normal fresh replays both exited0, with all3,795,253 allocations and the same margins. Mathematical loops were unchanged. Current source hashes are retained in the result JSON files.
