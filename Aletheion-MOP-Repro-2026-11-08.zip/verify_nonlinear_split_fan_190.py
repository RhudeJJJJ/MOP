"""Exact finite base for a nonlinear q/p charge; stars handled exactly."""
from pathlib import Path
from fractions import Fraction as F
import json
from verify_tighter_split_fan_charge_190 import sqrt_lo,sqrt_hi
ROOT=Path(__file__).resolve().parent

def main():
    from verify_tighter_charge_small_190 import score
    path=ROOT/'nonlinear-charge-190-small-certificate.json'
    certificate=json.loads(path.read_text()) if path.exists() else {'records':[],'denominator':65536}
    rows=[];weighted=[];triples=[];small=[];failures=[];shapes=0;stars=0
    for q in range(1,100):
        for p in range(1,q+1):
            m=q-p;gaps=[]
            if not m:
                stars+=1;shapes+=1;rows.append({'q':q,'p':p,'minimum_margin':'0','exact_star':True});continue
            target=2*q-p+2*sqrt_hi(F(q))-2*sqrt_lo(F(p))-F(m,4*q)
            for s in range(1,min(p,m)+1):
                shapes+=1;l=m-s+2
                radius=(F(0),F(1),F(2),F(8,3),F(3))[l-1] if l<=5 else F(4)-F(16,(l+1)**2)
                d2=4*m-2*s;loss=min(radius,F(2*d2,q)-F(4*m*m,q*q))
                lower=max(F(q),F(q+m)-loss+F(2*m*m,q*q)+F(2*m,q*q)*sqrt_lo(F(q**3+m*m)))
                if lower<=target:
                    required=target-m+radius;R=sqrt_hi(required)+F(1,10**6)
                    d3=4*m-4*s+max(0,2*s-m);success=False
                    for t in (F(1,2),F(1,3),F(1,4),F(1,8),F(1,16),F(1,32),F(1),F(2),F(1,64),F(3,4),F(3,2)):
                        hub=(q+2*t*m)/R
                        form=2*hub*(q+2*t*m)+2*m+2*t*d2+2*t*t*d3
                        norm=hub*hub+q+4*t*m+t*t*d2
                        if form>R*norm:
                            lower=R*R+m-radius;success=True
                            weighted.append({'q':q,'p':p,'s':s,'R':str(R),'t':str(t)});break
                    if not success:
                        N=m+s;n0=p-s;a=F(2*m,N)
                        loss=min(radius,F(2*d2,N)-a*a)
                        H=2*q+a*a+m-loss-target
                        if H>0:
                            R=sqrt_lo(H)
                            if R**3+a*R**2-q*R-a*n0>0:
                                lower=2*q+a*a-R*R+m-loss;success=True
                                triples.append({'q':q,'p':p,'s':s,'R':str(R)})
                    if not success:
                        cases=[r for r in certificate['records'] if (r['q'],r['p'],r['s'])==(q,p,s)]
                        if cases:
                            lower=min(score(r,certificate['denominator'])[1] for r in cases)
                            success=lower>target
                            if success:small.append({'q':q,'p':p,'s':s,'carriers':len(cases)})
                    if not success:failures.append({'q':q,'p':p,'s':s,'gap':str(lower-target)})
                if lower>target:gaps.append(lower-target)
            if len(gaps)==min(p,m):rows.append({'q':q,'p':p,'minimum_margin':str(min(gaps)),'exact_star':False})
    out={'status':'PASS_NONLINEAR_SPLIT_FAN_FINITE_BASE' if not failures else 'OPEN_NONLINEAR_SUFFICIENT_BASE',
      'q_range':[1,99],'cells':len(rows),'shape_cells':shapes,'exact_stars':stars,
      'weighted_witnesses':weighted,'three_dimensional_witnesses':triples,'finite_psd_shapes':small,
      'failures':failures,'rows':rows,'original':'GLOBAL OPEN',
      'scope':'Exact finite source expressions and shape bounds; nonstar strict, stars equal; analytic tail still required'}
    (ROOT/'nonlinear-charge-190-verification.json').write_text(json.dumps(out,indent=2)+'\n')
    print('NONLINEAR_BASE190',out['status'],len(rows),shapes,len(weighted),len(triples),len(failures),failures[:4],flush=True)
if __name__=='__main__':main()
