# Independent reproduction and submission audit, 8 November 2026

Scope: independent executable-input and proof-dependency audit of the claimed theorem for every finite simple unit maximal outerplanar graph, order at least8, splus>=2n. The root and other reviewers own geometric extraction and the rootball/phase argument. This report distinguishes defects in a completion predicate, missing portable dependencies, and incomplete independent re-execution from a mathematical counterexample. No energy counterexample was found here. Original accepted files were not edited.

## R1 — historical global gate is not a standalone mathematical verifier

Type: confirmed portability defect, not theorem refutation.

Location: `work/mop-global-input-audit-20261108/read_global_completion_inputs.py:11-20` traverses original absolute source maps; line27 checks acceptance receipts; line40 opens `file:C:/Users/jonas/Aletheion/aletheion/aletheion.db?mode=ro`.

Control: `repro_test_isolation.py` copies the exact old checker and its first source manifest into an isolated fixture. An audit hook rejects paths outside the fixture/runtime and database connections. Actual execution rejects the original-machine path to `mop-finite-assembly-20261108/finite-assembly-proof.md`; it cannot serve as an extracted submission verifier. This audit hook is an access diagnostic, not a claimed security sandbox. The original global checker itself explicitly says byte/status checks do not prove geometry or truth (line56).

Repair: new replay drivers resolve all mathematical inputs relative to their extracted root, never open SQLite, and never consult native receipt tables. Historical source maps remain provenance data only.

## R2 — selected36 grammar replay is not numerical compact replay

Type: exact scope limitation, explicitly acknowledged by the original reader.

Locations: `work/mop-double-eigen-tail-20261108/read_selected36.py:35` defines `zero=lambda*args:dict(upper=F(0))`; lines43 and46 traverse grammar with the dummy bound; line51 sums retained numerical areas. Lines26-29 and52 require the earlier execution observation. Line58 explicitly describes reused numerical areas and fresh signed tails. This is not evidence that the old authors concealed the distinction.

Consequence: a later successful selected36 read is not an independent re-evaluation of 284,102 numerical leaves. All3,584 tail intervals and28 final conditional inequalities are a different, freshly executable part.

Repair: `repro_verify_core.py double-compact` calls the real reciprocal/fixed numerical bounds for all36 slabs, including slab23 instead of reusing its preflight area. `double-tail --compact ...` accepts only that driver's full36 output. Separate subprocesses preserve rational-grid96 for compact and the original default192 interval backend for selected tails. `--smoke` performs eight real leaves and makes no full-family claim. This review completed the smoke and full signed-tail arithmetic, not the multi-hour complete compact rerun.

## R3 — finite completion predicate accepts missing parent evidence

Type: confirmed checker completeness flaw. Not a missing-parent allegation about the original completed mathematical sources.

Locations: `work/mop-finite-assembly-20261108/read_finite_assembly.py:37` says `if not path.exists():parents[folder]='PENDING_NATIVE_READBACK';continue`. Line90 selects `PASS_FRESH_COMPLETE_ORIGINAL_UNIT_MOP_FINITE_COVER_8_TO71` using only `mask_complete`; the four parent entries never gate the complete conclusion.

Actual countercontrol: `repro_finite_gate_counter.json` records the unchanged reader returning exit0 and its full finite PASS, all11,885 rows and29 orders, while **all four** parent entries equal `PENDING_NATIVE_READBACK`. `repro_finite_input_discovery.json` retains actual stdout/stderr and the18 individually copied runtime files needed to reach that predicate. The original four accepted parents did exist and had their completed proofs; this controlled omission shows that the gate does not establish their presence. It does not disprove B71.

Affected stored claim boundary: `math:mop:fresh-finite71:payment:20261108`, and the B71 input in `work/mop-global-closure-20261108/global-proof.md:35-51`. The successor must retain the mathematical theorem and original completed parents while correcting what this particular checker alone establishes. Native Aletheion corrections are owned by the root reviewer.

Repair: `repro_verify_finite.py:115-162` requires the five freshly computed mathematical result inputs (positive328, masked130, degree29, B42, high pairs/classes), checks their domains/payments, and evaluates the complete11,885-row scalar cover directly. It neither calls the old main nor depends on native PASSs. All five single-required-input omissions now reject (`repro_omission_all.json`), as does an altered actual positive maximum (`repro_bad_result_control.json`). The assembly stage is conditional on these five mathematical output files. The combined `repro_replay_b71.py` refuses old output directories and executes the entire fresh calculation sequence before calling that composition; this supplies a full entrypoint without treating supplied review outputs or JSON mode strings as proof of a new DP execution.

## R4 — declared source inventories omit transitive mathematical inputs

Type: standalone packaging omissions, not an independent refutation of the underlying lemmas.

Locations/examples:

- The global gate's13 declared inventory groups (`read_global_completion_inputs.py:11-13`) do not by themselves produce a closed executable distribution. The initial global inventory had409 unique source paths. Explicit TypeB8 additions alone were still insufficient.
- `work/mop-serial-turns-20261105/turn_metric_interval.py:6-8` imports sibling `mop-negative-modes-20261105/homotopy_interval.py` and `certify_full_cap_phase.py`; further helpers are needed. Import-only closure discovered28 previously unlisted local files.
- The finite reader opens additional generated scalar/DP records beyond those inventories. Actual isolated discovery added18 files, individually, without importing a database or recursively copying an old archive.
- The tighter/nonlinear190 finite bases require their four original validators and four certificate/screen JSONs. Those eight files were absent from the earlier747-member candidate. They are now included, freshly replayed, and explicitly linked by residual shape sets21/62. Their paired original full-cell and small readers already imply coverage; the new direct equality is a transparent strengthening, **not** a claimed newly discovered soundness hole.
- The bare-branch184/157 debt uses `mop-quantitative-trace-20261105/read_quantitative.py`, actual floor/resolvent polynomials, all288 jets, all256 scalar tail cells, and rigidity controls. Its21 explicitly declared sources were missing from the first candidate. The independent normalized-sign input additionally needs144 matrix jets and their original reader/helpers, not only its proof text. Nine further original files were added from that input's explicit manifest. The phase reviewer owns the detailed logical need for the imaginary sign.

The portable distribution now conservatively retains these exact sources and the full finite-parent manifests. Path equality, not title equality or a PASS label, is the unit for an archive member; SHA256 distinguishes byte versions. Distinct necessary import paths are retained even when their helper bytes agree. No database, earlier complete ZIP, native-export folder recursion, or existing fullarchive recursion was used.

## R5 — old global synopsis is not itself a no-leap submission paper

Type: expository/proof-dependency incompleteness of that file as a standalone paper.

`work/mop-global-closure-20261108/global-proof.md` is277 lines and refers to separate complete B71, gamma<=4, C0, parent-payment, normalization and compact-family proofs. Its35-77 input paragraphs and204-233 double-middle composition cannot replace those arguments. A submission must state and prove the published-input reductions, unit/outerplane domains, actual root degrees, coherent reflection rule, endpoint/lossless boundary, phase lift, infinite residue grammar and tail estimates, and complete parent-role partition. The root reviewer is integrating those proofs and the independent reproduction section; a content manifest or run receipt would not supply them.

## Completed fresh work and limits

The root review identified that an `assert __debug__` guard itself disappears under optimized Python. Six newly authored replay/integrity/packaging drivers now explicitly execute `if not __debug__: raise RuntimeError(...)` before any computation; `repro_optimization_negative_control.json` records all six `-O` invocations returning nonzero. Original frozen validators remain unchanged and require the documented nonoptimized interpreter. This is fail-closed hardening of the new wrappers, not a mathematical counterexample under the normal documented commands.

Completed against explicitly materialized copied inputs: complete C0 (2,304 node envelopes); B42 (6,853 base graphs,61 small-gap graphs,4,636 scalar rows); all29 degree envelopes;4,760 high-pair kernels and54,870 exterior-ear checks;1,150 cap complements; all328 positive DP targets; both190 finite bases with their exceptional forest readers and explicit residual linkage; normalized sign144jets/924PSD coefficient checks; all286,769 coupled gamma4 profiles with small Gram witness and literal table rebuild. Actual runtimes and process exits are retained.

Also completed: private smoke24+60 real leaves, double smoke8 real leaves, and all3,584 double signed-tail intervals/28 conditional budgets. These last tail conclusions are explicitly conditional on compact input when no fresh compact result is supplied. There is **no new complete private/double compact re-evaluation** in this review; the unchanged original sources and source-bound completions remain provided, with real full replay commands.

All eight named family readers and the removed-run n4..9 graph-domain calibration have now completed with exit0. Seven saved family result objects agree with originals in every field except explicitly removed runtimes and source-location fields (`repro_family_comparison.json`). This includes complete serial74,725-leaf, singular10,139-cell and both mixed full-domain exact checks; quantitative trace rebuilt all actual polynomials/288jets/256tail cells. The removed-run finite calibration supplements the written all-order proof; it is not itself an infinite enumeration.

The full masked130 DP completed with exit0 in2331.39s, all29groups freshly computed (including31/31), below the5400s cap. The guarded new finite assembler then completed with exit0 in4.98s using only the new mathematical input results. All11,885 high-degree rows,29 low-degree orders,328 positive and130 masked targets were used, with zero vacuous masked classes. The seven rule counts are527 single-gap,2201 balanced-block,3718 whole-moment,4049 coarse-residual,932 rho0,328 fresh-positive and130 masked.

The executed masked and bounded-runner variants are preserved, together with exact postguard diffs and AST equivalence checks in `repro_live_source_evidence`. The actual running masked file remained preguard until terminal; only then was the guarded file installed in the bundle. No mathematical DP function or frozen kernel/target changed. The whole earlier positive-launcher source hash was not captured before unrelated modes were added; no unsupported whole-file identity is asserted. The final index distinguishes fresh component executions, the provided combined fresh launcher, original source-bound slow compact completions, and smoke controls.
