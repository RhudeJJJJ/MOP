Positive square energy of maximal outerplanar graphs
Author: Jonas J. Gebendorfer
Manuscript date: 8 November 2026

The main source is positive_square_energy_mop.tex. Preserve the sections/
directory. There is no external bibliography file, external figure file,
database or network service needed by the manuscript itself.

The manuscript was built with Tectonic 0.17.0, AMSart and the standard
packages declared in its preamble. A complete local TeX installation can
build it with its usual LaTeX workflow. With Tectonic installed:

    tectonic --keep-logs positive_square_energy_mop.tex

Tectonic may download its TeX package bundle on its first invocation.
The actual build log and validation metadata are supplied with the review
artifacts; the PDF is also delivered directly.

The separate proof supplement contains every indexed source, finite witness,
partition and replay driver required by the computer-assisted assertions.
Read its README.md and REPRO_MEMBERS.json before running the commands.
Use ordinary nonoptimized Python with assertions enabled. Mathematical
verification requires the stated readers and their full domains; integrity
checks or stored PASS labels alone do not establish a theorem.

The manuscript and review distinguish fresh independent mathematical
derivations, new independent graph controls, re-executions of the original
exact arithmetic kernels, and explicitly reused full original compact
certificate proofs. No independent human peer review, proof-assistant
formalization of this manuscript, external submission, or priority claim
is represented by these artifacts.

